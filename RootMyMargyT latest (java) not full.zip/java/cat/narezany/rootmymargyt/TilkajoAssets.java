package cat.narezany.rootmymargyt;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.util.Base64;

/**
 * TilkajoAssets — HD текстуры пушистого Тилкайо для Режима Тилкайо и Защиты MargyT.
 */
public final class TilkajoAssets {
    private static Bitmap bgBitmap;
    private static Bitmap iconBitmap;
    private static Bitmap circleIconBitmap;

    public static final String TILKAJO_BG_B64 = 
        "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAYEBAUEBAYFBQUGBgYHCQ4JCQgICRINDQoOFRIWFhUSFBQXGiEcFxgfGRQUHScdHyIjJSUlFhwpLCgkKyEkJST/" +
        "2wBDAQYGBgkICREJCREkGBQYJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCT/wAARCAEUAWgDASIAAhEBAxEB/8QA" +
        "HwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkK" +
        "FhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXG" +
        "x8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAEC" +
        "AxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOE" +
        "hYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwDxK5g53mkh" +
        "nwu30qzIDKhWq32cp3zWKZ3tCNGZOe1R+SSamyVFOgG9zmhsaRZTAUDPQUj8mmPIFbaCM1FJNtOCRUMq4SS+XmsjU/3g3jt6Vav7gBDtx9azmlZxwM1pFGU9" +
        "SmrZPJqdHCc5qrICjc0/d8mSa0Rz7FhrocYqeK5LL2rLMnzVdtDuj6d6pMBbomQ5NOs1+YevFOkQetMibY/tQ9hp6nWaZcb4ApPIqzNMq55Fc9a3RBypHFWJ" +
        "Lpyc5FYWOlS0LE92Nx5quLwd8/hVC61KFN2SCw96oDVctwOKozcjZmn8w8GolvjbJt34zWRNeXDkGINj6Un2K/vAHKnFVZk3LtzfqMsXzVCXU2b7tWodBuJF" +
        "JfI/Dk0DSgpK+WTinYhtszWu5pDgH8qfFY3Fyfmzj1rUi0xEYMQAfpWhGixrgUNiSM238PjgtzWgmkwogGP0q0s2QBinhsip3LsU4tOiVtwWrPkRgYCDFTpH" +
        "x0pGUetNIClcWkciEFBjFc3PYrvYLxzXWEAg81hXS/vmq7EyMZrUq2OtXLCxWRst0FK2A3NXtOAOccUEJEy2VuBwKjmkjtcBQBmrRTBrM1VsMvNIou2+ZipH" +
        "eti3tyGU1z1lfxoEU9a6SO4DRK6HrUsuBcG7IA6VabEKAnms2K5J6tTpbgsuN1SaXIb29YsVX8azTDvYn1q3Id7HioxweKq5O5Np9qpkAYn3rYuUhjhKoRuP" +
        "aqFsNi7qURSTzAgnFTuUNEZHp+VSrIUNXVt0UYYge5qpqLQw42kE1VrEtiXJ8yPjpRVF7xiNo4FFVcVhpu3U8AUJMZWxTJo+4pbZgjZbpXOjdk7R4HOMVDNc" +
        "x20ZbPINOvb2NEG1hmucvb953Ze2aaVyXIvLqMkjnaAean8qW5G5jiqmmIoi3nk5q75zAcYAqrCTuLHYA8yHdUrRQwDJUVXaVscMfwqCWc8bmz+NMlso6vs8" +
        "zemcGs7cScVq3EYnjIrMaPa3WrRgwVMkZrVhjEcQ2/Ws2Me9aKuBEAOeKpILjGY0wtxTXfk8Gm5zTE2NN1JbnK96YNQmZ9ozyaWRM1PplgZrjfgYHAqWilJi" +
        "/wBkTTfOx681esdFjdxuzxWn5QVQB2qxZQqmH5yakuzHJZQRAKEGBV6PykiwFUAe1VpmUHrUTXe0bQOtUhNErXAO5QAPwqbw/wCHL3xLqiWFkq73y7O7bVRB" +
        "1YntgVTQhiCK9b8IW8el+B98Tbn1CVpWbbhgg4C569c8fSorT5I3Kpx5pWE07wR8PtGVrXVZL/Wbhlz5sREUY9lHU/U1Y1T4R+F/E1tHJ4Wv5rC9CYFtdEMk" +
        "h7Dd/CfrxWVdWt1FGlw8LRRsSFfHb35qvZ6yllJmSZzzx5S4IP515ntpvW56HsI2PPdX0LUNAvpbLU7SW2niYqyuuOnoe4qgZth9q+iPEujW/wAUvBrSJKH1" +
        "fToWmt3TJMq45jb16cd6+bJmYEhgQRwR6Gu+jV50cFSDiy8uoqPlwaDOHOe1Zatk9asxuOma6DMsSy7FyB1rKlUsxJ71fuSBHkGs55cdaAKUzBXxWhalEjBB" +
        "5NZN62JOKsW84EYOe3FAkaTz7QWPQVi3t01w5J6DpVp3e4+VeKrNZlTy2RSBlZW5rrtPctZr1Jq58Ofh3H4r1Fp9Tlmt9Lg5YxY3zH+6uf1Neh/FPwDovhXS" +
        "NK1jw5BdR6fd5SVZXDLC4xhd3XJ61lKavZGkIu1zzpWKDFK7/LTEkD9KV0yfamUVxIS+Ktww55qJoVXkGpoZSB0oCxaUiNcVJHOqHIqAMHFNlAVc9MUxXJbv" +
        "UFjQ7uTjisSS4kncs2aZd3BkkIB6GkhbbTE2WFUnrRTFEs5wnGKKdgufRuj/ALN9tJEj6leSbiOVXoKt6v8As16K1q32G7milAyOev1r2T7RG3C8UjPz1r4G" +
        "eZYhPm5iuY+FfGngnWfDOpT21xbzGGNuJdvBFcZJbyRyFvfqK/QPxD4a0/xHYz2t3bRv5qldxHIr5H+JfwwvvBF87lS9m7fK/p7V9DlmbQxC5J6SM5Hn1tcN" +
        "EoWrJu2PTFVpEAJxxzTfN2CvccSVOxbFyx4NMbcx65FUmuvmqQXhA+UfnQkPmuXUVQPmIrMvHAc7TQ96544qu7Fzk00SxglYHqa0IJMoMms3nHSrED44zVpi" +
        "Lk2OoqJW561Pb20t2wVFJ5wTW3beGjHiSVsjHQigLXMRYXk6KT+Fbml2nkW4JHzGrqQwwJtCrxULXG1tqjIqZM0grE6x7j04oeVYFwDjHaq01y4TCYBNZssk" +
        "0jkE5zWZq2X3ulJzuNQmcMeopnl7YwT1xUUa4fJq0ZM0Ipjt6k+le16fPNL4T0VpEXynt8lvXDEA+vavEYpUHpmvYNC1K4v/AANZXE52/Yma3TgfMAcgnj3/" +
        "AErmxv8ADOjDfGXEtobm2dW3sRnaAxz/APXrh9Xhms5GWVTjORxj9K6mw1BEumDEI+Omaj8S2X9pW29GBfsRXmRPRexZ+EutCz1JbpZWYxOFeFMjKE9SOlcr" +
        "8ePCEfhfxg91ZRKmnamDcwhBhVbPzL+Zz9DWr8P9Ant9RM8WTKMj5JcSA+jJ0Kn65Feq+OPCy/EXwI9rInl31uvnWxYfMsijlT9Rx+Vb06vs5HLVhzI+SxUs" +
        "WTTXieGRo5FKspKkHsaWNsGvWWquefaxLKCwxmqjWoY9SDVqVsAc9aiL4NAjOutOc/MvPrUNvC2drHGDWs7gofWs2Q7JOKYF2NFjTgVNpmlTazqcNpCCN5+Z" +
        "scKvc1WjlBTrXpHgmyhs7FY5rV2uJmzI6AFlU9F/kayqT5Y3Lpw5nY9C8D2VpAbfTLaVQVAxEeN34/n9a3fjVpFkfhNIsiK5tbxDGFk24cg5PHX6d6Tw5ZTw" +
        "7ZYpY7hiQImEe0qAMDPtUf7QG+z+H9lbsziWe98wLEuQQF7nsK86nO80ds42ifNtrKLVCHPfjmrC3IkIINULg7lKimQK8IJJODXpWOJSNSSX3p0c4xjFUFnL" +
        "deas265bJpDbNASBUzVW9vSkRCjJPFT5UAAkUpto35IzVAYUcU0zFiKtwWxyARnNXZ0EK8DANNswzSbiOKpJEst28flYygFFWRhqKsR9h/bf7rVYiuWNYMU+" +
        "QGB4q5FckV+XzXQdzZE4Vdx5rzL456Tea74VkFnFveMbiAOa79J9wGaS6Eb2squoKlTkH6VOHqOlUUkD1Pgi7iaJmRwVdTgg9Qao+ZyQa6r4mRpaeLL+KJQq" +
        "7ycAYrjTIc9K/S6FT2kFIxZLJjqKjEmOKCxP0pgGc1qFwLFjS80AYNSAr6UAR/N7U+NWZ1VQSxOKdx6VJCCsileueKBo7PRrRbS3V2QbiOtW5r1eQ5AxWXZ3" +
        "U2xVboB3pLkvM2f0FK5oiwd1wxEZ4qGUrbr8/JpbdZoV9M0XESumXznNSykVmulx0/WombdhgKk8iNecfnRgDpQkDYxdzcMaUBcdaGIQZ6VHGGkbiqsSxCWV" +
        "sLXp3w31b7V4d1DSnY+ZA63EeRwFPykfnivOhGBwetdb8NtUt9N8RJDcO6w3qG3k/ugN0J+hwaxxEeaBrRlyzRs6vcrZTsVUH+JT7VNaXz3W0M2Ae5NN8S2W" +
        "xLm2PzzWzkE+3Y+4xXJ6dqhhkELSBADwSeleYkejzHpel3VpaX8Vwlkk8uQpyrYPPUEcg1674dl2CXzHYMrqTnnr74ryPwrdy27w3P8AaIlRwCsayhCw9MEZ" +
        "r1LTJ5ZdTh81HVZF34mOG49COD/Os6i0GrHg3x58FL4a8THUrVCtpqJaXAHCPn5gPxOfxry9ck19e/E7wxH4w8HX8XliS5t/38IPXKjp+I/lXyLJA1u7RsMM" +
        "pwR6GvQwdTmjbqcGIp8ruhW6DmmEA96YSTTCxBxXacwyVinQ1SlclutW5DnvVU27TSrGnLMcAe9JuwWOi8I6PHqHm3Nzu8uIqEUf8tGOePywa9o8NaPcGCMy" +
        "BWQsHCoFDn161xXhzTPssdoiZSJcs7MOMhcsfw4r1bwjocDypPOheR8eWvRn4zux2Fedial9Dvw8Elc7jRtKtpXjLqyIOBtPHT2rG+Pcltb+F4IJdVtrE7GC" +
        "xMgaSbI+6ufuj1Nd7oNgqsGkADJ/DnivFP2nZTJc2oEbzjYQhVlCxgZyTzuz+nSssOryuFd9D57kTB4BA7ZOafGNwwRTATg55qSM8V6zOFhMqRqCABRFOCMI" +
        "1VtSkIUAdDTNPcPlTjIqWO5oBmZxzWnG3yfhWaBtXIHNOimYNyTVJgWpgWPJ4pYn2ptFRmRXOOKQHa3FWhFyKRsgE0VGjgc0UxH1BpGp/ao+MDA4GK1Emaue" +
        "0m7gWEbF/Kte3vomYK3Ga/NqtPVgaUNywOaszT7raTsdh/lVEOnGCKkcsYJMc/Kf5VzJalHxv8VnP/CZX3uxrjRXWfEtpLjxjegphg5XFYkeizvgkYzX6PhN" +
        "KMfQzaKOOKRRxXQ2ugqw+frWpb6Fa8ZUZrpuLlZx8dtNKQEjY56GrMmkXMQBYcGuye3gskGxF3DpxzWbeXXmttP5UFKBh2ulSTOATit230aO3CttBIqextRG" +
        "m89TzzUks4VSFpNjsMyo4IqaEp/drOeYk5JqSOYjvSKLsz1C7hlPFB3OuQD6U60066urmOERlBISAzccjqOahyS3GotmfLKCeKiZ27ZruV+FWuPbxSxWjyRz" +
        "EfvUXOz6ij/hWWtafdtDd2Fw8eCGATGQRwyms/rFPuaewn2OGCu6nqcVYRfLhV1+6eM+9em6P8JZVuIpSk09rJ9/bgSQjOCSP89K1NZ+ElrYTQJb3cFxZsrL" +
        "cMrYlHo+PUVDxlO9rl/VZs8baQ7utPjl2sGBwRzn0r0+2+C76lbFrC+tmaJygdj/AK5eo4HerGrfs/6vBFbvYyLJlCZec4Oe34UPF03o2L6tNajlE/ibwbba" +
        "02GuLcvBMvIeZVA+b3O09favLdXgex1D7wETnejt0xXqUuiar4K8I2lvN5sF0uoNIrsOMEAdO461xvjKzh1CH7ZBGIw5yUT/AJYyeg/2TjI/LtXMnFy02Oh3" +
        "SVzc+Ht1cS3Qlil2R8DcUKrn0OATXrTuY7uzutx3qwLGKdiBj/ZYDP8APpXhfw7vbu5uhDFIqyjBKyXOxgPXjn+dezXV3KNOTdiN4CPnYE/m3f61nWi0VTke" +
        "i210j3ckYaJlZFOBgZBz2/OvnT4i/C+8h8TajJp0P+jsftCED5cE8jP417jY3SyzhsfvCBllb2zyPXr+VN8WxD/Rb1Lkxea3kKuPvHqPp3rlpVnSldGkqSmr" +
        "M+V7jwdqcMm2S3YdSpH8WPSri/DnVJ9OmvlTMUSF+vUD/wCsc/hXqeqaBLcQPqrN5qFSQqDBDg/wj61BoGrvZTS2zIwgLlFA77u5B7Y4r0Prt1dGH1RXPCLr" +
        "Trm2fDxOAxIXj7w45/UV1ejeHbW0soNQlfdNLkxp3H1+hH616/c+FrW6My31pF5Uv+qnVQfl64Pp0/SuW8S+E5dJaKWCNjGo3gbeCuMnH+e1H1xPQPqvK79C" +
        "npf+jQoZB5js3yRHovct/Lj616j4NffEJJA8iyAqpAwGPZfU47mvJ9AuDc3OySQo2dq7Vyc9/pXsXg9RcrFP8wAGyNM4VFHHTua5Ksu50RSSsekWLyWOnTTP" +
        "hnUcBeBnHQZr49+LWr3OreL7me80+WwmVyvlyzmRz/tYzhQewA7V9jXcVw2gSx2/lrKYzt3rkD8MiviD4jyLa+Jrq0aIpMjkyvhRvY98L0/OunBI4a7uzD84" +
        "A04TqMYNZzSHOQeKBcBSM16Rylq8beuRUVjvjl39qdvWRaswxgpkDmgC5vDrlTn0qJ2ZG5PFQiUwk9cVKZEnjJzzSLuIbsL93BNWLSRpm+btVFYNzdeK0LcC" +
        "MfLVRFYtScKMdaKjDnPNFXcVj27T9YECKMtnuDW7aamXKnGfrV7xD4IieVriz/d55IrA+zXOngKQGx618HKUJq6Bqx19pctJweBitqxmVgEb864jTdWkzhl7" +
        "+lbq6qtvbSzkgbFJ5rjlTfNZAeJfGzRrG08Um5t1QSSDLAetcBHWx4317+2PENzPvLqWIGaxY5VHU193goyjRipAW4TtqR5mT7vFZ7TSMSI849qaWlUEZIrq" +
        "AfNeszHJBqirmS4B680rBiSTTbLH2kdKYG27MIQoqlKG9aul1b+ID60+LTbi4mRVQ/PypAJDewI7+1S3ZDUTHKsxwvP86v6Tp0uqSm1iRxOSAuVJH04r0jwn" +
        "8K4dfD3M08lvGpx+8j2sh9ODmvSND0vRvC87LBaiV2ABneQDOO4zyPwrhq4yMFpuddPCya1OT8E+Al04xx65DP5MuAY2UMvHX3xXfTeH/C0aOo0qGSJQp3Ho" +
        "p7ZB71xniT4gAGSzsGaExnmeNScn0FSeG/sOq2SXF79tcE8G7O1HY+gz/OvNnOcvebO6FOK6HoGhNNZq0FvbLHak5QJJux74P8s1XvYNStr4XCauhRh88ZA5" +
        "HpivPNXe8/tT7PZQ6pbJt3JHApfI/vZBx61uWeleINPtyZpmuWIyh2K7KD6jr+prmlG2tzaK1NKY322S4s5IrqWMEgrCUdOeVIPUGqty8WsWqosNo075D4Vk" +
        "aMnqDjn0OcEVJpcd5qFj5LSIUWTb5sTsHiPcMjYIBP1rG1fVB4WuWNzAzqy/LcRsSFOfukjpVRbuOVrFA+HPEVhe2cKKpjY7GuIQN4PXkA8/Wujh1TX7y3jE" +
        "M8c91ZOWdFbGQDz+OKi0TxvYXAP73z9yq/lPy0R9Qw64x+tW5dHtru+g1/SrtoSgw/lNzLxwGz+X4USqNv3kJQTWjE8eed4n8NbIgnnxK3y+hzwTn2rwKLXU" +
        "sL6KwvynLm3mB6FSeD9QRwa+gdQ1ae80zfIiI+wgnbhjj1r54+I2lTPKbwwCFgevA3j1rvwdnozkxKaWhI0F54W16O1gSW8jmy6KGALD0GfavS49fi1TRTDb" +
        "b7cKmNsjs2xsdDz09DXExTLqXhvTb+5kkgu7chPNQYZSOO/qK6u0tJChubjypYTj/SIFwXU93A79DxW9aSS1MaSu9DvfDdxJqKxSrE29ULtznJG3au76A/gR" +
        "Wpr95MmlKFj8+4EiiPHziOUHBzj0rif+Ekt9I00ppM7GNF/fQkje4A6oeuRj05ANcfqniS/eRLCxM8F5fL50ErcKSSTgH1JBGa8twc3odyXKjorfx1eaXf65" +
        "q13GbjTbaRUiiYbQxJ5P8vzraXxBput2Fte2dpCpuyU3yjAQjByPx6fSuL12CfTtKivr9kggQIJYS3MjD764/wA9Ku+AdUt/EmktpNjYmHyImBB6FTwDnse9" +
        "OpC0OZBB+9ZnUaT4qNsJtPv1ikkQshyM7cZOfyP5VV17ULaDTGa/ljNiEARUJ+XccjOeegI49qztbiEDwuSjyDck8qHkleCD/Kta006317w1cWzAPA0bxrLg" +
        "7xgAfNnpz/LFc0KvK03sbygrHM6D4btb/U5IdPlUIh81pA2TtI6AHmvWvBdi1rBG0m9pd2AZB1A7CvEdEvI9M8Sw2wupUntflinCYygO0qVJ9MkV7ppXiILd" +
        "PDdRqBnbFMxwWyeP0rpqzaa7HOo32Ov8Rauui6DJdvb3kwCkbbVQzj3wetfDHxH11tc8T3Nw1usLBiuREYy/PVlPRvWvtDxVdwpp/wBteJriKCMkLtJVsevt" +
        "XxR8QfEA8R+Iri8FjDZHO0xRfc47jvXqYG3Q8zEJxOf844xTC5LU0AkZPAq1Y2/nzDKkr616RyXZNZxyyj5VOB3rVgR41AYVcg8iFAoAGPao2bzHO2k2UU7p" +
        "Sythe1ZZuJI2xg106wqFJZcn3qhPZQlySv0qUFivBdJtXcccc1ppPEUHNYt3ahf9WMcU7T1aRtrtjFNAbsJSVSR2opixi3Xhjg0VdwufW0OprIhWTqPWsnU7" +
        "RLoExEZrj7DxWlw2Qxwe+a17PWw8wGcivz90ZRYXuIkUltMA6Hk46VmfELUbvT/DUr26kBs59+K6e6ZZED9Mc15x8QvHdq9lLo8cYkJGC2On0rpwlN1Kq0A8" +
        "bMnmOXJyxOTTjdInBJqG4iOCU4Oe1QpYzSgkt+Zr7WKsrCLP9rRxE4xUcmrNI2QvFRf2aN3zEVbjsoAORTGUptSYg4FO0yRnkGT3qV7SEMeOKdBFHHICsioP" +
        "9rpQLqbK2srBTtO1u4Gf5V6b4E8DXkbJfXCypCpDkbWUH6nv6jFZXw88K3N4fOY3EPG9XUbo2HYsCOldlrt82pxvp0d4RZ2kRMrQoQ0hHXgds+tediKrbcYn" +
        "fQpdWdhB4j0ySRLG2YzICFaIyhcepJPJpvijTIriwwVA3LuBgbBLexPb2rE8GxJZaUzw2MlrGuXYun7x/cY6fiSa4bxf4xutUu5IjNB5bHYvZ+vcjk/SvLVK" +
        "8tDuclbU39L13SorndqV1vmss7VWTy2k56EHitq81K28T2zXckSW9qi48uHEsjY/3TgD615pDZ6RquoR2EUUwMQHmsE3DHQknIx+JNenaLoOgrdw2ltDfBIl" +
        "DYQmKPPpgcE/U1Va0dApXZZ0O3vJIA0skNvYqQI1dWil7dB0J/HFWtQ1660mCSOD76YaN5UwT6hscVb1m+iht0s7aGN2ztCXj/IPoxGf1rhdRjnN9HHDcNMz" +
        "g7kt5A3l+4Zuw9OawjFSepq20NvvHQvzPDNCtq5beSjdVPXaO/PI5rKvtRutQjNsttdXEgOVniGDKB2dD1/nViy8O28mseZNLJeLg5heMIT9R0P4flXTnQ/t" +
        "2pQxWF6dPSKPEts8R2MPckkVrzRhsiLNnBeGgt1qksYguoG27JoDH87c8HHpXsfh/wAN6fpan7Ncssc6cwtn5WHQ/mawP7PtdC1BDZXETzu6/eOcHsBz0IyO" +
        "tblzqUVxpf2qyuHt3gbEiqu7AHUEHt1FZ1Jc70KjHlRk/EDWUsPJLIEkRgCEyyEfXFeZaxoMt3L9uMp2jEkaSHKgZz0610fjDWjqbeVtSVTgEjBApsUCvawQ" +
        "s2IgApG7DD6ZzW9ObhEzlHmMNNHGsWcr2caiN2G5HPy9OcEHI9qEtry2thY2bGOZD8/mt5a/ge9al5cJZ+db2J8xth3vIFXb9Mde9U9M82K5EVwzTSzEfL2Q" +
        "kYzyOR06HvUTrSluOFJR1Ksll/aQjj1JJPMWNkdVA2lh0cMOh/DnNX7W2fS4rae9uFudN3rEqS5LQcZB68Ag9j6UsMtpFDdxXMtxaTxOdoT5s4HbA9uP14q9" +
        "4fWLxEt9pIjKyMyhWRyFZeRkKRxjP0461N5Mbsc548v9MttFSHUpHu3kZ2EaHBR+gP6Y59an+Dd5d3U5V4oodNKtHG4+UK+C3J7nj9a4v4mQz6fr7214yu5T" +
        "a4Xop45H5A16D4a0Wc/Bs3auLB4mMyblOW2MG3fiOBXVOmlQS7nPGd6r8jf8WwrI6abBGiTXDeejqP3QA4Off5Sf/r1F4X1WXFrp7szPcSEBg3VgoJGPQgDI" +
        "PPOaigmh1zwws87oXt40mBUbQCAWxx39c+9Yuiagft9s2dpiukl2yL0RgBge+49fSvO9lpY7VK+ptfEvwhZ6pdf27bXD2phiCfIvyqwHA/HNXvD/ANh1jSoL" +
        "jSriG41OzRUjdnyF9Mg96WykOs+JtY0PfOLfULNrnDDhCuFAB9+SfrXnfwx1M6P4jlsLVJXmeZgYW4BQdATj2reNKU6er2MnJRlbue3Xtvca54UubbVYDOU6" +
        "Qh22vgcZC8n6CvkfxRpz6drN1HJAYWEh/d4wF56fQV9m+YJ4hc2zSrImNyIxGRjB47/jXkfx58LaMttHqttbzSajcHLEqSsaevHetcuxPLLlfU58ZRUo3R4F" +
        "aWJmxI5wvpWtbwxxLhaqKxU45GOKtoRjNfQs8haFlVVu9KqbTxUKucj0qwr/AC5qSiXcVXpVefkGpPP9ahnYMOKaE2U5+QRiqau0MmV61eHXmq15sVQwwPWm" +
        "ItrdSSqA+OKKoQ3A9aKQHT6F4qktiqu3Fdvpniy3dgc4PrmvFobnbwTir8WqtEVVXJNefXwUZu6Emez+IPiD9msGt4Tvkddua8tu5JrqZ5pCzMxyTUiStKqt" +
        "IcnFKzjgACtcLhI0VdbjKgtmIzio281DhFJFaW9ETLVUnuIw3yiu0CsUmY5IxS/MODTjNk8UuN3NAEMo6c4rZ8MaJDq1+kbXIzkYESb2Bz6HA/GsxbWW6dVj" +
        "jdskD5VJ/wD1V698MtBtdKR7u5kg3RhTtXa5TPckDr+NYYiooQNqUFKWp1eraJNpui29pp7XNzfSBUeSQDeF9BjGPxqlpXgCTTr1bzXQkquuBbuTtU92bBw3" +
        "H4V01pqccu67s1kns4jj5CPnfPc9T9Ko+INZ03RNMmvtRkL382Sq78bPTAHHpXhqpJu3c9W1kReJ5bbUI4bGztjDkBYUZtoYdyFHJ9s1iaf4MttNuZL3U72c" +
        "yCMhN0P7uLn73qefSue0nx19pv8A91NPLfyn94w2oET03H19hXUtNeajqMaLK0KBg0hZeenGS3Hv/Spqc0NC6aUtTT0Dw7pVtbT3MCqIt2fOddvnSfUjOKNf" +
        "8XW3hqxlg2JJ5rBjF5gbHH0xz6GmeINWGnGGS0keQRDYpncESPj06fjXjuq6jcajfT313dRxmOQ/uyNwJ9gOMUqFCVSXNLYdaooK0ToLrxFrMVwt15Mwubn/" +
        "AFEMZ3Mq+ue1dx4f07UrrTIZ9UurqFoDlo43XnPPQqPX3rzfwU8+u6k4gTzzHjBaHKR/7TH+Q9a77xJJqEFr9glAQMP9czYXB9zk59TXRWSXuxMqbb95mjda" +
        "/ptvOLC2icl/lUu3yu3c4xn8jVa7tNSh03y7B7+WSRSCmDtUdioOS1YfhLRb27uPtq3M720DAbySyPg9FPTHHNeijXtHSZYWxvVc7fuox9enUflXLL3XobR1" +
        "Vzn/AAXY6nc2M0OqJfNLkgSQR7Hj9M7j/kVb1WB9ER3N+XcjafMjwzfXH86t694tgsrQqFwzHgk5P5+lebatrNw4kuJZ2eNjwcVtCN9TOUrElw6SXiTTPGik" +
        "/ezkflUqNNOHS2tvMweZQSMCuZt5LjUoHkcNHaxnLtG3Lfj2rpbXWbLSrWOGK8GGAOJk5H4nrSqReyKg+rJGs7a1QySQuWYcvwQW/wAKXw1bNqd8qRtHhAUM" +
        "bLnJ7YHpUepataW8ZnS+TLjJ8sAk/h3rHbxRZ2MDT2Umy4ZSp8vIyPUjsamFNvoOU0j0k+ENPgljnumtEZWDBw5VgRwfUYPvgU/TNNsLe6aexuIZfKyYmhlG" +
        "+FueV5IxzyM4PPArwf7Lr3jW7lnkvpJoYiAxyflHoB61lajZyaPdvDZS3JdDgkHbtP4V2Rwulr6nJLEeR1fxw09rfXobwgASpsYZPUd8Hp16V6n4C1u0i+F2" +
        "mpOi3XmwGIxP0IzjH05rwK98R3+rWiWGtySXEcWDHK/+sjH17j61714C8NWl18PbGK2lFyEVnVx2J6/zp4mNqSj2FRfvuRh2vl2SxadaxR/ZA5kZ2HLkndj3" +
        "HbFZsPmWep3dyixh3URuHOduWyP5CrRsprKaaAlpHCtGXH8HGSefbHNZkc7PfyHy23FFJwc8gggZ9f8AGvPcTtTO68CyQyeJrTUmmO6OAWYAHDoTuDH05rj9" +
        "MspJfj3ewMkxgjuZZXDJuLrjJIHueB7V13g/SDo+iXXirVrhbfTbJTJAp48xsnGfX5iBj2rxuz8d6zBrN/qVrNnVNTkPmXsi7mUE8Bc9K6cLBtO5z15K6Pqa" +
        "DRNQa+e7kuD9lRcC3jXBkJGPmOc8Vh/FDQ7u/wDCNzBYu67RvKgdQBjHfj6V5Hpet/Ejwne2mrSaje3dpM4DFpDJGSf4WHbIr6GtdWvdV0+G6+yIJpoiSgcE" +
        "EEdR7VjKi6MlJFe05lY+Jr2Ca1uWhnVlkHUN1qSP7orV+Ibxw+K72I2hgkVyGypUk/Qk1gx3S7QOeK+hi3KKZ5E4qMmi4WC09Z1PBbFVhJv71HtLPgGnYkul" +
        "1PQg0EVWMTIuSfxpoMn95vzpoCWUdazr0HaB71dKtjqc1BNHuXntVAV7eHK7qKmgIVcUUCsZZHpTof8AWr9aQ009aCEdSkyiJST2pRcR561ipMfKXJ7VGbpg" +
        "eGoLubc0gcYB4quNoPJrOFxKw4NPXcepoBF3zI1P3hTW1AR8KAaqbdpp8durn3NAG/4Xhju9Uhe5nuEQsBshAJYemD1+mK9O12GSRPs1hbm2t42AkZsRqT7h" +
        "SOR/OsH4c6Da2ySapdYJiGRv+XHofrW/puoSavqhjjs2a3jZm3HbsQn+Iljya87ESvI7sPGyOqsLj+ydFjaGGK3Ma4RVIUEDuT1ya8w8Ra5Drck0l9cbznCg" +
        "k8f/AF67Lxozx6WUe42A8CR85b6DtXnum6KuoXERdMW8WGeXYTn6Af41yUUpNyZ11HayOr0D7JpmmK9tZvK4+bzNqrzj1OTXSItpb6Wb3UvOacZ2xs/yp6jn" +
        "qfeudu9Y06xligYiRkAESbO/qQK0dRnW/sfLIl3NhVLSEbieDtB6D371nWjzS1HTdkcLq+pz3lwSLkoHkCR8nCg961I/BTGCNrknyJDkbm2Mw/vHjj2GKt2W" +
        "kJpU/muRI54Xgcdjlj0A9a6i0ad5ozbNbOw2s7N8w46cngn8q0nU5VaIlG794fp2lwaHoxWykn8iMAt5Z2oDnnPdifU/lXGanca1e6xtgSIl8LEZj5gUDqfQ" +
        "V0niPVRPa7ZLtyijDIiFiffjgDPbB9awvDzlbiWcSzJEBtMjNwAegAwOaVNN+8wn7uiO0tPE114RsHtrx45wUDGYOOvrjisK01ka3PLcb5JCJNwMSkZ9Msf5" +
        "VzfiG+iub0wRJukY582U5z74A7fhW3pVsbLTlOZWB+VC+FAPsvb8aXskveGp9C5qd29xJ5ssPAO0Fh8x/EVzGvwXDR4xvDEhTnge1a3lTC4Mkz5lBIIX5P5n" +
        "H6Us0UckLNITx94qe/ufWriTLUzYbc6bo6SSszxojO8Sr8pPp74rlBbap4x1MQpG8dqCcbScKPbPeuhXVru41JLSK3dySI1BckAZr1ix8OnSfDzSfuzMy5I2" +
        "4wfr1odTkTa3Eo30POtB+HdtbyiG7n85e7OMn6Af4V1k3ww0NNInmsowZriMmLc2ea56XxPPZ3Ys7q1lbHJk+6o+gPP51J/wsPVrOVjHEGB4QEBVx75OfXpW" +
        "MJzbuzWVONtDj/Avi5PBGsXsN5bOYpH3bRwVccY5rnfEurXGqa9dXUULItxJvVfvE/jXV61Np3im7Et5oqwMRh7i1lMb5z6HIb+dEfwj13VYludN1CEwL/q0" +
        "ujscfUDI/GvQhUi3dvU4pUpWscqbWfVWSE7PtDhYUHAy2OufpzmvYf2fPEUNm95oLNvWQedGM8ZBw2Pr1rzjxH8MfEHhy0W/1Se2dM7AsLknJ7Y78VL4C1S5" +
        "0bWIpo0IPlsiHsBRUScHqELqaPWPE9vDaX11J8jBmZdnbbnJH61xkcTvcNKVbarYJIA7jr68HtW/Ndi+jJZvMbIOGzjP+PpVTw2s8dzcC9Jlj37gZFz8vTHT" +
        "qPrXmNHfHsaHx41I2+geH/DFnKI4DB9qmRBw7fw/1P1rxJ7prW6hMdtwCrADv616J8Y7i5udS05vKPki3RIZ14zjIx+Z6VjW/gjxxbzx58NTOxGVkIGxs985" +
        "wDXdRdoaHJVV5WO+1XxtbWngGOxilX7ReyQ7Y1GWXa4JyO2BxXSaPo3jTT0F1pVwn9lMBMkDt1QnPGenHavKbDwZNa61aT+LL+PToQ2NkYMrrz0+Xgfma+jN" +
        "I1nRvEVvBaWDTrFAoRAx2ggcZA+ntXPVkkkmaxV9j5F+JavF4rvkyrL5hOdoHJ57fWuU8w16P8bbPTLLxLJDA063AyCWU4I3HH6d89u1eaSDAwDmvYou8EeX" +
        "W+NlpJ2YY/rU8TlGBJ5FZ8RxVkBm71qZmqJBInBBpjNt7VUgBjJJ7ip2kGOadgJkO6orkYXioxerH0HNRPcNM2cDFACKD6UVKX2rkiigDHGSQBUnlHrVgWix" +
        "DJOTTWBxVWMxUwVAJoxGh/vVCyHOKlhtwT83ShIomV1OMCpAD6VLGYo1PyA1Xe6G/AWgEWPJOeau6d5SSoGbDsdp9AD7+tUopSygkYq7poj+2Ru7LgMCFK5y" +
        "c+lRLRFI9mSxz4WiS0tUtxtHkx5L5Yn7zEdT9afonhMaTamS8cXN+43EZxGij+tbWksF0yzY5H7veI1yBn3Hem6vdrDA5kG1BgyM3y4rwqlRttI9qFOyTZm6" +
        "la+dYiOUCR8Z2AZ+mB2FZ0UTwaeyxx7eeYwMgD/H9KdpXiEXc0qRFpZclY4lQKirnu3WrU939ts2adTDDFkKUG1Pw7kHvUK8SpWZyWk2bTanPeSSELC/3hy3" +
        "+6Mj9a6FJriSweaRTEjHgu+CwHfApmk4mVgzpBZQHJIGXmf/AOue3pSanfIzCOcyQQplgoXDBfr/AErW9yErHP21lqGpaqg8wPGGyQozn344wK7K2tlgvGlm" +
        "eSSFV27A4C/Qj/IqOwvLaO2D28bRJMv7sEHOB3NQ3CNHDLJO7KwHCxkdD/X9aznJMpI5/wASahbXFw0avtRT82M5HsBUOju+ohYIIpLe2TmHjJdjwSB3P14F" +
        "ZdzDJeXRSFHbe2Bnk49TXYaPatp1kBsZXA2ll5Jz2B61q9Imdm5ajbHQlnvCQASp2tuYlsD1x0rV1a6jZfLUiR4xtZgQI1H9asQI7+Wg3QxRndIgXBYgcZ9a" +
        "wtS12JbiWCL5dnPTgGseZs1ikjG1LUWtrhUDJGmc7skE/UmtS1u4762UwO0+RjKpn+vH6Vnx2f29xLM8RjPILjOTWukD2Vo0UCsEfkjgZNXF6EtdSbS7OFZ1" +
        "kgtE8xThnlAJX6D1r1IalbQ6YrSSRsqoNzEgbfwFeM6XqktjdZkYBWOWAbaiD8epruLm3j1fTTHFGPLcdSdpb34qZK44le+1Dw1qLy28D28M78M29VbP0Ncv" +
        "q3gS5tMXWmbbkH7oeQso9/Sua1X4ealp987W7uiM2QU5JHfJHNdn4T0ltKCvNfXUsjckOGP5daqSUVeLFFt7mBJZalpNmTeXKpnl/LO3A7Y9KyrLxlPcXv2G" +
        "yaWIAH5t5JJ/2j9a9Z1LTNPvLV5LjTLy6br/AKokfyrzXUUh0q8mvTpFxDAW2JEkYjOPeog4y+Iqb25R17/auoKs1/OZig+RMjaPfPcmuSu7XUJ9VMsC7Ujx" +
        "wpxj6Ct6LxVa3cwt2tZ7Vidq5xtx6k9q3ZfDhl0U6vYTQzzhSyKh4OM1vBuDs0ZVLNaDtDMsQjmlcBwejEZPfvXVWGy9JYlImPzZBzyDgjPHP1/WvGL3Wzex" +
        "LJNNtuB8rQ5OVP0qWy8QxQqgLzrgYdFY4f369a0nhm1cyjiLaHp3jPw9qVtqWnzpH9vspAQwz8uGP6detbd34r8R6JaW1rcuXsioTzNgbao6Bv8AH2qfwVqE" +
        "XjPSINNtiVhhh82fPDRuDgL9DyazZ/F2nXLjQXtZ9RQOUW4j+Yxn/dPPFcNRSXunZCUWrsqPBFqUhks4opZHHyug3xSDvkYyp/GvV/AfhGPR9La/vkeHGZPK" +
        "7KMdcCs/TvCQ0PT5rzSoZjOyho2KcIceh/wrlvGnjrVtA8Ktaasbm21W8yyOTtR1GR8vPB9s4PNTSpSnKwq1VKOh5B8Y75tU8SXH2ZrmeEPjbIzyFTntuUED" +
        "8687eCRB88br/vKRV++uIpbuVp7u6STcSQIun/j1MW8jiH7nU71T6FOP/Qq+ipx5UkeHN3dygo2tUyvUzahI3LvDc/8AXWIZP49f1pPOspR80Uls/qjb1/I8" +
        "/rV3JASmkeQmkeBkXeGWRP7yH+nao9x3UwJUjB5Ip/yqaYknQGkdvSlcEh8sylaKqlqKLjuWpXyKi7U1pM9KjaXAxV3IuIx5qeJwOpquozzTsc9aAuWzOmzj" +
        "OaSAIWyQDUBX5OtCMysMUDNByqjIwK0/C0azatCJbiOBdwy78kD2FYMhYjPIrQ8Lwu+rxOGUMhDbmOBWdT4SqfxI+jNNuYrV02u5TZiNn+8/HPFYXjKN2sWY" +
        "7cucYY54qLULqQfYSLg7XIUYGCBjkmrWtBbuyyGCgJ8g7nAr5+StK57kdY2OU8PslnIwZHMZ+6o/jb39au67cG7tIFlmMSbvuBecewFVtMshbCS5lf8AeEBI" +
        "y38I7kD1raa2knlhVLYxQDH3h87e9aSZEUyBby30fS1dcrgZQOMH14A6ZrhbzWdT1e6xFJtLnlm6KP6V2Hi4rFaeQFKKx46HB+lcjphSW+gVhGkIOMv/ABfT" +
        "8q1p7XInd6HeaUVs9OjhWZpJZEx5zDk/ieaLieK4xaRlXKYZnPTJ6k+vpisnxNfXMVntJCPKMLx0HoKy9H+0SZgmLQx7huKA75D7+1YunvJGim9jahsZJNSE" +
        "kcnlxJklgMZP0rUF1F5x2yySFRgBf4B3JP8AWoDeQWabc9Ofw96q2+px3qtDG/7vdgqOrN1ye/0FRq0U7I3ry4mOlPImQhQlUHH69/rXlVzLlpi3zsW6A5Gc" +
        "8/U163qxjk05onfM7qFEa/8ALMY5/HvXA2WgSzXTbhGqbj98ZJ9+K0py5dyZJvYs6K1zPbK7E/KMLv52D2XoK13uZZQlrEdrAfM5GSPeqltpkUKLGplZhlgI" +
        "1OT6k9hWRfX90jyW1uQ7McMQRnaO2egx61Ld3oPVLU27q3gaVTkS5O0MeWPv7Vu6HraWp8iQlVXhi+Aqj/8AV71z2hokkSwqDJMPmkfPyxj3J7e5x7VsyxxQ" +
        "RZinaZic/uCFGf8AeIz+QokCOws/st3GZIYJJs9G5UfpTzpSynf9khXHJ+Yk/wA65DT/ABNe2WUldYkOd2zLtgerNmtuw1061FhJHbAywJ5APTNQxl9UtozI" +
        "slpA204yNzY/LA/WotSOpeVHDpMds8KLkwuqqPqGJPWp4rO1DFRIrysNyr95j6n2HvWlb2Fvd2xiZYypzvIbdj059aEJnlt+niF7krdeErO5P3VkRfU8nI61" +
        "3/hK1hGjeXNpEenBMpHAMHH+114qS78FWAmia3jm8hDuYvcONx9Biq0/h+ysPMnuYI9u5WiSORyRj1rVSb0JcUeafET4evYXsurafax3EMh+YJyUNcN4b0O+" +
        "1nVIorSye62yDevQdehPavYfE2vJZ20sdrBLcM251+XaqZ9cVn/Dm9a0V4Li1ePLmUyRL90n17966lWfLqczp+8eueBPDVl4O8Kym1tYri4k/wBImRXG71wD" +
        "3xWJojeITrAvbDQLCyglcNJHG8bs5J++p4PTseM1oxeHm1ZVIggldgAjNuAK9cNgitrRPBml6VA80ttBbyR5YGFyVXPYg9Pwrjm+Z3N1ojWmvoYXM11fy2zg" +
        "ZMVxC0e4gdsHB/DNfN3xl8d22u6kbSSZbq0RsYKMNvqMjkfitek+J/iLol6brQ1urqK6tiUltpOrL3wT1HfPbivFNb0XVIbmZ1hg8S2EnzDzkKXcY9Mj5gR7" +
        "bgeoBBrtw1Fxd2cdWp0RyX9lWl6pa3llOOwYS4/Dhh+RrPn0WaMv5JWYp94J95fqDyPyrSbRNO1YsdJuZoLpetjeY359EcY3fTANUZL29s5PKv4zMIzt/eH5" +
        "0x2D9VP4/hXoHIzMCkHkGgg1oz38bti4VriI/dc4WUfU9CR79arXEGxRJE/mwno4GCPYjsaoREjspyCQfanjpUJbFKJKAJCSKaX96YXpu/JpJBcefrRTC1FM" +
        "CSo3qYrimOnrVECJmhmINPRG7KcfSkZce1ACxkt1qUYHNQDilycUDuTGStLw+Y21CHzmMcSOJJGBxkDoKx6tWUgidXflVOcf3j2FRJaFQep7ddj7bZWs1rG0" +
        "VsANqkYYk8ZNdFs8uxVRGo8tRGgUetc94M1D+0tH2MgOBuyy4BPcj2rT0zUg99NAzBV6tnoB/ia8Gsmm0e5Sd0mY2rxyRTBgUEg+UEj7o7nPrW/YTiCzVpHD" +
        "OR35JPr7modVsxLIroAShzg96hsYFtmMkm6R+vJzk1ipdzRozfEMC3CLJOCik5VFG4j6+9ZVvZxWkyPKAJHI8tWUO4H06LXY3FsLiISSukXUlupUf41z1xGt" +
        "s/nRozZ+6ZeAB64raE3sZyiZfiq4upWXei5GMnALfQmofDiSyy8qkUxBYkclv04rT1G2+028YcOrHkEcn6mkt4p7FWghVSQMbunJ/nV8+liOTW43X821sxzi" +
        "U8kdSR9e1ZvhmBru4Es5aJUPyRJjDnuSff1rQ1KM3lnIRKZSCQ0h4H4CqfhSPEspZt6IPvdTj+VENEE9ZHTT3nmyi3BEWW/5ZjIUDqc1cis2W2AtxsL5zI55" +
        "I7knt/8AWrOjVx++iGxP7zDn2AParV7q4g0/zEUup+Vdwx+JH1rNq5omU5NQWyL28StKDhXdU/1h7Yz2qKbTlliYRqEgUZlYAFieuB6n9B1qp9tN7AzQOikc" +
        "GVjzn6elOj1G2Ro7JCzJH94c8scnHPcn8vwpqNgcrlS2jnkPlRYiskfPkAnB7bicfM3ufwxW5bXsbERxDj7rMc5LegqreLLJGCNsMSAZK9z1wT9fT0qtp2BI" +
        "S4UxAYBT7wHouepJ4yamVxx0N1tHjni82dvJhzjCD5pCOdo/qe1LcWwsold2NvHjMdrCMnnozZ6k/wC19cGmQXwgVJnXYIl2KgOQvHTnrjqT3NRW94t3dCUP" +
        "5hJJ5PJI7/nUK5TJvt96kUlt5gVH5upOp9lz1Y+3c+gArV8P+JvJj3TfJbKdlvG3Jkbu7eoA/Xisr7MLwiNMKmcL7nuTVe/gjdCy/u41HloCfuryOPzJ+pNF" +
        "wsei2HiaJlE7MCGAYKegBPBrcihstUG5cGbGdhOK8o0uEsEO8sGIHsNpx+lbj6pNY5fd8rvtDD+DJqecXKdPqHguK5MjKo82RQAOwH06Vc03w3p2hi3kmkQF" +
        "EMcg4yxz3+lcnaeJbxLhTJNJ9/Y2WPSm6heXa3hmXdLG2TIo67T1NP2j7k+z6nolnrAN2YUTyY/ug8YJqTxir2egy3VpEXmALFB0cdwR6Y9PSoPDtk0HleYy" +
        "zQSRq6E8MhI+ZSPT+VUPitqpsdHNnbXcMbspIjkPXjkfl/KrpPmkkZz01PmfxXfGLVvtFxJK1u75guUJ+0WEg52g91HXaeCORg1PB4myBDqRjPmAMk8D+UuT" +
        "0dGH+rzyem3OQyjrXL61qkt9JcRXRWRgxQuo/iXO1vfuKz7C4Myf2e5ysvEef4XP9CcfjivejHQ8iT1Ot16exvJTFryuZGOyHWYItrqR/BcRDhiPVeccjcMV" +
        "i37zpJHa6vKjllH2e/Q71kTtlv409z8y/pUWnakk8QsL/wD1LARFiOUGeP8Avk9PT6E1VlabS5Z9MvVDwB/mTurf30PYkY+o61RLZWntHgmkgkTY4+8uePZl" +
        "Pcf41VguHt3OMEEYZDyGHoa0WR7iEQBw7wKWgcfxp1K/hyR6ciqTwh8SAcNz9KoVyOYJuzHyh6AnkexqPHtU4QDgmk2inYVyHFGKm2CmsvNFhDFUk0VJFwea" +
        "KBn1hYfsk6DBdvJd6td3VtjCIAFP1JrSm/Zk+H1xqESxLfxCMfvI/NJVz9e1euQ313KFM8HkKDjB71Ye3WVDv6t3HUVwOqzuUUcdo3wj8JaDpkulJoNlJYy5" +
        "DNKu92z/ALR5FVbD4D/DixuJJj4fgk8zoJGLKo9q6uXRp5YTm/mypygXgfQ+tXkQi0jhUjzBj/Wdx3qOdg4o4WL4C/DyzLyxeH4Gzk4Ykj8KZe/Bj4d6rD9l" +
        "/sG2hcD/AJZ8MDXbwXVpNLPFBeKXtziRc/dpYYY1bfaCJgw3b2bNHOw5UeQTfsteDLmZlhhvoVByD5vGKx/EP7J+mTQQpoV3PBOr/OZ2yrCvfJzJkTrKqDHI" +
        "U8Gs7WfFEelQwXMVlc3glcIxhQtsX1qlUZLgeCj4SeI/Bl1vuGF9YfLGq2owE4/iHesi5sZIb1mfKITkqfX0r6YurpJtNNzaWkspbDhD1z6YrxHxpo1zp00E" +
        "9xFtmuSXeAAkxgep/GuauubU66E3blZmXGCgPGWxkDsfSsx38tvVuwNTQ3g3yGYgZOFA9arzjMvrXA4WZ2JlgSMFYOokkI/4ClZl5Evnh3kaZxzg8DP0p8sm" +
        "04ZmKk8r6mopXcuAg3O3XjgVaEy0rARHftLnjI7CsTUrqK3ys5fZ65wWNasMZjBR3DSdOO56n8KzL+zjD+ZNhmHI7496tEsMS/2YIIo0Ric47Y96r6RbyWzr" +
        "5km5XJGCwxnuQv8AjTrGSeWM/KUVycA8lhUtpAhlkUIS3qx6VRLRoazfK6i0SRlVRk7R8ze3/wCqoNShabTvLiUOchdqjjOOlUFune9McHVzh5MZKjvz+lbO" +
        "nyGKJlwqIeI0PX3NU3oSkYun6TLaBY2Zdy8vtGdnHC1Gmklb1rmTIjUEhRn5z6n2rVMjpcCJy0UQYsT3cdhVTVddtFIiAJfOBGP4h6e1SpNluyINb1bdYRxw" +
        "JKpcbEDDLHP3mwPyqDRI7mFFa7jOwDcRnnrgA/QfzrT0+2KKZZhmeVdzv1EY/hQD8zUzeW0wtcbinzccDjoT/hSk+gIz9e1HZL9gTPyrt9vf9aytP1GaC6SO" +
        "F2Zd6x7vU85/Wr2qWUl3dhBzImGkb054/Oiy0oqTKgULDliRzuJNPRIZ1+lNHdQ+ZGDgqdnqcnGfx5qG8sBNeNAAxVUBKnpWfY3D6RBJlyI1IVHxwB9Pxrei" +
        "lFxcwyLtYdznqemPoeawZaJLey+xhIxyWBK+2aUBIWlgm+eKVzz3AI6fnU1/fRQ3cSjbtC4LD+Ef4cmkurcy2UyoSH4+bsDUqFwukV51isofMmkwTgZxkEjp" +
        "+n8q67w+kWof6MYwLlEEqY6uO4z9DxXJ6ZZvrWgS2spInkbySp6ow5B+ldP4X0q9iktDdhoruCNRBOAcPgn5G/p9cUNIVztvDtpJEZYZ7n7THCTs3DDqMdD+" +
        "FeI/HfXbhp5raO5DJFslhDKCV7/Ke3OMj6V614v1ceH9Oe9iuVstQk+YKw3IWxgg+nUV8s+MPE9x4jl+13ixy3MbNBKUJHGeDXoYCg2+ZnDiqltDkLy7NxcT" +
        "TFQplbcQBxmqykhgynBHIPpUsqKT8ufx7VE2QK9taI8tk17KJLl3AHz/AD/ieT+ua0tQlGpaXaXjHM8P+jSnuwxlGP4ZH4ViyZL59gKu2kuLO7jbowRh9Q2P" +
        "5E1NgGRyPGVKnBQ5U+hp9yUBLIMLJ84A7eo/OoC3FISTTsMTNITS4pD1xQSKKRqcq5FI60AN20VLFGXHAopDR+jYvrfykV2eQOTtJHBPpxWfb60b3Um02TS7" +
        "hJI/nZ/4AO3P9KjXT1trSWQgHdl/MII8thwCB9afda3a6PaW0d/frvnGFuMY3H+Wa8s9G1jVQrIHfbKvlnG1v6U1YppIwXw5znc3GKwNd8UweHtPW91MvNZM" +
        "eJA209MjjvXknjL4+6kYph4cshbxGPYbiYliOeCo9auMHLYiTtqz3kabAv79wsZOWcrwD7mse31qwlmWyi1LT7lpmYJsmGQB2r5etPib448Q2L2d9d6ldRRs" +
        "QzfcXB9emaqz3JtbmN4vMUHkOjdD74963WH7ke1PqjVdd0rwbZSHVbtEg/5Zr1Yk+nrWF/wuTwnb6ebm2uHuNgBMCrtc5647Zr5suNY1HVrwRX19JOR/q1Mh" +
        "OB6VnzFplZpJfJ8licxjIP1qlhl1ZLq32PoTWv2h9Ptik+k6XPPDtzL5zCPaewxXHX3xv/tW0nOo6XG8k5EUbI5ChM5IrydLhF2gyb1YhjubAP1FF9q0kcnl" +
        "pAqgDqv3abw0e4Ks0dTLqX2zcYE2lyWVAT8vPvVy21BX8yJsDygAW98etcfp2tTyTPvMSw9C0Y5/CpjqWRJFHKFUtySeelefXw7T02OylXTVmdaWDqDx9ajW" +
        "YojCPl+gb+tZKaqqRIi8hUyzZ6ntVtLpNqY+Ziu6uXlsdPOieJimTv5A25POKL1RIgRfmY889BVIv85d87eoGe9WvP3gE8KBz60OLBSuU1na3b5gWY8c9qtW" +
        "TD7xOS/3iO/fHvVC4Y3LlwNgweCetSfa1RkAIOAQijsaS3Gx0bLa3PlxIvmlxn271dSQfamu5HYIgwqAZOOgx/OoJItqLKQodxl8dRnt+NVfOIO8EM7Pzzwo" +
        "9vpWpmX9ZfzYWuNrKwX5U71x1rZy/bUkdlEh4DN0UV11tcJe73mYCOLJyf4iegqhd2qzzII4tqkAkhug9fxNKDsNlnTtV8y+2Wse5lUIHm6AYyxx6/57VJq1" +
        "5JGxlQbEYZ47+hpLG0itZk2NHkBsBhwgxyT/AJ7VNdwwGMttM8823ahPTI/QUSV3cEYei6rJc37xS5EZJ2kjkgKcV1ujrBfWyyQsDAqjzAPc5IrFWxjs3aSG" +
        "Lc4XYec+mT/OrWmRnTGlWB8pcHJXrgjuPzqZ2ZadjUfRFjeaNWLwzMWUNzg9Rj64P506G3XTrPyZtzJ1EmehJ4z+dOtLlp7ZbZpFEoX5WYYBI4FWEVdU09op" +
        "FZJVOdoPII6/hxWNirj2tRPCxmADLGEYjp9T+NT6ZG+FWY4VgEb0U/5FMiPDeZ90nv0NW4rqF8KQDGcAsD0obsCi2aumWR+3xXEaqhL7X9C1d1/aVlY6W9ze" +
        "usccQON56H/69cfoumS3d7JEwd4t25HTopHrWB8UPGq6PHEbBoLiMRsjlZBvX1BU9foarDxdSVkRWlyRucv8Tfia2pPJp0yrLYsPkkTBkQHoAe+K8cuvK85v" +
        "KnaVW53Mu0n6ireq3kF1JJPBKrJIcmJlwUPt6fSsgk5r36VNQjY8epJyldjmRT3qKSIe1SAZpGQ1tczaKchCnFPSYKrD+8MGlkhJbOKYYiO1FyQ30BuaaVI6" +
        "03BFK4FjHvScCowzEcAk0qJITypqhDyM0bG9DWlbwRogyvNTNGpHAFFhlO2/dqMgZoqfyfaiiwz7V8f/ABAm8GafbwCaFtSkXldoYZ+noa8h1z4ma5qdjcWl" +
        "xcKI2cOFjhGE+mOldX8UtRvj5I063szZuoSbUGjEkuCM85Hy/h6ivJ47yR72WOSK5kjQfK5j6n8O31rioqPU7J3L9z4luNct47GfVLi5jhHKux/IA1n3bXHk" +
        "C3S2eKIchgPm+tWF8PzGUzyQSvNjeqKh+T3IqHU47lreT7WC3G3LTbTj0xXZFLoc8rsbCb2C22ROysy7iWYYx/jTbq6VrVYtsQjx95W4/P1qCK1zZDJjt4E+" +
        "ViuWOPaqV0H8tktFLW2epBXH51TCw6XTwkDiGUu8j7j5Y6fXvVSWycARXkOIguRIjZrV022mt7CSee4tzE/yDDEsp96jls0SEWzh5CDu805x9B61IGSlpC8r" +
        "taoshTAG8H5f6U24SSG58uWLdkfwcIM/zrV/suCWNNxAR22kp7UlzGiW8uULKWCxqTgADvxQwMBpHjXyVdVUHg46iq/nMuVcs3oEXFb09tNKYpVi2oy4O5Qu" +
        "2s6exis3AViS/dWJ3E+mazYI3dnkaJFLJkFx071kXeq3VtKzKjRhk2Lnsa0otaguVsrYxnekixMGHAHcmsjX9ZtJJ2khlSZo9wCY6HpmuV0lfY6FVshuneKJ" +
        "UYrd4JBC89hXQadrltqETskqgKcHPFea3TPcymRFJDDnA4pYXuoYCiZjRzk9skU5YaLQvbyTPU5pI2yEPHrnrVdWWPLdWPT2rjoNeuAY2mdVRAPlzy/HNaQ8" +
        "TRyrwp/3R1Nc0sM1sbrEJnVpOBbMMhnxuJJ5OaqSoJ4VwwUKxOOmax7TXbeWVlR1ICnoat29558LdFAOQT3NQ6Ui1UTNBJBNLsYglsfKP4VFaBcNC1yfl2H5" +
        "Rnrjoa563IikyT7kjv7VoiaS52tIQIweUHcelZyi0jVSTKt9f3EYZLbc8soAGR1B65rSsdQbT5EjlzJcMgDHGcHv/hUVvIr4uJIxBkHamM4HSku7iOBAtvHu" +
        "uJfQcj3NZNtKxqkbEF1D5Kux/eOMHPXGeatahaBYRd252yR/MQB94dxXO2lo21JvmDOOVJ6fStc3jWenu8u5wOD7Cpgm2Eti+rR3MaTBgON25u2D3qaTWoIC" +
        "WOMqvDD+VcJdeKXid7RMFCO1MhuncITK27Pyj1rZ02jGMzr31ieaeLYu6MsVb16YFb2gafLdSBlPyMwJQ9RXM6RMnmBSMMzHaTXoem6npvhS7trjVj5ME6ZW" +
        "Vh8oI6g1yyhKTsjpU0lc6ubWNJ8JWIdbm3iupICxSV8FsdTzxkV8v+PNSl1bVprvEOfMYu8X3HB6MPrmtP4reI/7W1GWASZjjlZ7e4Rtyyxt6Ed687EjYwWO" +
        "K9jCYX2Ub9TycTiHN26CkAE0ZFNJz0ppNd5xt3JsgY4p+NwqJBuqUMFoGtRGTFQyLk1OZAaaAN1ANFYwE9qkg09pc7jireARwKliyBjoKBEMFmkRIKg1YaBc" +
        "cKKdkA5NNabAwDVIbRHtxTlkxxUDyYJNR+bmmJIvCRe+KKz3kb1NFBR90xy22pW73ejWemXttfMAsssWFbtnH8XTjHXFXrXwpp0UsYkmQXbfvZVRFDMn93H8" +
        "K5qC8v7O3vbdNLmtobe1H2ZmhhL+XnkKpHyqfqO9TNcz3ysZrXCs0cSXdswMhHU7sjhfpnrXlJ2O5q5dS2+xXwZN1y3yx7mi3Db6Ar+ua5b4j/DWDxZp6zWs" +
        "FsNXR9wmIEcZUnlWx1+tdRc6haxWUk0kX2FAxaRpD5PCj7xPcGp7G6gu7W3uFEl0jqXVwDtb86rnl3JcD54m+Enii1MrR21rLIJAgKzhgoJwMCsXVfAms6Q0" +
        "zXWnXk4hP7yRYi0af8CHFfTN7PePCUtjASWAkzwY8kAKOOvXk1Lf26NpqW7WH2hGHlumcoB3z6+n1rVV2txOkmfHUumtdCTybebyznOOBilFldWVu5hPyHCk" +
        "ySE7fwFfQuo/B7TZ9Yil837BpKAhraIsHkY/dy7HH5V5l4n8FX2kanK/9lTDSoHBEzBiDnoM8D6nFaxxEWZui0cQZZLVYozbRsCM5CnLVaiMgVHmjijK8x+Z" +
        "3P070kqNJe7R5in7wPJCr7E0o+2HbJBPKwlOBvUqEXuTu5rTnuTysU2rXTmK5lIVhlinGM9gO341lTwwWkIkt0cyb9qxzEsdo6/StJVhsbOSI7Loif5mKlWO" +
        "eme5FUrkXWoTTRLLEpdgu8sfkUenHWmSylPFd3ERmsxBEjjHkkYYe9VJLKCMQbWbzgNsxYYBY+/tU99ZPAD5hcgKQsm4qxUe1S2lzb+WLdbVpCFDSO+GUHH8" +
        "84pWApPFBFEjFYnlVtoijcFTzycVBNYEgOiRFTgbeMls9hmtm1spdpvJLVVGCQ0iZ79h06VMbCNW3QxMk+eG4Ur6/SlYDmLjQp0jkdkjQBgOSMj6Gq50+FFM" +
        "xcsuMBFJBY10kdtJOZYZmTcmZC8zh8DPYf5NDaaHuiywpPIeFkQnP4L2pAcva2g8wvGFA5BGTxQ2qSxMFRmdVXYABwK1F09DcSm4lK7eArNjNRJp8hd1SGNw" +
        "pznJUAUnFD1RTOr3EQQiUOQM/StHTPE8s0ipMAsQIG71qP8AsNWmDxrJt7twVY+g96yJ7fymDYZ1DHOPlx9RUypxfQpTkj0ySL7WRDG4EZX5mBzgUkkMNrEF" +
        "g+dfu7u7HGK5Xwvqsz3Rs2lZUkI6nmu2vYIkG8o2Y1wuOgrjqUEmdVOs7FKOQxqrHc6rwQO4z2/Wtm2l8yCVXQHbltvQtjnFcnM95KytbxPNGrAgJ0x/WtzR" +
        "rhvKHnRbNqks4cEAe47VCpIt1bo4TWLy3vddmlso3ijkbdsbkqe4q7ZXsdu3KhmUYAx05qvrmlXOmXUuoM8VxbSuSrwnpnsaueC4Tq2tQxIgEcjhNxGcVu4K" +
        "xipM6fwiZ9UvI4dheIsQHUV9B3PgHS/Gfg5NAubtoZUTJlQAuue+DXzno4h0HxtqWmXNw4tY7l4jt42HqD/+qvoXRfENtcaLp+qW1xFDcW5jjLT8+YkmQA2D" +
        "kcjg1ySXJK6N73jY8V8a/sz+I9CtJ73R76HWbaBd7RBTHKB3IU8H8DXj91pl7ZorXNncQK/3WkjZQ30yOa/QG/kM+lzxbbn99GVYwruKZGMjPBrk/FVrpltp" +
        "ljpuv6K+taVmNUmlhA8tydoBC9MCu2GIfU5JUFc+JBjFMbAr2bxl+zxqmn3GrXOkXUNxFCWngtAp3tFnoD0JANeNSIyMVYFWU4IPUGuqM1I5pQaBHp+SajVc" +
        "c1K0UkYBdHUNyCQRn6etVdCVyEkl+DU6jHNRBcNUgOaYn5kgcDvUiyc9arMcUI/vQNFtpOKgLnPJoLcVE7ZbimgZKwDLUQBBpVcigsDVIAciil2UUXC59525" +
        "gSBLy1tJi6BokjM3yuT1bA4J98ZqxNGqbp5JI0hyMb5AuPz9+MVmyx/2dMo8sxOpALQuV3enBz9cDr0rNm1WxktbdIteia6+0byHt1Kld2Su3sffrXj3PSsZ" +
        "vjy3s/Ed5aWd6mpQWtuDvlhiP70MOFGRt4PJbtWvoHiTSILCO2tdSvLiK2xZ7mYs+7G1egwPr04rVt9RfUIzAJoL6WFz56QvtCrjgFT1BBBzWdYTaTBcTDTb" +
        "eO3vLhQ9xANiOyZwMsAMj6UwsbUsqaiFWy1W4gmgkIYMuQ2OCrA+4698Vmvqz2kEcOpaqI0upvJiuLdDsUg85PIGeeTjFck974c8IaRc+fJdWciTS+XC15mT" +
        "cWGGXPBAODznv1rNsfi7oWl6LBpOiwG8EKmJzcZwzdWPqxJJ9KpRbJbSPV5ma8kTyriFAGyobEm844I54xWNcTa3p98bbU7Wz1LSrm6LvM0+42sZxgFWAAVc" +
        "Z4Jrxiz+Kes2GsrcJ9mMTAAwrFtRcdDVnXvjjrF8WsraJLSJ1O8xjeGHruNaKkzNyOy8TXfgzWNUjnOrxBIAxLLCj+UAMKuSOmecDNeSaxd2lxrE6wSSXisw" +
        "G6UKFAHQhRwKpebJeM7lZETdlgBgsR0H50+40zUEYMBcQpjACQFR7kkjJxW0VYhu5DJIkmpGBY0knC9YlwEHqSetSzf6K8cisXJzlFXAY+rH2qolx5U6xKHc" +
        "YO+QKTuP17fSuutPB+r6no8l/p2nGWCMYLvIvJxngd60UkS43OGa7aa7kke0Dqq7Vcn5evQetIbYrvP2dUlkff8AMgyv49q34NMvRLDBLaTRSyH5IvKw7HPY" +
        "Yrcbwdrd7ZrdJoNzGPmIlRcMwHXg8inzInlOHv57tdNndIXmMZUZmcYPsozWZBLqmpTBrqJocgqqFTtI9a6HUo2s3YpDPLdxjJgYfN+Oaof2PdX919tWOdEJ" +
        "DMHkAWP24piIrrSjH5fkRqAq4wpHzHufWkEc1nE6+QJ5VAQySD5VJ56DvWi1otveYZ5nf6BEP4nmlil+1RSkH7QiDASRsqpoGUjcxbRJHDtmKnK+WCBg8cnp" +
        "xUNrc/aTI84jTAyUc53H61oR2T27efIibvu7I1yOnfNKbOW3kSO7tolWTIUqpbj+RNSOxk3FvLdvsh2iOIA4jPc96xZ9Kb7QzAO24ZCrzk+prrBb+RKYIWXb" +
        "swA4xg+ppPsyWrmQ7VJ4BDZyPUVVhHNaPY/Y7mO7mKowfJU/eA9q6fWtQlmtrhow4t0wmU/jyOv0qnLaC4UuJYAeMO+c4/KprvRnuLRrS2unVXbe21cfNiol" +
        "G7GnYp6dKq6JaL55hIkbIHJzngH1qDw1fQxee08wLRzEHAPKk4x+VWLTSptJsMrIZF3EgSL1JXBIP41Bo3hTULF2uFlQFwSyOhPJHHIqHArmNfRJoNQl1HQZ" +
        "EEkQ3BX6qR1U+3BFd54L+D9hpknnvcalFfW9zE4haRIoyowxPIORgnoe1cHo8Muj3P8AaFqrRXQ+8UXn6kH/AArqdP8Ain4mjii8q8EAXJDvEuTn+E5+tZyi" +
        "zWFjrr79nvTdW1y41zS/El15d3IXWOW2EoLk8/Px8ue/au20n4aWllOksM8d7ZtGkdxZzYZSY/uFGXBXBycHNed+CPGuq3mpwW0mpWsMQJRFaLEYLHOMLwOe" +
        "9ev22raLAZgtxHDcyBTKsL7iOMdFPBzXPOD3ZqmbEIt3UKiiO5j/AIY2IMeeAcHio7691K3ukia386zUF2lib5+BxuzxyayW1ueykuUvNNkumgA8uaEDMuec" +
        "H0pklte/YpNV0p7sNJKly+nSyrGGPAZSxHp2zjIqbBY321KGeEJJbeaGg81d6csvQj614B4s+Gnw71a+uvEgutR0+1WVVnso1CgknBK55HPUV7bbT22tSz2l" +
        "1FHHe2+V2QyNmFTjuMfpU1/4dsdZsprO+t7e7tZiMxyDIbHQnuD75ohU/lBxj1R4bp/hz4Y3YNtFoLotrDk3kKGVwwOctk7WOO2K9wn0XRNU0OO0vNMtr+1a" +
        "FQsU1uuWUDPTjH4Vit8N9G06xlt7CaTS4HnjnjRSHWKReDjPOGHBGa6WyuZ4TMiolxbxbIwiIwYHHOM8FcY6VfPLuS4x7HjfiH9lbQNRvGm0vW59H8xi5glj" +
        "EsaqeyHIPGe9eLeP/g74o+Hpmub61+06WsmyO/gIaNs9MjqufevtsFGg3NF8sfOM5yp+vSsXxLocPiHS7mzjk/0a9t2t5oSBjaRwwzxkVtCs1ozCVJPY+AZS" +
        "T2pEzmu28ZfCzXvDnia90az0/UNTit2BS5htXIkUgHPGR35965G6sLrT7lra8t5raZescyFGH4GuuMrnPKLW4qjikKjJpA2BzTGk5q0Jg5x0qPcRSM/rSAg0" +
        "CJhIcdqKYBmigLH6AXkP9j2qGGWSUtKMmc7yePeubttPsNdv7i6utPtRcgCETRptcKRng+ue9FFeSz1YlO88P2kfh5dbSS5TUVl2LOkpUqA+3oODx65pP+ER" +
        "sLSz1nWXlvLq+hUIk1xMWKgDOOMcc0UU0EjxOKMeIbq4+2k/McnZx2Prn0rd0r4e6Pb6xDZq1y0dykTuWcEgkHpxx0oorrpnLLc6Xwl8ONH1XXorS9lvZrWS" +
        "N2aHzFVSR0+6oNdrD8NfCvhy6MdhpMQWeOQSeaxfIyOxOB1oopSYGw/gfw+oJ/s6LEkiyFR8o3DowAxg/StC8RWMtuwDRqxTBGcg560UVPQqG5nQaHpjQRxP" +
        "YWzxI25IzEu1TzyBjFaNnFGHu0VFQIQVCjGOnH05ooqZDK8UKale3UFwoItog8Trw6EjnBFUor+SKCzsRHEY5A6FmXLYoorJtje5554o8J6Wq299FE0MszPE" +
        "4Qjbt56Ajj8K5+x8KWNxor6i8tz5sYJVAwCcZxxj2oorujsYy3OPvsXMfnzjzZDkbmrYvNAs9O8O2V/D5hllfLBiCvT6UUVQjHtEEtkbh8tLk8k+pqL7XOJy" +
        "fNYkZUHPQCiikNjLqJbizSaTJaQlW57YpIIVZ1jyQp+TA9MgUUVRJozxILvyioZYwFG4Zzxnmqq2kJSaNEMYDMQUYgg5xmiigGU9bhW1063aIsGUsASfY1FN" +
        "qt1Hpllsk27wucD6UUUmI2L5PKMceWYB8AsckDGaeLaOHVJbQLuj2CT5uTniiipZpEkgmMM8ccaqoLEkjvjpXSaBfy2pW3gCRKCV3IMMdzc5P40UVhM0ieq+" +
        "G38zR4JZUWZyzZMgzux0z+VaC3VwdJe5M8hbaDtJyvDHjHpRRWMjVG5bIrD7qg7gNwAzj0zRe/PO0C5iXnmMkEcUUVnHdkvcbp0YmuDbT/vkQYHmYJ/Gqup2" +
        "5sjFcWs80BikciNG+RsjHI70UVoIkls4r7y7t98c6hG3xOULc9DjqOelRQTNDrA00fNbtCz/ADckEH1/GiikhrYs6awmjkmdVMkZZAw4OM1R8QeFdD8a6f5O" +
        "vaVaXu9hFvaMCRR2IYcgj60UVcXqZSPj/wCLXg3TvBHiZdN0yS5eB4i/79gzD5iMAgDjFcQwGaKK7aexyyImAxRGKKK0JJ1AxRRRQB//2Q==";

    public static final String TILKAJO_ICON_B64 = 
        "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAUDBAQEAwUEBAQFBQUGBwwIBwcHBw8LCwkMEQ8SEhEPERETFhwXExQaFRERGCEYGh0dHx8fExciJCIeJBweHx7/" +
        "2wBDAQUFBQcGBw4ICA4eFBEUHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh7/wAARCABgAGADASIAAhEBAxEB/8QA" +
        "HwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkK" +
        "FhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXG" +
        "x8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAEC" +
        "AxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOE" +
        "hYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD5I1AxRXOU" +
        "+bdycVYkn8yNWB7YxWUFZhyRXU+DVto4pbiZBJKpwgZcgU1oaLUh0nTHmu47iaJljUbgWGMntXQ+fDaBlypkfsDUVxK8sRl2MDnIQ8AVQYN5hkIVT3xzUN3Z" +
        "qkkjqPA8kWpeLdKt7iLzYZLuNWUjgjOcHNeo69qWoaS/9vWMr70kLSkN905yOPSvDdIupbLULW+gx+4mWXDdG2sD/SvWNb1ZbPWDbO6vY3vzrzlWDYI/MEGu" +
        "DHJtxO3BNWZzfxt0aO3vNL8VabbpDpniCDzwkQ/dw3C/61B6A5DgejEdq4KR3e1wMZz1r6vuPC0PjP4QXXh4Kn2xYxc2BAxsnTIUE+4+U49a+SZd8O6KVGV1" +
        "YhlPVSOCK2wlb2keV7owxFLkldbMzpo7iK9EuVCuMZzXT/D7wenifxNBFdrK1ijKblxkbueEBHQn9BmuauzLM6RRAsWYBR7mvqH9nPwbGqoGiZ2/jYnGWOAf" +
        "8444q8TW9nC/UihS9pKz2PN/jhpGmeE/Hrabp8NvbWTWFtMIoM7InZMMBkk4JGeveuMhmjWUFOCRzjnNeg/tWy2svxkv7e2j2i0hgt3OQQxVAOMdK8rEywXc" +
        "cafeYZ606d3BNhKXvMI9K0w3awwxkrGNzOzZ3CrzzxxOscCKijgADFUvD8r3F5KkMTFmAVQ3BNe+fDX4eaAiNJ4iiim1NU8z7NId0dupGQZCOOR/CaWIxEaM" +
        "byHRoOq7RPPfDvgbxX4mtBe6bprtZk7XmYgBPfBOT68VvP8AA7W4J1F9q+nrGVD743ZhtJ+n/wCrvXodjri6hqs8cV/C7RDy4dPt4GWIAHAbcuAf9kYOfbFa" +
        "WoanB4dtohqmqapcXIfLxtKHC5yAuOq9e2a8ermFbmtHQ9OngqVvePLLj4R2y60mnf8ACVwW+/HkyS2zbZBjqCucH/PeqvxC8M3GjeHNI0i4urW8vUt2mtLm" +
        "3YlZh5jYj55yAcAde3pXpfh/V9Wv9ffSIrBDp8ysQlyjDyx/ECw5B98A9Ky/jnp39qR2mlW907y2ey5ScAEoN33gf4iMD3PelDF1JzUaj0HLDQhFuC1Nr4Pe" +
        "IrcaFpDxyxhzE0XysSQQVODnuCKyviP4A8MXXi2eeytbP7XcObowPNs8/cQWxk4HLfjniuf0VrrRJ5HtrWFbgSGRGVhtj3AkHHUHJPrj0rP8W6jewWtvcXt4" +
        "13qk97ALaJ08wEZBAVe/POSQAcelQ5v237plKmvZ++i3qHw20mzjudc0YIspyBaM4kCHIJVe4YdB6joa9g/Zxgd4TPKjxbRuIcYAIHH4CuJlh06XXFspGEll" +
        "qNt5TMpzhmOByOu0+nTaBXSfCPW7+xjufDlxLa3ctmrRSmNzlY3BaKXJ/gIOCBnFc/1udRe/0NJYeMV7nU+VfilqTt8RvEDPcLM/9oS7pBJvD/N1B71hWjrd" +
        "zJJk7lHH1q14203Um8daxHqVulpc/a5DIghESjLH7qjjH0q5ZwJFbpDGqBV6kDk19RC3KmjwHfmaPSPgR4XW8vLjW70rEYgY7PzcENKejbepC9a9D1T+yIPP" +
        "8MyaxK97Ohlu51wZXTlgmwZC+vr0z6VheGYP7Jt3htUdpdKtWgilK7VeUruYADjj61k+GZJbC+U6izS3l23nSYC4CDpvPfJPSvExEnVnJ3PYoQVOCVjqtR1v" +
        "SvAGlK2nJP8AbrnDqJZiywrt4Y8gfKO3qfqaTTdRuJ9Ps73UrWTUdQvmzbxpDsAQkEMx6k9+P6Vzej2On3uu3s9/tv7jzQSCnyx9TtAxjOB9KWTWZf7YvdUs" +
        "RKLyMCKzEbMPL5xnGcD6n3rnVJWt17m7m079D02eUaVHJeX2uwvAmPIitlHnCbuc9z256VwEespqGsXN2twIFc485yAowcbV98/gKgu3njWCxvpw8zLmTJ5d" +
        "yMk8Uzwv4Ki8Rm5iubZjaaahlihMuFu3JONw9M5pKlFR1BzfML/bGg6bPcG9ku7hy6pBDp5V55JM/UYPvWNqniPRNc1/wjp2m2F7bXWna5Gz297s+dGcZHmA" +
        "kHBHQ+pq/wCKJ4YdOg0X/hHjo19BMk9rdwlVkjkQ8c4w4HpmuG1fQ7i1SXWR4g07ULh5/PkjXzPOR/vFzkbQQeeCeeK6cPCmlfqY13Ub8j1XxNNJZ60yNbva" +
        "vb38sscRJIUsSxGfTOCKsafr+jeGfiMFvl1OO5j0C3hnt7W0M8yPvZyzLnAxEVz3GRwcUy31oeL9T07WigdS8ck4UcswA5x/ESRzXKW2m+JZvFGreMrDU7C3" +
        "uZ7u7xm4LTAO5DN5W3ng8HIxjnFc1OnFOSnsbTlJpcpL+1fpdrbeKtI8SWt2sttqtouwlWUkIBg89Rgj6V5GlyFwUG4Hjg169+07pumQeBvCOoact5BHKZFC" +
        "XGcuQqhnwWIGSM4XivA7SVwfvcg8E9q9vA60Inj4pWqs+o/F2ryW0mnLatGYZpCJG6/UY781hapqkdkLvUZoT+7CRQhY/mdsZzjoMen49a1Lm0EultDHIslx" +
        "bsZVOOgbJGB9DVHxHpy6lo0SCIoiHdIoOCTjqfr6V4kZRTsz2JJtXRDbXqPocSSGO1uLmIv5YPPzdye/H61N4S0+PT4NjK5mYGWQ4GcgevbArCNu/wDbltck" +
        "KtvFAqhgpJGBVvQLu8XU9SYvISpEcYPZSOv5elW1vZkp7XKdjqSazqUk19bhUhfcmOAOT+Zrp/Dt2u68srq4c2d4pUtE2GQnqMr0rO1FdOgH2OIxeWyDzccF" +
        "Aec//X/KoNMb7FizU77aX7gAwAvXr/kD3pN6FJXZ2+heF4dGsGtpL+a/tJeFF3K0hUHsoz/KuUvvCX9navBZQnOmTyb5UFoqrgnJIIfIHXqO1aljeS6eSmm3" +
        "buRyyuAcegA7fSun8P8Aix5CljqdiJjGPmdcd+498ce9QqlndjcTyfxBoXi3RvHFtYaDcvdWtzJ/ocsTEKEzk7sEY29z3HNe76X4fs73xMI7+W3u7e1t1nme" +
        "KEBPtRA3sH3Z2+23HHPNZP2bwfPrcOub9QubiJgkabiMFvfPSrX7QmvXHhz4XQNaXJ0y6vJwCIMqfl6ZI5HPBz61s5RxEowOe0qKcj5//aC8SXHiLxkLW21b" +
        "7ZY6an2azM+Y/MAPzMuMKec9PTpXlc73EbkT26D6r/Iiusv9ctdYt3eS0QTuC8u1eJcdSU6Mw74wccg9q5S7BQgwkyRN1UtkY+v8j/8AXFe9SgoRUV0PGnPm" +
        "k2z7C+Imi6N4Z1cyaNPbPpxXyQsd2szxAdAcHPT19smuNnuPkZVw6P0+navMGvLyGSOdVUY5YqgO4555/KtLR9cu5LGa4MZaONwpQc54J4rycTgXF80dT1aG" +
        "LTXLI6nVC0mnAI6/uzyAM5Hpn+tVo3khFxNEPnn2q+G9evJ6Vh6f4t0+5nkt3l8iYk/JNx07/rV22uo8+WzK0TZwc9T6/nXN7OcHqjo9pGS0Zo6mNPgt2vru" +
        "Ishj8uVlOSccAAVDapDIkGpyTFRGoWNCwCxqeRkVWiuhOWtZgjq4yAe3vS20toiyWT2zmFuXlIyGOP1/kKTXcabexZ8PW97DenVfMM8bkEgchgTwf5DNdnZN" +
        "Z+T5wiZWnfLHH3VI4z+Nc/ouyyiVrOZPs8ny7Vb5cqOB7cZ59q1bbVrVrhY7XNzM2A5X7uR0JrGavr0NYvodt4F0u+udWE/lwmGPcLhW43LnIb8RnPoea8Y/" +
        "ak8Xp4g8RxaRYtm10xPJSWNsrN/tent1PQV6B8VvFkfg/wAEGwtb2E67qAG+33/NBCRySPfn/GvmCeVp5mkZiCxJIzmvTyzD/wDL1r0PNx9b/l2mUY5ZbeaN" +
        "kOGjkDj61JLIoaRI8BCxwPQZqSe2DgMScVAtlM7gRjr3Jr2bnlWaPYfKjnRfPQfNnkA7QPXnj/8AXWJeJ5Tsscs0McjbTIDtDcYPPAH1x0r1LXdA8V6pKt/N" +
        "Y6aplAXybe6t4yNpz93fxn1PXtRc/DrVpbu3El1pnkyoDxqkAWMnqGBbjBx6j3rHnT3OlxfQ8Yk8OQyBpRE2R1kLFifcDuKhk0+/tNhhubgpuXbg4GCeOK9A" +
        "17QLiy1hbOa4hItz8x+1q0LL6jafm9j061QSG3CZinjiy+DmQbWPfAOelNpNCWjOOGp61bjzBAjomfvDt7112iX0Wr6S9xEXHlgCaMnADdST61FeWlnLB5M1" +
        "7BIpyufNB59SR1qGKxjtdPu7azuoIo7hM/M45PYnHt2rnqYaE1sbU68oPcveILpp/Cdy1rHIZY5V+5lSBnliO4xW38EZEn8V6Ot/hbG6kcK5bAlKEArk8D7w" +
        "/OuashOuozXH9pWIUyodolG7Kfe69jnH416x4C8RfD/7XYWmpeENFsbe1DmK4eQSPG54OAuM5wM59M5rnnhkoctjeNdyle5W+MnwC1rVLw+I9A8UjVknjL+T" +
        "qf7uVeQqRiRcqx/hG7H3epzXzfrWnahouovY6rY3FhdxY8yG4Qo65GRkH1FfodZeK9ElsUTTNQ06K2T/AFRN7HGGVcfJ1zn/AHgRx15rG8Y+HfDHibU7fWbn" +
        "WvD8WoBRGJLmC1mkMWDmLJJxyevPoMZrSliJQ0kjCpQUndM+AyzlwMkeoqeOYKQPyr7+8R+Hvhd4o0yG18UWvh67mt4hbpKJI0kiwuPlZCGT1HOB2r5P+I/w" +
        "T8QaPrWpXPhxrHWNDhffbyQ6lA83lkZxsLBmK9CQOeuOa6addT0ehhOk467n/9k=";

    public static synchronized Bitmap getTilkajoBgBitmap() {
        if (bgBitmap == null || bgBitmap.isRecycled()) {
            try {
                byte[] bytes = Base64.decode(TILKAJO_BG_B64, Base64.DEFAULT);
                bgBitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
            } catch (Throwable t) {
                bgBitmap = null;
            }
        }
        return bgBitmap;
    }

    public static synchronized Bitmap getTilkajoIconBitmap() {
        if (iconBitmap == null || iconBitmap.isRecycled()) {
            try {
                byte[] bytes = Base64.decode(TILKAJO_ICON_B64, Base64.DEFAULT);
                iconBitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
            } catch (Throwable t) {
                iconBitmap = null;
            }
        }
        return iconBitmap;
    }

    public static synchronized Bitmap getCircleTilkajoIcon() {
        if (circleIconBitmap != null && !circleIconBitmap.isRecycled()) {
            return circleIconBitmap;
        }
        Bitmap src = getTilkajoIconBitmap();
        if (src == null) return null;

        try {
            int size = Math.min(src.getWidth(), src.getHeight());
            Bitmap output = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(output);
            Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);

            canvas.drawCircle(size / 2f, size / 2f, size / 2f, paint);
            paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
            canvas.drawBitmap(src, new Rect(0, 0, src.getWidth(), src.getHeight()), new Rect(0, 0, size, size), paint);

            circleIconBitmap = output;
            return circleIconBitmap;
        } catch (Throwable t) {
            return src;
        }
    }
}
