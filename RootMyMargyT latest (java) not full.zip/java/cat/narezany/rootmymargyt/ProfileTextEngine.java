package cat.narezany.rootmymargyt;

import android.app.Activity;
import android.view.View;

import cat.narezany.margyt.plugin.PluginContext;

/**
 * Переходный фасад на время рекода: реализация в {@link ProfileTextFeature}.
 * Форвардит старый публичный API для ещё не переписанных файлов (AstraExploitEngine,
 * RootPanel, RootWallpaperEngine). Удалить, когда они перейдут на ProfileTextFeature.
 */
public final class ProfileTextEngine {

    private ProfileTextEngine() {}

    public static final String KEY_TEXT_SHADOW_ENABLED = ProfileTextFeature.KEY_TEXT_SHADOW_ENABLED;
    public static final String KEY_TEXT_COLOR_ENABLED = ProfileTextFeature.KEY_TEXT_COLOR_ENABLED;
    public static final String KEY_TEXT_COLOR = ProfileTextFeature.KEY_TEXT_COLOR;

    public static final String[] COLOR_PRESET_NAMES = ProfileTextFeature.COLOR_PRESET_NAMES;
    public static final int[] COLOR_PRESET_VALUES = ProfileTextFeature.COLOR_PRESET_VALUES;

    public static boolean isShadowEnabled(PluginContext margyt) { return ProfileTextFeature.isShadowEnabled(margyt); }

    public static void setShadowEnabled(PluginContext margyt, boolean enabled) { ProfileTextFeature.setShadowEnabled(margyt, enabled); }

    public static boolean isTextColorEnabled(PluginContext margyt) { return ProfileTextFeature.isTextColorEnabled(margyt); }

    public static void setTextColorEnabled(PluginContext margyt, boolean enabled) { ProfileTextFeature.setTextColorEnabled(margyt, enabled); }

    public static int getTextColor(PluginContext margyt) { return ProfileTextFeature.getTextColor(margyt); }

    public static void setTextColor(PluginContext margyt, int color) { ProfileTextFeature.setTextColor(margyt, color); }

    public static String getTextColorSummary(PluginContext margyt) { return ProfileTextFeature.getTextColorSummary(margyt); }

    public static void applyProfileTextStyles(Activity activity, View profileContainer, PluginContext margyt) {
        ProfileTextFeature.applyProfileTextStyles(activity, profileContainer, margyt);
    }

    public static void holdTextColor(PluginContext margyt) { ProfileTextFeature.holdTextColor(margyt); }

    public static void resetProfileTextStyles(View profileContainer) { ProfileTextFeature.resetProfileTextStyles(profileContainer); }

    public static boolean isGradientNickname(android.widget.TextView tv, boolean hasGradientSetting, String myNick) {
        return ProfileTextFeature.isGradientNickname(tv, hasGradientSetting, myNick);
    }

    public static void showTextColorPickerDialog(Activity activity, PluginContext margyt, Runnable onDismiss) {
        ProfileTextFeature.showTextColorPickerDialog(activity, margyt, onDismiss);
    }
}
