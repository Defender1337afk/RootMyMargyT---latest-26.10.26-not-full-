package cat.narezany.rootmymargyt;

import android.annotation.TargetApi;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ImageDecoder;
import android.graphics.Movie;
import android.graphics.Paint;
import android.graphics.drawable.AnimatedImageDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.SystemClock;

import java.io.File;

/**
 * Анимированный фон (GIF, а на Android 9+ ещё и анимированный WebP).
 *
 * Рисуется в координатах исходника (0..width × 0..height) — масштаб и обрезку
 * задаёт drawable-хозяин через матрицу канвы, так же как для статичной картинки.
 *
 * Android 9+: AnimatedImageDrawable — кадры декодируются в отдельном потоке.
 * Старше: android.graphics.Movie, кадр рисуется в свой битмап (Movie на аппаратной
 * канве на части прошивок не рисуется), следующий кадр планируется через хозяина.
 */
abstract class AnimatedWallpaper {

    abstract int width();

    abstract int height();

    abstract void draw(Canvas canvas);

    /** Привязывает к хозяину и запускает. Повторный вызов безопасен. */
    abstract void start(Drawable host);

    abstract void stop();

    static AnimatedWallpaper load(File file, int maxDim) {
        if (file == null || !file.exists()) return null;
        if (Build.VERSION.SDK_INT >= 28) {
            AnimatedWallpaper modern = Modern.load(file, maxDim);
            if (modern != null) return modern;
        }
        return Legacy.load(file);
    }

    /** GIF87a / GIF89a, либо RIFF....WEBP (анимированный WebP понимает только Android 9+). */
    static boolean looksAnimated(byte[] head) {
        if (head == null || head.length < 12) return false;
        if (head[0] == 'G' && head[1] == 'I' && head[2] == 'F' && head[3] == '8') return true;
        return Build.VERSION.SDK_INT >= 28
            && head[0] == 'R' && head[1] == 'I' && head[2] == 'F' && head[3] == 'F'
            && head[8] == 'W' && head[9] == 'E' && head[10] == 'B' && head[11] == 'P';
    }

    @TargetApi(28)
    private static final class Modern extends AnimatedWallpaper {
        private final AnimatedImageDrawable drawable;

        private Modern(AnimatedImageDrawable drawable) {
            this.drawable = drawable;
        }

        static Modern load(File file, final int maxDim) {
            try {
                Drawable d = ImageDecoder.decodeDrawable(ImageDecoder.createSource(file), (decoder, info, source) -> {
                    int w = info.getSize().getWidth();
                    int h = info.getSize().getHeight();
                    int max = Math.max(w, h);
                    if (max > maxDim) {
                        float r = (float) maxDim / max;
                        decoder.setTargetSize(Math.max(1, Math.round(w * r)), Math.max(1, Math.round(h * r)));
                    }
                });
                // Одиночный кадр ImageDecoder отдаёт обычным BitmapDrawable — это не анимация
                if (!(d instanceof AnimatedImageDrawable)) return null;
                AnimatedImageDrawable a = (AnimatedImageDrawable) d;
                a.setRepeatCount(AnimatedImageDrawable.REPEAT_INFINITE);
                a.setBounds(0, 0, a.getIntrinsicWidth(), a.getIntrinsicHeight());
                return new Modern(a);
            } catch (Throwable t) {
                return null;
            }
        }

        @Override
        int width() {
            return drawable.getIntrinsicWidth();
        }

        @Override
        int height() {
            return drawable.getIntrinsicHeight();
        }

        @Override
        void draw(Canvas canvas) {
            drawable.draw(canvas);
        }

        @Override
        void start(Drawable host) {
            if (host instanceof Drawable.Callback && drawable.getCallback() != host) {
                drawable.setCallback((Drawable.Callback) host);
            }
            if (!drawable.isRunning()) drawable.start();
        }

        @Override
        void stop() {
            drawable.stop();
        }
    }

    @SuppressWarnings("deprecation")
    private static final class Legacy extends AnimatedWallpaper {
        private static final long FRAME_MS = 40;

        private final Movie movie;
        private final Bitmap frame;
        private final Canvas frameCanvas;
        private final Paint paint = new Paint(Paint.FILTER_BITMAP_FLAG);
        private long startedAt = 0;
        private Drawable host;
        private final Runnable tick = () -> {
            Drawable h = host;
            if (h != null) h.invalidateSelf();
        };

        private Legacy(Movie movie) {
            this.movie = movie;
            this.frame = Bitmap.createBitmap(movie.width(), movie.height(), Bitmap.Config.ARGB_8888);
            this.frameCanvas = new Canvas(frame);
        }

        static Legacy load(File file) {
            try {
                Movie m = Movie.decodeFile(file.getAbsolutePath());
                // duration() == 0 — один кадр, показываем как обычную картинку
                if (m == null || m.width() <= 0 || m.height() <= 0 || m.duration() <= 0) return null;
                return new Legacy(m);
            } catch (Throwable t) {
                return null;
            }
        }

        @Override
        int width() {
            return movie.width();
        }

        @Override
        int height() {
            return movie.height();
        }

        @Override
        void draw(Canvas canvas) {
            long now = SystemClock.uptimeMillis();
            if (startedAt == 0) startedAt = now;
            movie.setTime((int) ((now - startedAt) % movie.duration()));
            frame.eraseColor(0);
            movie.draw(frameCanvas, 0, 0);
            canvas.drawBitmap(frame, 0, 0, paint);

            Drawable h = host;
            if (h != null) {
                h.unscheduleSelf(tick);
                h.scheduleSelf(tick, now + FRAME_MS);
            }
        }

        @Override
        void start(Drawable host) {
            this.host = host;
        }

        @Override
        void stop() {
            Drawable h = host;
            host = null;
            if (h != null) h.unscheduleSelf(tick);
        }
    }
}
