package cat.narezany.rootmymargyt;

import android.app.Activity;
import android.os.SystemClock;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;

import cat.narezany.margyt.plugin.PluginContext;

/**
 * FeedCountsEngine — прячет цифры у кнопок ленты: лайки, комментарии, избранное, «поделиться».
 *
 * Кнопки берутся из реестра самого MargyT — FeedRail.slots (вид кнопки → её тип: 0 лайк,
 * 1 комментарии, 2 избранное, 3 поделиться), так же как нижняя панель берётся из NavBar.BARS.
 * Если реестра нет (другая версия мода), запасной путь: столбик чисел у правого края.
 *
 * Цифра становится прозрачной (alpha 0), место под ней остаётся — ничего не съезжает.
 * TikTok переписывает счётчики при пролистывании, поэтому скрытие проверяется на каждом
 * кадре до отрисовки — по списку уже найденных подписей, без обхода дерева. Новые кнопки
 * ищутся раз в 300 мс.
 */
public final class FeedCountsEngine {

    public static final String KEY_ENABLED = "hide_feed_counts";
    public static final String[] KEY_KIND = {
        "hide_count_like", "hide_count_comment", "hide_count_fav", "hide_count_share"
    };
    public static final String[] KIND_NAMES = {"Лайки", "Комментарии", "Избранное", "Поделиться"};

    private static final long RESCAN_MS = 300L;

    /** Подпись → тип кнопки (−1 — найдена запасным путём, тип неизвестен). */
    private static final WeakHashMap<TextView, Integer> labels = new WeakHashMap<>();
    /** Подпись → её alpha до нас. */
    private static final WeakHashMap<TextView, Float> originalAlpha = new WeakHashMap<>();
    private static long lastScan = 0L;
    private static final boolean[] hideKind = new boolean[4];

    private static Field slotsField;
    private static Field kindField;
    private static boolean reflectionBroken = false;
    private static boolean loggedFallback = false;

    private FeedCountsEngine() {}

    public static boolean isEnabled(PluginContext m) {
        return m != null && m.getBoolean(KEY_ENABLED, false);
    }

    public static boolean hides(PluginContext m, int kind) {
        return m == null || m.getBoolean(KEY_KIND[kind], true);
    }

    /** Из preDraw-наблюдателя, на каждом кадре. */
    public static void update(Activity activity, PluginContext m) {
        try {
            if (!isEnabled(m)) {
                if (!originalAlpha.isEmpty()) restoreAll();
                return;
            }
            for (int k = 0; k < 4; k++) hideKind[k] = hides(m, k);

            long now = SystemClock.uptimeMillis();
            if (now - lastScan >= RESCAN_MS) {
                lastScan = now;
                scan(activity, m);
            }
            enforce();
        } catch (Throwable ignored) {}
    }

    /** Дёшево: только по уже найденным подписям. */
    private static void enforce() {
        if (labels.isEmpty()) return;
        for (Map.Entry<TextView, Integer> e : labels.entrySet()) {
            TextView tv = e.getKey();
            if (tv == null || !tv.isAttachedToWindow()) continue;
            int kind = e.getValue();
            boolean hide = (kind < 0 ? anyKind() : hideKind[kind]) && hasDigit(tv.getText());
            if (hide) {
                if (tv.getAlpha() != 0f) {
                    if (!originalAlpha.containsKey(tv)) originalAlpha.put(tv, tv.getAlpha());
                    tv.setAlpha(0f);
                }
            } else {
                Float a = originalAlpha.remove(tv);
                if (a != null) tv.setAlpha(a);
            }
        }
    }

    private static boolean anyKind() {
        return hideKind[0] || hideKind[1] || hideKind[2] || hideKind[3];
    }

    private static boolean hasDigit(CharSequence cs) {
        if (cs == null) return false;
        for (int i = 0; i < cs.length(); i++) {
            char c = cs.charAt(i);
            if (c >= '0' && c <= '9') return true;
        }
        return false;
    }

    public static void restoreAll() {
        for (Map.Entry<TextView, Float> e : originalAlpha.entrySet()) {
            TextView tv = e.getKey();
            if (tv != null) tv.setAlpha(e.getValue());
        }
        originalAlpha.clear();
        labels.clear();
    }

    // ───────────────────────────── поиск кнопок

    private static void scan(Activity activity, PluginContext m) {
        Map<View, Integer> rail = readRail();
        if (rail != null) {
            for (Map.Entry<View, Integer> e : rail.entrySet()) {
                View slot = e.getKey();
                if (slot == null || !slot.isAttachedToWindow()) continue;
                collectTexts(slot, e.getValue(), 0);
            }
            return;
        }
        if (!loggedFallback && m != null) {
            loggedFallback = true;
            m.log("feed counts: MargyT rail registry unavailable, using right-column search");
        }
        if (activity == null || activity.getWindow() == null) return;
        View decor = activity.getWindow().getDecorView();
        int w = decor.getWidth(), h = decor.getHeight();
        if (w <= 0 || h <= 0) return;
        // Столбик чисел справа бывает не только в ленте (просмотры у превью в профиле) —
        // запасной поиск только там, где сверху «Для вас / Подписки»
        if (!(decor instanceof ViewGroup) || !ProfileLocator.hasVideoFeedMarkers((ViewGroup) decor)) return;
        fallbackScan(decor, w, h, 0);
    }

    /** FeedRail.slots: вид кнопки → тип. null, если реестр недоступен. */
    @SuppressWarnings("unchecked")
    static Map<View, Integer> readRail() {
        if (reflectionBroken) return null;
        try {
            if (slotsField == null) {
                Class<?> rail = Class.forName("cat.narezany.margyt.FeedRail");
                slotsField = rail.getDeclaredField("slots");
                slotsField.setAccessible(true);
                Class<?> state = Class.forName("cat.narezany.margyt.FeedRail$State");
                kindField = state.getDeclaredField("kind");
                kindField.setAccessible(true);
            }
            Map<View, Object> slots = (Map<View, Object>) slotsField.get(null);
            if (slots == null) return null;
            List<Map.Entry<View, Object>> copy;
            synchronized (slots) {
                copy = new ArrayList<>(slots.entrySet());
            }
            Map<View, Integer> out = new WeakHashMap<>();
            for (Map.Entry<View, Object> e : copy) {
                if (e.getKey() == null || e.getValue() == null) continue;
                int kind = kindField.getInt(e.getValue());
                if (kind >= 0 && kind < 4) out.put(e.getKey(), kind);
            }
            return out;
        } catch (Throwable t) {
            reflectionBroken = true;
            return null;
        }
    }

    private static void collectTexts(View v, int kind, int depth) {
        if (v == null || depth > 5) return;
        if (v instanceof TextView) {
            labels.put((TextView) v, kind);
            return;
        }
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) collectTexts(g.getChildAt(i), kind, depth + 1);
        }
    }

    /** Запасной путь: короткие числа («12.3K», «1,2 млн») у правого края, в средней части экрана. */
    private static void fallbackScan(View v, int w, int h, int depth) {
        if (v == null || depth > 40 || v.getVisibility() != View.VISIBLE) return;
        if (v instanceof TextView) {
            CharSequence cs = ((TextView) v).getText();
            if (cs != null && cs.length() > 0 && cs.length() <= 10 && hasDigit(cs) && v.isShown()) {
                int[] at = new int[2];
                v.getLocationOnScreen(at);
                if (at[0] >= w * 0.78f && at[1] >= h * 0.30f && at[1] <= h * 0.92f) {
                    labels.put((TextView) v, -1);
                }
            }
            return;
        }
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) fallbackScan(g.getChildAt(i), w, h, depth + 1);
        }
    }
}
