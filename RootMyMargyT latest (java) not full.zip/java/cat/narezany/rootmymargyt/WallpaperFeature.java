package cat.narezany.rootmymargyt;

import android.app.Activity;

import cat.narezany.margyt.plugin.PluginContext;
import cat.narezany.rootmymargyt.core.Feature;
import cat.narezany.rootmymargyt.core.Root;

/**
 * Кастомный фон профиля (фото/GIF/видео, шапка или весь профиль) — модуль-{@link Feature}
 * над проверенным {@link RootWallpaperEngine}. Движок device-проверенный, поэтому выведен
 * из god-entry в реестр без переписывания. Детектор «мы в профиле»
 * ({@code isLocalUserProfileThrottled}) остаётся в entry и кормит {@link Tick#inProfile}.
 */
public final class WallpaperFeature implements Feature {

    @Override public String id() { return "wallpaper"; }

    private static PluginContext m() { return Root.margyt(); }

    @Override
    public void onResume(Activity activity) {
        RootWallpaperEngine.updateProfileWallpaper(activity, m());
        RootWallpaperEngine.onResumed(activity, m());
    }

    @Override
    public void onScreen(Activity activity, String name) {
        RootWallpaperEngine.updateProfileWallpaper(activity, m());
    }

    @Override
    public void onPause(Activity activity) {
        RootWallpaperEngine.onPaused(activity);
    }

    @Override
    public void onTick(Activity activity, Tick tick) {
        // Движок сам ограничивает частоту обхода дерева.
        RootWallpaperEngine.updateProfileWallpaper(activity, m(), false);
    }
}
