package cat.narezany.rootmymargyt;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.os.SystemClock;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.SystemClock;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * WeatherOverlayView — интерактивный движок реалистичных погодных эффектов.
 * 
 * - Реалистичный дождь: многослойные струи, косой ветер, брызги на экране.
 * - Капли на стекле экрана (Screen Water Droplets): 3D-линзы с бликами.
 * - Снежинки Тилкайо: текстурированные HD снежинки с гироскопом (летят от наклона телефона).
 * - Не блокирует тапы и скролл (onTouchEvent возвращает false).
 */
public class WeatherOverlayView extends View implements SensorEventListener {

    public static final int MODE_OFF = 0;
    public static final int MODE_RAIN = 1;
    public static final int MODE_SNOW = 2;
    public static final int MODE_SAKURA = 3;

    private int currentMode = MODE_OFF;
    private boolean dropletsEnabled = true;

    private SensorManager sensorManager;
    private Sensor accelerometer;
    private boolean isSensorRegistered = false;
    private float targetWindX = 0f;
    private float targetWindY = 0f;
    private float currentWindX = 0f;
    private float currentWindY = 0f;

    private final Paint rainFgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint rainBgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint snowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dropBodyPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dropHighlightPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dropShadowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint trailPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint splashPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    private final Random random = new Random();

    // Дождевые струи (2 слоя: передний и задний)
    private static final int MAX_RAINDROPS = 120;
    private final float[] rainX = new float[MAX_RAINDROPS];
    private final float[] rainY = new float[MAX_RAINDROPS];
    private final float[] rainSpeed = new float[MAX_RAINDROPS];
    private final float[] rainLength = new float[MAX_RAINDROPS];
    private final boolean[] rainIsFg = new boolean[MAX_RAINDROPS];

    // Брызги на экране при падении струй
    private static class Splash {
        float x, y;
        float radius;
        int alpha;
    }
    private final List<Splash> splashes = new ArrayList<>();

    // Снежинки (текстурированные HD снежинки с вращением и ветром)
    private static final int MAX_SNOWFLAKES = 80;
    private final float[] snowX = new float[MAX_SNOWFLAKES];
    private final float[] snowY = new float[MAX_SNOWFLAKES];
    private final float[] snowSpeed = new float[MAX_SNOWFLAKES];
    private final float[] snowSize = new float[MAX_SNOWFLAKES];
    private final float[] snowPhase = new float[MAX_SNOWFLAKES];
    private final float[] snowRotation = new float[MAX_SNOWFLAKES];
    private final float[] snowRotSpeed = new float[MAX_SNOWFLAKES];
    private final int[] snowAlpha = new int[MAX_SNOWFLAKES];
    private final android.graphics.RectF flakeDst = new android.graphics.RectF();

    // Лепестки сакуры: кружатся, переворачиваются в воздухе и летят от наклона телефона
    private static final int MAX_PETALS = 46;
    private static final int[] PETAL_COLORS = {0xFFFFB7C5, 0xFFFF9EBB, 0xFFFFC9D6, 0xFFF8A5C2, 0xFFFFD1DC};
    private final float[] petalX = new float[MAX_PETALS];
    private final float[] petalY = new float[MAX_PETALS];
    private final float[] petalSpeed = new float[MAX_PETALS];
    private final float[] petalSize = new float[MAX_PETALS];
    private final float[] petalPhase = new float[MAX_PETALS];
    private final float[] petalRotation = new float[MAX_PETALS];
    private final float[] petalRotSpeed = new float[MAX_PETALS];
    private final float[] petalFlip = new float[MAX_PETALS];
    private final float[] petalFlipSpeed = new float[MAX_PETALS];
    private final int[] petalColor = new int[MAX_PETALS];
    private final int[] petalAlpha = new int[MAX_PETALS];
    private final Paint petalPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint petalLightPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    /** Лепесток высотой 1 с центром в нуле: острое основание снизу, круглый край с выемкой сверху. */
    private final android.graphics.Path petalPath = new android.graphics.Path();

    // Капли на стекле экрана
    private static final int MAX_SCREEN_DROPS = 16;
    private static class ScreenDrop {
        float x, y;
        float radius;
        float alpha; // 0..1
        float trickleSpeed;
        float trailY;
        long spawnTime;
        long lifeDuration;
        boolean trickling;
    }
    private final List<ScreenDrop> screenDrops = new ArrayList<>();
    private long lastDropSpawnTime = 0;

    private int viewWidth = 0;
    private int viewHeight = 0;

    public WeatherOverlayView(Context context) {
        super(context);
        initPaints();
    }

    private void initPaints() {
        rainFgPaint.setColor(0x99D0E8FF);
        rainFgPaint.setStrokeWidth(dp(1.6f));
        rainFgPaint.setStrokeCap(Paint.Cap.ROUND);

        rainBgPaint.setColor(0x44B0D8FF);
        rainBgPaint.setStrokeWidth(dp(1.0f));
        rainBgPaint.setStrokeCap(Paint.Cap.ROUND);

        snowPaint.setColor(Color.WHITE);
        snowPaint.setFilterBitmap(true);
        snowPaint.setStyle(Paint.Style.FILL);

        dropBodyPaint.setColor(0x28FFFFFF);
        dropBodyPaint.setStyle(Paint.Style.FILL);

        dropHighlightPaint.setColor(0xDDFFFFFF);
        dropHighlightPaint.setStyle(Paint.Style.FILL);

        dropShadowPaint.setColor(0x40000000);
        dropShadowPaint.setStyle(Paint.Style.STROKE);
        dropShadowPaint.setStrokeWidth(dp(1.8f));

        trailPaint.setColor(0x20FFFFFF);
        trailPaint.setStrokeCap(Paint.Cap.ROUND);

        splashPaint.setStyle(Paint.Style.STROKE);
        splashPaint.setColor(0x77CCE5FF);
        splashPaint.setStrokeWidth(dp(1.0f));

        petalPaint.setStyle(Paint.Style.FILL);
        petalLightPaint.setStyle(Paint.Style.FILL);
        petalLightPaint.setColor(0xFFFFEEF3);

        petalPath.moveTo(0f, 0.5f);
        petalPath.cubicTo(-0.55f, 0.25f, -0.52f, -0.42f, -0.2f, -0.5f);
        petalPath.quadTo(-0.07f, -0.52f, 0f, -0.38f);
        petalPath.quadTo(0.07f, -0.52f, 0.2f, -0.5f);
        petalPath.cubicTo(0.52f, -0.42f, 0.55f, 0.25f, 0f, 0.5f);
        petalPath.close();
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        updateSensorRegistration();
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        unregisterSensor();
    }

    public void setWeatherMode(int mode, boolean enableDroplets) {
        this.currentMode = mode;
        this.dropletsEnabled = enableDroplets;
        updateSensorRegistration();
        if (mode == MODE_OFF) {
            setVisibility(GONE);
        } else {
            setVisibility(VISIBLE);
            if (viewWidth > 0 && viewHeight > 0) {
                initParticles();
            }
            invalidate();
        }
    }

    private void updateSensorRegistration() {
        if ((currentMode == MODE_SNOW || currentMode == MODE_SAKURA) && isAttachedToWindow()) {
            registerSensor();
        } else {
            unregisterSensor();
        }
    }

    private void registerSensor() {
        if (isSensorRegistered) return;
        try {
            if (sensorManager == null) {
                sensorManager = (SensorManager) getContext().getSystemService(Context.SENSOR_SERVICE);
                if (sensorManager != null) {
                    accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
                }
            }
            if (sensorManager != null && accelerometer != null) {
                sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_GAME);
                isSensorRegistered = true;
            }
        } catch (Throwable ignored) {}
    }

    private void unregisterSensor() {
        if (!isSensorRegistered) return;
        try {
            if (sensorManager != null) {
                sensorManager.unregisterListener(this);
            }
            isSensorRegistered = false;
        } catch (Throwable ignored) {}
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            float ax = event.values[0]; // Наклон влево (-) / вправо (+)
            float ay = event.values[1]; // Наклон вперед / назад
            targetWindX = -ax * dp(0.70f);
            targetWindY = (ay - 7.5f) * dp(0.18f);
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {}

    public int getWeatherMode() {
        return currentMode;
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        return false;
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        viewWidth = w;
        viewHeight = h;
        if (w > 0 && h > 0) {
            initParticles();
        }
    }

    private void initParticles() {
        if (viewWidth <= 0 || viewHeight <= 0) return;

        for (int i = 0; i < MAX_RAINDROPS; i++) {
            rainX[i] = random.nextFloat() * (viewWidth + dp(120)) - dp(60);
            rainY[i] = random.nextFloat() * viewHeight;
            boolean isFg = random.nextBoolean();
            rainIsFg[i] = isFg;
            rainSpeed[i] = isFg ? (dp(24f) + random.nextFloat() * dp(18f)) : (dp(14f) + random.nextFloat() * dp(10f));
            rainLength[i] = isFg ? (dp(22f) + random.nextFloat() * dp(24f)) : (dp(12f) + random.nextFloat() * dp(14f));
        }

        for (int i = 0; i < MAX_SNOWFLAKES; i++) {
            snowX[i] = random.nextFloat() * viewWidth;
            snowY[i] = random.nextFloat() * viewHeight;
            float depth = random.nextFloat();
            snowSpeed[i] = dp(0.35f) + depth * dp(0.75f); // Плавный, медленный снегопад
            snowSize[i] = dp(8f) + depth * dp(10f); // Аккуратный меньший размер (8dp..18dp)
            snowPhase[i] = random.nextFloat() * 6.28f;
            snowAlpha[i] = (int) (130 + depth * 125);
            snowRotation[i] = random.nextFloat() * 360f;
            snowRotSpeed[i] = (random.nextFloat() - 0.5f) * 1.6f;
        }

        for (int i = 0; i < MAX_PETALS; i++) {
            petalX[i] = random.nextFloat() * viewWidth;
            petalY[i] = random.nextFloat() * viewHeight;
            float depth = random.nextFloat();
            petalSpeed[i] = dp(0.45f) + depth * dp(0.9f);
            petalSize[i] = dp(9f) + depth * dp(9f);
            petalPhase[i] = random.nextFloat() * 6.28f;
            petalRotation[i] = random.nextFloat() * 360f;
            petalRotSpeed[i] = (random.nextFloat() - 0.5f) * 2.4f;
            petalFlip[i] = random.nextFloat() * 6.28f;
            petalFlipSpeed[i] = 0.03f + random.nextFloat() * 0.05f;
            petalColor[i] = PETAL_COLORS[random.nextInt(PETAL_COLORS.length)];
            petalAlpha[i] = (int) (150 + depth * 105);
        }

        screenDrops.clear();
        splashes.clear();
        lastDropSpawnTime = SystemClock.uptimeMillis();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (currentMode == MODE_OFF || viewWidth <= 0 || viewHeight <= 0) return;

        long now = SystemClock.uptimeMillis();

        if (currentMode == MODE_RAIN) {
            drawRain(canvas);
            drawSplashes(canvas);
            if (dropletsEnabled) {
                updateAndDrawScreenDrops(canvas, now);
            }
        } else if (currentMode == MODE_SNOW) {
            drawSnow(canvas);
        } else if (currentMode == MODE_SAKURA) {
            drawSakura(canvas);
        }

        postInvalidateOnAnimation();
    }

    private void drawRain(Canvas canvas) {
        float slantX = dp(4.2f);
        for (int i = 0; i < MAX_RAINDROPS; i++) {
            float x1 = rainX[i];
            float y1 = rainY[i];
            float x2 = x1 - slantX;
            float y2 = y1 + rainLength[i];

            canvas.drawLine(x1, y1, x2, y2, rainIsFg[i] ? rainFgPaint : rainBgPaint);

            rainY[i] += rainSpeed[i];
            rainX[i] -= slantX * 0.42f;

            if (rainY[i] > viewHeight) {
                if (rainIsFg[i] && splashes.size() < 12 && random.nextFloat() < 0.25f) {
                    Splash s = new Splash();
                    s.x = x2;
                    s.y = viewHeight - dp(10);
                    s.radius = dp(3);
                    s.alpha = 200;
                    splashes.add(s);
                }
                rainY[i] = -rainLength[i] - random.nextFloat() * dp(40);
                rainX[i] = random.nextFloat() * (viewWidth + dp(100)) - dp(40);
            }
        }
    }

    private void drawSplashes(Canvas canvas) {
        for (int i = splashes.size() - 1; i >= 0; i--) {
            Splash s = splashes.get(i);
            splashPaint.setAlpha(s.alpha);
            canvas.drawCircle(s.x, s.y, s.radius, splashPaint);
            s.radius += dp(1.2f);
            s.alpha -= 25;
            if (s.alpha <= 0) {
                splashes.remove(i);
            }
        }
    }

    private void drawSnow(Canvas canvas) {
        android.graphics.Bitmap snowflakeBmp = SnowflakeAssets.getSnowflakeBitmap();

        // Плавная инерция ветра от гироскопа
        currentWindX += (targetWindX - currentWindX) * 0.12f;
        currentWindY += (targetWindY - currentWindY) * 0.12f;

        for (int i = 0; i < MAX_SNOWFLAKES; i++) {
            snowPhase[i] += 0.028f;
            float sway = (float) Math.sin(snowPhase[i]) * dp(0.9f);

            snowX[i] += sway + currentWindX;
            snowY[i] += snowSpeed[i] + currentWindY;
            snowRotation[i] += snowRotSpeed[i];

            float size = snowSize[i];
            snowPaint.setAlpha(snowAlpha[i]);

            if (snowflakeBmp != null && !snowflakeBmp.isRecycled()) {
                canvas.save();
                canvas.translate(snowX[i], snowY[i]);
                canvas.rotate(snowRotation[i]);
                flakeDst.set(-size / 2f, -size / 2f, size / 2f, size / 2f);
                canvas.drawBitmap(snowflakeBmp, null, flakeDst, snowPaint);
                canvas.restore();
            } else {
                canvas.drawCircle(snowX[i], snowY[i], size / 4f, snowPaint);
            }

            // Заворачивание по краям экрана при наклоне телефона
            if (snowX[i] < -size) {
                snowX[i] = viewWidth + size;
            } else if (snowX[i] > viewWidth + size) {
                snowX[i] = -size;
            }

            if (snowY[i] > viewHeight + size) {
                snowY[i] = -size - random.nextFloat() * dp(15);
                snowX[i] = random.nextFloat() * viewWidth;
                snowRotation[i] = random.nextFloat() * 360f;
            } else if (snowY[i] < -size * 2) {
                snowY[i] = viewHeight + size;
            }
        }
    }

    private void drawSakura(Canvas canvas) {
        currentWindX += (targetWindX - currentWindX) * 0.12f;
        currentWindY += (targetWindY - currentWindY) * 0.12f;
        float breeze = dp(0.35f); // лепестки легче снега: их всегда чуть сносит вбок

        for (int i = 0; i < MAX_PETALS; i++) {
            petalPhase[i] += 0.022f;
            petalFlip[i] += petalFlipSpeed[i];
            petalRotation[i] += petalRotSpeed[i];

            float sway = (float) Math.sin(petalPhase[i]) * dp(1.4f);
            petalX[i] += sway + breeze + currentWindX * 0.8f;
            petalY[i] += petalSpeed[i] + currentWindY;

            // Переворот в воздухе: лепесток сжимается по ширине, но не исчезает целиком
            float flip = (float) Math.cos(petalFlip[i]);
            float sx = (flip < 0 ? -1f : 1f) * (0.18f + 0.82f * Math.abs(flip));
            float size = petalSize[i];

            petalPaint.setColor(petalColor[i]);
            petalPaint.setAlpha(petalAlpha[i]);
            petalLightPaint.setAlpha((int) (petalAlpha[i] * 0.55f * Math.abs(flip)));

            canvas.save();
            canvas.translate(petalX[i], petalY[i]);
            canvas.rotate(petalRotation[i]);
            canvas.scale(size * sx, size);
            canvas.drawPath(petalPath, petalPaint);
            canvas.translate(0f, -0.1f);
            canvas.scale(0.5f, 0.5f);
            canvas.drawPath(petalPath, petalLightPaint);
            canvas.restore();

            if (petalX[i] < -size) {
                petalX[i] = viewWidth + size;
            } else if (petalX[i] > viewWidth + size) {
                petalX[i] = -size;
            }
            if (petalY[i] > viewHeight + size) {
                petalY[i] = -size - random.nextFloat() * dp(20);
                petalX[i] = random.nextFloat() * viewWidth;
            } else if (petalY[i] < -size * 2) {
                petalY[i] = viewHeight + size;
            }
        }
    }

    private void updateAndDrawScreenDrops(Canvas canvas, long now) {
        if (now - lastDropSpawnTime > 1600 && screenDrops.size() < MAX_SCREEN_DROPS) {
            ScreenDrop d = new ScreenDrop();
            d.x = dp(25) + random.nextFloat() * (viewWidth - dp(50));
            d.y = dp(50) + random.nextFloat() * (viewHeight * 0.70f);
            d.radius = dp(8f) + random.nextFloat() * dp(12f);
            d.alpha = 0.05f;
            d.trickleSpeed = dp(0.4f) + random.nextFloat() * dp(1.1f);
            d.trailY = d.y;
            d.spawnTime = now;
            d.lifeDuration = 8000 + random.nextInt(7000);
            d.trickling = random.nextBoolean();
            screenDrops.add(d);
            lastDropSpawnTime = now;
        }

        for (int i = screenDrops.size() - 1; i >= 0; i--) {
            ScreenDrop drop = screenDrops.get(i);
            long age = now - drop.spawnTime;

            if (age > drop.lifeDuration || drop.y > viewHeight + drop.radius) {
                screenDrops.remove(i);
                continue;
            }

            if (age < 500) {
                drop.alpha = (age / 500f) * 0.90f;
            } else if (age > drop.lifeDuration - 1500) {
                drop.alpha = ((drop.lifeDuration - age) / 1500f) * 0.90f;
            } else {
                drop.alpha = 0.90f;
            }

            if (drop.trickling && age > 1200) {
                drop.y += drop.trickleSpeed;
                trailPaint.setStrokeWidth(drop.radius * 0.65f);
                canvas.drawLine(drop.x, drop.trailY, drop.x, drop.y, trailPaint);
            }

            // Внешняя преломляющая тень
            dropShadowPaint.setAlpha((int) (drop.alpha * 90));
            canvas.drawCircle(drop.x, drop.y, drop.radius, dropShadowPaint);

            // Тело стеклянной линзы с размытием
            dropBodyPaint.setAlpha((int) (drop.alpha * 110));
            canvas.drawCircle(drop.x, drop.y, drop.radius - dp(1.0f), dropBodyPaint);

            // Яркий линзовый блик
            dropHighlightPaint.setAlpha((int) (drop.alpha * 220));
            float hlX = drop.x - drop.radius * 0.32f;
            float hlY = drop.y - drop.radius * 0.35f;
            canvas.drawCircle(hlX, hlY, drop.radius * 0.30f, dropHighlightPaint);

            // Вторичный блик снизу-справа
            dropHighlightPaint.setAlpha((int) (drop.alpha * 120));
            float hl2X = drop.x + drop.radius * 0.28f;
            float hl2Y = drop.y + drop.radius * 0.28f;
            canvas.drawCircle(hl2X, hl2Y, drop.radius * 0.18f, dropHighlightPaint);
        }
    }

    private float dp(float v) {
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }
}
