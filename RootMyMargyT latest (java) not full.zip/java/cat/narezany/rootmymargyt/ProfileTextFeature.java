package cat.narezany.rootmymargyt;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.ref.WeakReference;
import java.util.ArrayList;

import cat.narezany.margyt.plugin.PluginContext;
import cat.narezany.rootmymargyt.core.Feature;
import cat.narezany.rootmymargyt.core.HostBadges;
import cat.narezany.rootmymargyt.core.Root;

/**
 * Стили текста профиля и починка ника.
 *
 * 1. Тень текста для читаемости на кастомных обоях.
 * 2. Кастомный цвет надписей/счётчиков/био (градиентный ник не трогаем — проверка Shader).
 * 3. Device-проверенный фикс «1 после ника»: мод выбирает диапазон private-use меток заново
 *    при каждом старте, а TikTok кэширует ник со старой меткой — шрифт рисует её как «1».
 *    Отдаём сырой ник обработчику мода ({@code Badge.setText}), затем вырезаем оставшиеся
 *    устаревшие метки, сохраняя спаны бейджей и шейдер градиента.
 *
 * Рефлексия диапазона меток и {@code Badge.setText} — через {@link HostBadges}.
 */
public final class ProfileTextFeature implements Feature {

    public static final String KEY_TEXT_SHADOW_ENABLED = "root_profile_text_shadow";
    public static final String KEY_TEXT_COLOR_ENABLED = "root_profile_text_color_enabled";
    public static final String KEY_TEXT_COLOR = "root_profile_text_color";

    private static final int TAG_KEY_ORIG_TEXT_COLOR = 0x7F0B9990;
    private static final int TAG_KEY_MARK_WATCH = 0x7F0B9992;

    public static final String[] COLOR_PRESET_NAMES = {
        "Белый (по умолчанию)", "Чистый чёрный", "Неоновый циан", "Кибер-розовый", "Золотой",
        "Мятно-зеленый", "Лавандовый", "Кибер-оранжевый", "Светло-серебристый"
    };

    public static final int[] COLOR_PRESET_VALUES = {
        0xFFFFFFFF, 0xFF000000, 0xFF00F2FE, 0xFFFF007F, 0xFFFFD700,
        0xFF00E676, 0xFFB388FF, 0xFFFF9100, 0xFFE0E0E0
    };

    @Override public String id() { return "profile-text"; }

    private static PluginContext m() { return Root.margyt(); }

    @Override
    public void onTick(Activity activity, Tick tick) {
        if (activity == null || activity.isFinishing() || !tick.inProfile) return;
        View decor = activity.getWindow() != null ? activity.getWindow().getDecorView() : null;
        if (decor == null) return;
        if (tick.heavy) applyProfileTextStyles(activity, decor, m());
        // Цвет найденных надписей держим каждый кадр — иначе он мигал между обходами.
        holdTextColor(m());
    }

    // ─────────────────────────── настройки ───────────────────────────

    public static boolean isShadowEnabled(PluginContext margyt) {
        return margyt != null && margyt.getBoolean(KEY_TEXT_SHADOW_ENABLED, true);
    }

    public static void setShadowEnabled(PluginContext margyt, boolean enabled) {
        if (margyt != null) margyt.prefs().edit().putBoolean(KEY_TEXT_SHADOW_ENABLED, enabled).apply();
    }

    public static boolean isTextColorEnabled(PluginContext margyt) {
        return margyt != null && margyt.getBoolean(KEY_TEXT_COLOR_ENABLED, false);
    }

    public static void setTextColorEnabled(PluginContext margyt, boolean enabled) {
        if (margyt != null) margyt.prefs().edit().putBoolean(KEY_TEXT_COLOR_ENABLED, enabled).apply();
    }

    public static int getTextColor(PluginContext margyt) {
        return margyt == null ? 0xFFFFFFFF : margyt.getInt(KEY_TEXT_COLOR, 0xFFFFFFFF);
    }

    public static void setTextColor(PluginContext margyt, int color) {
        if (margyt != null) margyt.prefs().edit().putInt(KEY_TEXT_COLOR, color).apply();
    }

    public static String getTextColorSummary(PluginContext margyt) {
        if (!isTextColorEnabled(margyt)) return "По умолчанию";
        int col = getTextColor(margyt);
        for (int i = 0; i < COLOR_PRESET_VALUES.length; i++) {
            if (COLOR_PRESET_VALUES[i] == col) return COLOR_PRESET_NAMES[i];
        }
        return String.format("#%06X", (0xFFFFFF & col));
    }

    // ─────────────────────────── применение стилей ───────────────────────────

    /** Надписи, перекрашенные последним обходом: их цвет держим каждый кадр. */
    private static final ArrayList<WeakReference<TextView>> COLORED = new ArrayList<>();

    public static void applyProfileTextStyles(Activity activity, View profileContainer, PluginContext margyt) {
        if (activity == null || profileContainer == null || margyt == null) return;
        boolean shadowOn = isShadowEnabled(margyt);
        boolean colorOn = isTextColorEnabled(margyt);
        int customColor = getTextColor(margyt);
        int gradChoice = margyt.getInt("nick_gradient_choice", 0);
        String savedNick = margyt.prefs().getString("local_my_account_name", "");
        COLORED.clear();
        walkAndApplyStyles(profileContainer, shadowOn, colorOn, customColor, gradChoice > 0, savedNick, 0, margyt);
    }

    /**
     * Обход идёт раз в 250 мс, а TikTok возвращает свой цвет при каждой перепривязке шапки —
     * между обходами текст успевал мигнуть. Сверяем цвет уже найденных надписей каждый кадр:
     * одно сравнение на надпись, обход дерева не нужен.
     */
    public static void holdTextColor(PluginContext margyt) {
        if (COLORED.isEmpty() || !isTextColorEnabled(margyt)) return;
        int customColor = getTextColor(margyt);
        for (int i = COLORED.size() - 1; i >= 0; i--) {
            TextView tv = COLORED.get(i).get();
            if (tv == null) { COLORED.remove(i); continue; }
            if (tv.getPaint() != null && tv.getPaint().getShader() != null) continue; // градиентный ник не трогаем
            if (tv.getCurrentTextColor() != customColor) tv.setTextColor(customColor);
        }
    }

    private static void walkAndApplyStyles(View v, boolean shadowOn, boolean colorOn, int customColor,
                                           boolean hasGradientNick, String myNick, int depth, PluginContext margyt) {
        if (v == null || depth > 25 || !v.isShown()) return;

        if (v instanceof TextView && !(v instanceof EditText)) {
            CharSequence raw = ((TextView) v).getText();
            if (raw != null && hasStrayMarks(raw)) {
                repairModMarks((TextView) v, raw, margyt);
                watchForMarks((TextView) v, margyt);
            }
        }

        if (v instanceof TextView) {
            TextView tv = (TextView) v;
            CharSequence cs = tv.getText();
            if (cs != null && cs.length() > 0) {
                boolean isGradient = isGradientNickname(tv, hasGradientNick, myNick);

                if (!isGradient) {
                    if (colorOn) {
                        if (tv.getTag(TAG_KEY_ORIG_TEXT_COLOR) == null) {
                            tv.setTag(TAG_KEY_ORIG_TEXT_COLOR, tv.getCurrentTextColor());
                        }
                        tv.setTextColor(customColor);
                        COLORED.add(new WeakReference<>(tv));
                    } else {
                        Object orig = tv.getTag(TAG_KEY_ORIG_TEXT_COLOR);
                        if (orig instanceof Integer) {
                            tv.setTextColor((Integer) orig);
                            tv.setTag(TAG_KEY_ORIG_TEXT_COLOR, null);
                        }
                    }
                }

                if (shadowOn) {
                    tv.setShadowLayer(8f, 0f, 2f, 0xDE000000); // 87% чёрный
                } else {
                    tv.setShadowLayer(0f, 0f, 0f, 0);
                }
            }
        }

        if (v instanceof ViewGroup) {
            ViewGroup vg = (ViewGroup) v;
            for (int i = 0; i < vg.getChildCount(); i++) {
                walkAndApplyStyles(vg.getChildAt(i), shadowOn, colorOn, customColor, hasGradientNick, myNick, depth + 1, margyt);
            }
        }
    }

    public static void resetProfileTextStyles(View profileContainer) {
        if (profileContainer == null) return;
        walkAndResetStyles(profileContainer, 0);
    }

    private static void walkAndResetStyles(View v, int depth) {
        if (v == null || depth > 25) return;
        if (v instanceof TextView) {
            TextView tv = (TextView) v;
            Object orig = tv.getTag(TAG_KEY_ORIG_TEXT_COLOR);
            if (orig instanceof Integer) {
                tv.setTextColor((Integer) orig);
                tv.setTag(TAG_KEY_ORIG_TEXT_COLOR, null);
            }
            tv.setShadowLayer(0f, 0f, 0f, 0);
        }
        if (v instanceof ViewGroup) {
            ViewGroup vg = (ViewGroup) v;
            for (int i = 0; i < vg.getChildCount(); i++) walkAndResetStyles(vg.getChildAt(i), depth + 1);
        }
    }

    public static boolean isGradientNickname(TextView tv, boolean hasGradientSetting, String myNick) {
        if (tv == null) return false;
        if (tv.getPaint() != null && tv.getPaint().getShader() != null) return true;
        if (hasGradientSetting) {
            CharSequence cs = tv.getText();
            if (cs != null) {
                String s = cs.toString().trim();
                if (myNick != null && !myNick.isEmpty() && s.contains(myNick)) return true;
                if (tv.getTextSize() >= 48 && !s.startsWith("@") && !s.matches("^\\d+.*$") &&
                        !s.contains("Подпис") && !s.contains("Лайк") && !s.contains("Редакт")) {
                    return true;
                }
            }
        }
        return false;
    }

    // ─────────────────────────── починка меток ника («1») ───────────────────────────

    private static boolean isPua(char c) { return c >= '' && c <= ''; }

    /**
     * Лишний private-use символ в нике: не под картинкой бейджа (ImageSpan) и в тексте с буквами.
     * Это метки текущего запуска и устаревшие метки прошлых; иконочные надписи TikTok
     * (одни PUA без букв) не трогаем.
     */
    private static boolean hasStrayMarks(CharSequence cs) {
        boolean letters = false, stray = false;
        android.text.Spanned spanned = cs instanceof android.text.Spanned ? (android.text.Spanned) cs : null;
        for (int i = 0; i < cs.length(); i++) {
            char c = cs.charAt(i);
            if (!isPua(c)) {
                if (Character.isLetterOrDigit(c)) letters = true;
                continue;
            }
            if (spanned != null && spanned.getSpans(i, i + 1, android.text.style.ImageSpan.class).length > 0) continue;
            stray = true;
        }
        return letters && stray;
    }

    /**
     * Отдаём ник моду ({@code Badge.setText}): свои метки он превратит в градиент и бейджи.
     * Оставшиеся без картинки (чужие/устаревшие) вырезаем сами, сохраняя спаны и шейдер.
     */
    private static void repairModMarks(TextView tv, CharSequence cs, PluginContext margyt) {
        try {
            // Со спанами, не toString(): в нике лежит иконка TikTok (ImageSpan над заглушкой),
            // без спана заглушка рисуется как «1».
            HostBadges.setText(tv, new android.text.SpannableStringBuilder(cs));

            CharSequence now = tv.getText();
            if (now == null || !hasStrayMarks(now)) return;
            android.text.SpannableStringBuilder out = new android.text.SpannableStringBuilder(now);
            for (int i = out.length() - 1; i >= 0; i--) {
                if (!isPua(out.charAt(i))) continue;
                if (out.getSpans(i, i + 1, android.text.style.ImageSpan.class).length > 0) continue;
                out.delete(i, i + 1);
            }
            int end = out.length();
            while (end > 0 && (out.charAt(end - 1) == ' ' || out.charAt(end - 1) == ' ')) end--;
            if (end < out.length()) out.delete(end, out.length());
            tv.setText(out, TextView.BufferType.SPANNABLE);
        } catch (Throwable ignored) {}
    }

    /**
     * Обход раз в 250 мс проигрывал TikTok: шапка перезаписывает ник при каждой перепривязке.
     * Слушатель текста срабатывает прямо внутри setText, до кадра — метка не успевает показаться.
     */
    private static void watchForMarks(final TextView tv, final PluginContext margyt) {
        if (Boolean.TRUE.equals(tv.getTag(TAG_KEY_MARK_WATCH))) return;
        tv.setTag(TAG_KEY_MARK_WATCH, Boolean.TRUE);
        tv.addTextChangedListener(new TextWatcher() {
            private boolean busy;
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {}
            @Override public void afterTextChanged(Editable s) {
                if (busy || s == null || !hasStrayMarks(s)) return;
                busy = true;
                try { repairModMarks(tv, s, margyt); } finally { busy = false; }
            }
        });
    }

    // ─────────────────────────── диалог выбора цвета ───────────────────────────

    public static void showTextColorPickerDialog(final Activity activity, final PluginContext margyt, final Runnable onDismiss) {
        if (activity == null || activity.isFinishing()) return;

        final Dialog dialog = new Dialog(activity);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            dialog.getWindow().setDimAmount(0.65f);
        }

        int dp12 = dp(activity, 12), dp16 = dp(activity, 16), dp20 = dp(activity, 20);

        LinearLayout box = new LinearLayout(activity);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp20, dp20, dp20, dp16);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xFF161823);
        bg.setCornerRadius(dp(activity, 20));
        box.setBackground(bg);

        TextView title = new TextView(activity);
        title.setText("Цвет текста профиля");
        title.setTextColor(0xFFFFFFFF);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        title.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        title.setGravity(Gravity.CENTER);
        box.addView(title);

        TextView sub = new TextView(activity);
        sub.setText("Выберите цвет для надписей, цифр и био в профиле.\nНа градиентный никнейм цвет не накладывается.");
        sub.setTextColor(0xAAFFFFFF);
        sub.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        sub.setPadding(0, dp(activity, 6), 0, dp16);
        sub.setGravity(Gravity.CENTER);
        box.addView(sub);

        ScrollView scroll = new ScrollView(activity);
        scroll.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(activity, 280)));

        LinearLayout list = new LinearLayout(activity);
        list.setOrientation(LinearLayout.VERTICAL);

        int currentColor = getTextColor(margyt);
        boolean isCustomEnabled = isTextColorEnabled(margyt);

        for (int i = 0; i < COLOR_PRESET_NAMES.length; i++) {
            final int colorVal = COLOR_PRESET_VALUES[i];
            final String name = COLOR_PRESET_NAMES[i];
            boolean selected = isCustomEnabled && currentColor == colorVal;

            LinearLayout row = new LinearLayout(activity);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp16, dp12, dp16, dp12);
            row.setClickable(true);
            row.setFocusable(true);
            GradientDrawable rowBg = new GradientDrawable();
            rowBg.setColor(selected ? 0x22FFFFFF : 0x08FFFFFF);
            rowBg.setCornerRadius(dp(activity, 12));
            row.setBackground(rowBg);
            LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            rlp.bottomMargin = dp(activity, 8);
            row.setLayoutParams(rlp);

            View dot = new View(activity);
            int dotSize = dp(activity, 22);
            LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(dotSize, dotSize);
            dlp.rightMargin = dp16;
            dot.setLayoutParams(dlp);
            GradientDrawable dotBg = new GradientDrawable();
            dotBg.setShape(GradientDrawable.OVAL);
            dotBg.setColor(colorVal);
            dotBg.setStroke(dp(activity, 1.5f), 0x55FFFFFF);
            dot.setBackground(dotBg);
            row.addView(dot);

            TextView label = new TextView(activity);
            label.setText(name);
            label.setTextColor(selected ? 0xFF00F2FE : 0xFFFFFFFF);
            label.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
            label.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            row.addView(label);

            if (selected) {
                TextView check = new TextView(activity);
                check.setText("✓");
                check.setTextColor(0xFF00F2FE);
                check.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
                check.setTypeface(Typeface.DEFAULT_BOLD);
                row.addView(check);
            }

            row.setOnClickListener(v -> {
                setTextColorEnabled(margyt, true);
                setTextColor(margyt, colorVal);
                dialog.dismiss();
                if (onDismiss != null) onDismiss.run();
                Toast.makeText(activity, "Установлен цвет: " + name, Toast.LENGTH_SHORT).show();
            });
            list.addView(row);
        }

        LinearLayout hexBox = new LinearLayout(activity);
        hexBox.setOrientation(LinearLayout.VERTICAL);
        hexBox.setPadding(dp16, dp12, dp16, dp12);
        GradientDrawable hexBg = new GradientDrawable();
        hexBg.setColor(0x14FFFFFF);
        hexBg.setCornerRadius(dp(activity, 12));
        hexBox.setBackground(hexBg);
        LinearLayout.LayoutParams hlp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        hlp.bottomMargin = dp(activity, 8);
        hexBox.setLayoutParams(hlp);

        TextView hexTitle = new TextView(activity);
        hexTitle.setText("Свой HEX цвет (#RRGGBB):");
        hexTitle.setTextColor(0xCCFFFFFF);
        hexTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        hexBox.addView(hexTitle);

        final EditText hexInput = new EditText(activity);
        hexInput.setHint("#FF5500");
        hexInput.setHintTextColor(0x66FFFFFF);
        hexInput.setTextColor(0xFFFFFFFF);
        hexInput.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        hexInput.setSingleLine(true);
        hexBox.addView(hexInput);

        TextView btnApplyHex = new TextView(activity);
        btnApplyHex.setText("Применить HEX");
        btnApplyHex.setTextColor(0xFF000000);
        btnApplyHex.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        btnApplyHex.setTypeface(Typeface.DEFAULT_BOLD);
        btnApplyHex.setGravity(Gravity.CENTER);
        btnApplyHex.setPadding(0, dp(activity, 10), 0, dp(activity, 10));
        GradientDrawable hexBtnBg = new GradientDrawable();
        hexBtnBg.setColor(0xFF00F2FE);
        hexBtnBg.setCornerRadius(dp(activity, 10));
        btnApplyHex.setBackground(hexBtnBg);
        btnApplyHex.setOnClickListener(v -> {
            String txt = hexInput.getText().toString().trim();
            if (!txt.startsWith("#")) txt = "#" + txt;
            try {
                int c = Color.parseColor(txt);
                setTextColorEnabled(margyt, true);
                setTextColor(margyt, c);
                dialog.dismiss();
                if (onDismiss != null) onDismiss.run();
                Toast.makeText(activity, "Установлен цвет: " + txt, Toast.LENGTH_SHORT).show();
            } catch (Throwable t) {
                Toast.makeText(activity, "Неверный формат HEX цвета!", Toast.LENGTH_SHORT).show();
            }
        });
        hexBox.addView(btnApplyHex);
        list.addView(hexBox);

        scroll.addView(list);
        box.addView(scroll);

        TextView btnReset = new TextView(activity);
        btnReset.setText("Сбросить на цвета по умолчанию");
        btnReset.setTextColor(0xAAFFFFFF);
        btnReset.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        btnReset.setGravity(Gravity.CENTER);
        btnReset.setPadding(0, dp16, 0, dp(activity, 8));
        btnReset.setOnClickListener(v -> {
            setTextColorEnabled(margyt, false);
            dialog.dismiss();
            if (onDismiss != null) onDismiss.run();
            Toast.makeText(activity, "Цвета сброшены по умолчанию", Toast.LENGTH_SHORT).show();
        });
        box.addView(btnReset);

        dialog.setContentView(box);
        dialog.show();
    }

    private static int dp(Context ctx, float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, ctx.getResources().getDisplayMetrics());
    }
}
