package cat.narezany.rootmymargyt;

import java.util.Locale;
import java.util.Random;

/**
 * ClawdBrain — «мысли» Clawd: настроение комментария и тема видео по тексту.
 *
 * Картинку видео Clawd не видит: всё работает на телефоне, без сети. Он читает то, что
 * написано на экране, — подпись и хэштеги видео, текст комментария — и ищет в них слова
 * и эмодзи. Чистая Java без Android: проверяется тестами.
 *
 * Как сравниваются слова (иначе «ого» находилось бы в «много», а «кот» — в «который»):
 * - «основа» — слово должно с неё начинаться: «смешн» → «смешно», «смешной»;
 * - «=слово» — только целиком: «=ору», «=ого», «=кот»;
 * - эмодзи и прочее не-буквенное — где угодно.
 * Буква «ё» считается за «е» и в тексте, и в словаре.
 */
public final class ClawdBrain {

    public static final int NEUTRAL = 0, FUNNY = 1, SAD = 2, ANGRY = 3, LOVE = 4, WOW = 5;

    private static final String[][] MOOD_WORDS = {
        {},
        // FUNNY
        {"ахах", "хаха", "=хд", "=xd", "ржу", "ржак", "ржач", "оржал", "орнул", "=ору", "угар",
            "смешн", "=лол", "=lol", "lmao", "haha", "=кек", "😂", "🤣", "😹", "💀", "😆"},
        // SAD
        {"грустн", "грущу", "печал", "жаль", "плачу", "плак", "слез", "скучаю", "тоск", "одиноко",
            "=rip", "сочувств", "😢", "😭", "💔", "🥺", "😔", "😞"},
        // ANGRY
        {"бесит", "бесят", "злит", "=злой", "злюсь", "ненавиж", "отвратит", "кринж", "позор", "достал", "раздража",
            "=фу", "фууу", "😡", "🤬", "😤", "👎", "😠"},
        // LOVE
        {"люблю", "обожаю", "красив", "мило", "милаш", "лучш", "кайф", "шедевр", "прекрасн", "топчик",
            "❤", "😍", "🥰", "💕", "💖", "💗", "😘", "🫶"},
        // WOW
        {"вау", "=ого", "офиге", "невероят", "жесть", "обалде", "=wow", "=omg", "😱", "😮", "🤯", "😳"},
    };

    private static final String[][] MOOD_PHRASES = {
        {},
        {"Комментарий от %s меня рассмешил! 😂", "Ахах, %s, ну ты даёшь 😂"},
        {"Комментарий от %s меня расстроил 😢", "Из-за комментария от %s я загрустил 😢"},
        {"Комментарий от %s меня рассердил! 😠", "%s, ну зачем так 😠"},
        {"Комментарий от %s меня порадовал ❤", "%s пишет мило ❤"},
        {"Комментарий от %s меня удивил 😮", "Ого, %s, правда? 😮"},
    };

    /** Темы видео: слова (в подписи и хэштегах) → фраза. Порядок — приоритет. */
    private static final String[][] TOPICS = {
        {"Это видео про котиков 🐱", "=кот", "=коты", "котик", "котэ", "котен", "котят", "кошк", "kitten", "=cat", "=cats",
            "мяу", "🐱", "🐈"},
        {"Тут собакен! 🐶", "собак", "собач", "=пес", "=пса", "псин", "щен", "=dog", "dogs", "puppy", "🐶", "🐕"},
        {"Аниме! 🌸", "аниме", "anime", "манга", "manga"},
        {"Видео про игры 🎮", "=игра", "=игры", "игров", "играю", "game", "gaming", "minecraft", "майнкрафт", "roblox",
            "роблокс", "dota", "fortnite", "brawl", "standoff", "=cs2", "геймер", "🎮"},
        {"Кто-то готовит что-то вкусное 🍳", "рецепт", "готовлю", "готовим", "кухн", "вкусн", "=еда", "food", "recipe",
            "cooking", "=торт", "пицц", "🍕", "🍔", "🍳"},
        {"Тут танцуют 💃", "танц", "dance", "хореограф", "💃", "🕺"},
        {"Музыкальное видео 🎵", "песн", "музык", "кавер", "cover", "гитар", "song", "music", "🎵", "🎶", "🎸"},
        {"Тут про спорт ⚽", "спорт", "футбол", "football", "gym", "качалк", "трениров", "workout", "бокс", "⚽", "🏀"},
        {"Тачки! 🚗", "машин", "тачк", "автомоб", "дрифт", "drift", "=bmw", "mercedes", "🚗", "🏎"},
        {"Что-то про технологии 💻", "программ", "кодинг", "coding", "нейросет", "айфон", "iphone", "android", "гаджет",
            "техник", "💻", "📱"},
        {"Полезное видео 📚", "лайфхак", "lifehack", "учеб", "школ", "егэ", "огэ", "урок", "study", "📚"},
        {"Про стиль и красоту 💄", "макияж", "makeup", "=мода", "fashion", "outfit", "beauty", "💄"},
        {"Красивые места 🌄", "природ", "закат", "=горы", "=море", "путешеств", "travel", "nature", "🌄", "🏔"},
        {"Мемное видео 😂", "=мем", "=мемы", "meme", "прикол", "юмор", "funny", "ржак", "угар"},
    };

    private ClawdBrain() {}

    static String norm(String s) {
        if (s == null) return "";
        return " " + s.toLowerCase(Locale.ROOT).replace('ё', 'е').replace(' ', ' ') + " ";
    }

    private static boolean isWordChar(char c) {
        return Character.isLetterOrDigit(c);
    }

    /** Сколько раз встречается слово по правилам из шапки класса. */
    static int count(String t, String entry) {
        boolean whole = entry.startsWith("=");
        String w = (whole ? entry.substring(1) : entry).replace('ё', 'е');
        if (w.isEmpty()) return 0;
        boolean wordy = isWordChar(w.charAt(0));
        int n = 0, from = 0;
        while ((from = t.indexOf(w, from)) >= 0) {
            boolean startOk = !wordy || from == 0 || !isWordChar(t.charAt(from - 1));
            int end = from + w.length();
            boolean endOk = !whole || end >= t.length() || !isWordChar(t.charAt(end));
            if (startOk && endOk) n++;
            from = end;
        }
        return n;
    }

    /** Настроение текста. NEUTRAL, если ничего не нашлось или чувства поровну. */
    public static int mood(String text) {
        return moodWithScore(text)[0];
    }

    /** [настроение, сила] — сила нужна, чтобы выбрать самый эмоциональный комментарий. */
    public static int[] moodWithScore(String text) {
        String t = norm(text);
        int best = NEUTRAL, bestScore = 0, second = 0;
        for (int m = 1; m < MOOD_WORDS.length; m++) {
            int score = 0;
            for (String w : MOOD_WORDS[m]) score += count(t, w);
            if (score > bestScore) {
                second = bestScore;
                bestScore = score;
                best = m;
            } else if (score > second) {
                second = score;
            }
        }
        // «смешно и грустно» одинаково — не понять, молчим
        if (bestScore == 0 || bestScore == second) return new int[] {NEUTRAL, 0};
        return new int[] {best, bestScore};
    }

    public static String moodPhrase(int mood, String user, Random rnd) {
        if (mood <= NEUTRAL || mood >= MOOD_PHRASES.length) return null;
        String[] variants = MOOD_PHRASES[mood];
        return String.format(Locale.ROOT, variants[rnd.nextInt(variants.length)], shortName(user));
    }

    /** Фраза о теме видео или null, если тема не угадалась. */
    public static String topic(String caption) {
        String t = norm(caption);
        if (t.trim().isEmpty()) return null;
        for (String[] topic : TOPICS) {
            for (int i = 1; i < topic.length; i++) {
                if (count(t, topic[i]) > 0) return topic[0];
            }
        }
        return null;
    }

    /** Что сказать про видео: тема, а если не угадалась — автор и начало подписи. */
    public static String videoPhrase(String caption, String author) {
        String topic = topic(caption);
        if (topic != null) return topic;
        String c = caption == null ? "" : caption.replaceAll("#\\S+", "").replaceAll("\\s+", " ").trim();
        String a = author == null ? "" : author.trim();
        if (!c.isEmpty()) {
            String start = c.length() > 22 ? c.substring(0, 22).trim() + "…" : c;
            return a.isEmpty() ? "Смотрим: «" + start + "»" : "Видео от " + shortName(a) + ": «" + start + "»";
        }
        return a.isEmpty() ? null : "Смотрим " + shortName(a) + " 👀";
    }

    /** Имя покороче, чтобы облачко не растягивалось на весь экран. */
    static String shortName(String user) {
        if (user == null || user.trim().isEmpty()) return "кого-то";
        String u = user.trim();
        return u.length() > 18 ? u.substring(0, 17) + "…" : u;
    }
}
