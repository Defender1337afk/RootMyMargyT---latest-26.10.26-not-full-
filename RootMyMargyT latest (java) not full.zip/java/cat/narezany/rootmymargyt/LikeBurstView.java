package cat.narezany.rootmymargyt;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import java.util.ArrayList;
import java.util.Random;

import cat.narezany.margyt.plugin.PluginContext;
import cat.narezany.rootmymargyt.core.Host;

/**
 * «Салют при лайке»: лайкнул видео (кнопкой или двойным тапом) — у пальца всплеск сердечек и искр,
 * летящих вверх и гаснущих. Цвет — под акцент темы MargyT. Оверлей на декоре, касания не перехватывает.
 *
 * Эффект завязан на {@code FunFx.onLike}, который надёжно вызывает TouchSpy при реальном лайке —
 * поэтому работает без чтения кадра/плеера.
 */
public final class LikeBurstView extends View {

    public static final String TAG = "rootmymargyt_like_burst";
    public static final String KEY_ENABLED = "like_burst_enabled";

    private static final class P {
        float x, y, vx, vy, rot, vrot, size;
        long born, life;
        int color;
        boolean heart;
    }

    private final ArrayList<P> parts = new ArrayList<>();
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Random rnd = new Random();
    private long lastFrame = 0;

    public LikeBurstView(Context context) {
        super(context);
        setClickable(false);
        setFocusable(false);
        paint.setTextAlign(Paint.Align.CENTER);
    }

    public static boolean isEnabled(PluginContext m) {
        return m != null && m.getBoolean(KEY_ENABLED, true); // по умолчанию вкл — это приятная мелочь
    }

    public static void setEnabled(PluginContext m, boolean on) {
        if (m != null) m.prefs().edit().putBoolean(KEY_ENABLED, on).apply();
    }

    /** Показать всплеск в точке (screen-coords) поверх activity, если фича включена. */
    public static void burst(Activity activity, PluginContext m, float rawX, float rawY) {
        if (activity == null || activity.isFinishing() || activity.getWindow() == null) return;
        if (!isEnabled(m)) return;
        ViewGroup decor = (ViewGroup) activity.getWindow().getDecorView();
        LikeBurstView v = (LikeBurstView) decor.findViewWithTag(TAG);
        if (v == null) {
            v = new LikeBurstView(activity);
            v.setTag(TAG);
            decor.addView(v, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        }
        int[] dLoc = new int[2];
        decor.getLocationOnScreen(dLoc);
        v.spawn(rawX - dLoc[0], rawY - dLoc[1]);
        v.bringToFront();
    }

    private void spawn(float x, float y) {
        float d = getResources().getDisplayMetrics().density;
        int accent = Host.accent(0xFFFF4D67) | 0xFF000000;
        long now = SystemClock.uptimeMillis();
        int n = 14;
        for (int i = 0; i < n; i++) {
            P p = new P();
            p.heart = i % 3 != 0; // 2/3 сердечки, 1/3 искры
            double ang = -Math.PI / 2 + (rnd.nextFloat() - 0.5f) * 1.7; // вверх с разбросом
            float speed = (p.heart ? 0.9f : 1.2f) * d * (90 + rnd.nextFloat() * 120); // px/сек
            p.x = x + (rnd.nextFloat() - 0.5f) * 24 * d;
            p.y = y + (rnd.nextFloat() - 0.5f) * 10 * d;
            p.vx = (float) Math.cos(ang) * speed;
            p.vy = (float) Math.sin(ang) * speed;
            p.rot = (rnd.nextFloat() - 0.5f) * 40;
            p.vrot = (rnd.nextFloat() - 0.5f) * 240;
            p.size = (p.heart ? 16 + rnd.nextFloat() * 12 : 10 + rnd.nextFloat() * 8) * d;
            p.born = now;
            p.life = 650 + (long) (rnd.nextFloat() * 400);
            // сердечки — акцент/красный микс, искры — светлые с акцентом
            p.color = p.heart ? mix(accent, 0xFFFF2D55, rnd.nextFloat() * 0.5f)
                              : mix(accent, 0xFFFFFFFF, 0.5f + rnd.nextFloat() * 0.4f);
            parts.add(p);
        }
        if (lastFrame == 0) lastFrame = now;
        postInvalidateOnAnimation();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (parts.isEmpty()) return;
        long now = SystemClock.uptimeMillis();
        float dt = lastFrame == 0 ? 0 : Math.min(0.05f, (now - lastFrame) / 1000f);
        lastFrame = now;
        float d = getResources().getDisplayMetrics().density;
        float gravity = 520 * d; // px/сек^2, тянет вниз

        for (int i = parts.size() - 1; i >= 0; i--) {
            P p = parts.get(i);
            long age = now - p.born;
            if (age >= p.life) { parts.remove(i); continue; }

            p.vy += gravity * dt;
            p.x += p.vx * dt;
            p.y += p.vy * dt;
            p.rot += p.vrot * dt;

            float t = age / (float) p.life;           // 0..1
            float alpha = t < 0.15f ? t / 0.15f : 1f - (t - 0.15f) / 0.85f; // быстрый вход, плавный уход
            float scale = 0.6f + 0.4f * Math.min(1f, t * 4f);

            int a = Math.max(0, Math.min(255, (int) (alpha * 255)));
            paint.setColor((p.color & 0x00FFFFFF) | (a << 24));

            canvas.save();
            canvas.translate(p.x, p.y);
            canvas.rotate(p.rot);
            float s = p.size * scale;
            paint.setTextSize(s);
            // ♥ (U+2665) и ✦ (U+2726) — текстовые глифы, честно красятся paint-цветом (в отличие от emoji)
            canvas.drawText(p.heart ? "♥" : "✦", 0, s * 0.35f, paint);
            canvas.restore();
        }

        if (!parts.isEmpty()) postInvalidateOnAnimation();
        else lastFrame = 0;
    }

    private static int mix(int a, int b, float t) {
        int ar = Color.red(a), ag = Color.green(a), ab = Color.blue(a);
        int br = Color.red(b), bg = Color.green(b), bb = Color.blue(b);
        return Color.rgb(
                (int) (ar + (br - ar) * t),
                (int) (ag + (bg - ag) * t),
                (int) (ab + (bb - ab) * t));
    }
}
