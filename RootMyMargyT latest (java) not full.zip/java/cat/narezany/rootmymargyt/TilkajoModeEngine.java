package cat.narezany.rootmymargyt;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.SystemClock;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.lang.ref.WeakReference;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.WeakHashMap;

import cat.narezany.margyt.plugin.PluginContext;

/**
 * TilkajoModeEngine — Режим Тилкайо: все кнопки ленты и нижней панели — из Тилкайо, и он мяукает.
 *
 * С MargyT 2.1 мод сам перерисовывает иконки ленты перед каждым кадром (FeedRail.icons →
 * Md3.icons), а нижнюю панель рисует своей капсулой (NavBar.Capsule) поверх спрятанных
 * вкладок TikTok — подменять картинки бесполезно. Поэтому:
 *  - кнопки ленты (FeedRail.slots): родная иконка прозрачна (alpha 0 на каждом кадре), её
 *    рисунок снимается в битмап, дырки заливаются — получается силуэт сердечка/облачка/
 *    закладки/стрелки, и он закрашивается Тилкайо. Лайкнутое сердце — с красным оттенком;
 *  - нижняя панель капсулы: места и контуры иконок читаются у самой капсулы (её вкладки,
 *    NavBar.outline), и сверху рисуется та же иконка, залитая Тилкайо. Без капсулы —
 *    как с лентой, по ImageView вкладок TikTok;
 *  - тап по любой такой кнопке — она подпрыгивает и мяукает (meow.ogg из ассетов MargyT,
 *    через MediaPlayer, как мяукают котики самого мода).
 * Выключение возвращает иконкам их прозрачность.
 */
public final class TilkajoModeEngine {

    public static final String KEY_ENABLED = "tilkajo_mode_enabled";
    public static final String KEY_MEOW = "tilkajo_meow";

    private static final String TAG_VIEW = "rootmymargyt_tilkajo_overlay";
    private static final long RESCAN_MS = 400L;
    /** Как часто снимается силуэт иконки ленты заново: лайк анимируется и меняет цвет. */
    private static final long RESHAPE_MS = 140L;

    /** Одна заменённая кнопка-вью: вся кнопка, её иконка и снятый с иконки силуэт в Тилкайо. */
    private static final class Target {
        final WeakReference<View> button, icon;
        final boolean tab;
        Bitmap shape;
        long shapedAt;

        Target(View button, View icon, boolean tab) {
            this.button = new WeakReference<>(button);
            this.icon = new WeakReference<>(icon);
            this.tab = tab;
        }
    }

    /** Нарисованное в этом кадре место кнопки (координаты экрана) — для тапов. */
    private static final class Hit {
        final RectF box = new RectF();
        Object key;
    }

    private static final ArrayList<Target> targets = new ArrayList<>();
    private static final WeakHashMap<View, Float> hiddenAlpha = new WeakHashMap<>();
    private static final ArrayList<Hit> hits = new ArrayList<>();
    private static int hitCount;
    private static final HashMap<Object, Long> popped = new HashMap<>();
    private static WeakReference<Overlay> overlay = new WeakReference<>(null);
    private static WeakReference<Activity> scannedFor = new WeakReference<>(null);
    private static WeakReference<ViewGroup> navBar = new WeakReference<>(null);
    private static long lastScan;
    private static PluginContext margyt;

    private TilkajoModeEngine() {}

    public static boolean isEnabled(PluginContext m) {
        return m != null && m.getBoolean(KEY_ENABLED, false);
    }

    /** Старое имя — из onResumed/onScreen и настроек. */
    public static void applyTilkajoMode(Activity activity, PluginContext m) {
        update(activity, m);
    }

    /** Из preDraw каждый кадр: дёшево — пересканирует реестры раз в 400 мс, иначе только держит alpha. */
    public static void update(Activity activity, PluginContext m) {
        margyt = m;
        if (activity == null || activity.isFinishing() || activity.getWindow() == null) return;
        if (!isEnabled(m)) {
            restoreAll();
            return;
        }
        long now = SystemClock.uptimeMillis();
        if (scannedFor.get() != activity || now - lastScan > RESCAN_MS) {
            lastScan = now;
            scannedFor = new WeakReference<>(activity);
            scan(activity);
            ensureOverlay(activity);
        }
        for (int i = targets.size() - 1; i >= 0; i--) {
            View icon = targets.get(i).icon.get();
            if (icon == null) {
                targets.remove(i);
                continue;
            }
            if (icon.getAlpha() != 0f) {
                if (!hiddenAlpha.containsKey(icon)) hiddenAlpha.put(icon, icon.getAlpha());
                icon.setAlpha(0f);
            }
        }
        Overlay o = overlay.get();
        if (o != null) o.invalidate();
    }

    private static void scan(Activity activity) {
        ArrayList<Target> old = new ArrayList<>(targets);
        targets.clear();
        float d = activity.getResources().getDisplayMetrics().density;
        Map<View, Integer> rail = FeedCountsEngine.readRail();
        if (rail != null) {
            for (View slot : rail.keySet()) {
                if (slot == null || !slot.isAttachedToWindow() || slot.getVisibility() != View.VISIBLE) continue;
                View icon = findIcon(slot, d, 0);
                if (icon != null) targets.add(reuse(old, slot, icon, false));
            }
        }
        ViewGroup bar = NavBarPositionEngine.findNavBar(activity);
        navBar = new WeakReference<>(bar);
        // Капсулу MargyT рисуем по её же раскладке (см. Overlay.drawCapsule); иначе — вкладки TikTok
        if (bar != null && Cap.of(bar) == null) {
            for (int i = 0; i < bar.getChildCount(); i++) {
                View tab = bar.getChildAt(i);
                if (tab.getVisibility() != View.VISIBLE) continue;
                View icon = findIcon(tab, d, 0);
                if (icon != null) targets.add(reuse(old, tab, icon, true));
            }
        }
        for (Target t : old) {
            if (!targets.contains(t) && t.shape != null) t.shape.recycle();
        }
        // То, что перестало быть кнопкой (лента пролистана, экран сменился), — вернуть как было
        for (View v : new ArrayList<>(hiddenAlpha.keySet())) {
            boolean still = false;
            for (Target t : targets) if (t.icon.get() == v) still = true;
            if (!still && v != null) {
                Float a = hiddenAlpha.remove(v);
                v.setAlpha(a == null ? 1f : a);
            }
        }
    }

    private static Target reuse(ArrayList<Target> old, View button, View icon, boolean tab) {
        for (Target t : old) if (t.button.get() == button && t.icon.get() == icon) return t;
        return new Target(button, icon, tab);
    }

    /** Самая крупная картинка внутри кнопки: ImageView (в т.ч. Lottie) от 16 до 90 dp, не текст. */
    private static View findIcon(View v, float d, int depth) {
        if (v == null || depth > 8 || v.getVisibility() != View.VISIBLE) return null;
        View best = null;
        if (v instanceof ImageView && !(v instanceof TextView)) {
            int w = v.getWidth(), h = v.getHeight();
            if (w >= 16 * d && h >= 16 * d && w <= 90 * d && h <= 90 * d) best = v;
        }
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) {
                View c = findIcon(g.getChildAt(i), d, depth + 1);
                if (c != null && (best == null || c.getWidth() * c.getHeight() > best.getWidth() * best.getHeight())) best = c;
            }
        }
        return best;
    }

    private static void restoreAll() {
        if (hiddenAlpha.isEmpty() && targets.isEmpty() && overlay.get() == null) return;
        for (Map.Entry<View, Float> e : hiddenAlpha.entrySet()) {
            if (e.getKey() != null) e.getKey().setAlpha(e.getValue() == null ? 1f : e.getValue());
        }
        hiddenAlpha.clear();
        for (Target t : targets) if (t.shape != null) t.shape.recycle();
        targets.clear();
        hitCount = 0;
        popped.clear();
        Overlay o = overlay.get();
        if (o != null && o.getParent() instanceof ViewGroup) ((ViewGroup) o.getParent()).removeView(o);
        overlay = new WeakReference<>(null);
    }

    private static void ensureOverlay(Activity activity) {
        ViewGroup decor = (ViewGroup) activity.getWindow().getDecorView();
        Overlay o = overlay.get();
        if (o != null && o.getParent() == decor) return;
        View existing = decor.findViewWithTag(TAG_VIEW);
        if (existing instanceof Overlay) {
            overlay = new WeakReference<>((Overlay) existing);
            return;
        }
        o = new Overlay(activity);
        o.setTag(TAG_VIEW);
        decor.addView(o, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        overlay = new WeakReference<>(o);
    }

    // ───────────────────────────── капсула MargyT ─────────────────────────────

    /** Чтение NavBar.Capsule через рефлексию: вкладки, их места и контуры иконок. */
    private static final class Cap {
        static final int CAPSULE = 0x4D41634E; // NavBar.CAPSULE, "MAcN"
        static final int CREATE = 2, PROFILE = 4;
        static boolean asked, ok;
        static Field tabs, body, unit, away, worn, small, face, peekUntil;
        static Field kind, open, left, right, name, nameWide, count, shown;
        static Method outline;

        static Object of(View bar) {
            Object c = bar == null ? null : bar.getTag(CAPSULE);
            if (c == null || !init(c)) return null;
            try {
                return worn.getBoolean(c) ? c : null;
            } catch (Throwable e) {
                return null;
            }
        }

        private static boolean init(Object capsule) {
            if (asked) return ok;
            asked = true;
            try {
                Class<?> cc = capsule.getClass();
                tabs = field(cc, "tabs");
                body = field(cc, "body");
                unit = field(cc, "unit");
                away = field(cc, "away");
                worn = field(cc, "worn");
                small = field(cc, "small");
                face = field(cc, "faceShader");
                peekUntil = field(cc, "peekUntil");
                Class<?> tc = tabs.getType().getComponentType();
                kind = field(tc, "kind");
                open = field(tc, "open");
                left = field(tc, "left");
                right = field(tc, "right");
                name = field(tc, "name");
                nameWide = field(tc, "nameWide");
                count = field(tc, "count");
                shown = field(tc, "shown");
                outline = Class.forName("cat.narezany.margyt.NavBar").getDeclaredMethod("outline", int.class, boolean.class);
                outline.setAccessible(true);
                ok = true;
            } catch (Throwable e) {
                ok = false;
                if (margyt != null) margyt.log("tilkajo: capsule unreadable: " + e);
            }
            return ok;
        }

        private static Field field(Class<?> c, String n) throws NoSuchFieldException {
            Field f = c.getDeclaredField(n);
            f.setAccessible(true);
            return f;
        }
    }

    // ───────────────────────────── тап: мяу ─────────────────────────────

    /** Из TouchSpy на каждый тап (координаты экрана). Только наблюдает — тап уходит в TikTok как был. */
    static void onTap(Activity activity, float rawX, float rawY) {
        if (!isEnabled(margyt) || hitCount == 0) return;
        float slop = 8f * activity.getResources().getDisplayMetrics().density;
        for (int i = 0; i < hitCount; i++) {
            Hit h = hits.get(i);
            if (rawX < h.box.left - slop || rawX > h.box.right + slop
                    || rawY < h.box.top - slop || rawY > h.box.bottom + slop) continue;
            popped.put(h.key, SystemClock.uptimeMillis());
            if (margyt.getBoolean(KEY_MEOW, true)) Meow.play(activity.getApplicationContext());
            Overlay o = overlay.get();
            if (o != null) o.invalidate();
            return;
        }
    }

    /** meow.ogg из ассетов MargyT, скопированный в файл (сжатый ассет на месте не играется). */
    private static final class Meow {
        private static long lastAt;
        private static boolean logged;

        static void play(Context ctx) {
            long now = SystemClock.uptimeMillis();
            if (now - lastAt < 90) return;
            lastAt = now;
            MediaPlayer player = null;
            try {
                File sound = file(ctx);
                // свой плеер на каждый тап — частые тапы накладываются, а не обрывают друг друга
                player = new MediaPlayer();
                player.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
                player.setDataSource(sound.getAbsolutePath());
                player.setOnCompletionListener(MediaPlayer::release);
                player.setOnErrorListener((p, what, extra) -> {
                    p.release();
                    return true;
                });
                player.prepare();
                if (Build.VERSION.SDK_INT >= 23) {
                    try { // чуть разный тон каждый раз — живее
                        player.setPlaybackParams(player.getPlaybackParams()
                            .setPitch(0.9f + (float) Math.random() * 0.35f).setSpeed(1f));
                    } catch (Throwable ignored) {}
                }
                player.start();
            } catch (Throwable e) {
                if (player != null) player.release();
                if (!logged && margyt != null) {
                    logged = true;
                    margyt.log("tilkajo: meow failed: " + e);
                }
            }
        }

        private static File file(Context ctx) throws Exception {
            File sound = new File(ctx.getFilesDir(), "margyt/meow.ogg");
            if (sound.isFile() && sound.length() > 0) return sound;
            File dir = sound.getParentFile();
            if (dir != null && !dir.isDirectory()) dir.mkdirs();
            File tmp = new File(dir, "meow.ogg.rmm");
            try (InputStream in = ctx.getAssets().open("margyt/meow.ogg");
                 FileOutputStream out = new FileOutputStream(tmp)) {
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            }
            if (!tmp.renameTo(sound)) return tmp;
            return sound;
        }
    }

    // ───────────────────────────── силуэт иконки ─────────────────────────────

    /**
     * Рисунок иконки → силуэт, залитый Тилкайо. Дырки внутри (контурные иконки, точки облачка)
     * заливаются: всё, до чего нельзя дойти от края по прозрачному, — внутри фигуры.
     */
    private static Bitmap silhouette(View icon, Bitmap cat) {
        int w = icon.getWidth(), h = icon.getHeight();
        if (w <= 0 || h <= 0 || w > 400 || h > 400) return null;
        Bitmap drawn = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        try {
            icon.draw(new Canvas(drawn)); // своя alpha вью тут не применяется — рисунок целиком
        } catch (Throwable e) {
            drawn.recycle();
            return null;
        }
        int n = w * h;
        int[] px = new int[n];
        drawn.getPixels(px, 0, w, 0, 0, w, h);
        drawn.recycle();

        boolean[] outside = new boolean[n];
        int[] queue = new int[n];
        int head = 0, tail = 0;
        for (int x = 0; x < w; x++) {
            tail = seed(px, outside, queue, tail, x);
            tail = seed(px, outside, queue, tail, (h - 1) * w + x);
        }
        for (int y = 0; y < h; y++) {
            tail = seed(px, outside, queue, tail, y * w);
            tail = seed(px, outside, queue, tail, y * w + w - 1);
        }
        while (head < tail) {
            int i = queue[head++], x = i % w;
            if (x > 0) tail = seed(px, outside, queue, tail, i - 1);
            if (x < w - 1) tail = seed(px, outside, queue, tail, i + 1);
            if (i >= w) tail = seed(px, outside, queue, tail, i - w);
            if (i < n - w) tail = seed(px, outside, queue, tail, i + w);
        }

        int solid = 0, minX = w, minY = h, maxX = -1, maxY = -1;
        long r = 0, g = 0, b = 0;
        int[] mask = new int[n];
        for (int i = 0; i < n; i++) {
            int a = outside[i] ? (px[i] >>> 24) : 255;
            mask[i] = a << 24;
            if (a > 128) {
                int x = i % w, y = i / w;
                if (x < minX) minX = x;
                if (x > maxX) maxX = x;
                if (y < minY) minY = y;
                if (y > maxY) maxY = y;
                if ((px[i] >>> 24) > 128) {
                    solid++;
                    r += Color.red(px[i]);
                    g += Color.green(px[i]);
                    b += Color.blue(px[i]);
                }
            }
        }
        if (solid < 8 || maxX < minX) return null;

        Bitmap out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(out);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        // Тилкайо — «cover» по габаритам фигуры, чтобы мордочка была в самой иконке, а не в пустых полях
        float bw = maxX - minX + 1, bh = maxY - minY + 1;
        float s = Math.max(bw / cat.getWidth(), bh / cat.getHeight());
        float cw = cat.getWidth() * s, ch = cat.getHeight() * s;
        float cx = minX + bw / 2f, cy = minY + bh / 2f;
        c.drawBitmap(cat, null, new RectF(cx - cw / 2f, cy - ch / 2f, cx + cw / 2f, cy + ch / 2f), p);
        // цветная иконка (красное сердце после лайка) — оттенок поверх Тилкайо
        int avg = Color.rgb((int) (r / solid), (int) (g / solid), (int) (b / solid));
        float[] hsv = new float[3];
        Color.colorToHSV(avg, hsv);
        if (hsv[1] > 0.35f && hsv[2] > 0.25f) c.drawColor((avg & 0xFFFFFF) | 0x73000000, PorterDuff.Mode.SRC_ATOP);
        Bitmap m = Bitmap.createBitmap(mask, w, h, Bitmap.Config.ARGB_8888);
        p.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
        c.drawBitmap(m, 0, 0, p);
        m.recycle();
        return out;
    }

    private static int seed(int[] px, boolean[] outside, int[] queue, int tail, int i) {
        if (outside[i] || (px[i] >>> 24) >= 100) return tail;
        outside[i] = true;
        queue[tail] = i;
        return tail + 1;
    }

    private static Hit nextHit() {
        if (hitCount == hits.size()) hits.add(new Hit());
        return hits.get(hitCount++);
    }

    /** Подскок от тапа: множитель размера и идёт ли ещё анимация. */
    private static float pop(Object key, long now) {
        Long at = popped.get(key);
        if (at == null) return 1f;
        long age = now - at;
        if (age >= 600) {
            popped.remove(key);
            return 1f;
        }
        return 1f + 0.35f * (float) Math.exp(-age / 120.0) * (float) Math.sin(age / 40.0);
    }

    // ───────────────────────────── оверлей ─────────────────────────────

    private static final class Overlay extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        private final Paint shade = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        private final Paint fur = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        private final Matrix furFit = new Matrix();
        private final Rect seen = new Rect();
        private final RectF dst = new RectF();
        private final int[] at = new int[2], self = new int[2];
        private final Matrix place = new Matrix();
        private final RectF box = new RectF();
        private final HashMap<Object, long[]> coverMemo = new HashMap<>();
        private Bitmap furOf;
        private boolean animating;

        Overlay(Context c) {
            super(c);
            setClickable(false);
            setFocusable(false);
            setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);
            shade.setColorFilter(new PorterDuffColorFilter(0x55000000, PorterDuff.Mode.SRC_IN));
        }

        @Override
        public boolean onTouchEvent(android.view.MotionEvent event) {
            return false;
        }

        @Override
        protected void onDraw(Canvas c) {
            hitCount = 0;
            Bitmap cat = TilkajoAssets.getTilkajoIconBitmap();
            if (cat == null) return;
            getLocationOnScreen(self);
            long now = SystemClock.uptimeMillis();
            animating = false;
            float d = getResources().getDisplayMetrics().density;
            for (Target t : targets) drawTarget(c, t, cat, now, d);
            ViewGroup bar = navBar.get();
            Object cap = Cap.of(bar);
            if (cap != null) drawCapsule(c, bar, cap, cat, now);
            if (animating) postInvalidateOnAnimation();
        }

        private void drawTarget(Canvas c, Target t, Bitmap cat, long now, float d) {
            View icon = t.icon.get(), button = t.button.get();
            if (icon == null || button == null || !button.isShown() || !icon.getGlobalVisibleRect(seen)) return;
            if (t.shape == null || now - t.shapedAt > RESHAPE_MS
                    || t.shape.getWidth() != icon.getWidth() || t.shape.getHeight() != icon.getHeight()) {
                Bitmap fresh = silhouette(icon, cat);
                if (fresh != null || now - t.shapedAt > 1000) { // моргнувшую пустоту не показываем сразу
                    if (t.shape != null) t.shape.recycle();
                    t.shape = fresh;
                }
                t.shapedAt = now;
            }
            if (t.shape == null) return;
            // со всеми масштабами и сдвигами предков (панель в профиле уменьшается целиком)
            if (!toDecor(icon, this, place)) return;
            dst.set(0, 0, icon.getWidth(), icon.getHeight());
            place.mapRect(box, dst);
            if (covered(t, icon, box, now)) return;
            float scale = pop(t, now);
            if (scale != 1f) animating = true;
            int alpha = t.tab && !button.isSelected() ? 170 : 255;
            int saved = c.save();
            c.concat(place);
            c.scale(scale, scale, icon.getWidth() / 2f, icon.getHeight() / 2f);
            // лёгкая тень — чтобы фигура читалась на светлом видео
            shade.setAlpha(alpha);
            dst.offset(0, d);
            c.drawBitmap(t.shape, null, dst, shade);
            dst.offset(0, -d);
            p.setAlpha(alpha);
            c.drawBitmap(t.shape, null, dst, p);
            c.restoreToCount(saved);
            Hit h = nextHit();
            h.key = t;
            h.box.set(box);
            h.box.offset(self[0], self[1]);
        }

        /** Матрица из координат вью в координаты оверлея (он лежит на decor в 0,0). */
        private boolean toDecor(View v, View overlayView, Matrix out) {
            View decor = (View) overlayView.getParent();
            out.reset();
            View cur = v;
            while (cur != null && cur != decor) {
                Matrix own = cur.getMatrix();
                if (!own.isIdentity()) out.postConcat(own);
                out.postTranslate(cur.getLeft(), cur.getTop());
                if (!(cur.getParent() instanceof View)) return false;
                View parent = (View) cur.getParent();
                out.postTranslate(-parent.getScrollX(), -parent.getScrollY());
                cur = parent;
            }
            return cur == decor;
        }

        /**
         * Закрыта ли кнопка чем-то поверх (панель комментариев, шторка, диалог в том же окне):
         * ищем у предков, среди тех, кто рисуется позже, сплошной фон над центром кнопки.
         * Раз в 150 мс на кнопку — это обход дерева.
         */
        private boolean covered(Object key, View v, RectF where, long now) {
            long[] memo = coverMemo.get(key);
            if (memo != null && now - memo[0] < 150) return memo[1] != 0;
            View decor = (View) getParent();
            int px = Math.round(where.centerX()) + self[0], py = Math.round(where.centerY()) + self[1];
            boolean hidden = false;
            View cur = v;
            while (!hidden && cur != null && cur != decor && cur.getParent() instanceof ViewGroup) {
                ViewGroup parent = (ViewGroup) cur.getParent();
                for (int i = parent.indexOfChild(cur) + 1; i < parent.getChildCount() && !hidden; i++) {
                    hidden = coversPoint(parent.getChildAt(i), px, py, 0);
                }
                cur = parent;
            }
            if (memo == null) coverMemo.put(key, memo = new long[2]);
            memo[0] = now;
            memo[1] = hidden ? 1 : 0;
            return hidden;
        }

        private boolean coversPoint(View v, int px, int py, int depth) {
            if (v == null || v == this || depth > 14 || v.getVisibility() != View.VISIBLE || v.getAlpha() < 0.5f) return false;
            if (!v.getGlobalVisibleRect(seen) || !seen.contains(px, py)) return false;
            if (solid(v.getBackground(), seen)) return true;
            if (v instanceof ViewGroup) {
                ViewGroup g = (ViewGroup) v;
                for (int i = g.getChildCount() - 1; i >= 0; i--) {
                    if (coversPoint(g.getChildAt(i), px, py, depth + 1)) return true;
                }
            }
            return false;
        }

        /** Сплошной ли фон: цвет без прозрачности, или большая непрозрачная подложка (шторки). */
        private boolean solid(Drawable bg, Rect area) {
            if (bg == null || !bg.isVisible() || bg.getAlpha() < 200) return false;
            int sw = getWidth(), sh = getHeight();
            if (bg instanceof ColorDrawable) return Color.alpha(((ColorDrawable) bg).getColor()) >= 200;
            if (bg instanceof GradientDrawable) {
                if (Build.VERSION.SDK_INT < 24) return false;
                ColorStateList fill = ((GradientDrawable) bg).getColor();
                return fill != null && Color.alpha(fill.getDefaultColor()) >= 200; // градиентные тени — нет
            }
            if (bg.getOpacity() == PixelFormat.OPAQUE) return true;
            // MaterialShapeDrawable и т.п. у шторок: широкая и высокая подложка
            return area.width() >= sw * 0.8f && area.height() >= sh * 0.25f;
        }

        /** Нижняя панель капсулы: те же места, что в NavBar.Capsule.draw, и заполненный контур — Тилкайо. */
        private void drawCapsule(Canvas c, ViewGroup bar, Object cap, Bitmap cat, long now) {
            int barSaved = -1;
            try {
                Object[] tabs = (Object[]) Cap.tabs.get(cap);
                RectF body = (RectF) Cap.body.get(cap);
                float unit = Cap.unit.getFloat(cap), away = Cap.away.getFloat(cap);
                Paint small = (Paint) Cap.small.get(cap);
                boolean face = Cap.face.get(cap) != null;
                boolean peeking = now < Cap.peekUntil.getLong(cap);
                if (tabs == null || tabs.length == 0 || body == null || body.isEmpty() || away >= 1f || !bar.isShown()) return;
                if (furOf != cat) {
                    furOf = cat;
                    fur.setShader(new BitmapShader(cat, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP));
                }
                // панель целиком масштабируется (уменьшенная в профиле) — рисуем в её координатах
                if (!toDecor(bar, this, place)) return;
                place.mapRect(box, body);
                if (covered(bar, bar, box, now)) return;
                barSaved = c.save();
                c.concat(place);
                float ox = 0f, oy = 0f;
                float middle = body.centerY(), size = 24f * unit, gap = 6f * unit;
                for (int i = 0; i < tabs.length; i++) {
                    Object tab = tabs[i];
                    int kind = Cap.kind.getInt(tab);
                    if (kind == Cap.CREATE || (kind == Cap.PROFILE && face)) continue; // «+» и своя аватарка — как были
                    // всегда залитый вариант иконки: в тонком контуре Тилкайо не разглядеть
                    Path path = (Path) Cap.outline.invoke(null, kind, true);
                    if (path == null) continue;
                    float l = Cap.left.getFloat(tab), r = Cap.right.getFloat(tab), open = Cap.open.getFloat(tab);
                    String name = (String) Cap.name.get(tab), count = (String) Cap.count.get(tab);
                    float nameWide = Cap.nameWide.getFloat(tab);
                    float badge = count == null ? 0f : Math.max(16f * unit, small.measureText(count) + 8f * unit) + 4f * unit;
                    float room = Math.max(0f, r - l - 2f * 8f * unit - size - gap - badge);
                    float shrink = name == null || nameWide <= room ? 1f : Math.max(0.82f, room / nameWide);
                    float text = name == null ? 0f : Math.min(nameWide * shrink, room);
                    float content = size + open * (gap + text + badge);
                    float left = ox + (l + r) / 2f - content / 2f, top = oy + middle - size / 2f;

                    float seenA = (peeking ? 1f : Cap.shown.getFloat(tab)) * (1f - away);
                    Integer key = i;
                    float scale = pop(key, now);
                    if (scale != 1f) animating = true;
                    int saved = c.save();
                    c.translate(left + size / 2f, top + size / 2f);
                    c.scale(scale, scale);
                    c.translate(-size / 2f, -size / 2f);
                    c.scale(size / 960f, size / 960f);
                    c.translate(0f, 960f);
                    // Тилкайо на квадрат иконки 960×960 (y от −960 до 0), «cover»
                    float s = 960f / Math.min(cat.getWidth(), cat.getHeight());
                    furFit.setScale(s, s);
                    furFit.postTranslate((960f - cat.getWidth() * s) / 2f, -960f + (960f - cat.getHeight() * s) / 2f);
                    fur.getShader().setLocalMatrix(furFit);
                    fur.setAlpha(Math.round(seenA * (150f + 105f * open)));
                    c.drawPath(path, fur);
                    c.restoreToCount(saved);

                    Hit h = nextHit();
                    h.key = key;
                    dst.set(l, body.top, r, body.bottom);
                    place.mapRect(h.box, dst);
                    h.box.offset(self[0], self[1]);
                }
            } catch (Throwable e) {
                // капсула поменялась в новой версии мода — лента всё равно в Тилкайо
            } finally {
                if (barSaved >= 0) c.restoreToCount(barSaved);
            }
        }
    }
}
