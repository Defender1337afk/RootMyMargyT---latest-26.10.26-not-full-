package cat.narezany.rootmymargyt;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.os.SystemClock;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import java.util.Random;

import cat.narezany.margyt.plugin.PluginContext;

/**
 * SparkleOverlayView — мерцающие блёстки, медленно всплывающие по экрану своего профиля.
 *
 * Прозрачный оверлей поверх decor, касания не перехватывает. Анимируется только пока виден:
 * вне профиля он GONE и кадров не запрашивает. Частиц немного и все объекты созданы заранее —
 * onDraw ничего не выделяет.
 */
public final class SparkleOverlayView extends View {

    public static final String KEY_ENABLED = "profile_sparkles_enabled";
    public static final String TAG_VIEW = "rootmymargyt_sparkles";

    private static final int COUNT = 26;

    private static java.lang.ref.WeakReference<SparkleOverlayView> current = new java.lang.ref.WeakReference<>(null);

    private final Random random = new Random();
    private final float[] x = new float[COUNT];
    private final float[] y = new float[COUNT];
    private final float[] size = new float[COUNT];
    private final float[] speed = new float[COUNT];
    private final float[] phase = new float[COUNT];
    private final float[] rate = new float[COUNT];
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path star = new Path();
    private long lastFrame = 0L;
    private boolean seeded = false;

    public SparkleOverlayView(Context context) {
        super(context);
        setWillNotDraw(false);
        setClickable(false);
        setFocusable(false);
        setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);
        setVisibility(GONE);
        paint.setColor(Color.WHITE);
        glow.setColor(Color.WHITE);
    }

    public static boolean isEnabled(PluginContext m) {
        return m != null && m.getBoolean(KEY_ENABLED, false);
    }

    /** Из preDraw-наблюдателя: показать в своём профиле, иначе спрятать. */
    public static void update(Activity activity, PluginContext m, boolean profileShown) {
        try {
            if (activity == null || activity.isFinishing() || activity.getWindow() == null) return;
            ViewGroup decor = (ViewGroup) activity.getWindow().getDecorView();
            boolean want = isEnabled(m) && profileShown;
            SparkleOverlayView cached = current.get();
            View existing = cached != null && cached.getParent() == decor ? cached : null;
            // Поиск по дереву — только когда показывать надо, а ссылки ещё нет
            if (existing == null && want) existing = decor.findViewWithTag(TAG_VIEW);
            if (!want) {
                if (existing != null && existing.getVisibility() != GONE) existing.setVisibility(GONE);
                return;
            }
            if (existing == null) {
                final SparkleOverlayView v = new SparkleOverlayView(activity);
                v.setTag(TAG_VIEW);
                // Иерархию меняем после текущего прохода отрисовки
                decor.post(() -> {
                    if (decor.findViewWithTag(TAG_VIEW) == null) {
                        decor.addView(v, new FrameLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
                        current = new java.lang.ref.WeakReference<>(v);
                    }
                });
                return;
            }
            if (existing instanceof SparkleOverlayView && current.get() != existing) {
                current = new java.lang.ref.WeakReference<>((SparkleOverlayView) existing);
            }
            if (existing.getVisibility() != VISIBLE) {
                existing.setVisibility(VISIBLE);
                existing.bringToFront();
                // Ушки и живая аватарка остаются поверх блёсток
                View avatar = decor.findViewWithTag(LiveAvatarEngine.TAG_VIEW);
                if (avatar != null) avatar.bringToFront();
                View ears = decor.findViewWithTag(ProfileLocator.TAG_EARS);
                if (ears != null) ears.bringToFront();
            }
        } catch (Throwable ignored) {}
    }

    private void seed(int i, boolean anywhere) {
        int w = Math.max(1, getWidth());
        int h = Math.max(1, getHeight());
        float d = getResources().getDisplayMetrics().density;
        x[i] = random.nextFloat() * w;
        y[i] = anywhere ? random.nextFloat() * h : h + random.nextFloat() * h * 0.2f;
        size[i] = (2.5f + random.nextFloat() * 4.5f) * d;
        speed[i] = (6f + random.nextFloat() * 16f) * d;   // пикселей в секунду
        phase[i] = random.nextFloat() * 6.2832f;
        rate[i] = 1.2f + random.nextFloat() * 2.2f;        // скорость мерцания
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (getVisibility() != VISIBLE || getWidth() <= 0) return;
        if (!seeded) {
            for (int i = 0; i < COUNT; i++) seed(i, true);
            seeded = true;
        }

        long now = SystemClock.uptimeMillis();
        float dt = lastFrame == 0L ? 0f : Math.min(0.05f, (now - lastFrame) / 1000f);
        lastFrame = now;
        float t = now / 1000f;

        for (int i = 0; i < COUNT; i++) {
            y[i] -= speed[i] * dt;
            if (y[i] < -size[i] * 3) seed(i, false);

            float twinkle = 0.5f + 0.5f * (float) Math.sin(phase[i] + t * rate[i]);
            int alpha = Math.round(40 + 180 * twinkle);
            float s = size[i] * (0.6f + 0.4f * twinkle);

            glow.setAlpha(alpha / 5);
            canvas.drawCircle(x[i], y[i], s * 1.8f, glow);

            // Четырёхлучевая звёздочка
            star.rewind();
            float n = s * 0.28f;
            star.moveTo(x[i], y[i] - s);
            star.quadTo(x[i] + n, y[i] - n, x[i] + s, y[i]);
            star.quadTo(x[i] + n, y[i] + n, x[i], y[i] + s);
            star.quadTo(x[i] - n, y[i] + n, x[i] - s, y[i]);
            star.quadTo(x[i] - n, y[i] - n, x[i], y[i] - s);
            star.close();
            paint.setAlpha(alpha);
            canvas.drawPath(star, paint);
        }
        postInvalidateOnAnimation();
    }

    @Override
    protected void onVisibilityChanged(View changedView, int visibility) {
        super.onVisibilityChanged(changedView, visibility);
        // После паузы частицы продолжают с места, а не прыгают на накопленное время
        lastFrame = 0L;
        if (visibility == VISIBLE) invalidate();
    }
}
