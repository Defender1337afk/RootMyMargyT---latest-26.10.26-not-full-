package cat.narezany.rootmymargyt;

import android.app.Activity;
import android.graphics.Rect;
import android.os.SystemClock;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Random;

import cat.narezany.margyt.plugin.PluginContext;

/**
 * ClawdSenses — что Clawd «видит» на экране: комментарии и подпись видео.
 *
 * Комментарии — ячейки, которые помечает сам MargyT (тег 0x5454434D). Из ячейки берутся
 * имя (первая подпись) и текст (самая длинная); ClawdBrain решает, чем комментарий зацепил.
 * Не больше трёх реплик на одно открытие комментариев и не чаще раза в 7 секунд. Если
 * комментарии открыты в отдельном окне поверх Clawd, он скажет это, когда их закроют.
 *
 * Видео — подпись и автор в левом нижнем углу ленты. Если задержался на видео 4 секунды,
 * Clawd иногда (в половине случаев и не чаще раза в 25 секунд) говорит, о чём оно.
 *
 * Всё читается только на телефоне; ничего никуда не отправляется.
 */
final class ClawdSenses {

    private static final int TAG_COMMENT_CELL = 0x5454434D;
    private static final Random RND = new Random();
    private static final Rect R = new Rect();

    private static long lastCommentScan = 0L, lastVideoScan = 0L;

    // Комментарии
    private static long lastCellsSeenAt = 0L;
    private static int saidThisSheet = 0;
    private static long lastCommentTalk = 0L;
    private static final HashSet<Integer> seenComments = new HashSet<>();
    private static String queuedLine = null;
    private static int queuedMood = 0;

    // Видео
    private static String caption = "";
    private static String author = "";
    private static long captionSince = 0L;
    private static String judgedCaption = "";
    private static long lastVideoTalk = -30000L;

    private ClawdSenses() {}

    /** Из preDraw (раз в 250 мс); свои интервалы внутри. */
    static void update(Activity activity, PluginContext m) {
        try {
            if (activity == null || activity.getWindow() == null || !ClawdPetView.wantsSenses()) return;
            long now = SystemClock.uptimeMillis();
            if (now - lastCommentScan >= 1500L) {
                lastCommentScan = now;
                scanComments(activity, now);
            }
            if (now - lastVideoScan >= 1000L) {
                lastVideoScan = now;
                scanVideo(activity, now);
            }
        } catch (Throwable ignored) {}
    }

    // ───────────────────────────── комментарии

    private static void scanComments(Activity activity, long now) {
        View decor = activity.getWindow().getDecorView();
        List<View> cells = new ArrayList<>();
        View cellsRoot = null;
        for (View root : CommentWallpaperEngine.collectRoots(activity)) {
            collectCells(root, cells);
            if (!cells.isEmpty()) {
                cellsRoot = root;
                break;
            }
        }

        if (cells.isEmpty()) {
            // Комментарии закрыли — договариваем то, что не было видно за ними
            if (now - lastCellsSeenAt > 3000L && lastCellsSeenAt != 0L) {
                lastCellsSeenAt = 0L;
                saidThisSheet = 0;
                seenComments.clear();
                if (queuedLine != null) {
                    String line = queuedLine;
                    queuedLine = null;
                    ClawdPetView.react(ClawdPetView.EV_COMMENT, queuedMood,
                        "Кстати! " + Character.toLowerCase(line.charAt(0)) + line.substring(1));
                }
            }
            return;
        }
        lastCellsSeenAt = now;
        if (saidThisSheet >= 3 || now - lastCommentTalk < 7000L) return;

        String bestUser = null;
        int bestMood = ClawdBrain.NEUTRAL, bestScore = 0;
        for (View cell : cells) {
            String[] uc = readComment(cell);
            if (uc == null) continue;
            int key = (uc[0] + "\n" + uc[1]).hashCode();
            if (!seenComments.add(key)) continue;
            int[] ms = ClawdBrain.moodWithScore(uc[1]);
            if (ms[0] != ClawdBrain.NEUTRAL && ms[1] > bestScore) {
                bestScore = ms[1];
                bestMood = ms[0];
                bestUser = uc[0];
            }
        }
        if (bestMood == ClawdBrain.NEUTRAL) return;

        String line = ClawdBrain.moodPhrase(bestMood, bestUser, RND);
        if (line == null) return;
        saidThisSheet++;
        lastCommentTalk = now;
        if (cellsRoot == decor) {
            ClawdPetView.react(ClawdPetView.EV_COMMENT, bestMood, line);
        } else if (queuedLine == null) {
            // Комментарии в отдельном окне закрывают Clawd — скажет, когда их закроют
            queuedLine = line;
            queuedMood = bestMood;
        }
    }

    /** Видимые ячейки комментариев; внутрь помеченной ячейки не спускаемся. */
    private static void collectCells(View root, List<View> out) {
        ArrayDeque<View> queue = new ArrayDeque<>();
        queue.add(root);
        int seen = 0;
        while (!queue.isEmpty() && seen++ < 9000 && out.size() < 12) {
            View v = queue.poll();
            if (v.getVisibility() != View.VISIBLE) continue;
            if (Boolean.TRUE.equals(v.getTag(TAG_COMMENT_CELL))) {
                if (v.isShown() && v.getGlobalVisibleRect(R)) out.add(v);
                continue;
            }
            if (v instanceof ViewGroup) {
                ViewGroup g = (ViewGroup) v;
                for (int i = 0; i < g.getChildCount(); i++) {
                    View c = g.getChildAt(i);
                    if (c != null) queue.add(c);
                }
            }
        }
    }

    /** [имя, текст] из ячейки или null. Имя — первая подпись, текст — самая длинная из остальных. */
    static String[] readComment(View cell) {
        List<String> texts = new ArrayList<>();
        collectTexts(cell, texts, 0);
        if (texts.size() < 2) return null;
        String user = null;
        for (String t : texts) {
            if (t.length() <= 40 && t.indexOf('\n') < 0 && !isService(t)) {
                user = t;
                break;
            }
        }
        if (user == null) return null;
        String body = null;
        for (String t : texts) {
            if (t.equals(user) || isService(t)) continue;
            if (body == null || t.length() > body.length()) body = t;
        }
        if (body == null || body.length() < 2) return null;
        return new String[] {user, body};
    }

    private static void collectTexts(View v, List<String> out, int depth) {
        if (v == null || depth > 8 || v.getVisibility() != View.VISIBLE) return;
        if (v instanceof TextView && !(v instanceof EditText)) {
            CharSequence cs = ((TextView) v).getText();
            if (cs != null) {
                String s = cs.toString().trim();
                if (!s.isEmpty()) out.add(s);
            }
            return;
        }
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) collectTexts(g.getChildAt(i), out, depth + 1);
        }
    }

    /** «Ответить», время «3 ч», счётчики и прочее служебное — не имя и не комментарий. */
    static boolean isService(String s) {
        String t = s.toLowerCase(Locale.ROOT).trim();
        if (t.equals("ответить") || t.equals("reply") || t.startsWith("перевести") || t.startsWith("see translation")
                || t.startsWith("посмотреть") || t.startsWith("view ") || t.equals("автор") || t.equals("creator")
                || t.startsWith("показать") || t.equals("закреплено") || t.equals("pinned")) {
            return true;
        }
        // Только цифры, точки, «K/M», «ч/д/н/мин» — время или счётчик
        return t.matches("^[\\d.,\\s]+(k|m|тыс\\.?|млн|ч|д|н|нед\\.?|мин\\.?|с|h|d|w|m|s)?$")
            || t.matches("^\\d{1,2}-\\d{1,2}(-\\d{2,4})?$");
    }

    // ───────────────────────────── видео

    private static void scanVideo(Activity activity, long now) {
        if (now - lastCellsSeenAt < 3000L) return; // открыты комментарии — не до видео
        View decor = activity.getWindow().getDecorView();
        if (!(decor instanceof ViewGroup) || !ProfileLocator.hasVideoFeedMarkers((ViewGroup) decor)) return;
        int w = decor.getWidth(), h = decor.getHeight();
        if (w <= 0 || h <= 0) return;

        String[] ca = new String[] {null, null}; // [подпись, автор]
        findCaption(decor, w, h, ca, 0);
        String cap = ca[0] == null ? "" : ca[0];
        if (!cap.equals(caption)) {
            caption = cap;
            author = ca[1] == null ? "" : ca[1];
            captionSince = now;
            return;
        }
        if (caption.isEmpty() || caption.equals(judgedCaption) || now - captionSince < 4000L) return;
        judgedCaption = caption; // решаем один раз на видео
        if (now - lastVideoTalk < 25000L || RND.nextFloat() > 0.5f) return;
        String phrase = ClawdBrain.videoPhrase(caption, author);
        if (phrase == null) return;
        lastVideoTalk = now;
        ClawdPetView.react(ClawdPetView.EV_VIDEO, 0, phrase);
    }

    /** Подпись — самая длинная надпись в левом нижнем углу; автор — надпись с «@». */
    private static void findCaption(View v, int w, int h, String[] out, int depth) {
        if (v == null || depth > 45 || v.getVisibility() != View.VISIBLE) return;
        if (v instanceof TextView && !(v instanceof EditText)) {
            CharSequence cs = ((TextView) v).getText();
            if (cs == null || cs.length() < 2 || !v.isShown() || !v.getGlobalVisibleRect(R)) return;
            if (R.left > w * 0.7f || R.top < h * 0.55f || R.top > h * 0.95f) return;
            String s = cs.toString().trim();
            String low = s.toLowerCase(Locale.ROOT);
            if (low.contains("♫") || low.contains("♪") || low.contains("оригинальный звук") || low.contains("original sound")
                    || isService(s) || low.equals("ещё") || low.equals("more") || low.equals("...ещё")) {
                return;
            }
            if (s.startsWith("@")) {
                if (out[1] == null) out[1] = s;
            } else if (out[0] == null || s.length() > out[0].length()) {
                out[0] = s;
            }
            return;
        }
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) findCaption(g.getChildAt(i), w, h, out, depth + 1);
        }
    }
}
