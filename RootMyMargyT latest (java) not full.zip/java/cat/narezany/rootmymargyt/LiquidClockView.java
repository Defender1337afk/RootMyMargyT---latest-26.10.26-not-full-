package cat.narezany.rootmymargyt;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Outline;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.os.SystemClock;
import android.text.format.DateFormat;
import android.view.GestureDetector;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.widget.FrameLayout;

import java.lang.ref.WeakReference;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.WeakHashMap;

import cat.narezany.margyt.plugin.PluginContext;

/**
 * LiquidClockView — часы как на экране блокировки iOS, из «жидкого стекла», в своём профиле.
 *
 * Перетаскиваются пальцем, растягиваются щипком или за уголок справа внизу; двойной тап
 * меняет стекло (светлое / тёмное / цвета акцента). Положение и размер запоминаются.
 *
 * Аватарка, блок статистики и превью видео упруго расступаются от часов — и разбегаются
 * в реальном времени, пока часы тащат. Сдвиг — translationX/Y, и только у тех, кого мы
 * двигали; при скрытии часов всё возвращается на место.
 *
 * Стекло имитированное: настоящее размытие того, что под обычным View, Android дёшево
 * не даёт. Полупрозрачная заливка, блик сверху, светящаяся кромка, преломление снизу
 * и системная тень от контура.
 */
public final class LiquidClockView extends View {

    public static final String KEY_ENABLED = "liquid_clock_enabled";
    public static final String KEY_STYLE = "liquid_clock_style";
    public static final String KEY_REPEL = "liquid_clock_repel";
    private static final String KEY_CX = "liquid_clock_cx";
    private static final String KEY_CY = "liquid_clock_cy";
    private static final String KEY_SCALE = "liquid_clock_scale";

    public static final int STYLE_LIGHT = 0;
    public static final int STYLE_DARK = 1;
    public static final int STYLE_ACCENT = 2;
    public static final String[] STYLE_NAMES = {"Светлое стекло", "Тёмное стекло", "Стекло цвета акцента"};

    public static final String TAG_VIEW = "rootmymargyt_liquid_clock";

    private static final float BASE_W = 210f, BASE_H = 104f;
    private static final float MIN_SCALE = 0.6f, MAX_SCALE = 2.2f;

    private static WeakReference<LiquidClockView> current = new WeakReference<>(null);
    /** decor, куда оверлей уже поставлен в очередь на добавление: пока он «в пути», второй не создаём. */
    private static WeakReference<ViewGroup> pendingFor = new WeakReference<>(null);

    private final PluginContext margyt;
    private final float d;
    private float scale;
    private int style;

    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint highlight = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint rim = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint refraction = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint specular = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint timePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint datePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint handle = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private int shadersFor = -1;

    private String timeText = "";
    private String dateText = "";
    private final Runnable tick = this::onMinute;

    private final ScaleGestureDetector scaleDetector;
    private final GestureDetector tapDetector;
    private boolean touching = false;
    private boolean resizing = false;
    private float downRawX, downRawY, startTX, startTY, startScale, startDiag;

    private LiquidClockView(Context ctx, PluginContext margyt) {
        super(ctx);
        this.margyt = margyt;
        this.d = ctx.getResources().getDisplayMetrics().density;
        this.scale = clamp(margyt != null ? margyt.prefs().getFloat(KEY_SCALE, 1f) : 1f);
        this.style = getStyle(margyt);
        setClickable(true);
        setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_YES);

        rim.setStyle(Paint.Style.STROKE);
        refraction.setStyle(Paint.Style.STROKE);
        handle.setStyle(Paint.Style.STROKE);
        handle.setStrokeCap(Paint.Cap.ROUND);
        handle.setColor(0xCCFFFFFF);
        timePaint.setColor(Color.WHITE);
        timePaint.setTextAlign(Paint.Align.CENTER);
        timePaint.setTypeface(Typeface.create("sans-serif-black", Typeface.NORMAL));
        timePaint.setLetterSpacing(-0.03f);
        datePaint.setColor(0xE6FFFFFF);
        datePaint.setTextAlign(Paint.Align.CENTER);
        datePaint.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));

        // Системная тень от скруглённого контура — мягкая и аппаратная
        setOutlineProvider(new ViewOutlineProvider() {
            @Override
            public void getOutline(View view, Outline outline) {
                outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), view.getHeight() * 0.42f);
                outline.setAlpha(0.55f);
            }
        });
        setElevation(10 * d);

        scaleDetector = new ScaleGestureDetector(ctx, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override
            public boolean onScale(ScaleGestureDetector det) {
                setScale(scale * det.getScaleFactor());
                return true;
            }
        });
        tapDetector = new GestureDetector(ctx, new GestureDetector.SimpleOnGestureListener() {
            @Override
            public boolean onDoubleTap(MotionEvent e) {
                style = (style + 1) % STYLE_NAMES.length;
                if (margyt != null) margyt.prefs().edit().putInt(KEY_STYLE, style).apply();
                shadersFor = -1;
                performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK);
                invalidate();
                return true;
            }
        });
    }

    // ───────────────────────────── Настройки ─────────────────────────────

    public static boolean isEnabled(PluginContext m) {
        return m != null && m.getBoolean(KEY_ENABLED, false);
    }

    public static boolean isRepel(PluginContext m) {
        return m == null || m.getBoolean(KEY_REPEL, true);
    }

    public static int getStyle(PluginContext m) {
        int s = m != null ? m.getInt(KEY_STYLE, STYLE_LIGHT) : STYLE_LIGHT;
        return s < 0 || s >= STYLE_NAMES.length ? STYLE_LIGHT : s;
    }

    public static void setStyle(PluginContext m, int style) {
        if (m != null) m.prefs().edit().putInt(KEY_STYLE, style).apply();
        LiquidClockView v = current.get();
        if (v != null) {
            v.style = style;
            v.shadersFor = -1;
            v.invalidate();
        }
    }

    /** Вернуть в середину шапки обычного размера. */
    public static void resetPlacement(PluginContext m) {
        if (m != null) m.prefs().edit().remove(KEY_CX).remove(KEY_CY).remove(KEY_SCALE).apply();
        LiquidClockView v = current.get();
        if (v != null && v.getParent() instanceof View) {
            v.scale = 1f;
            v.applySize();
            v.placeFromPrefs((View) v.getParent());
        }
    }

    // ───────────────────────────── Показ ─────────────────────────────

    private static WeakReference<View> avatarRef = new WeakReference<>(null);
    private static long lastAvatarFind = 0L;
    private static final android.graphics.Rect AVATAR_SEEN = new android.graphics.Rect();

    /**
     * Профиль действительно на экране, а не просто жив в иерархии.
     *
     * Лента, входящие и профиль — вкладки одной MainActivity: профиль остаётся в
     * дереве (страница пейджера, сдвинутая за экран), и детектор «свой профиль»
     * продолжает отвечать «да» — поэтому часы висели поверх других вкладок.
     * Кольцо и ушки этим не страдали: они проверяют, видна ли аватарка. Здесь то же.
     */
    static boolean profileOnScreen(ViewGroup decor) {
        View avatar = avatarRef.get();
        if (avatar == null || !avatar.isAttachedToWindow()) {
            long now = SystemClock.uptimeMillis();
            if (now - lastAvatarFind < 300L) return false;
            lastAvatarFind = now;
            avatar = ProfileLocator.findProfileAvatar(decor);
            avatarRef = new WeakReference<>(avatar);
            if (avatar == null) return false;
        }
        if (!avatar.isShown() || avatar.getWidth() <= 0) return false;
        // getGlobalVisibleRect отсекает и страницу пейджера за краем экрана, и шапку, прокрученную вверх
        if (!avatar.getGlobalVisibleRect(AVATAR_SEEN)) return false;
        int screenW = decor.getWidth() > 0 ? decor.getWidth() : decor.getResources().getDisplayMetrics().widthPixels;
        return AVATAR_SEEN.right > 0 && AVATAR_SEEN.left < screenW;
    }

    /** Из preDraw-наблюдателя: показать в своём профиле и раздвигать вокруг. Дёшево. */
    public static void update(final Activity activity, final PluginContext m, boolean profileShown) {
        try {
            if (activity == null || activity.isFinishing() || activity.getWindow() == null) return;
            final ViewGroup decor = (ViewGroup) activity.getWindow().getDecorView();
            LiquidClockView v = current.get();
            if (v != null && v.getParent() != decor) v = null;

            if (!isEnabled(m) || !profileShown || !profileOnScreen(decor)) {
                if (v != null && v.getVisibility() != GONE) v.setVisibility(GONE);
                Repel.reset();
                return;
            }
            if (v == null) {
                // preDraw идёт каждый кадр, а добавление — после кадра: без этой проверки
                // за время ожидания создавались дубли
                if (pendingFor.get() == decor || decor.findViewWithTag(TAG_VIEW) != null) return;
                final LiquidClockView fresh = new LiquidClockView(activity, m);
                fresh.setTag(TAG_VIEW);
                pendingFor = new WeakReference<>(decor);
                decor.post(() -> {
                    pendingFor = new WeakReference<>(null);
                    if (fresh.getParent() == null && !activity.isFinishing() && decor.findViewWithTag(TAG_VIEW) == null) {
                        int w = Math.round(BASE_W * fresh.d * fresh.scale);
                        int h = Math.round(BASE_H * fresh.d * fresh.scale);
                        decor.addView(fresh, new FrameLayout.LayoutParams(w, h));
                        fresh.placeFromPrefs(decor);
                        current = new WeakReference<>(fresh);
                    }
                });
                return;
            }
            if (v.getVisibility() != VISIBLE) {
                v.setVisibility(VISIBLE);
                v.bringToFront();
            }
            if (isRepel(m)) Repel.step(decor, v);
            else Repel.reset();
        } catch (Throwable ignored) {}
    }

    private void placeFromPrefs(View parent) {
        float cx = margyt != null ? margyt.prefs().getFloat(KEY_CX, 0.5f) : 0.5f;
        float cy = margyt != null ? margyt.prefs().getFloat(KEY_CY, 0.3f) : 0.3f;
        int pw = parent.getWidth() > 0 ? parent.getWidth() : getResources().getDisplayMetrics().widthPixels;
        int ph = parent.getHeight() > 0 ? parent.getHeight() : getResources().getDisplayMetrics().heightPixels;
        float w = BASE_W * d * scale, h = BASE_H * d * scale;
        setTranslationX(clampX(cx * pw - w / 2f, w, pw));
        setTranslationY(clampY(cy * ph - h / 2f, h, ph));
    }

    private void savePlacement() {
        if (margyt == null || !(getParent() instanceof View)) return;
        View p = (View) getParent();
        if (p.getWidth() <= 0 || p.getHeight() <= 0) return;
        margyt.prefs().edit()
            .putFloat(KEY_CX, (getTranslationX() + getWidth() / 2f) / p.getWidth())
            .putFloat(KEY_CY, (getTranslationY() + getHeight() / 2f) / p.getHeight())
            .putFloat(KEY_SCALE, scale)
            .apply();
    }

    private float clampX(float x, float w, int pw) {
        return Math.max(-w * 0.25f, Math.min(pw - w * 0.75f, x));
    }

    private float clampY(float y, float h, int ph) {
        return Math.max(0f, Math.min(ph - h, y));
    }

    private static float clamp(float s) {
        return Math.max(MIN_SCALE, Math.min(MAX_SCALE, s));
    }

    /** Новый размер с сохранением центра. */
    private void setScale(float s) {
        s = clamp(s);
        if (Math.abs(s - scale) < 0.003f) return;
        float cx = getTranslationX() + getWidth() / 2f;
        float cy = getTranslationY() + getHeight() / 2f;
        scale = s;
        applySize();
        float w = BASE_W * d * scale, h = BASE_H * d * scale;
        setTranslationX(cx - w / 2f);
        setTranslationY(cy - h / 2f);
    }

    private void applySize() {
        ViewGroup.LayoutParams lp = getLayoutParams();
        if (lp == null) return;
        lp.width = Math.round(BASE_W * d * scale);
        lp.height = Math.round(BASE_H * d * scale);
        setLayoutParams(lp);
        shadersFor = -1;
        invalidateOutline();
    }

    // ───────────────────────────── Касания ─────────────────────────────

    @Override
    public boolean onTouchEvent(MotionEvent ev) {
        scaleDetector.onTouchEvent(ev);
        tapDetector.onTouchEvent(ev);
        View parent = getParent() instanceof View ? (View) getParent() : null;
        switch (ev.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                touching = true;
                downRawX = ev.getRawX();
                downRawY = ev.getRawY();
                startTX = getTranslationX();
                startTY = getTranslationY();
                startScale = scale;
                float corner = 40 * d;
                resizing = ev.getX() > getWidth() - corner && ev.getY() > getHeight() - corner;
                startDiag = (float) Math.hypot(ev.getX(), ev.getY());
                animate().scaleX(1.04f).scaleY(1.04f).setDuration(120).start();
                invalidate();
                return true;
            case MotionEvent.ACTION_MOVE:
                if (scaleDetector.isInProgress() || ev.getPointerCount() > 1) return true;
                float dx = ev.getRawX() - downRawX, dy = ev.getRawY() - downRawY;
                if (resizing) {
                    // Тянем уголок: размер растёт пропорционально удалению пальца от левого верха
                    float diag = (float) Math.hypot(ev.getRawX() - (getLeft() + startTX) - locX(), ev.getRawY() - (getTop() + startTY) - locY());
                    if (startDiag > 0) setScaleKeepingTopLeft(startScale * diag / startDiag);
                } else if (parent != null) {
                    setTranslationX(clampX(startTX + dx, getWidth(), parent.getWidth()));
                    setTranslationY(clampY(startTY + dy, getHeight(), parent.getHeight()));
                }
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                touching = false;
                resizing = false;
                animate().scaleX(1f).scaleY(1f).setDuration(320)
                    .setInterpolator(new android.view.animation.OvershootInterpolator(3f)).start();
                savePlacement();
                invalidate();
                return true;
            default:
                return true;
        }
    }

    /** Экранное смещение родителя: rawX/rawY — экранные, translation — в координатах родителя. */
    private float locX() {
        if (!(getParent() instanceof View)) return 0f;
        int[] at = new int[2];
        ((View) getParent()).getLocationOnScreen(at);
        return at[0];
    }

    private float locY() {
        if (!(getParent() instanceof View)) return 0f;
        int[] at = new int[2];
        ((View) getParent()).getLocationOnScreen(at);
        return at[1];
    }

    private void setScaleKeepingTopLeft(float s) {
        s = clamp(s);
        if (Math.abs(s - scale) < 0.003f) return;
        scale = s;
        applySize();
    }

    // ───────────────────────────── Время ─────────────────────────────

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        onMinute();
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        removeCallbacks(tick);
    }

    private void onMinute() {
        Calendar now = Calendar.getInstance();
        boolean h24 = DateFormat.is24HourFormat(getContext());
        int hour = now.get(h24 ? Calendar.HOUR_OF_DAY : Calendar.HOUR);
        if (!h24 && hour == 0) hour = 12;
        int minute = now.get(Calendar.MINUTE);
        timeText = (h24 && hour < 10 ? "0" : "") + hour + ":" + (minute < 10 ? "0" : "") + minute;
        String date = new SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(now.getTime());
        dateText = date.isEmpty() ? date : Character.toUpperCase(date.charAt(0)) + date.substring(1);
        setContentDescription(timeText + ", " + dateText);
        invalidate();
        // Следующее обновление — ровно на границе минуты
        long delay = 60000L - (System.currentTimeMillis() % 60000L) + 50L;
        removeCallbacks(tick);
        postDelayed(tick, delay);
    }

    // ───────────────────────────── Стекло ─────────────────────────────

    private int accent() {
        try {
            if (margyt != null) return margyt.accentColour() | 0xFF000000;
        } catch (Throwable ignored) {}
        return 0xFF8B5CF6;
    }

    private void buildShaders(float w, float h) {
        int key = Math.round(w) * 31 + Math.round(h) + style * 100003;
        if (key == shadersFor) return;
        shadersFor = key;
        switch (style) {
            case STYLE_DARK:
                fill.setColor(0x66101018);
                break;
            case STYLE_ACCENT:
                fill.setColor((accent() & 0x00FFFFFF) | 0x66000000);
                break;
            default:
                fill.setColor(0x38FFFFFF);
                break;
        }
        boolean dark = style == STYLE_DARK;
        highlight.setShader(new LinearGradient(0, 0, 0, h * 0.55f,
            dark ? 0x33FFFFFF : 0x66FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP));
        rim.setStrokeWidth(1.4f * d * Math.max(0.8f, scale));
        rim.setShader(new LinearGradient(0, 0, w, h,
            dark ? 0xA6FFFFFF : 0xE6FFFFFF, dark ? 0x14FFFFFF : 0x26FFFFFF, Shader.TileMode.CLAMP));
        refraction.setStrokeWidth(1.2f * d * Math.max(0.8f, scale));
        refraction.setShader(new LinearGradient(0, h * 0.5f, 0, h,
            0x00FFFFFF, dark ? 0x40FFFFFF : 0x73FFFFFF, Shader.TileMode.CLAMP));
        specular.setShader(new RadialGradient(w * 0.24f, h * 0.2f, Math.max(1f, w * 0.28f),
            dark ? 0x26FFFFFF : 0x4DFFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP));
        timePaint.setTextSize(54 * d * scale);
        timePaint.setShadowLayer(5 * d * scale, 0, 1.5f * d * scale, 0x40000000);
        datePaint.setTextSize(13.5f * d * scale);
        datePaint.setShadowLayer(3 * d * scale, 0, d * scale, 0x40000000);
        handle.setStrokeWidth(3 * d);
    }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight();
        if (w <= 0 || h <= 0) return;
        buildShaders(w, h);
        float r = h * 0.42f;
        float inset = d * 0.7f;
        rect.set(inset, inset, w - inset, h - inset);

        c.drawRoundRect(rect, r, r, fill);
        c.drawRoundRect(rect, r, r, highlight);
        c.drawRoundRect(rect, r, r, specular);
        c.drawRoundRect(rect, r, r, rim);
        float in = 2.6f * d * Math.max(0.8f, scale);
        rect.set(in, in, w - in, h - in);
        c.drawRoundRect(rect, r - in, r - in, refraction);

        // Дата сверху, время крупно под ней
        float dateY = h * 0.30f;
        float timeY = h * 0.80f;
        c.drawText(dateText, w / 2f, dateY, datePaint);
        c.drawText(timeText, w / 2f, timeY, timePaint);

        // Уголок для растягивания — пока часы держат пальцем, как у виджетов iOS
        if (touching) {
            float hs = 14 * d, m = 9 * d;
            c.drawArc(w - m - hs * 2, h - m - hs * 2, w - m, h - m, 0, 90, false, handle);
        }
    }

    // ═════════════════════════════ раздвигание

    /**
     * Аватарка, блок статистики и превью видео упруго отодвигаются от часов.
     * Цель сдвига считается от «настоящего» положения (без нашего translation) — иначе
     * вид, уже отодвинутый, переставал бы чувствовать часы и прыгал обратно.
     */
    static final class Repel {
        private static final WeakHashMap<View, Boolean> moved = new WeakHashMap<>();
        private static WeakReference<ViewGroup> grid = new WeakReference<>(null);
        private static WeakReference<View> avatar = new WeakReference<>(null);
        private static long lastFind = 0L;
        private static final int[] AT = new int[2];
        private static final RectF CLOCK = new RectF();
        private static final List<View> targets = new ArrayList<>();

        static void step(ViewGroup decor, LiquidClockView clock) {
            if (clock.getWidth() <= 0) return;
            clock.getLocationOnScreen(AT);
            // Часы во время нажатия чуть увеличены — берём размер без этого
            CLOCK.set(AT[0], AT[1], AT[0] + clock.getWidth(), AT[1] + clock.getHeight());

            collect(decor);
            float density = decor.getResources().getDisplayMetrics().density;
            float reach = 70 * density * Math.max(0.8f, clock.scale);
            float maxPush = 38 * density * Math.max(0.8f, clock.scale);

            for (int i = 0; i < targets.size(); i++) {
                View v = targets.get(i);
                if (v.getWidth() <= 0 || !v.isShown()) continue;
                v.getLocationOnScreen(AT);
                float left = AT[0] - v.getTranslationX();
                float top = AT[1] - v.getTranslationY();
                float cx = left + v.getWidth() / 2f, cy = top + v.getHeight() / 2f;

                // Расстояние от рамки вида до рамки часов
                float gapX = Math.max(0f, Math.max(CLOCK.left - (left + v.getWidth()), left - CLOCK.right));
                float gapY = Math.max(0f, Math.max(CLOCK.top - (top + v.getHeight()), top - CLOCK.bottom));
                float dist = (float) Math.hypot(gapX, gapY);

                float tx = 0f, ty = 0f;
                if (dist < reach) {
                    float dirX = cx - CLOCK.centerX(), dirY = cy - CLOCK.centerY();
                    float len = (float) Math.hypot(dirX, dirY);
                    if (len < 1f) {
                        dirX = 0f;
                        dirY = 1f;
                        len = 1f;
                    }
                    float k = 1f - dist / reach;
                    float push = maxPush * k * k;
                    tx = dirX / len * push;
                    ty = dirY / len * push;
                }
                // Пружинистое приближение к цели: на каждом кадре четверть пути
                float nx = v.getTranslationX() + (tx - v.getTranslationX()) * 0.25f;
                float ny = v.getTranslationY() + (ty - v.getTranslationY()) * 0.25f;
                if (Math.abs(nx - v.getTranslationX()) > 0.2f || Math.abs(ny - v.getTranslationY()) > 0.2f) {
                    v.setTranslationX(Math.abs(nx) < 0.3f && tx == 0f ? 0f : nx);
                    v.setTranslationY(Math.abs(ny) < 0.3f && ty == 0f ? 0f : ny);
                    moved.put(v, Boolean.TRUE);
                }
            }
        }

        /** Кого раздвигать: ячейки сетки видео, аватарка, блок статистики — без вложенных друг в друга. */
        private static void collect(ViewGroup decor) {
            targets.clear();
            long now = SystemClock.uptimeMillis();
            ViewGroup g = grid.get();
            View a = avatar.get();
            boolean stale = g == null || !g.isShown() || a == null || !a.isShown();
            if (stale && now - lastFind > 500L) {
                lastFind = now;
                if (g == null || !g.isShown()) {
                    g = findGrid(decor);
                    grid = new WeakReference<>(g);
                }
                if (a == null || !a.isShown()) {
                    a = ProfileLocator.findProfileAvatar(decor);
                    avatar = new WeakReference<>(a);
                }
            }
            View stats = RootWallpaperEngine.statsBlockFor(decor);
            if (a != null && a.isShown() && (stats == null || !isInside(a, stats))) targets.add(a);
            if (stats != null && stats.isShown()) targets.add(stats);
            if (g != null && g.isShown()) {
                for (int i = 0; i < g.getChildCount(); i++) {
                    View cell = g.getChildAt(i);
                    if (cell != null && cell.getVisibility() == VISIBLE) targets.add(cell);
                }
            }
        }

        /** Сетка видео — список во всю ширину, начинающийся у строки вкладок видео или ниже. */
        private static ViewGroup findGrid(ViewGroup decor) {
            int tabTop = RootWallpaperEngine.videoTabBarTop(decor);
            if (tabTop <= 0) return null;
            int screenW = decor.getResources().getDisplayMetrics().widthPixels;
            float slack = 8 * decor.getResources().getDisplayMetrics().density;
            return scanGrid(decor, tabTop, screenW, slack, 0);
        }

        private static ViewGroup scanGrid(View v, int tabTop, int screenW, float slack, int depth) {
            if (!(v instanceof ViewGroup) || depth > 40 || v.getVisibility() != VISIBLE) return null;
            ViewGroup g = (ViewGroup) v;
            String type = g.getClass().getName();
            if ((type.contains("RecyclerView") || type.contains("GridView")) && g.getWidth() >= screenW * 0.85f && g.isShown()) {
                g.getLocationOnScreen(AT);
                if (AT[1] >= tabTop - slack) return g;
            }
            for (int i = 0; i < g.getChildCount(); i++) {
                ViewGroup r = scanGrid(g.getChildAt(i), tabTop, screenW, slack, depth + 1);
                if (r != null) return r;
            }
            return null;
        }

        private static boolean isInside(View child, View root) {
            Object p = child.getParent();
            while (p instanceof View) {
                if (p == root) return true;
                p = ((View) p).getParent();
            }
            return false;
        }

        /** Часы скрыты или раздвигание выключено — всё на место. */
        static void reset() {
            if (moved.isEmpty()) return;
            for (View v : moved.keySet()) {
                if (v == null) continue;
                v.animate().translationX(0f).translationY(0f).setDuration(260).start();
            }
            moved.clear();
        }
    }
}
