package cat.narezany.rootmymargyt;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Animatable;
import android.graphics.drawable.Drawable;

/**
 * BackdropDrawable — фон из картинки или GIF: масштаб «center crop», затемняющая/осветляющая
 * подложка поверх и (по желанию) скруглённые верхние углы.
 *
 * Анимированное содержимое (AnimatedImageDrawable) перерисовывает фон само, через Drawable.Callback.
 * Когда вью скрыта, анимация ставится на паузу, чтобы не жечь батарею за кадром.
 */
public final class BackdropDrawable extends Drawable implements Drawable.Callback {

    private Drawable content;
    private final Paint scrimPaint = new Paint();
    private final Path clip = new Path();
    private final RectF rectF = new RectF();
    private final Rect placed = new Rect();

    private float focusY = 0.5f;
    private float topRadius = 0f;
    private int scrimColor = 0;
    private int alpha = 255;

    /** Подпись содержимого: движок по ней понимает, что фон уже собран из этого же файла. */
    public String signature = "";

    public BackdropDrawable() {
        scrimPaint.setStyle(Paint.Style.FILL);
    }

    public void setContent(Drawable d) {
        releaseContent();
        content = d;
        if (d != null) {
            d.setCallback(this);
            d.setAlpha(alpha);
            if (isVisible() && d instanceof Animatable) {
                ((Animatable) d).start();
            }
        }
        placed.setEmpty();
        invalidateSelf();
    }

    public boolean hasContent() {
        return content != null;
    }

    public boolean isAnimated() {
        return content instanceof Animatable;
    }

    public void setScrim(int argb) {
        scrimColor = argb;
        invalidateSelf();
    }

    public void setTopRadius(float px) {
        topRadius = Math.max(0f, px);
        invalidateSelf();
    }

    /** Куда сдвигать кадр, если он выше окна: 0 — прижать к верху, 1 — к низу, 0.5 — по центру. */
    public void setFocusY(float f) {
        focusY = Math.max(0f, Math.min(1f, f));
        placed.setEmpty();
        invalidateSelf();
    }

    /** Остановить анимацию и отпустить содержимое. После этого Drawable можно выбросить. */
    public void release() {
        releaseContent();
        invalidateSelf();
    }

    private void releaseContent() {
        Drawable c = content;
        content = null;
        if (c == null) return;
        try {
            if (c instanceof Animatable) ((Animatable) c).stop();
        } catch (Throwable ignored) {}
        try {
            c.setCallback(null);
        } catch (Throwable ignored) {}
    }

    @Override
    public boolean setVisible(boolean visible, boolean restart) {
        boolean changed = super.setVisible(visible, restart);
        Drawable c = content;
        if (c instanceof Animatable) {
            Animatable a = (Animatable) c;
            try {
                if (visible) {
                    if (!a.isRunning()) a.start();
                } else if (a.isRunning()) {
                    a.stop();
                }
            } catch (Throwable ignored) {}
        }
        return changed;
    }

    @Override
    protected void onBoundsChange(Rect bounds) {
        super.onBoundsChange(bounds);
        placed.setEmpty();
    }

    @Override
    public void draw(Canvas canvas) {
        Rect b = getBounds();
        if (b.isEmpty()) return;
        int save = canvas.save();
        try {
            canvas.clipRect(b);
            if (topRadius > 0f) {
                clip.reset();
                rectF.set(b);
                float r = topRadius;
                clip.addRoundRect(rectF, new float[] { r, r, r, r, 0f, 0f, 0f, 0f }, Path.Direction.CW);
                canvas.clipPath(clip);
            }

            Drawable c = content;
            if (c != null) {
                int iw = c.getIntrinsicWidth();
                int ih = c.getIntrinsicHeight();
                if (iw > 0 && ih > 0) {
                    if (placed.isEmpty()) {
                        float scale = Math.max(b.width() / (float) iw, b.height() / (float) ih);
                        int dw = Math.round(iw * scale);
                        int dh = Math.round(ih * scale);
                        int left = b.left + (b.width() - dw) / 2;
                        int top = b.top + Math.round((b.height() - dh) * focusY);
                        placed.set(left, top, left + dw, top + dh);
                    }
                    c.setBounds(placed);
                } else {
                    c.setBounds(b);
                }
                c.draw(canvas);
            }

            if (Color.alpha(scrimColor) > 0) {
                scrimPaint.setColor(scrimColor);
                scrimPaint.setAlpha(Math.round(Color.alpha(scrimColor) * (alpha / 255f)));
                canvas.drawRect(b, scrimPaint);
            }
        } finally {
            canvas.restoreToCount(save);
        }
    }

    @Override
    public void setAlpha(int a) {
        alpha = a;
        Drawable c = content;
        if (c != null) c.setAlpha(a);
        invalidateSelf();
    }

    @Override
    public void setColorFilter(ColorFilter colorFilter) {
        Drawable c = content;
        if (c != null) c.setColorFilter(colorFilter);
    }

    @Override
    public int getOpacity() {
        return PixelFormat.TRANSLUCENT;
    }

    // ---- Drawable.Callback: кадры анимации перерисовывают нас

    @Override
    public void invalidateDrawable(Drawable who) {
        invalidateSelf();
    }

    @Override
    public void scheduleDrawable(Drawable who, Runnable what, long when) {
        scheduleSelf(what, when);
    }

    @Override
    public void unscheduleDrawable(Drawable who, Runnable what) {
        unscheduleSelf(what);
    }
}
