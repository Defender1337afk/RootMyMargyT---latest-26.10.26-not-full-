package cat.narezany.rootmymargyt;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Outline;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.os.SystemClock;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.TextView;

import java.util.Random;

import cat.narezany.margyt.plugin.PluginContext;

/**
 * ClawdRunGame — «динозаврик» в цвете: бежит Clawd, прыгает через баги и вирусы.
 *
 * Тап — прыжок (держи — выше), свайп вниз — пригнуться / быстро приземлиться.
 * Летающие вирусы (со 250 очков) проходят над пригнувшимся Clawd. Золотые токены — +25.
 * Небо идёт по кругу: день → закат → ночь со звёздами → рассвет.
 *
 * Игровой цикл — onDraw + postInvalidateOnAnimation, физика от реального времени кадра.
 * В кадре ничего не создаётся: краски, пути и пул объектов заготовлены заранее.
 */
public final class ClawdRunGame {

    public static final String KEY_BEST = "clawd_run_best";

    private ClawdRunGame() {}

    public static void show(Activity activity, PluginContext margyt) {
        if (activity == null || activity.isFinishing()) return;
        final Dialog d = new Dialog(activity);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);

        float density = activity.getResources().getDisplayMetrics().density;
        FrameLayout frame = new FrameLayout(activity);
        final float radius = 28 * density;
        frame.setOutlineProvider(new ViewOutlineProvider() {
            @Override
            public void getOutline(View view, Outline outline) {
                outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), radius);
            }
        });
        frame.setClipToOutline(true);

        GameView game = new GameView(activity, margyt);
        frame.addView(game, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        TextView close = new TextView(activity);
        close.setText("✕");
        close.setTextColor(0xFFFFFFFF);
        close.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        close.setGravity(Gravity.CENTER);
        android.graphics.drawable.GradientDrawable cbg = M3X.shape(0x55000000, 20 * density);
        close.setBackground(cbg);
        close.setClickable(true);
        M3X.pressable(close, cbg, 20 * density, 8 * density);
        close.setOnClickListener(v -> d.dismiss());
        int cs = Math.round(40 * density);
        FrameLayout.LayoutParams clp = new FrameLayout.LayoutParams(cs, cs, Gravity.TOP | Gravity.START);
        clp.setMargins(Math.round(12 * density), Math.round(12 * density), 0, 0);
        frame.addView(close, clp);

        d.setContentView(frame);
        if (d.getWindow() != null) {
            d.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            int sw = activity.getResources().getDisplayMetrics().widthPixels;
            int sh = activity.getResources().getDisplayMetrics().heightPixels;
            d.getWindow().setLayout(Math.round(sw * 0.95f), Math.round(Math.min(sh * 0.62f, sw * 1.15f)));
        }
        d.show();
    }

    // ═════════════════════════════════════════════════════════════ игра

    static final class GameView extends View {

        private static final int READY = 0, RUN = 1, OVER = 2;
        private static final int BUG = 0, VIRUS = 1, VIRUS_FLY = 2, TOKEN = 3;
        private static final int POOL = 14;

        private final PluginContext margyt;
        private final float d;
        private final Random rnd = new Random();

        private int state = READY;
        private long lastFrame = 0L;
        private float time = 0f;
        private long overAt = 0L;

        // Clawd: x фиксирован, y — уровень ног относительно земли (0 — стоит, < 0 — в воздухе)
        private float clawdX;
        private float jumpY = 0f;
        private float vy = 0f;
        private boolean holding = false;
        private float holdTime = 0f;
        private boolean ducking = false;
        private float sinceGround = 0f;
        private float downY = 0f;

        private float speed;
        private float distance = 0f;
        private int bonus = 0;
        private int best;
        private float nextSpawn = 0f;
        private float flash = 0f;
        private int lastMilestone = 0;
        private String overLine = "";
        private static final String READY_TITLE = "CLAWD RUN";
        private static final String[] READY_LINES = {"Тап — прыжок (держи — выше)", "Свайп вниз — пригнуться"};
        private final String[] overLines = new String[2];
        private int hudScore = -1, hudBest = -1;
        private String hudScoreText = "", hudBestText = "";

        // Пул препятствий
        private final int[] oType = new int[POOL];
        private final float[] oX = new float[POOL];
        private final float[] oY = new float[POOL];
        private final float[] oW = new float[POOL];
        private final float[] oH = new float[POOL];
        private final int[] oColor = new int[POOL];
        private final float[] oPhase = new float[POOL];
        private final boolean[] oOn = new boolean[POOL];
        /** Препятствие уже пройдено и посчитано для ачивок. */
        private final boolean[] oCounted = new boolean[POOL];

        // Ачивки: статистика забега (на диск — только в конце забега)
        private float runTime = 0f;
        private int runTokens = 0, runBugs = 0, runDucks = 0;
        private final java.util.HashSet<String> askedThisRun = new java.util.HashSet<>();
        private final java.util.ArrayDeque<String> bannerQueue = new java.util.ArrayDeque<>();
        private String bannerText = null;
        private float bannerT = 0f;

        // Всплывающие «+25»
        private final float[] popX = new float[6];
        private final float[] popY = new float[6];
        private final float[] popT = new float[6];

        // Фон
        private final float[] cloudX = new float[5];
        private final float[] cloudY = new float[5];
        private final float[] cloudS = new float[5];
        private final float[] starX = new float[40];
        private final float[] starY = new float[40];
        private final float[] pebbleX = new float[24];
        private final float[] pebbleY = new float[24];
        private float hillFar = 0f, hillNear = 0f, groundScroll = 0f;
        private final Path farHills = new Path();
        private final Path nearHills = new Path();
        private float hillPeriod = 1f;

        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint sky = new Paint();
        private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint pixel = new Paint();
        private final RectF r = new RectF();
        private final Path path = new Path();
        private int skyTopNow = 0, skyBottomNow = 0;
        private float groundY;

        private static final int[] BUG_COLORS = {0xFFE53935, 0xFF43A047, 0xFF8E24AA, 0xFFFB8C00, 0xFF1E88E5};
        private static final String[] OVER_LINES = {
            "Баг победил!", "Clawd поймал вирус", "Лимиты кончились", "Это не баг, это фича?", "Segmentation fault"
        };

        GameView(Context ctx, PluginContext margyt) {
            super(ctx);
            this.margyt = margyt;
            this.d = ctx.getResources().getDisplayMetrics().density;
            this.best = margyt != null ? margyt.getInt(KEY_BEST, 0) : 0;
            stroke.setStyle(Paint.Style.STROKE);
            stroke.setStrokeCap(Paint.Cap.ROUND);
            text.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
            text.setShadowLayer(3 * d, 0, d, 0x66000000);
            setClickable(true);
        }

        @Override
        protected void onSizeChanged(int w, int h, int ow, int oh) {
            super.onSizeChanged(w, h, ow, oh);
            groundY = h * 0.80f;
            clawdX = w * 0.16f;
            for (int i = 0; i < cloudX.length; i++) {
                cloudX[i] = rnd.nextFloat() * w;
                cloudY[i] = h * (0.08f + rnd.nextFloat() * 0.35f);
                cloudS[i] = 0.7f + rnd.nextFloat() * 0.8f;
            }
            for (int i = 0; i < starX.length; i++) {
                starX[i] = rnd.nextFloat() * w;
                starY[i] = rnd.nextFloat() * groundY * 0.7f;
            }
            for (int i = 0; i < pebbleX.length; i++) {
                pebbleX[i] = rnd.nextFloat() * w;
                pebbleY[i] = groundY + 14 * d + rnd.nextFloat() * (h - groundY - 18 * d);
            }
            buildHills(w);
            reset();
        }

        private void buildHills(int w) {
            hillPeriod = Math.max(w, 1);
            farHills.rewind();
            nearHills.rewind();
            // Два периода подряд: при прокрутке на период картинка совпадает с началом
            buildHill(farHills, hillPeriod, groundY - 70 * d, 34 * d, 3);
            buildHill(nearHills, hillPeriod, groundY - 30 * d, 22 * d, 5);
        }

        private void buildHill(Path p, float period, float baseY, float amp, int bumps) {
            p.moveTo(0, groundY + d);
            for (int i = 0; i <= 120; i++) {
                float x = period * 2 * i / 120f;
                double a = x / period * Math.PI * 2 * bumps;
                float y = (float) (baseY - amp * (0.6 * Math.sin(a) + 0.4 * Math.sin(a * 0.5 + 1.3)));
                p.lineTo(x, y);
            }
            p.lineTo(period * 2, groundY + d);
            p.close();
        }

        private void reset() {
            jumpY = 0f;
            vy = 0f;
            ducking = false;
            holding = false;
            speed = 360 * d;
            distance = 0f;
            bonus = 0;
            flash = 0f;
            lastMilestone = 0;
            nextSpawn = getWidth() * 0.9f;
            for (int i = 0; i < POOL; i++) oOn[i] = false;
            for (int i = 0; i < popT.length; i++) popT[i] = 0f;
            runTime = 0f;
            runTokens = 0;
            runBugs = 0;
            runDucks = 0;
            askedThisRun.clear();
        }

        private void startRun() {
            state = RUN;
            int games = Achievements.add(margyt, "games", 1);
            achieve("first_run");
            if (games >= 25) achieve("games_25");
        }

        /** Получить ачивку (каждую спрашиваем у хранилища не чаще раза за забег). */
        private void achieve(String id) {
            if (!askedThisRun.add(id)) return;
            if (Achievements.unlock(margyt, id)) {
                Achievements.Def def = Achievements.find(id);
                if (def != null) bannerQueue.add(def.icon + "  " + def.title);
                performHapticFeedback(HapticFeedbackConstants.CONFIRM);
            }
        }

        private int score() {
            return (int) (distance / (12 * d)) + bonus;
        }

        // ───────────────────────────── ввод

        @Override
        public boolean onTouchEvent(MotionEvent ev) {
            switch (ev.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downY = ev.getY();
                    holding = true;
                    holdTime = 0f;
                    if (state == READY) {
                        startRun();
                        jump();
                    } else if (state == RUN) {
                        jump();
                    } else if (state == OVER && SystemClock.uptimeMillis() - overAt > 450) {
                        reset();
                        startRun();
                        jump();
                    }
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (state == RUN && ev.getY() - downY > 36 * d) {
                        ducking = true;
                        holding = false;
                        if (jumpY < 0) vy = Math.max(vy, 1500 * d); // быстро вниз
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    holding = false;
                    ducking = false;
                    return true;
                default:
                    return true;
            }
        }

        private void jump() {
            // «Койот»: прыжок ещё засчитывается чуть после схода с земли
            if (jumpY >= 0 || sinceGround < 0.08f) {
                vy = -700 * d;
                jumpY = Math.min(jumpY, -0.5f);
                sinceGround = 1f;
                performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
            }
        }

        // ───────────────────────────── шаг мира

        private void step(float dt) {
            time += dt;
            speed = Math.min(980 * d, speed + 10 * d * dt);
            float dx = speed * dt;
            distance += dx;

            // Физика Clawd: пока держишь палец на взлёте — гравитация слабее, прыжок выше
            holdTime += dt;
            float g = 3000 * d;
            if (holding && vy < 0 && holdTime < 0.14f) g *= 0.7f;
            vy += g * dt;
            jumpY += vy * dt;
            if (jumpY >= 0) {
                jumpY = 0;
                vy = 0;
                sinceGround = 0f;
            } else {
                sinceGround += dt;
            }

            // Фон с параллаксом
            hillFar = (hillFar + dx * 0.15f) % hillPeriod;
            hillNear = (hillNear + dx * 0.4f) % hillPeriod;
            groundScroll += dx;
            for (int i = 0; i < cloudX.length; i++) {
                cloudX[i] -= dx * 0.12f * cloudS[i];
                if (cloudX[i] < -120 * d * cloudS[i]) {
                    cloudX[i] = getWidth() + rnd.nextFloat() * 120 * d;
                    cloudY[i] = getHeight() * (0.08f + rnd.nextFloat() * 0.35f);
                }
            }

            // Препятствия
            for (int i = 0; i < POOL; i++) {
                if (!oOn[i]) continue;
                oX[i] -= dx;
                oPhase[i] += dt;
                if (oX[i] + oW[i] < -20 * d) oOn[i] = false;
            }
            nextSpawn -= dx;
            if (nextSpawn <= 0) spawn();

            // Пройденные препятствия — для ачивок
            runTime += dt;
            for (int i = 0; i < POOL; i++) {
                if (!oOn[i] || oCounted[i] || oType[i] == TOKEN || oX[i] + oW[i] >= clawdX) continue;
                oCounted[i] = true;
                if (oType[i] == BUG) runBugs++;
                else if (oType[i] == VIRUS_FLY && ducking) runDucks++;
            }

            // Всплывашки
            for (int i = 0; i < popT.length; i++) {
                if (popT[i] > 0) {
                    popT[i] -= dt;
                    popY[i] -= 40 * d * dt;
                }
            }

            collide();

            int s = score();
            if (s >= 100) achieve("score_100");
            if (s >= 500) achieve("score_500");
            if (s >= 1000) achieve("score_1000");
            if (s >= 2500) achieve("score_2500");
            if (nightAmount() >= 0.99f) achieve("night");
            if (speed >= 980 * d - 1f) achieve("max_speed");
            if (runTime >= 120f) achieve("marathon");
            if (runTokens >= 10) achieve("tokens_run");
            if (s / 100 > lastMilestone) {
                lastMilestone = s / 100;
                flash = 1f;
            }
            flash = Math.max(0f, flash - dt * 1.5f);
        }

        private int free() {
            for (int i = 0; i < POOL; i++) if (!oOn[i]) return i;
            return -1;
        }

        private void spawn() {
            int s = score();
            float w = getWidth();
            float roll = rnd.nextFloat();
            if (s > 250 && roll < 0.18f) {
                add(VIRUS_FLY, w + 20 * d, groundY - 52 * d, 22 * d, 22 * d, 0xFF7E57C2);
            } else if (roll < 0.45f) {
                add(VIRUS, w + 20 * d, groundY - 36 * d, 28 * d, 28 * d, 0xFF7CB342);
            } else {
                // Жуки: по одному или кучкой до трёх
                int n = s > 150 ? 1 + rnd.nextInt(3) : 1 + rnd.nextInt(2);
                float x = w + 20 * d;
                for (int k = 0; k < n; k++) {
                    boolean big = rnd.nextFloat() < 0.4f;
                    float bw = (big ? 40 : 30) * d;
                    float bh = (big ? 26 : 20) * d;
                    add(BUG, x, groundY - bh, bw, bh, BUG_COLORS[rnd.nextInt(BUG_COLORS.length)]);
                    x += bw + 4 * d;
                }
            }
            // Иногда золотой токен — его нужно поймать в прыжке
            if (rnd.nextFloat() < 0.22f) {
                add(TOKEN, w + 150 * d + rnd.nextFloat() * 80 * d, groundY - 84 * d, 22 * d, 22 * d, 0xFFFFC107);
            }
            float min = Math.max(240 * d, speed * 0.55f);
            nextSpawn = min + rnd.nextFloat() * speed * 0.6f;
        }

        private void add(int type, float x, float y, float w, float h, int color) {
            int i = free();
            if (i < 0) return;
            oType[i] = type;
            oX[i] = x;
            oY[i] = y;
            oW[i] = w;
            oH[i] = h;
            oColor[i] = color;
            oPhase[i] = rnd.nextFloat() * 6f;
            oOn[i] = true;
            oCounted[i] = false;
        }

        private float clawdPx() {
            return 3.2f * d;
        }

        private void clawdBox(RectF out) {
            float p = clawdPx();
            float w = (ducking ? 15 : 13) * p;
            float h = (ducking ? 8 : 11) * p;
            float feet = groundY + jumpY;
            out.set(clawdX + w * 0.12f, feet - h + h * 0.06f, clawdX + w - w * 0.12f, feet - h * 0.08f);
        }

        private void collide() {
            clawdBox(r);
            for (int i = 0; i < POOL; i++) {
                if (!oOn[i]) continue;
                float ox = oX[i], oy = oY[i], ow = oW[i], oh = oH[i];
                if (oType[i] == VIRUS_FLY) oy += (float) Math.sin(oPhase[i] * 5) * 1.5f * d;
                float ix = ow * 0.15f, iy = oh * (oType[i] == VIRUS_FLY ? 0.05f : 0.15f);
                boolean hit = r.right > ox + ix && r.left < ox + ow - ix && r.bottom > oy + iy && r.top < oy + oh - iy;
                if (!hit) continue;
                if (oType[i] == TOKEN) {
                    oOn[i] = false;
                    bonus += 25;
                    runTokens++;
                    for (int k = 0; k < popT.length; k++) {
                        if (popT[k] <= 0) {
                            popX[k] = ox;
                            popY[k] = oy;
                            popT[k] = 0.9f;
                            break;
                        }
                    }
                    performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
                } else {
                    die();
                    return;
                }
            }
        }

        private void die() {
            state = OVER;
            overAt = SystemClock.uptimeMillis();
            overLine = OVER_LINES[rnd.nextInt(OVER_LINES.length)];
            performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
            int s = score();
            boolean record = s > best;
            if (record) {
                best = s;
                if (margyt != null) margyt.prefs().edit().putInt(KEY_BEST, best).apply();
                ClawdPetView.react(ClawdPetView.EV_RECORD, s);
            }
            overLines[0] = record ? "Новый рекорд: " + s + "!" : "Счёт " + s + " · Рекорд " + best;

            if (runTime < 3f) achieve("quick_death");
            if (Achievements.add(margyt, "tokens", runTokens) >= 100) achieve("tokens_total");
            if (Achievements.add(margyt, "bugs", runBugs) >= 300) achieve("bugs_total");
            if (Achievements.add(margyt, "ducks", runDucks) >= 10) achieve("duck_10");
            overLines[1] = "Нажми, чтобы ещё раз";
        }

        // ───────────────────────────── отрисовка

        @Override
        protected void onDraw(Canvas c) {
            super.onDraw(c);
            long now = SystemClock.uptimeMillis();
            float dt = lastFrame == 0 ? 0f : Math.min(0.05f, (now - lastFrame) / 1000f);
            lastFrame = now;
            if (state == RUN) step(dt);
            else time += dt;

            drawSky(c);
            drawHills(c);
            drawGround(c);
            for (int i = 0; i < POOL; i++) if (oOn[i]) drawObstacle(c, i);
            drawClawd(c);
            drawPops(c);
            drawHud(c);
            drawBanner(c, dt);
            if (state == READY) drawCenter(c, READY_TITLE, READY_LINES);
            if (state == OVER) drawCenter(c, overLine, overLines);

            postInvalidateOnAnimation();
        }

        @Override
        protected void onDetachedFromWindow() {
            super.onDetachedFromWindow();
            lastFrame = 0L;
        }

        /** 0 — день, 1 — ночь; закат и рассвет — переходы. Полный круг за 1000 очков. */
        private float nightAmount() {
            float t = (score() % 1000) / 1000f;
            if (t < 0.45f) return 0f;
            if (t < 0.6f) return (t - 0.45f) / 0.15f;
            if (t < 0.85f) return 1f;
            return 1f - (t - 0.85f) / 0.15f;
        }

        private float sunsetAmount() {
            float n = nightAmount();
            return n > 0f && n < 1f ? 1f - Math.abs(n - 0.5f) * 2f : 0f;
        }

        private void drawSky(Canvas c) {
            float n = nightAmount();
            float ss = sunsetAmount();
            int top = M3X.mix(M3X.mix(0xFF4FA8F0, 0xFF141A4A, n), 0xFFFF7A59, ss * 0.8f);
            int bottom = M3X.mix(M3X.mix(0xFFCDEBFF, 0xFF3F4A8C, n), 0xFFFFD39A, ss * 0.8f);
            if (top != skyTopNow || bottom != skyBottomNow) {
                skyTopNow = top;
                skyBottomNow = bottom;
                sky.setShader(new LinearGradient(0, 0, 0, groundY, top, bottom, Shader.TileMode.CLAMP));
            }
            c.drawRect(0, 0, getWidth(), groundY + d, sky);

            // Звёзды ночью
            if (n > 0.05f) {
                fill.setColor(0xFFFFFFFF);
                for (int i = 0; i < starX.length; i++) {
                    float tw = 0.5f + 0.5f * (float) Math.sin(time * 2 + i);
                    fill.setAlpha(Math.round(255 * n * (0.4f + 0.6f * tw)));
                    c.drawCircle(starX[i], starY[i], (1 + (i % 3) * 0.5f) * d, fill);
                }
                fill.setAlpha(255);
            }

            // Солнце днём, луна ночью
            float w = getWidth();
            float bodyX = w * 0.78f;
            float bodyY = groundY * 0.22f;
            if (n < 0.5f) {
                fill.setColor(M3X.mix(0xFFFFE066, 0xFFFF8A50, ss));
                fill.setAlpha(Math.round(255 * (1f - n * 2f)));
                c.drawCircle(bodyX, bodyY, 26 * d, fill);
                fill.setAlpha(Math.round(70 * (1f - n * 2f)));
                c.drawCircle(bodyX, bodyY, 38 * d, fill);
            } else {
                fill.setColor(0xFFF5F3CE);
                fill.setAlpha(Math.round(255 * (n * 2f - 1f)));
                c.drawCircle(bodyX, bodyY, 20 * d, fill);
                fill.setColor(skyTopNow);
                c.drawCircle(bodyX + 8 * d, bodyY - 5 * d, 17 * d, fill); // серп
            }
            fill.setAlpha(255);

            // Облака
            int cloud = M3X.mix(0xFFFFFFFF, 0xFF8E99C8, n);
            for (int i = 0; i < cloudX.length; i++) {
                float s = cloudS[i] * d;
                float x = cloudX[i], y = cloudY[i];
                fill.setColor(cloud);
                fill.setAlpha(220);
                c.drawCircle(x, y, 14 * s, fill);
                c.drawCircle(x + 16 * s, y - 8 * s, 18 * s, fill);
                c.drawCircle(x + 34 * s, y, 14 * s, fill);
                r.set(x - 4 * s, y - 2 * s, x + 40 * s, y + 12 * s);
                c.drawRoundRect(r, 8 * s, 8 * s, fill);
            }
            fill.setAlpha(255);
        }

        private void drawHills(Canvas c) {
            float n = nightAmount();
            fill.setColor(M3X.mix(0xFF8FD18F, 0xFF2E3B66, n));
            c.save();
            c.translate(-hillFar, 0);
            c.drawPath(farHills, fill);
            c.restore();
            fill.setColor(M3X.mix(0xFF5DBB63, 0xFF243055, n));
            c.save();
            c.translate(-hillNear, 0);
            c.drawPath(nearHills, fill);
            c.restore();
        }

        private void drawGround(Canvas c) {
            float n = nightAmount();
            float w = getWidth(), h = getHeight();
            fill.setColor(M3X.mix(0xFF8D6E63, 0xFF3E3040, n));
            c.drawRect(0, groundY, w, h, fill);
            fill.setColor(M3X.mix(0xFF7CB342, 0xFF33502E, n));
            c.drawRect(0, groundY, w, groundY + 10 * d, fill);
            // Травинки и камешки едут вместе с миром
            fill.setColor(M3X.mix(0xFF9CCC65, 0xFF3F6037, n));
            float step = 22 * d;
            float off = groundScroll % step;
            for (float x = -off; x < w; x += step) {
                r.set(x, groundY - 3 * d, x + 3 * d, groundY + 2 * d);
                c.drawRect(r, fill);
            }
            fill.setColor(M3X.mix(0xFF6D4C41, 0xFF2C2230, n));
            for (int i = 0; i < pebbleX.length; i++) {
                float x = (pebbleX[i] - groundScroll) % w;
                if (x < 0) x += w;
                c.drawCircle(x, pebbleY[i], (1.5f + (i % 3)) * d, fill);
            }
        }

        // ───────────────────────────── персонажи

        /** Clawd из пикселей: оранжевое тело, глаза «> <», ручки по бокам, четыре ножки. */
        private void drawClawd(Canvas c) {
            float p = clawdPx();
            float feet = groundY + jumpY;
            boolean air = jumpY < 0;
            int bodyW = ducking ? 15 : 12;
            int bodyH = ducking ? 6 : 8;
            int legH = ducking ? 2 : 3;
            float idle = state == READY ? (float) Math.sin(time * 4) * p * 0.5f : 0f;
            float left = clawdX + (ducking ? 0 : p);
            float top = feet - (bodyH + legH) * p + idle;

            // Тень
            fill.setColor(0x33000000);
            float shadow = Math.max(0.3f, 1f + jumpY / (130 * d));
            r.set(clawdX + p, groundY - 2 * d, clawdX + p + bodyW * p * shadow, groundY + 3 * d);
            c.drawOval(r, fill);

            // Ножки: на бегу попарно «шагают», в прыжке поджаты
            int body = 0xFFD97757;
            pixel.setColor(0xFFC4623F);
            boolean phase = ((int) (time * 12)) % 2 == 0;
            int[] legCols = {1, 4, bodyW - 5, bodyW - 2};
            for (int k = 0; k < 4; k++) {
                float lift = 0f;
                if (air) lift = legH * 0.5f;
                else if (state == RUN) lift = ((k % 2 == 0) == phase) ? 1f : 0f;
                float lx = left + legCols[k] * p;
                float ly = top + bodyH * p;
                c.drawRect(lx, ly, lx + p, ly + (legH - lift) * p, pixel);
            }

            // Ручки
            pixel.setColor(body);
            int armRow = ducking ? 2 : 3;
            c.drawRect(left - p, top + armRow * p, left, top + (armRow + 2) * p, pixel);
            c.drawRect(left + bodyW * p, top + armRow * p, left + (bodyW + 1) * p, top + (armRow + 2) * p, pixel);

            // Тело со светом сверху и тенью снизу/справа
            c.drawRect(left, top, left + bodyW * p, top + bodyH * p, pixel);
            pixel.setColor(0xFFE8956F);
            c.drawRect(left, top, left + bodyW * p, top + p, pixel);
            pixel.setColor(0xFFB85C3E);
            c.drawRect(left, top + (bodyH - 1) * p, left + bodyW * p, top + bodyH * p, pixel);
            c.drawRect(left + (bodyW - 1) * p, top + p, left + bodyW * p, top + bodyH * p, pixel);

            // Глаза «>  <»; после проигрыша — «x  x»
            pixel.setColor(0xFF2B1A14);
            float ey = top + (ducking ? 2 : 3) * p;
            float exL = left + 2 * p;
            float exR = left + (bodyW - 4) * p;
            if (state == OVER) {
                cross(c, exL, ey, p);
                cross(c, exR, ey, p);
            } else {
                // >
                c.drawRect(exL, ey, exL + p, ey + p, pixel);
                c.drawRect(exL + p, ey + p, exL + 2 * p, ey + 2 * p, pixel);
                c.drawRect(exL, ey + 2 * p, exL + p, ey + 3 * p, pixel);
                // <
                c.drawRect(exR + p, ey, exR + 2 * p, ey + p, pixel);
                c.drawRect(exR, ey + p, exR + p, ey + 2 * p, pixel);
                c.drawRect(exR + p, ey + 2 * p, exR + 2 * p, ey + 3 * p, pixel);
            }
        }

        private void cross(Canvas c, float x, float y, float p) {
            c.drawRect(x, y, x + p, y + p, pixel);
            c.drawRect(x + p, y + p, x + 2 * p, y + 2 * p, pixel);
            c.drawRect(x + 2 * p, y, x + 3 * p, y + p, pixel);
            c.drawRect(x, y + 2 * p, x + p, y + 3 * p, pixel);
            c.drawRect(x + 2 * p, y + 2 * p, x + 3 * p, y + 3 * p, pixel);
        }

        private void drawObstacle(Canvas c, int i) {
            switch (oType[i]) {
                case BUG: drawBug(c, i); break;
                case VIRUS: drawVirus(c, oX[i] + oW[i] / 2, oY[i] + oH[i] / 2, oW[i] / 2, oColor[i], -oX[i] / (oW[i] / 2), false); break;
                case VIRUS_FLY: {
                    float bob = (float) Math.sin(oPhase[i] * 5) * 1.5f * d;
                    drawVirus(c, oX[i] + oW[i] / 2, oY[i] + oH[i] / 2 + bob, oW[i] / 2, oColor[i], oPhase[i] * 3, true);
                    break;
                }
                case TOKEN: drawToken(c, i); break;
                default: break;
            }
        }

        /** Жук: панцирь с пятнами, голова, шевелящиеся лапки и усики. Смотрит влево — на Clawd. */
        private void drawBug(Canvas c, int i) {
            float x = oX[i], y = oY[i], w = oW[i], h = oH[i];
            int col = oColor[i];
            float wiggle = (float) Math.sin(oPhase[i] * 18) * 2 * d;

            stroke.setColor(0xFF2B2B2B);
            stroke.setStrokeWidth(2 * d);
            for (int k = 0; k < 3; k++) {
                float lx = x + w * (0.3f + 0.22f * k);
                float sway = (k % 2 == 0 ? wiggle : -wiggle);
                c.drawLine(lx, y + h * 0.7f, lx - 4 * d + sway, y + h + d, stroke);
            }
            // Усики
            c.drawLine(x + w * 0.12f, y + h * 0.35f, x - 3 * d, y - 2 * d + wiggle * 0.5f, stroke);
            c.drawLine(x + w * 0.18f, y + h * 0.3f, x + 3 * d, y - 4 * d - wiggle * 0.5f, stroke);

            // Голова
            fill.setColor(0xFF2B2B2B);
            c.drawCircle(x + w * 0.16f, y + h * 0.55f, h * 0.32f, fill);
            fill.setColor(0xFFFFFFFF);
            c.drawCircle(x + w * 0.1f, y + h * 0.48f, h * 0.09f, fill);

            // Панцирь
            fill.setColor(col);
            r.set(x + w * 0.2f, y, x + w, y + h * 0.95f);
            c.drawOval(r, fill);
            fill.setColor(M3X.mix(col, 0xFFFFFFFF, 0.35f));
            r.set(x + w * 0.35f, y + h * 0.1f, x + w * 0.7f, y + h * 0.35f);
            c.drawOval(r, fill);
            stroke.setColor(M3X.mix(col, 0xFF000000, 0.4f));
            stroke.setStrokeWidth(1.5f * d);
            c.drawLine(x + w * 0.6f, y + h * 0.05f, x + w * 0.6f, y + h * 0.9f, stroke);
            fill.setColor(M3X.mix(col, 0xFF000000, 0.45f));
            c.drawCircle(x + w * 0.45f, y + h * 0.55f, h * 0.1f, fill);
            c.drawCircle(x + w * 0.78f, y + h * 0.4f, h * 0.1f, fill);
            c.drawCircle(x + w * 0.75f, y + h * 0.7f, h * 0.08f, fill);
        }

        /** Вирус: шар с шипами-грибками и сердитой мордочкой; катится или парит. */
        private void drawVirus(Canvas c, float cx, float cy, float rad, int col, float angle, boolean flying) {
            float spike = flying ? 1.15f : 1.3f;
            stroke.setColor(M3X.mix(col, 0xFF000000, 0.25f));
            stroke.setStrokeWidth(2.5f * d);
            fill.setColor(M3X.mix(col, 0xFFFFFFFF, 0.25f));
            for (int k = 0; k < 8; k++) {
                double a = angle + k * Math.PI / 4;
                float sx = cx + (float) Math.cos(a) * rad * 0.9f;
                float sy = cy + (float) Math.sin(a) * rad * 0.9f;
                float ex = cx + (float) Math.cos(a) * rad * spike;
                float ey = cy + (float) Math.sin(a) * rad * spike;
                c.drawLine(sx, sy, ex, ey, stroke);
                c.drawCircle(ex, ey, rad * (flying ? 0.13f : 0.17f), fill);
            }
            fill.setColor(col);
            c.drawCircle(cx, cy, rad, fill);
            fill.setColor(M3X.mix(col, 0xFFFFFFFF, 0.3f));
            c.drawCircle(cx - rad * 0.35f, cy - rad * 0.35f, rad * 0.25f, fill);
            // Сердитые глаза
            fill.setColor(0xFFFFFFFF);
            c.drawCircle(cx - rad * 0.35f, cy, rad * 0.22f, fill);
            c.drawCircle(cx + rad * 0.2f, cy, rad * 0.22f, fill);
            fill.setColor(0xFF1A1A1A);
            c.drawCircle(cx - rad * 0.4f, cy + rad * 0.03f, rad * 0.11f, fill);
            c.drawCircle(cx + rad * 0.15f, cy + rad * 0.03f, rad * 0.11f, fill);
            stroke.setColor(0xFF1A1A1A);
            stroke.setStrokeWidth(2 * d);
            c.drawLine(cx - rad * 0.6f, cy - rad * 0.35f, cx - rad * 0.15f, cy - rad * 0.2f, stroke);
            c.drawLine(cx + rad * 0.45f, cy - rad * 0.35f, cx, cy - rad * 0.2f, stroke);
            if (flying) {
                // Крылышки
                fill.setColor(0xAAFFFFFF);
                float flap = (float) Math.sin(time * 30) * rad * 0.25f;
                r.set(cx - rad * 0.2f, cy - rad * 1.5f - flap, cx + rad * 0.9f, cy - rad * 0.7f);
                c.drawOval(r, fill);
            }
        }

        private void drawToken(Canvas c, int i) {
            float cx = oX[i] + oW[i] / 2, cy = oY[i] + oH[i] / 2;
            float rad = oW[i] / 2;
            float squash = Math.abs((float) Math.cos(oPhase[i] * 4)); // монетка вращается
            fill.setColor(0x55FFE082);
            c.drawCircle(cx, cy, rad * 1.5f, fill);
            fill.setColor(0xFFFFC107);
            r.set(cx - rad * Math.max(0.15f, squash), cy - rad, cx + rad * Math.max(0.15f, squash), cy + rad);
            c.drawOval(r, fill);
            if (squash > 0.5f) {
                text.setColor(0xFF8D5A00);
                text.setTextSize(rad * 1.2f);
                text.setTextAlign(Paint.Align.CENTER);
                text.clearShadowLayer();
                c.drawText("T", cx, cy + rad * 0.42f, text);
                text.setShadowLayer(3 * d, 0, d, 0x66000000);
            }
        }

        private void drawPops(Canvas c) {
            text.setTextAlign(Paint.Align.CENTER);
            text.setTextSize(16 * d);
            for (int i = 0; i < popT.length; i++) {
                if (popT[i] <= 0) continue;
                text.setColor(0xFFFFD54F);
                text.setAlpha(Math.round(255 * Math.min(1f, popT[i] * 1.5f)));
                c.drawText("+25", popX[i], popY[i], text);
            }
            text.setAlpha(255);
        }

        private void drawHud(Canvas c) {
            text.setTextAlign(Paint.Align.RIGHT);
            text.setTextSize(18 * d);
            float x = getWidth() - 16 * d, y = 34 * d;
            boolean blink = flash > 0f && ((int) (flash * 8)) % 2 == 0;
            text.setColor(blink ? 0xFFFFD54F : 0xFFFFFFFF);
            int sc = score();
            if (sc != hudScore) {
                hudScore = sc;
                hudScoreText = pad(sc);
            }
            if (best != hudBest) {
                hudBest = best;
                hudBestText = "HI " + pad(best);
            }
            c.drawText(hudScoreText, x, y, text);
            text.setColor(0xCCFFFFFF);
            text.setTextSize(14 * d);
            c.drawText(hudBestText, x, y + 20 * d, text);
        }

        /** Плашка «ачивка получена»: выезжает сверху, висит ~2 секунды, уезжает. */
        private void drawBanner(Canvas c, float dt) {
            if (bannerText == null) {
                if (bannerQueue.isEmpty()) return;
                bannerText = "🏆  " + bannerQueue.poll(); // подпись собирается один раз на плашку
                bannerT = 2.4f;
            }
            bannerT -= dt;
            if (bannerT <= 0f) {
                bannerText = null;
                return;
            }
            float appear = Math.min(1f, (2.4f - bannerT) / 0.25f);
            float leave = Math.min(1f, bannerT / 0.25f);
            float k = Math.min(appear, leave);
            float y = -40 * d + (64 * d) * k;

            text.setTextSize(15 * d);
            text.setTextAlign(Paint.Align.CENTER);
            String label = bannerText;
            float tw = text.measureText(label);
            float w = getWidth();
            r.set(w / 2 - tw / 2 - 18 * d, y - 22 * d, w / 2 + tw / 2 + 18 * d, y + 12 * d);
            fill.setColor(0xF0FFF4D6);
            c.drawRoundRect(r, 17 * d, 17 * d, fill);
            text.setColor(0xFF5B3A00);
            text.clearShadowLayer();
            c.drawText(label, w / 2, y, text);
            text.setShadowLayer(3 * d, 0, d, 0x66000000);
        }

        private static String pad(int v) {
            String s = String.valueOf(Math.max(0, v));
            return s.length() >= 5 ? s : "00000".substring(s.length()) + s;
        }

        private void drawCenter(Canvas c, String title, String[] lines) {
            float w = getWidth();
            float cy = getHeight() * 0.38f;
            fill.setColor(0x66000000);
            r.set(w * 0.08f, cy - 44 * d, w * 0.92f, cy + 52 * d);
            c.drawRoundRect(r, 24 * d, 24 * d, fill);
            text.setTextAlign(Paint.Align.CENTER);
            text.setColor(0xFFFFFFFF);
            text.setTextSize(26 * d);
            c.drawText(title, w / 2, cy - 8 * d, text);
            text.setTextSize(13 * d);
            text.setColor(0xE6FFFFFF);
            for (int i = 0; i < lines.length; i++) c.drawText(lines[i], w / 2, cy + 18 * d + i * 18 * d, text);
        }
    }
}
