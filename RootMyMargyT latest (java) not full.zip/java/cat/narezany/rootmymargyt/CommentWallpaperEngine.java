package cat.narezany.rootmymargyt;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.File;
import java.lang.ref.WeakReference;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

import cat.narezany.margyt.plugin.PluginContext;
import cat.narezany.rootmymargyt.core.Host;

/**
 * CommentWallpaperEngine — свой фон (картинка или GIF) за шторкой комментариев.
 *
 * Как находим шторку — три способа по убыванию надёжности:
 * 1. MargyT сам помечает каждую ячейку комментария тегом 0x5454434D (Comments.mark,
 *    им же пользуется его Dim). От первой видимой помеченной ячейки поднимаемся до
 *    самого внешнего предка, который ещё похож на шторку по размеру.
 * 2. Контейнер, чей класс или id ресурса называется как панель комментариев
 *    (commentpanel / commentlist / commentsheet, x.0h10 в текущей сборке) — те же имена,
 *    по которым шторку узнаёт Dim.
 * 3. Запасной: заголовок «N комментариев» и поле «Добавить комментарий…» под ним.
 *
 * Шторка бывает и в окне activity, и в отдельном окне (диалог), поэтому просматриваются
 * корни всех окон приложения. Окно-диалог не вызывает onPreDraw activity, а если видео
 * под шторкой на паузе, activity не перерисовывается вовсе — поэтому есть опрос.
 *
 * Поверх картинки — подложка цвета темы: белая при тёмном тексте комментариев, чёрная при
 * светлом, так текст TikTok остаётся читаемым без перекраски. Поле ввода остаётся родным:
 * контейнеры с EditText не очищаются.
 */
public final class CommentWallpaperEngine {

    public static final String KEY_ENABLED = "comments_bg_enabled";
    public static final String KEY_SOURCE = "comments_bg_source";
    public static final String KEY_VEIL = "comments_bg_veil";
    public static final String KEY_SCOPE = "comments_bg_scope";

    public static final int SOURCE_PROFILE = 0;
    public static final int SOURCE_OWN = 1;

    /** Где показывать фон: во весь лист комментариев или только на своём комментарии. */
    public static final int SCOPE_SHEET = 0;
    public static final int SCOPE_OWN = 1;

    public static final int DEFAULT_VEIL = 60;
    public static final int[] VEIL_LEVELS = {0, 30, 45, 60, 75};

    /** Метка ячейки комментария, которую ставит MargyT (Comments.mark). */
    private static final int TAG_COMMENT_CELL = 0x5454434D;
    private static final int TAG_KEY_ORIGINAL_BG = 0x7F0B9990;
    private static final int TAG_KEY_ROOT_HOOKED = 0x7F0B9991;

    private static final long THROTTLE_MS = 400;
    private static final long POLL_MS = 600;
    private static final long CLEAR_EVERY_MS = 1000;
    private static final int SCAN_BUDGET = 9000;

    private static final Pattern HEADER = Pattern.compile(
        "^(\\d[\\d\\s.,]*\\s*(тыс\\.?|млн|k|m)?\\s*)?(комментари[йяеив]*|comments?)"
        + "(\\s*[(:]?\\s*\\d[\\d\\s.,]*\\s*(тыс\\.?|млн|k|m)?\\)?)?$");
    private static final String[] INPUT_PREFIXES = {
        "добавить комментарий", "добавьте комментарий", "оставить комментарий",
        "оставьте комментарий", "написать комментарий", "напишите комментарий",
        "add comment", "add a comment", "leave a comment"
    };

    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    private static PluginContext margytRef;
    private static final List<WeakReference<View>> touchedViews = new ArrayList<>();
    private static WeakReference<ViewGroup> appliedSheet = null;
    private static int missCount = 0;
    private static long lastRunAt = 0;
    private static long lastClearAt = 0;
    private static long lastOwnLog = 0;
    private static boolean trailingScheduled = false;
    private static boolean windowReflectionBroken = false;

    /** Загруженное содержимое: один GIF на шторку, переиспользуется, пока не сменился источник. */
    private static String contentSig = "";
    private static Drawable content = null;
    private static String failedSig = "";

    // ── Уступка новой фиче мода "design_comments" (класс CommentStyle) ──
    // Начиная с обновления интерфейса MargyT сам красит фон панели комментариев
    // (Surface/GlassBackdrop) и переустанавливает его на каждый layout/scroll.
    // Если одновременно свой фон ставит и плагин — оба дерутся за background
    // панели, и фон моргает. Поэтому пока активен наш коммент-фон, мы временно
    // гасим design_comments мода, а когда выключаем — возвращаем как было.
    // CommentStyle.set() пишет design_comments на диск, поэтому и пометка «это мы
    // выключили» хранится в настройках плагина — иначе после перезапуска она
    // терялась, и стиль комментариев мода оставался выключенным навсегда.
    private static final String KEY_MUTED_MOD_STYLE = "comments_bg_muted_mod_style";
    /** Последнее отданное состояние: трогаем мод только при смене, а не каждый кадр. */
    private static Boolean lastYield = null;

    private static void yieldModCommentStyle(boolean pluginActive, PluginContext margyt) {
        if (!Host.hasCommentStyle()) return; // старая сборка без CommentStyle
        // Только на переходе вкл/выкл: так пользователь может сам включить
        // design_comments обратно, и плагин не перещёлкнет его на следующем кадре
        if (lastYield != null && lastYield == pluginActive) return;
        lastYield = pluginActive;
        boolean on = Host.commentStyleEnabled();
        boolean weMuted = margyt != null && margyt.getBoolean(KEY_MUTED_MOD_STYLE, false);
        if (pluginActive) {
            // Гасим только если мод реально держит фичу включённой — запоминаем, что это мы.
            if (on) { Host.setCommentStyle(false); weMuted = true; }
        } else if (weMuted) {
            if (!on) Host.setCommentStyle(true);
            weMuted = false;
        }
        if (margyt != null) margyt.prefs().edit().putBoolean(KEY_MUTED_MOD_STYLE, weMuted).apply();
    }

    private CommentWallpaperEngine() {}

    // ───────────────────────────── Настройки ─────────────────────────────

    public static boolean isEnabled(PluginContext margyt) {
        return margyt != null && margyt.getBoolean(KEY_ENABLED, false);
    }

    public static void setEnabled(PluginContext margyt, boolean on) {
        if (margyt != null) margyt.prefs().edit().putBoolean(KEY_ENABLED, on).apply();
    }

    public static int getSource(PluginContext margyt) {
        return margyt != null && margyt.getInt(KEY_SOURCE, SOURCE_PROFILE) == SOURCE_OWN ? SOURCE_OWN : SOURCE_PROFILE;
    }

    public static void setSource(PluginContext margyt, int source) {
        if (margyt != null) margyt.prefs().edit().putInt(KEY_SOURCE, source).apply();
    }

    public static int getScope(PluginContext margyt) {
        return margyt != null && margyt.getInt(KEY_SCOPE, SCOPE_SHEET) == SCOPE_OWN ? SCOPE_OWN : SCOPE_SHEET;
    }

    public static void setScope(PluginContext margyt, int scope) {
        if (margyt != null) margyt.prefs().edit().putInt(KEY_SCOPE, scope).apply();
        invalidate();
    }

    public static int getVeil(PluginContext margyt) {
        int v = margyt != null ? margyt.getInt(KEY_VEIL, DEFAULT_VEIL) : DEFAULT_VEIL;
        return Math.max(0, Math.min(90, v));
    }

    public static void setVeil(PluginContext margyt, int veil) {
        if (margyt != null) margyt.prefs().edit().putInt(KEY_VEIL, veil).apply();
    }

    // ───────────────────────────── Своё фото ─────────────────────────────

    /** Файл своего фона комментариев (слот BackdropMedia, GIF сохраняется как есть) или null. */
    public static File ownFile(Context context) {
        if (context == null) return null;
        File f = BackdropMedia.fileOf(context, BackdropMedia.SLOT_COMMENTS);
        if (f != null) return f;
        // Ранние сборки 5.1 хранили своё фото JPEG-ом отдельно
        File legacy = new File(new File(context.getFilesDir(), "rootmymargyt"), "comments_wallpaper.jpg");
        return legacy.length() > 0 ? legacy : null;
    }

    public static boolean hasOwn(Context context) {
        return ownFile(context) != null;
    }

    /** @deprecated оставлено для старых вызовов; используй {@link #hasOwn}. */
    @Deprecated
    public static File getOwnFile(Context context) {
        File f = ownFile(context);
        return f != null ? f : new File(context.getFilesDir(), "rootmymargyt/media/comments_bg.none");
    }

    public static boolean saveFromUri(Context context, Uri uri, PluginContext margyt) {
        int kind = BackdropMedia.saveFromUri(context, uri, BackdropMedia.SLOT_COMMENTS, margyt);
        if (kind == BackdropMedia.KIND_NONE) {
            RootWallpaperEngine.lastSaveError = BackdropMedia.lastError();
            return false;
        }
        if (margyt != null) {
            margyt.prefs().edit()
                .putInt(KEY_SOURCE, SOURCE_OWN)
                .putBoolean(KEY_ENABLED, true)
                .apply();
        }
        invalidate();
        return true;
    }

    public static void clearOwn(Context context, PluginContext margyt) {
        BackdropMedia.clear(context, margyt, BackdropMedia.SLOT_COMMENTS);
        new File(new File(context.getFilesDir(), "rootmymargyt"), "comments_wallpaper.jpg").delete();
        setSource(margyt, SOURCE_PROFILE);
        invalidate();
    }

    /** Источник или настройки сменились: фон соберётся заново на следующем проходе. */
    public static void invalidate() {
        failedSig = "";
        dropContent();
        restoreAll();
    }

    // ───────────────────────────── Обновление ─────────────────────────────

    public static void update(Activity activity, PluginContext margyt) {
        update(activity, margyt, false);
    }

    public static void update(final Activity activity, final PluginContext margyt, boolean force) {
        if (activity == null || activity.isFinishing()) return;
        margytRef = margyt;

        if (!isEnabled(margyt)) {
            if (!touchedViews.isEmpty() || appliedSheet != null) restoreAll();
            dropContent();
            yieldModCommentStyle(false, margyt);
            return;
        }
        // Пока наш фон активен — мод не должен красить ту же панель сам.
        yieldModCommentStyle(true, margyt);
        startPolling(activity);

        if (!force) {
            long wait = THROTTLE_MS - (SystemClock.uptimeMillis() - lastRunAt);
            if (wait > 0) {
                if (!trailingScheduled) {
                    trailingScheduled = true;
                    final WeakReference<Activity> ref = new WeakReference<>(activity);
                    MAIN.postDelayed(() -> {
                        trailingScheduled = false;
                        Activity a = ref.get();
                        if (a != null && !a.isFinishing()) update(a, margytRef, false);
                    }, wait);
                }
                return;
            }
        }
        lastRunAt = SystemClock.uptimeMillis();

        try {
            doUpdate(activity, margyt);
        } catch (Throwable t) {
            restoreAll();
            if (margyt != null) margyt.log("comments bg: " + t);
        }
    }

    private static void doUpdate(Activity activity, PluginContext margyt) {
        int screenW = activity.getResources().getDisplayMetrics().widthPixels;
        int screenH = activity.getResources().getDisplayMetrics().heightPixels;

        Found found = null;
        View foundRoot = null;
        for (View root : collectRoots(activity)) {
            found = findSheet(root, screenW, screenH);
            if (found != null) {
                foundRoot = root;
                break;
            }
        }

        ViewGroup applied = appliedSheet != null ? appliedSheet.get() : null;
        if (found == null) {
            // Один пропуск — ещё не закрытие: шторка могла перестраиваться на этом кадре
            if (applied != null && (!applied.isAttachedToWindow() || !applied.isShown() || ++missCount >= 2)) {
                restoreAll();
            }
            pruneTouched();
            return;
        }
        missCount = 0;

        // Куда красим: во весь лист (SCOPE_SHEET) или только на свой комментарий (SCOPE_OWN).
        ViewGroup target = found.sheet;
        boolean ownScope = getScope(margyt) == SCOPE_OWN;
        if (ownScope) {
            ViewGroup ownCell = findOwnCommentCell(found.sheet, margyt);
            if (ownCell == null) {
                // Своего комментария сейчас не видно на экране — снимаем прошлый фон, лист не красим.
                // Диагностика (раз в ~5с): какой ник ищем — помогает понять, если имя не совпадает.
                long now = SystemClock.uptimeMillis();
                if (margyt != null && now - lastOwnLog > 5000L) {
                    lastOwnLog = now;
                    String nk = margyt.getString("local_my_account_name", "");
                    margyt.log("comments bg (мой коммент): своя ячейка не найдена; ищу ник='" + nk + "'"
                        + (nk == null || nk.isEmpty() ? " (ник ещё не известен — открой свой профиль/ленту разок)" : ""));
                }
                if (applied != null) restoreAll();
                pruneTouched();
                return;
            }
            target = ownCell;
        }
        if (applied != null && applied != target) restoreAll();

        String sig = sourceSignature(activity, margyt);
        if (sig.equals(failedSig)) return;
        Drawable media = contentFor(activity, margyt, sig);
        if (media == null) {
            failedSig = sig;
            margyt.log("comments bg: не удалось прочитать картинку для комментариев");
            return;
        }

        // Чистим непрозрачные слои и на листе, и на своей ячейке — иначе картинка прячется за фоном контента.
        applyTo(target, found, media, sig + "|" + getVeil(margyt) + (ownScope ? "|own" : ""),
                getVeil(margyt), screenW, true);
        if (foundRoot != activity.getWindow().getDecorView()) hookForeignRoot(foundRoot, activity);
    }

    private static final class Found {
        ViewGroup sheet;
        /** Любой текст комментариев: по его цвету понимаем, светлая тема или тёмная. */
        TextView sample;
    }

    private static void apply(Found found, Drawable media, String sig, int veil, int screenW) {
        applyTo(found.sheet, found, media, sig, veil, screenW, true);
    }

    private static void applyTo(ViewGroup target, Found found, Drawable media, String sig, int veil,
                                int screenW, boolean clearChildLayers) {
        ViewGroup sheet = target;
        Drawable current = sheet.getBackground();
        if (!(current instanceof BackdropDrawable) || !sig.equals(((BackdropDrawable) current).signature)) {
            if (current instanceof BackdropDrawable) {
                ((BackdropDrawable) current).release();
            } else {
                remember(sheet, current);
            }
            Object saved = sheet.getTag(TAG_KEY_ORIGINAL_BG);
            Drawable original = saved instanceof Drawable ? (Drawable) saved : null;

            int base = found.sample != null && !isDark(found.sample.getCurrentTextColor()) ? 0 : 255;
            BackdropDrawable d = new BackdropDrawable();
            d.signature = sig;
            d.setFocusY(0.35f);
            d.setScrim(Color.argb(veil * 255 / 100, base, base, base));
            d.setTopRadius(cornerOf(original, sheet.getResources().getDisplayMetrics().density));
            d.setContent(media);
            sheet.setBackground(d);
            appliedSheet = new WeakReference<>(sheet);
            lastClearAt = 0;
        }

        // TikTok может вернуть непрозрачную подложку строкам при прокрутке — проверяем раз в секунду.
        // Только в режиме «во весь лист»: на своей ячейке детей не чистим.
        if (clearChildLayers) {
            long now = SystemClock.uptimeMillis();
            if (now - lastClearAt >= CLEAR_EVERY_MS) {
                lastClearAt = now;
                clearLayers(sheet, sheet.getWidth(), sheet.getResources().getDisplayMetrics().density, 0);
            }
        }
    }

    /**
     * Широкие контейнеры со своим фоном закрыли бы картинку — снимаем с них фон.
     * Не трогаем: картинки (аватарки, стикеры), поле ввода вместе с его панелью, мелкие кнопки.
     */
    private static void clearLayers(ViewGroup parent, int sheetW, float density, int depth) {
        if (depth > 14 || sheetW <= 0) return;
        for (int i = 0; i < parent.getChildCount(); i++) {
            View c = parent.getChildAt(i);
            if (c == null || c.getVisibility() != View.VISIBLE) continue;
            if (c instanceof ImageView || c instanceof EditText) continue;
            if (c instanceof ViewGroup && containsEditText(c, 0)) continue;

            Drawable bg = c.getBackground();
            if (bg != null && !(bg instanceof BackdropDrawable)
                    && !(bg instanceof ColorDrawable && ((ColorDrawable) bg).getAlpha() == 0)
                    && c.getWidth() >= sheetW * 0.8f && c.getHeight() >= 36 * density) {
                remember(c, bg);
                c.setBackground(new ColorDrawable(Color.TRANSPARENT));
            }
            if (c instanceof ViewGroup) clearLayers((ViewGroup) c, sheetW, density, depth + 1);
        }
    }

    private static boolean containsEditText(View v, int depth) {
        if (v instanceof EditText) return true;
        if (depth > 6 || !(v instanceof ViewGroup)) return false;
        ViewGroup g = (ViewGroup) v;
        for (int i = 0; i < g.getChildCount(); i++) {
            if (containsEditText(g.getChildAt(i), depth + 1)) return true;
        }
        return false;
    }

    private static void remember(View v, Drawable original) {
        if (v.getTag(TAG_KEY_ORIGINAL_BG) == null) {
            v.setTag(TAG_KEY_ORIGINAL_BG, original != null ? original : RootWallpaperEngine.NO_ORIGINAL);
            touchedViews.add(new WeakReference<>(v));
        }
    }

    public static void restoreAll() {
        for (WeakReference<View> ref : touchedViews) {
            View v = ref.get();
            if (v == null) continue;
            Drawable cur = v.getBackground();
            if (cur instanceof BackdropDrawable) ((BackdropDrawable) cur).release();
            Object bg = v.getTag(TAG_KEY_ORIGINAL_BG);
            if (bg != null) {
                v.setBackground(bg instanceof Drawable ? (Drawable) bg : null);
                v.setTag(TAG_KEY_ORIGINAL_BG, null);
            }
        }
        touchedViews.clear();
        appliedSheet = null;
        missCount = 0;
    }

    private static void pruneTouched() {
        for (int i = touchedViews.size() - 1; i >= 0; i--) {
            View v = touchedViews.get(i).get();
            if (v == null || !v.isAttachedToWindow()) touchedViews.remove(i);
        }
    }

    // ───────────────────────────── Содержимое ─────────────────────────────

    private static boolean profileIsCustom(PluginContext m) {
        String preset = m.getString(RootWallpaperEngine.KEY_WALLPAPER_PRESET, "");
        return preset == null || preset.isEmpty() || RootWallpaperEngine.PRESET_CUSTOM.equals(preset);
    }

    private static String sourceSignature(Context ctx, PluginContext m) {
        if (getSource(m) == SOURCE_OWN) {
            File f = ownFile(ctx);
            if (f != null) return "own|" + f.getAbsolutePath() + "|" + BackdropMedia.version(m, BackdropMedia.SLOT_COMMENTS);
        }
        Bitmap b = RootWallpaperEngine.getWallpaperBitmap(ctx, m);
        return "profile|" + m.getString(RootWallpaperEngine.KEY_WALLPAPER_PRESET, "")
            + "|" + RootWallpaperEngine.isAnimated(m) + "|" + RootWallpaperEngine.isPlayGif(m)
            + "|" + System.identityHashCode(b);
    }

    private static Drawable contentFor(Activity a, PluginContext m, String sig) {
        if (content != null && sig.equals(contentSig)) return content;
        dropContent();

        Drawable d = null;
        if (getSource(m) == SOURCE_OWN) {
            File f = ownFile(a);
            if (f != null) d = BackdropMedia.load(a, f, 1080);
        }
        if (d == null && profileIsCustom(m) && RootWallpaperEngine.isAnimated(m)
                && !RootWallpaperEngine.isVideo(m) && RootWallpaperEngine.isPlayGif(m)) {
            File anim = RootWallpaperEngine.getAnimFile(a);
            if (anim.length() > 0) d = BackdropMedia.load(a, anim, 1080);
        }
        if (d == null) {
            // Статичное фото, первый кадр GIF/видео или пресет
            Bitmap b = RootWallpaperEngine.getWallpaperBitmap(a, m);
            if (b != null && !b.isRecycled()) d = new BitmapDrawable(a.getResources(), b);
        }
        if (d != null) {
            content = d;
            contentSig = sig;
        }
        return d;
    }

    private static void dropContent() {
        Drawable d = content;
        content = null;
        contentSig = "";
        if (d instanceof android.graphics.drawable.Animatable) {
            try {
                ((android.graphics.drawable.Animatable) d).stop();
            } catch (Throwable ignored) {}
        }
    }

    // ───────────────────────────── Поиск шторки ─────────────────────────────

    private static Found findSheet(View root, int screenW, int screenH) {
        // 1. Ячейка, помеченная MargyT
        View cell = findMarkedCell(root);
        if (cell != null) {
            ViewGroup sheet = climbToSheet(cell, root, screenW, screenH);
            if (sheet != null) return found(sheet);
        }

        // 2. Контейнер с «комментарийным» именем класса или id
        View panel = findNamedPanel(root, screenW);
        if (panel != null) {
            ViewGroup sheet = climbToSheet(panel, root, screenW, screenH);
            if (sheet != null) return found(sheet);
        }

        // 3. Заголовок + поле ввода
        return findByText(root, screenW, screenH);
    }

    private static Found found(ViewGroup sheet) {
        Found f = new Found();
        f.sheet = sheet;
        f.sample = firstText(sheet, 0);
        return f;
    }

    private static View findMarkedCell(View root) {
        ArrayDeque<View> queue = new ArrayDeque<>();
        queue.add(root);
        int seen = 0;
        while (!queue.isEmpty() && seen++ < SCAN_BUDGET) {
            View v = queue.poll();
            if (v.getVisibility() != View.VISIBLE) continue;
            if (Boolean.TRUE.equals(v.getTag(TAG_COMMENT_CELL)) && v.getWidth() > 0 && v.isShown()) return v;
            if (v instanceof ViewGroup) {
                ViewGroup g = (ViewGroup) v;
                for (int i = 0; i < g.getChildCount(); i++) {
                    View c = g.getChildAt(i);
                    if (c != null) queue.add(c);
                }
            }
        }
        return null;
    }

    /**
     * Ячейка своего комментария: помечена MargyT (TAG_COMMENT_CELL) и содержит наш ник.
     * Из всех подходящих берём наименьшую по площади — это сам комментарий, а не весь тред
     * (у треда с нашим ответом ник тоже встретится глубже).
     */
    private static ViewGroup findOwnCommentCell(ViewGroup sheet, PluginContext margyt) {
        String nick = margyt != null ? margyt.getString("local_my_account_name", "") : "";
        if (nick == null) return null;
        String want = nick.trim().replace("@", "").toLowerCase(Locale.ROOT);
        if (want.isEmpty()) return null;

        ViewGroup best = null;
        long bestArea = Long.MAX_VALUE;
        ArrayDeque<View> queue = new ArrayDeque<>();
        queue.add(sheet);
        int seen = 0;
        while (!queue.isEmpty() && seen++ < SCAN_BUDGET) {
            View v = queue.poll();
            if (v.getVisibility() != View.VISIBLE) continue;
            if (v instanceof ViewGroup && Boolean.TRUE.equals(v.getTag(TAG_COMMENT_CELL))
                    && v.getWidth() > 0 && v.isShown() && cellHasNick(v, want, 0)) {
                long area = (long) v.getWidth() * v.getHeight();
                if (area < bestArea) { bestArea = area; best = (ViewGroup) v; }
            }
            if (v instanceof ViewGroup) {
                ViewGroup g = (ViewGroup) v;
                for (int i = 0; i < g.getChildCount(); i++) {
                    View c = g.getChildAt(i);
                    if (c != null) queue.add(c);
                }
            }
        }
        return best;
    }

    /**
     * В ячейке есть надпись-ник, соответствующая нашему нику. Матч устойчивый: в комментариях мод
     * дорисовывает к нику невидимые PUA-метки и значок бейджа/галочки, поэтому точного равенства мало —
     * чистим PUA и небуквенный хвост, принимаем равенство ИЛИ «начинается с ника» у короткой надписи-имени
     * (не у длинного текста самого комментария).
     */
    private static boolean cellHasNick(View v, String wantLower, int depth) {
        if (v == null || depth > 8) return false;
        if (v instanceof TextView && !(v instanceof EditText)) {
            CharSequence cs = ((TextView) v).getText();
            if (cs != null && nameMatches(cs.toString(), wantLower)) return true;
        }
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) {
                if (cellHasNick(g.getChildAt(i), wantLower, depth + 1)) return true;
            }
        }
        return false;
    }

    private static boolean nameMatches(String raw, String wantLower) {
        if (raw == null) return false;
        // Убираем private-use метки мода, '@', схлопываем пробелы, нижний регистр.
        StringBuilder b = new StringBuilder(raw.length());
        for (int i = 0; i < raw.length(); i++) {
            char c = raw.charAt(i);
            if (c >= '' && c <= '') continue; // PUA-метка
            if (c == '@') continue;
            b.append(c);
        }
        String s = b.toString().trim().toLowerCase(Locale.ROOT);
        if (s.isEmpty()) return false;
        if (s.equals(wantLower)) return true;
        // Надпись-имя короткая: ник + возможный хвост (галочка/точка/«· 2д»). Длинный текст — это сам коммент.
        if (s.length() <= wantLower.length() + 6 && s.startsWith(wantLower)) return true;
        // Обрезанный моложе хвост: уберём небуквенные символы с конца и сравним ещё раз.
        int end = s.length();
        while (end > 0 && !Character.isLetterOrDigit(s.charAt(end - 1))) end--;
        return end > 0 && s.substring(0, end).equals(wantLower);
    }

    /** Те же признаки, по которым панель комментариев узнаёт Dim из MargyT. */
    private static View findNamedPanel(View root, int screenW) {
        ArrayDeque<View> queue = new ArrayDeque<>();
        queue.add(root);
        int seen = 0;
        while (!queue.isEmpty() && seen++ < SCAN_BUDGET) {
            View v = queue.poll();
            if (v.getVisibility() != View.VISIBLE) continue;
            if (v instanceof ViewGroup && v.getWidth() >= screenW * 0.65f && v.isShown() && namedLikePanel(v)) return v;
            if (v instanceof ViewGroup) {
                ViewGroup g = (ViewGroup) v;
                for (int i = 0; i < g.getChildCount(); i++) {
                    View c = g.getChildAt(i);
                    if (c != null) queue.add(c);
                }
            }
        }
        return null;
    }

    private static boolean namedLikePanel(View v) {
        String type = v.getClass().getName().toLowerCase(Locale.ROOT);
        if (type.equals("x.0h10") || type.contains("commentlist") || type.contains("commentpanel")
                || type.contains("commentsheet")) {
            return true;
        }
        int id = v.getId();
        if (id <= 0 || (id >>> 24) == 0) return false;
        try {
            String name = v.getResources().getResourceEntryName(id).toLowerCase(Locale.ROOT);
            return name.contains("comment") && (name.contains("panel") || name.contains("list") || name.contains("sheet"));
        } catch (Throwable t) {
            return false;
        }
    }

    /**
     * Самый внешний предок (или сам вид), который по размеру ещё шторка:
     * шириной от 65% экрана, высотой от 20% до 95% экрана.
     */
    private static ViewGroup climbToSheet(View start, View root, int screenW, int screenH) {
        ViewGroup best = null;
        View cur = start instanceof ViewGroup ? start : (View) start.getParent();
        int guard = 0;
        while (cur instanceof ViewGroup && guard++ < 40) {
            ViewGroup g = (ViewGroup) cur;
            if (isScreenRoot(g, root)) break;
            boolean wide = g.getWidth() >= screenW * 0.65f;
            boolean tall = g.getHeight() >= screenH * 0.20f;
            boolean notFull = g.getHeight() < screenH * 0.95f;
            if (wide && tall && notFull) {
                best = g;
            } else if (best != null && (!notFull || !wide)) {
                break;
            }
            Object p = g.getParent();
            cur = p instanceof View ? (View) p : null;
        }
        return best;
    }

    private static Found findByText(View root, int screenW, int screenH) {
        List<TextView> headers = new ArrayList<>();
        List<TextView> inputs = new ArrayList<>();
        collect(root, headers, inputs, screenH, 0);
        if (headers.isEmpty() || inputs.isEmpty()) {
            logMissingOnce(headers, inputs);
            return null;
        }

        for (TextView header : headers) {
            int headerY = RootWallpaperEngine.getScreenY(header);
            for (TextView input : inputs) {
                if (RootWallpaperEngine.getScreenY(input) <= headerY) continue;
                ViewGroup common = RootWallpaperEngine.findCommonAncestor(header, input);
                View start = common != null && !isScreenRoot(common, root) ? common : header;
                ViewGroup sheet = climbToSheet(start, root, screenW, screenH);
                if (sheet == null) continue;
                Found f = new Found();
                f.sheet = sheet;
                f.sample = header;
                return f;
            }
        }
        return null;
    }

    private static boolean isScreenRoot(View v, View root) {
        return v == root || v.getId() == android.R.id.content || v.getParent() == null;
    }

    private static void collect(View v, List<TextView> headers, List<TextView> inputs, int screenH, int depth) {
        if (v == null || depth > 45 || !v.isShown()) return;
        if (v instanceof TextView) {
            TextView tv = (TextView) v;
            String text = normalize(tv.getText());
            if (isInput(text) || (tv.getText().length() == 0 && isInput(normalize(tv.getHint())))) {
                inputs.add(tv);
            } else if (text.length() > 0 && text.length() <= 40 && HEADER.matcher(text).matches()) {
                int y = RootWallpaperEngine.getScreenY(tv);
                if (y > screenH * 0.05f && y < screenH * 0.75f) headers.add(tv);
            }
        }
        if (v instanceof ViewGroup) {
            ViewGroup vg = (ViewGroup) v;
            for (int i = 0; i < vg.getChildCount(); i++) {
                collect(vg.getChildAt(i), headers, inputs, screenH, depth + 1);
            }
        }
    }

    private static TextView firstText(View v, int depth) {
        if (depth > 25 || v == null || v.getVisibility() != View.VISIBLE) return null;
        if (v instanceof TextView && !(v instanceof EditText)) {
            CharSequence t = ((TextView) v).getText();
            if (t != null && t.length() > 1) return (TextView) v;
        }
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) {
                TextView r = firstText(g.getChildAt(i), depth + 1);
                if (r != null) return r;
            }
        }
        return null;
    }

    private static String normalize(CharSequence cs) {
        if (cs == null) return "";
        return cs.toString().replace(' ', ' ').replace(' ', ' ').trim().toLowerCase(Locale.ROOT);
    }

    private static boolean isInput(String s) {
        if (s.isEmpty()) return false;
        for (String p : INPUT_PREFIXES) {
            if (s.startsWith(p)) return true;
        }
        return false;
    }

    private static boolean isDark(int color) {
        double lum = (0.299 * Color.red(color) + 0.587 * Color.green(color) + 0.114 * Color.blue(color)) / 255.0;
        return lum < 0.5;
    }

    /** Радиус верхних углов родного фона шторки; если не прочитать — 16dp. */
    private static float cornerOf(Drawable original, float density) {
        try {
            if (Build.VERSION.SDK_INT >= 24 && original instanceof GradientDrawable) {
                GradientDrawable g = (GradientDrawable) original;
                float[] radii = g.getCornerRadii();
                if (radii != null && radii.length >= 2 && radii[0] > 0f) return radii[0];
                float single = g.getCornerRadius();
                if (single > 0f) return single;
            }
        } catch (Throwable ignored) {}
        return 16f * density;
    }

    private static boolean loggedNoInput = false;
    private static boolean loggedNoHeader = false;

    /**
     * Одна строка в журнал на сессию, если шторка не опознаётся даже по тексту:
     * по ней видно, какая из примет не нашлась и как TikTok подписывает элементы.
     */
    private static void logMissingOnce(List<TextView> headers, List<TextView> inputs) {
        if (margytRef == null) return;
        if (!headers.isEmpty() && inputs.isEmpty() && !loggedNoInput) {
            loggedNoInput = true;
            margytRef.log("comments bg: header \"" + headers.get(0).getText() + "\" found, input field not found");
        } else if (headers.isEmpty() && !inputs.isEmpty() && !loggedNoHeader) {
            loggedNoHeader = true;
            CharSequence t = inputs.get(0).getText();
            if (t == null || t.length() == 0) t = inputs.get(0).getHint();
            margytRef.log("comments bg: input \"" + t + "\" found, header not found");
        }
    }

    // ───────────────────────────── Окна и опрос ─────────────────────────────

    /**
     * decor activity и корни остальных видимых окон приложения. По контексту окна их не
     * отфильтровать: с Android 10 у decor диалога контекст — DecorContext поверх Application.
     * Да и не нужно: на экране только окна текущей activity, а шторка опознаётся по содержимому.
     */
    @SuppressWarnings("unchecked")
    static List<View> collectRoots(Activity activity) {
        List<View> roots = new ArrayList<>();
        View decor = activity.getWindow().getDecorView();
        roots.add(decor);
        if (windowReflectionBroken) return roots;

        try {
            Class<?> wmg = Class.forName("android.view.WindowManagerGlobal");
            Object global = wmg.getMethod("getInstance").invoke(null);
            List<View> all = new ArrayList<>();
            try {
                String[] names = (String[]) wmg.getMethod("getViewRootNames").invoke(global);
                java.lang.reflect.Method getRoot = wmg.getMethod("getRootView", String.class);
                if (names != null) {
                    for (String name : names) {
                        View v = (View) getRoot.invoke(global, name);
                        if (v != null) all.add(v);
                    }
                }
            } catch (Throwable notPublic) {
                // Так окна перебирает сам MargyT (Stickers.windows)
                java.lang.reflect.Field views = wmg.getDeclaredField("mViews");
                views.setAccessible(true);
                Object held = views.get(global);
                if (held instanceof List) all.addAll((List<View>) held);
            }
            // Сверху вниз: последнее добавленное окно — верхнее
            for (int i = all.size() - 1; i >= 0; i--) {
                View v = all.get(i);
                if (v != decor && v.isShown()) roots.add(v);
            }
        } catch (Throwable t) {
            windowReflectionBroken = true;
            if (margytRef != null) margytRef.log("comments bg: other windows unavailable: " + t);
        }
        return roots;
    }

    /** Окно-диалог перерисовывается само по себе, onPreDraw activity его не видит. */
    private static void hookForeignRoot(View root, Activity activity) {
        if (root.getTag(TAG_KEY_ROOT_HOOKED) != null) return;
        root.setTag(TAG_KEY_ROOT_HOOKED, Boolean.TRUE);
        final WeakReference<Activity> ref = new WeakReference<>(activity);
        root.getViewTreeObserver().addOnPreDrawListener(new ViewTreeObserver.OnPreDrawListener() {
            @Override
            public boolean onPreDraw() {
                Activity a = ref.get();
                if (a != null && !a.isFinishing()) update(a, margytRef, false);
                return true;
            }
        });
    }

    private static WeakReference<Activity> pollActivity = null;
    private static boolean polling = false;

    private static final Runnable POLL = new Runnable() {
        @Override
        public void run() {
            Activity a = pollActivity != null ? pollActivity.get() : null;
            if (a == null || a.isFinishing() || !isEnabled(margytRef)) {
                polling = false;
                return;
            }
            update(a, margytRef, false);
            MAIN.postDelayed(this, POLL_MS);
        }
    };

    private static void startPolling(Activity activity) {
        Activity current = pollActivity != null ? pollActivity.get() : null;
        if (current != activity) pollActivity = new WeakReference<>(activity);
        if (!polling) {
            polling = true;
            MAIN.postDelayed(POLL, POLL_MS);
        }
    }

    /** Activity ушла с экрана: опрос не нужен, фон возвращаем, GIF на паузу. */
    public static void onPaused(Activity activity) {
        Activity current = pollActivity != null ? pollActivity.get() : null;
        if (current == activity) {
            MAIN.removeCallbacks(POLL);
            polling = false;
            pollActivity = null;
        }
        restoreAll();
    }
}
