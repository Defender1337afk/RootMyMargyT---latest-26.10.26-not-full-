package cat.narezany.rootmymargyt;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.os.SystemClock;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * ClawdSpaceGame — космос из пасхалки Astra 0.3, как Landroid в Android 14.
 *
 * Держишь палец — Clawd-корабль разворачивается и летит туда. Мир бесконечный:
 * пространство нарезано на клетки, и в большинстве лежит планета (положение,
 * размер, цвет и имя выводятся из хеша клетки, так что мир всегда один и тот же).
 * У планет есть притяжение. Мягкая посадка засчитывает планету, удар на скорости —
 * взрыв и возрождение. Стрелка у края экрана показывает ближайшую непосещённую.
 *
 * Все координаты мира — в пикселях; скорости заданы в dp и умножаются на плотность.
 */
final class ClawdSpaceGame extends View {

    private static final float CELL_DP = 1500f;
    private static final float SAFE_LANDING_DP = 170f;
    private static final float THRUST_DP = 380f;
    private static final float MAX_SPEED_DP = 900f;
    private static final float SURFACE_G_DP = 120f;

    private static final String[] NAME_A = {"Тилкайо", "Маргит", "Вайбпедия", "Багландия", "Токен", "Лимит",
        "Кот", "Астра", "Нарез", "Клод", "Бойкиссер", "Сакура"};
    private static final String[] NAME_B = {"-7", "-IX", " Прайм", " Минор", "-42", "-b", " Альфа", " Бета", "-0.3", " Нова"};
    private static final int[][] PALETTES = {
        {0xFFFFB08A, 0xFF8A3B1E}, {0xFF7AB8FF, 0xFF1C3E7A}, {0xFFA8E6B8, 0xFF2D6B44}, {0xFFF7E08A, 0xFF8A6A18},
        {0xFFF59AC4, 0xFF7A2450}, {0xFFC9A2F5, 0xFF4A2A80}, {0xFFE8E8EE, 0xFF5A5A66}, {0xFFFF8A65, 0xFF6B1E10}
    };

    private static final class Planet {
        long key;
        float x, y, r;
        int light, dark;
        boolean rings;
        String name;
        RadialGradient shade, halo;
    }

    private final float d;
    private final Map<Long, Planet> planets = new HashMap<>();
    private final Set<Long> visited = new HashSet<>();

    // корабль
    private float sx, sy, svx, svy, angle = (float) (-Math.PI / 2);
    private Planet landedOn;
    private float landAngle;
    private long crashedAt;
    private boolean touching, everTouched;
    /** Сел, держа палец: взлёт только после того, как палец отпустят и нажмут снова. */
    private boolean needRelease;
    private float tx, ty;

    // частицы: пламя и взрывы, в координатах мира
    private static final int MAX_P = 160;
    private final float[] px = new float[MAX_P], py = new float[MAX_P], pvx = new float[MAX_P], pvy = new float[MAX_P],
        plife = new float[MAX_P];
    private final int[] pcol = new int[MAX_P];
    private int pNext;

    private String banner = "";
    private long bannerAt;
    private long lastFrame;

    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pix = new Paint();
    private final RectF oval = new RectF();
    private final Path arrow = new Path();

    ClawdSpaceGame(Context c) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
        stroke.setStyle(Paint.Style.STROKE);
        text.setColor(0xFFFFFFFF);
        text.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        setKeepScreenOn(true);
    }

    // ───────────────────────────── мир ─────────────────────────────

    private static long hash(long a, long b) {
        long h = a * 0x9E3779B97F4A7C15L ^ b * 0xC2B2AE3D27D4EB4FL;
        h ^= h >>> 31;
        h *= 0xBF58476D1CE4E5B9L;
        h ^= h >>> 29;
        return h;
    }

    private static float unit(long h, int shift) {
        return ((h >>> shift) & 0xFFFF) / 65535f;
    }

    /** Планета клетки или null. В стартовой клетке планеты нет — Clawd появляется в пустоте. */
    private Planet planetAt(int cx, int cy) {
        long key = ((long) cx << 32) ^ (cy & 0xFFFFFFFFL);
        if (planets.containsKey(key)) return planets.get(key);
        Planet p = null;
        long h = hash(cx, cy);
        if (!(cx == 0 && cy == 0) && unit(h, 0) > 0.18f) {
            float cell = CELL_DP * d;
            p = new Planet();
            p.key = key;
            p.r = (70 + 120 * unit(h, 16)) * d;
            p.x = cx * cell + cell * (0.25f + 0.5f * unit(h, 24));
            p.y = cy * cell + cell * (0.25f + 0.5f * unit(h, 40));
            int[] pal = PALETTES[(int) ((h >>> 8) & 0x7F) % PALETTES.length];
            p.light = pal[0];
            p.dark = pal[1];
            p.rings = unit(h, 48) > 0.7f;
            p.name = NAME_A[(int) ((h >>> 12) & 0xFF) % NAME_A.length] + NAME_B[(int) ((h >>> 20) & 0xFF) % NAME_B.length];
            // шейдеры в координатах планеты: рисуем с canvas.translate
            p.shade = new RadialGradient(-p.r * 0.35f, -p.r * 0.4f, p.r * 1.5f,
                new int[] {p.light, p.dark, 0xFF05050A}, new float[] {0f, 0.7f, 1f}, Shader.TileMode.CLAMP);
            p.halo = new RadialGradient(0, 0, p.r * 1.35f,
                new int[] {0x00000000, (p.light & 0x00FFFFFF) | 0x40000000, 0x00000000},
                new float[] {0.7f, 0.76f, 1f}, Shader.TileMode.CLAMP);
        }
        if (planets.size() > 400) planets.clear(); // далеко улетел — забываем старые клетки
        planets.put(key, p);
        return p;
    }

    // ───────────────────────────── ввод ─────────────────────────────

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_MOVE:
                touching = true;
                everTouched = true;
                tx = e.getX();
                ty = e.getY();
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                touching = false;
                needRelease = false;
                return true;
        }
        return super.onTouchEvent(e);
    }

    // ───────────────────────────── физика ─────────────────────────────

    private void emit(float x, float y, float vx, float vy, int color, float life) {
        int i = pNext;
        pNext = (pNext + 1) % MAX_P;
        px[i] = x;
        py[i] = y;
        pvx[i] = vx;
        pvy[i] = vy;
        pcol[i] = color;
        plife[i] = life;
    }

    private void say(String s) {
        banner = s;
        bannerAt = SystemClock.uptimeMillis();
    }

    private void step(float dt, long now) {
        for (int i = 0; i < MAX_P; i++) {
            if (plife[i] <= 0) continue;
            px[i] += pvx[i] * dt;
            py[i] += pvy[i] * dt;
            plife[i] -= dt;
        }

        if (crashedAt > 0) {
            if (now - crashedAt > 1400) {
                crashedAt = 0;
                svx = svy = 0;
            }
            return;
        }

        if (landedOn != null) {
            Planet p = landedOn;
            float rr = p.r + 14 * d;
            sx = p.x + (float) Math.cos(landAngle) * rr;
            sy = p.y + (float) Math.sin(landAngle) * rr;
            angle = landAngle;
            if (touching && !needRelease) { // взлёт — от поверхности
                svx = (float) Math.cos(landAngle) * 220 * d;
                svy = (float) Math.sin(landAngle) * 220 * d;
                sx += svx * dt * 2;
                sy += svy * dt * 2;
                landedOn = null;
            }
            return;
        }

        if (touching) {
            float target = (float) Math.atan2(ty - getHeight() / 2f, tx - getWidth() / 2f);
            float diff = (float) Math.atan2(Math.sin(target - angle), Math.cos(target - angle));
            angle += Math.max(-6f * dt, Math.min(6f * dt, diff));
            svx += (float) Math.cos(angle) * THRUST_DP * d * dt;
            svy += (float) Math.sin(angle) * THRUST_DP * d * dt;
            // пламя из сопел — назад от носа
            float bx = sx - (float) Math.cos(angle) * 16 * d, by = sy - (float) Math.sin(angle) * 16 * d;
            for (int k = 0; k < 2; k++) {
                float spread = (float) ((Math.random() - 0.5) * 0.6);
                float v = (120 + (float) Math.random() * 80) * d;
                emit(bx, by, svx - (float) Math.cos(angle + spread) * v, svy - (float) Math.sin(angle + spread) * v,
                    Math.random() < 0.5 ? 0xFFFFC107 : 0xFFFF7043, 0.35f);
            }
        }

        // притяжение ближайших планет
        float cell = CELL_DP * d;
        int ccx = (int) Math.floor(sx / cell), ccy = (int) Math.floor(sy / cell);
        for (int gx = ccx - 1; gx <= ccx + 1; gx++) {
            for (int gy = ccy - 1; gy <= ccy + 1; gy++) {
                Planet p = planetAt(gx, gy);
                if (p == null) continue;
                float dx = p.x - sx, dy = p.y - sy;
                float dist = (float) Math.hypot(dx, dy);
                if (dist < 1) continue;
                if (dist < p.r * 9) {
                    float a = SURFACE_G_DP * d * (p.r * p.r) / (dist * dist);
                    svx += dx / dist * a * dt;
                    svy += dy / dist * a * dt;
                }
                if (dist < p.r + 12 * d) touchdown(p, dx, dy, dist);
                if (crashedAt > 0 || landedOn != null) return;
            }
        }

        float speed = (float) Math.hypot(svx, svy), max = MAX_SPEED_DP * d;
        if (speed > max) {
            svx *= max / speed;
            svy *= max / speed;
        }
        sx += svx * dt;
        sy += svy * dt;
    }

    private void touchdown(Planet p, float dx, float dy, float dist) {
        float speed = (float) Math.hypot(svx, svy);
        if (speed < SAFE_LANDING_DP * d) {
            landedOn = p;
            needRelease = touching;
            landAngle = (float) Math.atan2(-dy, -dx);
            svx = svy = 0;
            boolean fresh = visited.add(p.key);
            performHapticFeedback(HapticFeedbackConstants.CONFIRM);
            say(fresh ? "Посадка: " + p.name + " · планета №" + visited.size() : "Снова на " + p.name);
        } else {
            crashedAt = SystemClock.uptimeMillis();
            performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
            for (int k = 0; k < 40; k++) {
                double a = Math.random() * Math.PI * 2;
                float v = (60 + (float) Math.random() * 240) * d;
                emit(sx, sy, (float) Math.cos(a) * v, (float) Math.sin(a) * v,
                    k % 3 == 0 ? 0xFFFFFFFF : (k % 3 == 1 ? 0xFFD97757 : 0xFFFFC107), 0.9f);
            }
            // отлетаем от планеты, чтобы не появиться внутри
            sx = p.x - dx / dist * (p.r + 160 * d);
            sy = p.y - dy / dist * (p.r + 160 * d);
            say("Бах! Слишком быстро. Садись мягче");
        }
    }

    // ───────────────────────────── отрисовка ─────────────────────────────

    @Override
    protected void onDraw(Canvas c) {
        int w = getWidth(), h = getHeight();
        if (w <= 0) return;
        long now = SystemClock.uptimeMillis();
        float dt = lastFrame == 0 ? 0.016f : Math.min(0.033f, (now - lastFrame) / 1000f);
        lastFrame = now;
        step(dt, now);

        c.drawColor(0xFF02030A);
        drawStars(c, w, h);

        float camX = sx - w / 2f, camY = sy - h / 2f;
        float cell = CELL_DP * d;
        int x0 = (int) Math.floor(camX / cell) - 1, x1 = (int) Math.floor((camX + w) / cell) + 1;
        int y0 = (int) Math.floor(camY / cell) - 1, y1 = (int) Math.floor((camY + h) / cell) + 1;
        Planet nearest = null;
        float nearestD = Float.MAX_VALUE;
        for (int gx = x0 - 2; gx <= x1 + 2; gx++) {
            for (int gy = y0 - 2; gy <= y1 + 2; gy++) {
                Planet p = planetAt(gx, gy);
                if (p == null) continue;
                float sxp = p.x - camX, syp = p.y - camY;
                if (sxp > -p.r * 2 && sxp < w + p.r * 2 && syp > -p.r * 2 && syp < h + p.r * 2) drawPlanet(c, p, sxp, syp);
                if (!visited.contains(p.key)) {
                    float dd = (float) Math.hypot(p.x - sx, p.y - sy);
                    if (dd < nearestD) {
                        nearestD = dd;
                        nearest = p;
                    }
                }
            }
        }

        for (int i = 0; i < MAX_P; i++) {
            if (plife[i] <= 0) continue;
            fill.setColor(pcol[i]);
            fill.setAlpha((int) (255 * Math.min(1f, plife[i] * 2.5f)));
            c.drawCircle(px[i] - camX, py[i] - camY, 3 * d * Math.min(1f, plife[i] * 2f) + d, fill);
        }

        if (crashedAt == 0) drawClawd(c, w / 2f, h / 2f, now);
        if (nearest != null) drawArrow(c, w, h, nearest, camX, camY);
        drawHud(c, w, h, now);
        postInvalidateOnAnimation();
    }

    /** Три слоя звёзд с параллаксом; в каждом тайле 12 звёзд из хеша тайла. */
    private void drawStars(Canvas c, int w, int h) {
        float[] par = {0.12f, 0.3f, 0.6f};
        float tile = 360 * d;
        for (int layer = 0; layer < 3; layer++) {
            float ox = sx * par[layer], oy = sy * par[layer];
            int tx0 = (int) Math.floor(ox / tile), ty0 = (int) Math.floor(oy / tile);
            int nx = (int) (w / tile) + 2, ny = (int) (h / tile) + 2;
            fill.setColor(0xFFFFFFFF);
            for (int ix = 0; ix < nx; ix++) {
                for (int iy = 0; iy < ny; iy++) {
                    long hh = hash(tx0 + ix + layer * 7919, ty0 + iy);
                    for (int k = 0; k < 12; k++) {
                        long hk = hash(hh, k);
                        float x = (tx0 + ix) * tile + unit(hk, 0) * tile - ox;
                        float y = (ty0 + iy) * tile + unit(hk, 16) * tile - oy;
                        fill.setAlpha(60 + layer * 60 + (int) (unit(hk, 32) * 60));
                        c.drawCircle(x, y, (0.6f + layer * 0.5f) * d, fill);
                    }
                }
            }
        }
    }

    private void drawPlanet(Canvas c, Planet p, float x, float y) {
        c.save();
        c.translate(x, y);
        fill.setAlpha(255);
        fill.setShader(p.halo);
        c.drawCircle(0, 0, p.r * 1.35f, fill);
        if (p.rings) {
            oval.set(-p.r * 1.8f, -p.r * 0.45f, p.r * 1.8f, p.r * 0.45f);
            stroke.setColor((p.light & 0x00FFFFFF) | 0x99000000);
            stroke.setStrokeWidth(p.r * 0.12f);
            c.save();
            c.rotate(-20);
            c.drawArc(oval, 180, 180, false, stroke); // задняя половина кольца
            c.restore();
        }
        fill.setShader(p.shade);
        c.drawCircle(0, 0, p.r, fill);
        fill.setShader(null);
        if (p.rings) {
            c.save();
            c.rotate(-20);
            c.drawArc(oval, 0, 180, false, stroke); // передняя половина
            c.restore();
        }
        if (visited.contains(p.key)) { // флажок на посещённых
            fill.setColor(0xFFD97757);
            c.drawRect(-1.5f * d, -p.r - 18 * d, 1.5f * d, -p.r, fill);
            c.drawRect(1.5f * d, -p.r - 18 * d, 12 * d, -p.r - 10 * d, fill);
        }
        c.restore();
    }

    /** Пиксельный Clawd (12×8, как в ClawdPetView), носом по курсу; ножки — сопла. */
    private void drawClawd(Canvas c, float x, float y, long now) {
        float p = 3.2f * d;
        c.save();
        c.translate(x, y);
        c.rotate((float) Math.toDegrees(angle) + 90f);
        float l = -6 * p, t = -5.5f * p;
        if (touching && landedOn == null) { // пламя
            float f = 1f + 0.35f * (float) Math.sin(now / 30.0);
            fill.setColor(0xFFFFC107);
            c.drawRect(l + 1.5f * p, t + 11 * p, l + 4.5f * p, t + (11 + 2.5f * f) * p, fill);
            c.drawRect(l + 7.5f * p, t + 11 * p, l + 10.5f * p, t + (11 + 2.5f * f) * p, fill);
            fill.setColor(0xFFFF7043);
            c.drawRect(l + 2.2f * p, t + 11 * p, l + 3.8f * p, t + (11 + 4f * f) * p, fill);
            c.drawRect(l + 8.2f * p, t + 11 * p, l + 9.8f * p, t + (11 + 4f * f) * p, fill);
        }
        px(c, l, t, p, 1, 8, 1, 3, 0xFFC4623F);
        px(c, l, t, p, 4, 8, 1, 3, 0xFFC4623F);
        px(c, l, t, p, 7, 8, 1, 3, 0xFFC4623F);
        px(c, l, t, p, 10, 8, 1, 3, 0xFFC4623F);
        px(c, l, t, p, -1, 3, 1, 2, 0xFFD97757);
        px(c, l, t, p, 12, 3, 1, 2, 0xFFD97757);
        px(c, l, t, p, 0, 0, 12, 8, 0xFFD97757);
        px(c, l, t, p, 0, 0, 12, 1, 0xFFE8956F);
        px(c, l, t, p, 0, 7, 12, 1, 0xFFB85C3E);
        px(c, l, t, p, 11, 1, 1, 7, 0xFFB85C3E);
        int eye = 0xFF2B1A14;
        if (landedOn != null) { // на планете счастлив: ^ ^
            px(c, l, t, p, 2, 4, 1, 1, eye); px(c, l, t, p, 3, 3, 1, 1, eye); px(c, l, t, p, 4, 4, 1, 1, eye);
            px(c, l, t, p, 7, 4, 1, 1, eye); px(c, l, t, p, 8, 3, 1, 1, eye); px(c, l, t, p, 9, 4, 1, 1, eye);
        } else { // > <
            px(c, l, t, p, 2, 3, 1, 1, eye); px(c, l, t, p, 3, 4, 1, 1, eye); px(c, l, t, p, 2, 5, 1, 1, eye);
            px(c, l, t, p, 9, 3, 1, 1, eye); px(c, l, t, p, 8, 4, 1, 1, eye); px(c, l, t, p, 9, 5, 1, 1, eye);
        }
        c.restore();
    }

    private void px(Canvas c, float l, float t, float p, int x, int y, int w, int h, int color) {
        pix.setColor(color);
        c.drawRect(l + x * p, t + y * p, l + (x + w) * p, t + (y + h) * p, pix);
    }

    /** Стрелка у края экрана на ближайшую непосещённую планету, если она за кадром. */
    private void drawArrow(Canvas c, int w, int h, Planet p, float camX, float camY) {
        float x = p.x - camX, y = p.y - camY;
        if (x > 0 && x < w && y > 0 && y < h) return;
        float a = (float) Math.atan2(y - h / 2f, x - w / 2f);
        float m = 28 * d;
        float ex = w / 2f + (float) Math.cos(a) * (w / 2f - m), ey = h / 2f + (float) Math.sin(a) * (h / 2f - m);
        ex = Math.max(m, Math.min(w - m, ex));
        ey = Math.max(m * 3, Math.min(h - m * 2, ey));
        c.save();
        c.translate(ex, ey);
        c.rotate((float) Math.toDegrees(a));
        arrow.rewind();
        arrow.moveTo(12 * d, 0);
        arrow.lineTo(-8 * d, -8 * d);
        arrow.lineTo(-4 * d, 0);
        arrow.lineTo(-8 * d, 8 * d);
        arrow.close();
        fill.setColor(p.light);
        fill.setAlpha(220);
        c.drawPath(arrow, fill);
        c.restore();
    }

    private void drawHud(Canvas c, int w, int h, long now) {
        text.setTextAlign(Paint.Align.LEFT);
        text.setTextSize(13 * d);
        text.setAlpha(230);
        c.drawText("CLAWD-КОРАБЛЬ", 20 * d, 52 * d, text);
        text.setAlpha(170);
        text.setTextSize(12 * d);
        c.drawText("Планет: " + visited.size() + "   Скорость: " + Math.round(Math.hypot(svx, svy) / d), 20 * d, 72 * d, text);

        text.setTextAlign(Paint.Align.CENTER);
        if (!everTouched) {
            text.setAlpha(150);
            text.setTextSize(13 * d);
            c.drawText("Держи палец — Clawd полетит туда", w / 2f, h - 60 * d, text);
            c.drawText("Садись на планеты мягко", w / 2f, h - 40 * d, text);
        }
        long age = now - bannerAt;
        if (!banner.isEmpty() && age < 2600) {
            float k = age < 200 ? age / 200f : (age > 2200 ? (2600 - age) / 400f : 1f);
            text.setAlpha((int) (255 * k));
            text.setTextSize(15 * d);
            c.drawText(banner, w / 2f, 120 * d, text);
        }
    }
}
