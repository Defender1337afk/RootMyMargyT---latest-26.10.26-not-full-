package cat.narezany.rootmymargyt;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import cat.narezany.margyt.plugin.PluginContext;

/**
 * RootPanel — консоль управления Superuser Root-правами для MargyT.
 * Material 3 Dark: полноразмерное окно со ScrollView,
 * Рамка аватара «Ушки фембоя», Graviboard (падающие видео), Реалистичный дождь/снег,
 * Famous Mode, 16 HD бейджей, кастомный фон профиля и градиент ника.
 */
public final class RootPanel {

    // Палитра панели берётся из живой темы MargyT (Skin + Accent) при открытии —
    // смотри applyMargytSkin(). Значения ниже — фолбэк на случай, если тему
    // прочитать не удалось (старая сборка, измерение ещё не готово). Поэтому
    // поля больше не final: applyMargytSkin() перекрашивает их под MargyT, и
    // весь UI панели следует теме и акценту мода, как нативные экраны.
    public static int COLOR_BACKGROUND = 0xFF0E0E12;
    public static int COLOR_SURFACE = 0xFF16161C;
    public static int COLOR_CARD = 0xFF1C1C24;
    public static int COLOR_CARD_HOVER = 0xFF24242E;
    public static int COLOR_BORDER = 0xFF282834;
    public static int COLOR_ACCENT = 0xFF8B5CF6;
    public static final int COLOR_SWITCH_ON = 0xFF00FF66;
    public static int COLOR_SWITCH_OFF = 0xFF32323E;
    public static int COLOR_TEXT_PRIMARY = 0xFFF1F1F6;
    public static int COLOR_TEXT_SECONDARY = 0xFF9090A0;
    public static int COLOR_TEXT_MUTED = 0xFF5A5A6A;
    public static final int COLOR_FEMBOY = 0xFFFF80AA;

    /**
     * Перекрашивает палитру панели под текущую тему MargyT.
     *
     * Читает Skin (page/card/text/muted) и Accent.colour() из мода через
     * рефлексию и выводит из них весь набор цветов панели — так RootPanel
     * совпадает с нативными настройками по теме (светлая/тёмная) и акценту.
     * Любая ошибка оставляет фолбэк-значения нетронутыми.
     */
    private static void applyMargytSkin(Context ctx) {
        // Вся рефлексия темы — в core.Host (setAccessible там корректный). Старая сборка без Skin —
        // Host.hasTheme()==false, остаёмся на фолбэк-палитре.
        if (!cat.narezany.rootmymargyt.core.Host.hasTheme()) return;
        int page = cat.narezany.rootmymargyt.core.Host.skinPage(ctx, COLOR_BACKGROUND);
        int card = cat.narezany.rootmymargyt.core.Host.skinCard(ctx, COLOR_CARD);
        int text = cat.narezany.rootmymargyt.core.Host.skinText(ctx, COLOR_TEXT_PRIMARY);
        int accent = cat.narezany.rootmymargyt.core.Host.accent(COLOR_ACCENT);

        // Skin.muted() — цвет текста с альфой 0x99; на сплошной карточке получаем тот же вес смешиванием.
        int mRaw = cat.narezany.rootmymargyt.core.Host.skinMuted(ctx, 0);
        int muted = mRaw != 0
            ? M3X.mix(card, mRaw | 0xFF000000, ((mRaw >>> 24) & 0xFF) / 255f)
            : M3X.mix(card, text, 0.6f);

        COLOR_BACKGROUND   = page;
        COLOR_CARD         = card;
        COLOR_SURFACE      = M3X.mix(page, card, 0.5f) | 0xFF000000;
        COLOR_CARD_HOVER   = M3X.mix(card, text, 0.10f) | 0xFF000000;
        COLOR_BORDER       = M3X.mix(card, text, 0.18f) | 0xFF000000;
        COLOR_SWITCH_OFF   = M3X.mix(card, text, 0.14f) | 0xFF000000;
        COLOR_ACCENT       = accent;
        COLOR_TEXT_PRIMARY = text;
        COLOR_TEXT_SECONDARY = muted | 0xFF000000;
        COLOR_TEXT_MUTED   = M3X.mix(card, text, 0.45f) | 0xFF000000;
    }

    public interface Callback {
        void onBadgesChanged();
        void onWallpaperSelected(String path);
        void onApplyWallpaperNow();
        void onGradientSelected(int index);
        void onFlushMemory();
        void onToggleGravityShake(boolean on);
        void onTestGraviboardNow();
        void onWeatherModeSelected(int mode, boolean droplets);
        void onAmbilightChanged();
        void onTilkajoModeChanged(boolean on);
        void onFastRestart();
        void onReinstallRoot();
        void onNavBarPositionChanged(int pos);
    }

    public static void show(Activity activity, PluginContext margyt, Callback callback) {
        if (activity == null || activity.isFinishing()) return;

        // Подхватываем тему и акцент MargyT перед построением панели.
        applyMargytSkin(activity);

        Dialog dialog = new Dialog(activity);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            window.setDimAmount(0.75f);
        }

        int dp8 = dp(activity, 8);
        int dp12 = dp(activity, 12);
        int dp16 = dp(activity, 16);
        int dp20 = dp(activity, 20);
        int dp24 = dp(activity, 24);

        LinearLayout root = new LinearLayout(activity);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp20, dp20, dp20, dp16);

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(COLOR_SURFACE);
        bg.setCornerRadius(dp24);
        bg.setStroke(dp(activity, 1), COLOR_BORDER);
        root.setBackground(bg);

        // Header
        LinearLayout header = new LinearLayout(activity);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);

        TextView title = new TextView(activity);
        title.setText("RootMyMargyT");
        title.setTextColor(COLOR_TEXT_PRIMARY);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        title.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        header.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView status = new TextView(activity);
        status.setText("SUPERUSER ROOT");
        status.setTextColor(COLOR_SWITCH_ON);
        status.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
        status.setTypeface(Typeface.DEFAULT_BOLD);
        status.setLetterSpacing(0.08f);
        status.setPadding(dp(activity, 8), dp(activity, 3), dp(activity, 8), dp(activity, 3));

        GradientDrawable chipBg = new GradientDrawable();
        chipBg.setColor(0x1800FF66);
        chipBg.setCornerRadius(dp12);
        chipBg.setStroke(dp(activity, 1), 0x4400FF66);
        status.setBackground(chipBg);
        header.addView(status);
        root.addView(header);

        TextView subtitle = new TextView(activity);
        String uid = margyt != null ? margyt.accountId() : null;
        subtitle.setText("Kernel: Linux-MargySU v4.0 • UID: " + (uid != null ? uid : "0 (root)") + " • SELinux: Permissive");
        subtitle.setTextColor(COLOR_TEXT_MUTED);
        subtitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        subtitle.setPadding(0, dp(activity, 3), 0, dp16);
        root.addView(subtitle);

        View div = new View(activity);
        div.setBackgroundColor(COLOR_BORDER);
        root.addView(div, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(activity, 1)));

        ScrollView scroll = new ScrollView(activity);
        scroll.setVerticalScrollBarEnabled(false);
        LinearLayout content = new LinearLayout(activity);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(0, dp16, 0, dp8);

        scroll.addView(content, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // [ РАЗДЕЛ: ПОЛОЖЕНИЕ НАВИГАЦИОННОЙ ПАНЕЛИ ]
        addSectionHeader(activity, content, "🧭 ПОЛОЖЕНИЕ ПАНЕЛИ НАВИГАЦИИ");
        View navPosCard = createCard(activity, dp12, dp8);
        LinearLayout navPosLayout = (LinearLayout) navPosCard;

        final int curNavPos = NavBarPositionEngine.getPosition(margyt);
        String[] posTitles = new String[] {
            "⬇️ Снизу (По умолчанию)",
            "⬆️ Вверху (В ленте — вверху, в профиле — внизу)"
        };

        for (int p = 0; p < posTitles.length; p++) {
            final int posIndex = p;
            boolean isSel = (posIndex == curNavPos);
            View r = createChoiceRow(activity, posTitles[p], isSel, () -> {
                NavBarPositionEngine.setPosition(margyt, posIndex);
                NavBarPositionEngine.applyPosition(activity, margyt);
                if (callback != null) callback.onNavBarPositionChanged(posIndex);
                dialog.dismiss();
                show(activity, margyt, callback);
            });
            navPosLayout.addView(r);
        }
        content.addView(navPosCard);

        // [ РАЗДЕЛ 2: ПАДАЮЩИЕ ВИДЕО (GRAVIBOARD) ]
        addSectionHeader(activity, content, "📱 ПАДАЮЩИЕ ВИДЕО (GRAVIBOARD / ТРЯСКА)");
        View gravCard = createCard(activity, dp12, dp8);
        LinearLayout gravLayout = (LinearLayout) gravCard;

        boolean gravOn = margyt == null || margyt.getBoolean("root_graviboard", true);
        gravLayout.addView(createSwitchRow(activity, "Падающие видео при тряске", "Потрясите телефон в профиле: карточки уменьшаются на 35%, скругляются (16dp), сталкиваются по физике и их можно швырять пальцем по экрану!", gravOn, state -> {
            if (margyt != null) margyt.prefs().edit().putBoolean("root_graviboard", state).apply();
            if (callback != null) callback.onToggleGravityShake(state);
        }));

        View btnTestGrav = createMinimalButton(activity, "🎮 Запустить Graviboard сейчас (Тест)", COLOR_SWITCH_ON, COLOR_CARD_HOVER);
        btnTestGrav.setOnClickListener(v -> {
            v.performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY);
            dialog.dismiss();
            if (callback != null) callback.onTestGraviboardNow();
        });
        LinearLayout.LayoutParams tgp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tgp.setMargins(0, dp8, 0, 0);
        gravLayout.addView(btnTestGrav, tgp);

        content.addView(gravCard);

        // [ РАЗДЕЛ 3: РЕАЛИСТИЧНЫЙ ДОЖДЬ И СНЕГ ]
        addSectionHeader(activity, content, "🌧️ ПОГОДНЫЕ ЭФФЕКТЫ (ДОЖДЬ И СНЕГ)");
        View weatherCard = createCard(activity, dp12, dp8);
        LinearLayout weatherLayout = (LinearLayout) weatherCard;

        final int curWeather = margyt != null ? margyt.getInt("weather_mode", WeatherOverlayView.MODE_OFF) : WeatherOverlayView.MODE_OFF;
        final boolean dropletsOn = margyt == null || margyt.getBoolean("weather_droplets_blur", true);

        String[] weatherTitles = new String[] { "Выключено", "🌧️ Реалистичный дождь со струями", "❄️ Зимний 3D снегопад", "🌸 Лепестки сакуры" };
        for (int m = 0; m < weatherTitles.length; m++) {
            final int wMode = m;
            boolean isSel = (wMode == curWeather);
            View r = createChoiceRow(activity, weatherTitles[m], isSel, () -> {
                if (margyt != null) margyt.prefs().edit().putInt("weather_mode", wMode).apply();
                if (callback != null) callback.onWeatherModeSelected(wMode, dropletsOn);
                dialog.dismiss();
                show(activity, margyt, callback);
            });
            weatherLayout.addView(r);
        }

        weatherLayout.addView(createSwitchRow(activity, "Капли на стекле экрана", "Реалистичные объемные капли с преломлением и медленным стеканием", dropletsOn, state -> {
            if (margyt != null) margyt.prefs().edit().putBoolean("weather_droplets_blur", state).apply();
            if (callback != null) callback.onWeatherModeSelected(curWeather, state);
        }));

        content.addView(weatherCard);

        // [ РАЗДЕЛ 4: НЕОНОВАЯ САКУРА И ВИНЬЕТКА ]
        addSectionHeader(activity, content, "🌸 НЕОНОВАЯ САКУРА И КИНО-ВИНЬЕТКА");
        View sakuraCard = createCard(activity, dp12, dp8);
        LinearLayout sakuraLayout = (LinearLayout) sakuraCard;

        final boolean sakuraOn = margyt == null || margyt.getBoolean("sakura_neon", true);
        final boolean vignetteOn = margyt == null || margyt.getBoolean("vignette_effect", true);
        final boolean sakuraPulse = margyt == null || margyt.getBoolean("sakura_pulse", true);

        sakuraLayout.addView(createSwitchRow(activity, "🌸 Неоновая сакура (Edge Glow)", "Мягкий переливающийся розово-лавандовый ореол вдоль краев экрана", sakuraOn, state -> {
            if (margyt != null) margyt.prefs().edit().putBoolean("sakura_neon", state).apply();
            if (callback != null) callback.onAmbilightChanged();
        }));

        sakuraLayout.addView(createSwitchRow(activity, "🎬 Кинематографичная виньетка", "Мягкое затемнение по краям и углам дисплея для кино-эффекта и контраста видео", vignetteOn, state -> {
            if (margyt != null) margyt.prefs().edit().putBoolean("vignette_effect", state).apply();
            if (callback != null) callback.onAmbilightChanged();
        }));

        sakuraLayout.addView(createSwitchRow(activity, "Плавное дыхание (Пульсация)", "Волнообразное мягкое дыхание яркости неоновой подсветки", sakuraPulse, state -> {
            if (margyt != null) margyt.prefs().edit().putBoolean("sakura_pulse", state).apply();
            if (callback != null) callback.onAmbilightChanged();
        }));

        content.addView(sakuraCard);

        // [ РАЗДЕЛ 5: ВСЕ 17 БЕЙДЖЕЙ ]
        addSectionHeader(activity, content, "✨ БЕЙДЖИ И ВЕРИФИКАЦИЯ (МУЛЬТИ-ВЫБОР)");
        View badgeCard = createCard(activity, dp12, dp8);
        LinearLayout badgeLayout = (LinearLayout) badgeCard;

        // По умолчанию без бейджей (раньше было 1 — это бит «Владельца»)
        final int curMask = margyt != null ? margyt.getInt("badges_mask", 0) : 0;
        final int[] maskRef = new int[] { curMask };

        // Быстрые кнопки: Выключить все / Включить все
        LinearLayout quickRow = new LinearLayout(activity);
        quickRow.setOrientation(LinearLayout.HORIZONTAL);
        quickRow.setPadding(dp12, dp4(activity), dp12, dp8);

        View btnOffAll = createMinimalButton(activity, "🚫 Выключить все", COLOR_TEXT_MUTED, COLOR_CARD_HOVER);
        btnOffAll.setOnClickListener(v -> {
            v.performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY);
            maskRef[0] = 0;
            if (margyt != null) margyt.prefs().edit().putInt("badges_mask", 0).apply();
            if (callback != null) callback.onBadgesChanged();
            dialog.dismiss();
            show(activity, margyt, callback);
        });
        quickRow.addView(btnOffAll, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        View qSp = new View(activity);
        quickRow.addView(qSp, new LinearLayout.LayoutParams(dp8, 1));

        View btnOnAll = createMinimalButton(activity, "✨ Включить все", COLOR_SWITCH_ON, COLOR_CARD_HOVER);
        btnOnAll.setOnClickListener(v -> {
            v.performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY);
            maskRef[0] = (1 << RootBadgeEngine.BADGE_IDS.length) - 1;
            if (margyt != null) margyt.prefs().edit().putInt("badges_mask", maskRef[0]).apply();
            if (callback != null) callback.onBadgesChanged();
            dialog.dismiss();
            show(activity, margyt, callback);
        });
        quickRow.addView(btnOnAll, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        badgeLayout.addView(quickRow);

        for (int i = 0; i < RootBadgeEngine.BADGE_TITLES.length; i++) {
            final int idx = i;
            final boolean isChecked = (maskRef[0] & (1 << idx)) != 0;

            LinearLayout row = new LinearLayout(activity);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp12, dp8, dp12, dp8);

            GradientDrawable rBg = new GradientDrawable();
            rBg.setColor(isChecked ? 0x148B5CF6 : Color.TRANSPARENT);
            rBg.setCornerRadius(dp12);
            if (isChecked) {
                rBg.setStroke(dp(activity, 1), 0x338B5CF6);
            }
            row.setBackground(rBg);

            ImageView iv = new ImageView(activity);
            Bitmap b = RootMyMargyT.getBadgeBitmap(idx);
            if (b != null) iv.setImageBitmap(b);
            row.addView(iv, new LinearLayout.LayoutParams(dp(activity, 26), dp(activity, 26)));

            LinearLayout textCol = new LinearLayout(activity);
            textCol.setOrientation(LinearLayout.VERTICAL);
            textCol.setPadding(dp12, 0, dp8, 0);

            TextView tvN = new TextView(activity);
            tvN.setText(RootBadgeEngine.BADGE_TITLES[idx]);
            tvN.setTextColor(COLOR_TEXT_PRIMARY);
            tvN.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
            tvN.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
            textCol.addView(tvN);

            TextView tvD = new TextView(activity);
            tvD.setText(RootBadgeEngine.BADGE_DESCRIPTIONS[idx]);
            tvD.setTextColor(COLOR_TEXT_MUTED);
            tvD.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
            textCol.addView(tvD);

            row.addView(textCol, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

            final FrameLayout switchContainer = (FrameLayout) createSwitchView(activity, isChecked);
            row.addView(switchContainer);

            row.setOnClickListener(v -> {
                v.performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY);
                maskRef[0] ^= (1 << idx);
                // Разрешаем маске быть 0, если пользователь отключил все бейджи!
                boolean nowChecked = (maskRef[0] & (1 << idx)) != 0;

                updateSwitchVisual(activity, switchContainer, nowChecked);

                GradientDrawable rowBg = new GradientDrawable();
                rowBg.setColor(nowChecked ? 0x148B5CF6 : Color.TRANSPARENT);
                rowBg.setCornerRadius(dp(activity, 12));
                if (nowChecked) rowBg.setStroke(dp(activity, 1), 0x338B5CF6);
                row.setBackground(rowBg);

                if (margyt != null) margyt.prefs().edit().putInt("badges_mask", maskRef[0]).apply();
                if (callback != null) callback.onBadgesChanged();
            });

            LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            rlp.setMargins(0, 0, 0, dp(activity, 4));
            badgeLayout.addView(row, rlp);
        }

        content.addView(badgeCard);

        // [ РАЗДЕЛ 6: КАСТОМНЫЙ ФОН ПРОФИЛЯ ]
        addSectionHeader(activity, content, "🖼️ КАСТОМНЫЙ ФОН ПРОФИЛЯ");
        View wallCard = createCard(activity, dp12, dp8);
        LinearLayout wallLayout = (LinearLayout) wallCard;

        boolean wallOn = RootWallpaperEngine.isEnabled(margyt);
        wallLayout.addView(createSwitchRow(activity, "Включить фон профиля", "Свои обои на странице своего профиля", wallOn, state -> {
            RootWallpaperEngine.setEnabled(margyt, state);
            if (callback != null) callback.onApplyWallpaperNow();
        }));

        addSubLabel(activity, wallLayout, "Где показывать фон:");
        wallLayout.addView(createChoiceGroup(activity, new String[] {
            "🔝 Только шапка профиля",
            "🖼️ Во весь профиль (под видео тоже)"
        }, RootWallpaperEngine.getMode(margyt), idx -> {
            RootWallpaperEngine.setMode(margyt, idx == 1 ? RootWallpaperEngine.MODE_FULL : RootWallpaperEngine.MODE_HEADER);
            RootWallpaperEngine.updateProfileWallpaper(activity, margyt);
        }));

        addSubLabel(activity, wallLayout, "Затемнение фона:");
        wallLayout.addView(createChipGroup(activity, levelLabels(RootWallpaperEngine.DIM_LEVELS, "Нет"),
            indexOfLevel(RootWallpaperEngine.DIM_LEVELS, RootWallpaperEngine.getDim(margyt)), idx -> {
                RootWallpaperEngine.setDim(margyt, RootWallpaperEngine.DIM_LEVELS[idx]);
                RootWallpaperEngine.updateProfileWallpaper(activity, margyt);
            }));

        TextView wSub = new TextView(activity);
        wSub.setText("Выберите изображение из памяти устройства или введите путь:");
        wSub.setTextColor(COLOR_TEXT_MUTED);
        wSub.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        wSub.setPadding(dp8, dp4(activity), dp8, dp4(activity));
        wallLayout.addView(wSub);

        View btnGallery = createMinimalButton(activity, "🖼️ ВЫБРАТЬ ИЗ ГАЛЕРЕИ (ФОТО)", COLOR_FEMBOY, COLOR_CARD_HOVER);
        btnGallery.setOnClickListener(v -> {
            v.performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY);
            openWallpaperGalleryPicker(activity, margyt, callback);
        });
        LinearLayout.LayoutParams lpGal = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lpGal.setMargins(0, dp8, 0, dp8);
        wallLayout.addView(btnGallery, lpGal);

        String currentWallPath = margyt != null ? margyt.getString("custom_profile_wallpaper_path", "") : "";
        final EditText etWallPath = createInputField(activity, "/sdcard/Download/wallpaper.jpg", currentWallPath);
        wallLayout.addView(createInputRow(activity, "Или путь:", etWallPath));

        LinearLayout wallBtns = new LinearLayout(activity);
        wallBtns.setOrientation(LinearLayout.HORIZONTAL);
        wallBtns.setPadding(0, dp4(activity), 0, 0);

        View btnScan = createMinimalButton(activity, "🔍 В памяти", COLOR_ACCENT, COLOR_CARD_HOVER);
        btnScan.setOnClickListener(v -> {
            v.performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY);
            showStorageImagePicker(activity, path -> {
                etWallPath.setText(path);
                if (margyt != null) margyt.prefs().edit().putString("custom_profile_wallpaper_path", path).apply();
                if (callback != null) callback.onWallpaperSelected(path);
            });
        });
        wallBtns.addView(btnScan, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        View wallSp = new View(activity);
        wallBtns.addView(wallSp, new LinearLayout.LayoutParams(dp8, 1));

        View btnSaveWall = createMinimalButton(activity, "Применить", COLOR_SWITCH_ON, COLOR_CARD_HOVER);
        btnSaveWall.setOnClickListener(v -> {
            v.performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY);
            String p = etWallPath.getText().toString().trim();
            if (margyt != null) margyt.prefs().edit().putString("custom_profile_wallpaper_path", p).apply();
            if (callback != null) callback.onWallpaperSelected(p);
            Toast.makeText(activity, "Обои профиля сохранены!", Toast.LENGTH_SHORT).show();
        });
        wallBtns.addView(btnSaveWall, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        wallLayout.addView(wallBtns);

        View btnWallPresets = createMinimalButton(activity, "✨ ГОТОВЫЕ ПРЕСЕТЫ ФОНА", COLOR_ACCENT, COLOR_CARD_HOVER);
        btnWallPresets.setOnClickListener(v -> {
            v.performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY);
            RootWallpaperEngine.showWallpaperPresetDialog(activity, margyt, () -> {
                if (callback != null) callback.onApplyWallpaperNow();
            });
        });
        LinearLayout.LayoutParams lpWallPresets = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lpWallPresets.setMargins(0, dp8, 0, 0);
        wallLayout.addView(btnWallPresets, lpWallPresets);

        content.addView(wallCard);

        // [ РАЗДЕЛ: ФОН КОММЕНТАРИЕВ ]
        addSectionHeader(activity, content, "💬 ФОН КОММЕНТАРИЕВ");
        View comCard = createCard(activity, dp12, dp8);
        LinearLayout comLayout = (LinearLayout) comCard;

        comLayout.addView(createSwitchRow(activity, "Фон в комментариях", "Картинка под панелью комментариев. Текст остаётся читаемым за счёт подложки цвета темы", CommentWallpaperEngine.isEnabled(margyt), state -> {
            CommentWallpaperEngine.setEnabled(margyt, state);
            CommentWallpaperEngine.update(activity, margyt, true);
        }));

        addSubLabel(activity, comLayout, "Какую картинку брать:");
        comLayout.addView(createChoiceGroup(activity, new String[] {
            "🔗 Ту же, что в профиле",
            "📷 Отдельное фото"
        }, CommentWallpaperEngine.getSource(margyt), idx -> {
            CommentWallpaperEngine.setSource(margyt, idx);
            if (idx == CommentWallpaperEngine.SOURCE_OWN && !CommentWallpaperEngine.hasOwn(activity)) {
                RootWallpaperEngine.openWallpaperGalleryPicker(activity, margyt, RootWallpaperEngine.TARGET_COMMENTS,
                    () -> CommentWallpaperEngine.update(activity, margyt, true));
            } else {
                CommentWallpaperEngine.update(activity, margyt, true);
            }
        }));

        View btnComPhoto = createMinimalButton(activity, "📷 ВЫБРАТЬ ФОТО ДЛЯ КОММЕНТАРИЕВ", COLOR_FEMBOY, COLOR_CARD_HOVER);
        btnComPhoto.setOnClickListener(v -> {
            v.performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY);
            RootWallpaperEngine.openWallpaperGalleryPicker(activity, margyt, RootWallpaperEngine.TARGET_COMMENTS,
                () -> CommentWallpaperEngine.update(activity, margyt, true));
        });
        LinearLayout.LayoutParams lpComPhoto = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lpComPhoto.setMargins(0, dp8, 0, dp8);
        comLayout.addView(btnComPhoto, lpComPhoto);

        addSubLabel(activity, comLayout, "Плотность подложки (чем больше — тем лучше читается текст):");
        comLayout.addView(createChipGroup(activity, levelLabels(CommentWallpaperEngine.VEIL_LEVELS, "Нет"),
            indexOfLevel(CommentWallpaperEngine.VEIL_LEVELS, CommentWallpaperEngine.getVeil(margyt)), idx -> {
                CommentWallpaperEngine.setVeil(margyt, CommentWallpaperEngine.VEIL_LEVELS[idx]);
                CommentWallpaperEngine.update(activity, margyt, true);
            }));

        content.addView(comCard);

        // [ РАЗДЕЛ 7: СТИЛИ ТЕКСТА ПРОФИЛЯ ]
        addSectionHeader(activity, content, "✍️ ТЕКСТ ПРОФИЛЯ (ТЕНЬ И ЦВЕТ)");
        View textCard = createCard(activity, dp12, dp8);
        LinearLayout textLayout = (LinearLayout) textCard;

        boolean textShadow = ProfileTextEngine.isShadowEnabled(margyt);
        textLayout.addView(createSwitchRow(activity, "Тень текста в профиле", "Объемная тень для четкой читаемости текста на любых обоях", textShadow, state -> {
            ProfileTextEngine.setShadowEnabled(margyt, state);
            if (activity != null) {
                ProfileTextEngine.applyProfileTextStyles(activity, (ViewGroup) activity.getWindow().getDecorView(), margyt);
            }
        }));

        View btnTextColor = createMinimalButton(activity, "🎨 ВЫБРАТЬ ЦВЕТ ТЕКСТА (" + ProfileTextEngine.getTextColorSummary(margyt) + ")", COLOR_ACCENT, COLOR_CARD_HOVER);
        btnTextColor.setOnClickListener(v -> {
            v.performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY);
            ProfileTextEngine.showTextColorPickerDialog(activity, margyt, () -> {
                dialog.dismiss();
                show(activity, margyt, callback);
            });
        });
        LinearLayout.LayoutParams lpCol = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lpCol.setMargins(0, dp8, 0, dp4(activity));
        textLayout.addView(btnTextColor, lpCol);

        content.addView(textCard);

        // [ РАЗДЕЛ 7: ГРАДИЕНТ НИКА ]
        addSectionHeader(activity, content, "🌈 ГРАДИЕНТ НИКА");
        View gradCard = createCard(activity, dp12, dp8);
        LinearLayout gradLayout = (LinearLayout) gradCard;

        int curGrad = margyt != null ? margyt.getInt("nick_gradient_choice", 0) : 0;
        for (int i = 0; i < RootMyMargyT.GRADIENT_NAMES.length; i++) {
            final int gIdx = i;
            boolean gSel = (gIdx == curGrad);
            View r = createChoiceRow(activity, RootMyMargyT.GRADIENT_NAMES[i], gSel, () -> {
                if (margyt != null) margyt.prefs().edit().putInt("nick_gradient_choice", gIdx).apply();
                if (callback != null) callback.onGradientSelected(gIdx);
                dialog.dismiss();
                show(activity, margyt, callback);
            });
            gradLayout.addView(r);
        }
        content.addView(gradCard);

        // [ РАЗДЕЛ: ЭКСПЛОИТ ASTRA v0.2 ]
        addSectionHeader(activity, content, "⚡ ЭКСПЛОИТ ASTRA v0.2 (ПАТЧЕР MARGYT)");
        View astraCard = createCard(activity, dp12, dp8);
        LinearLayout astraLayout = (LinearLayout) astraCard;

        boolean isPatched = AstraExploitEngine.isPatched(margyt);
        TextView astraStatus = new TextView(activity);
        if (isPatched) {
            astraStatus.setText("✓ MARGYT УСПЕШНО ПРОПАТЧЕН (Astra v0.2)");
            astraStatus.setTextColor(COLOR_SWITCH_ON);
        } else {
            astraStatus.setText("⚠ ТРЕБУЕТСЯ ПАТЧ ЯДРА (Astra v0.2)");
            astraStatus.setTextColor(COLOR_ACCENT);
        }
        astraStatus.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        astraStatus.setTypeface(Typeface.DEFAULT_BOLD);
        astraLayout.addView(astraStatus);

        TextView astraDesc = new TextView(activity);
        if (isPatched) {
            astraDesc.setText("Все настройки SuperUser уже интегрированы прямо в «Оформление» и «Профиль». Баннер во вкладке «О проекте» активен.");
        } else {
            astraDesc.setText("Эксплоит внедряет настройки напрямую в меню MargyT («Оформление», «Профиль», «О проекте»). В процессе мод выполнит 2 автоматические перезагрузки ядра.");
        }
        astraDesc.setTextColor(COLOR_TEXT_MUTED);
        astraDesc.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        astraDesc.setPadding(0, dp(activity, 4), 0, dp8);
        astraLayout.addView(astraDesc);

        String btnText = isPatched ? "🔄 Перепатчить MargyT (эксплоит Astra v0.2)" : "⚡ Начать патч MargyT (эксплоит Astra v0.2)";
        int btnColor = isPatched ? COLOR_SWITCH_ON : COLOR_ACCENT;
        View btnStartExploit = createMinimalButton(activity, btnText, btnColor, COLOR_CARD_HOVER);
        btnStartExploit.setOnClickListener(v -> {
            v.performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY);
            dialog.dismiss();
            AstraExploitEngine.startExploitSequence(activity, margyt, null);
        });
        astraLayout.addView(btnStartExploit);
        content.addView(astraCard);

        // [ РАЗДЕЛ 8: СИСТЕМНЫЕ КНОПКИ ]
        addSectionHeader(activity, content, "⚙️ СИСТЕМА SUPERUSER");
        View secCard = createCard(activity, dp12, dp8);
        LinearLayout secLayout = (LinearLayout) secCard;
        boolean tilkOn = margyt != null && margyt.getBoolean("tilkajo_mode_enabled", false);
        secLayout.addView(createSwitchRow(activity, "🐾 Режим Тилкайо", "Все кнопки ленты и нижней панели — Тилкайо, при нажатии мяукает", tilkOn, state -> {
            if (margyt != null) margyt.prefs().edit().putBoolean("tilkajo_mode_enabled", state).apply();
            if (callback != null) callback.onTilkajoModeChanged(state);
        }));

        LinearLayout sysBtns = new LinearLayout(activity);
        sysBtns.setOrientation(LinearLayout.HORIZONTAL);

        View btnGc = createMinimalButton(activity, "🧹 Сброс RAM", COLOR_TEXT_PRIMARY, COLOR_CARD_HOVER);
        btnGc.setOnClickListener(v -> {
            v.performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY);
            if (callback != null) callback.onFlushMemory();
        });
        sysBtns.addView(btnGc, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        View sSp = new View(activity);
        sysBtns.addView(sSp, new LinearLayout.LayoutParams(dp8, 1));

        View btnRestart = createMinimalButton(activity, "⚡ Рестарт MargyT", COLOR_ACCENT, COLOR_CARD_HOVER);
        btnRestart.setOnClickListener(v -> {
            v.performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY);
            if (callback != null) callback.onFastRestart();
        });
        sysBtns.addView(btnRestart, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        secLayout.addView(sysBtns);

        View btnReinstall = createMinimalButton(activity, "⚡ Переустановить Root права (Патчер)", COLOR_SWITCH_ON, COLOR_CARD_HOVER);
        btnReinstall.setOnClickListener(v -> {
            v.performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY);
            dialog.dismiss();
            if (callback != null) callback.onReinstallRoot();
        });
        LinearLayout.LayoutParams rip = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rip.setMargins(0, dp8, 0, 0);
        secLayout.addView(btnReinstall, rip);

        content.addView(secCard);

        root.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        View btnClose = createMinimalButton(activity, "Закрыть", COLOR_TEXT_MUTED, COLOR_CARD_HOVER);
        btnClose.setOnClickListener(v -> {
            v.performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY);
            dialog.dismiss();
        });
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        clp.setMargins(0, dp8, 0, 0);
        root.addView(btnClose, clp);

        M3X.expressify(root);

        dialog.setContentView(root);

        if (window != null) {
            DisplayMetrics dm = activity.getResources().getDisplayMetrics();
            int width = Math.min((int) (dm.widthPixels * 0.94f), dp(activity, 440));
            int height = (int) (dm.heightPixels * 0.88f);
            window.setLayout(width, height);
            window.setGravity(Gravity.CENTER);
        }

        dialog.show();
    }

    public interface OnPathSelected {
        void onSelected(String path);
    }

    private static void showStorageImagePicker(Activity activity, OnPathSelected onSelected) {
        Dialog d = new Dialog(activity);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        if (d.getWindow() != null) {
            d.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            d.getWindow().setDimAmount(0.7f);
        }

        LinearLayout l = new LinearLayout(activity);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(activity, 20), dp(activity, 20), dp(activity, 20), dp(activity, 16));

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(COLOR_SURFACE);
        bg.setCornerRadius(dp(activity, 20));
        bg.setStroke(dp(activity, 1), COLOR_BORDER);
        l.setBackground(bg);

        TextView t = new TextView(activity);
        t.setText("Выберите фото из памяти:");
        t.setTextColor(COLOR_TEXT_PRIMARY);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setPadding(0, 0, 0, dp(activity, 12));
        l.addView(t);

        ScrollView sv = new ScrollView(activity);
        LinearLayout items = new LinearLayout(activity);
        items.setOrientation(LinearLayout.VERTICAL);

        List<File> found = new ArrayList<>();
        scanDir(new File("/sdcard/Download"), found, 10);
        scanDir(new File("/sdcard/Pictures"), found, 10);
        scanDir(new File("/sdcard/DCIM/Camera"), found, 10);

        if (found.isEmpty()) {
            TextView none = new TextView(activity);
            none.setText("Картинки не найдены в Download/Pictures.\nПоместите файл в /sdcard/Download/wallpaper.jpg и укажите путь вручную.");
            none.setTextColor(COLOR_TEXT_MUTED);
            none.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
            none.setPadding(0, dp(activity, 8), 0, dp(activity, 8));
            items.addView(none);
        } else {
            for (File f : found) {
                View r = createChoiceRow(activity, f.getName(), false, () -> {
                    if (onSelected != null) onSelected.onSelected(f.getAbsolutePath());
                    d.dismiss();
                    Toast.makeText(activity, "Выбрано: " + f.getName(), Toast.LENGTH_SHORT).show();
                });
                items.addView(r);
            }
        }

        sv.addView(items);
        l.addView(sv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(activity, 260)));

        View close = createMinimalButton(activity, "Отмена", COLOR_TEXT_MUTED, COLOR_CARD_HOVER);
        close.setOnClickListener(v -> d.dismiss());
        l.addView(close);

        d.setContentView(l);

        if (d.getWindow() != null) {
            DisplayMetrics dm = activity.getResources().getDisplayMetrics();
            d.getWindow().setLayout(Math.min((int)(dm.widthPixels * 0.90f), dp(activity, 400)), ViewGroup.LayoutParams.WRAP_CONTENT);
        }
        d.show();
    }

    private static void scanDir(File dir, List<File> out, int limit) {
        if (dir == null || !dir.exists() || out.size() >= limit) return;
        File[] files = dir.listFiles();
        if (files == null) return;
        for (File f : files) {
            if (out.size() >= limit) break;
            if (f.isFile()) {
                String n = f.getName().toLowerCase();
                if (n.endsWith(".jpg") || n.endsWith(".jpeg") || n.endsWith(".png") || n.endsWith(".webp")) {
                    out.add(f);
                }
            }
        }
    }

    public interface SwitchCallback {
        void onToggle(boolean newState);
    }

    private static View createSwitchRow(Context ctx, String title, String subtitle, boolean checked, SwitchCallback callback) {
        LinearLayout row = new LinearLayout(ctx);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(ctx, 12), dp(ctx, 10), dp(ctx, 12), dp(ctx, 10));

        LinearLayout textCol = new LinearLayout(ctx);
        textCol.setOrientation(LinearLayout.VERTICAL);

        TextView tvT = new TextView(ctx);
        tvT.setText(title);
        tvT.setTextColor(COLOR_TEXT_PRIMARY);
        tvT.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        tvT.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        textCol.addView(tvT);

        if (subtitle != null && !subtitle.isEmpty()) {
            TextView tvS = new TextView(ctx);
            tvS.setText(subtitle);
            tvS.setTextColor(COLOR_TEXT_MUTED);
            tvS.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
            textCol.addView(tvS);
        }
        row.addView(textCol, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        final boolean[] state = new boolean[] { checked };
        final FrameLayout switchContainer = (FrameLayout) createSwitchView(ctx, checked);
        row.addView(switchContainer);

        row.setOnClickListener(v -> {
            v.performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY);
            state[0] = !state[0];
            updateSwitchVisual(ctx, switchContainer, state[0]);
            if (callback != null) callback.onToggle(state[0]);
        });

        return row;
    }

    private static View createSwitchView(Context ctx, boolean checked) {
        int width = dp(ctx, 38);
        int height = dp(ctx, 22);
        int thumbSize = dp(ctx, 16);

        FrameLayout container = new FrameLayout(ctx);
        container.setLayoutParams(new LinearLayout.LayoutParams(width, height));

        GradientDrawable track = new GradientDrawable();
        track.setColor(checked ? COLOR_SWITCH_ON : COLOR_SWITCH_OFF);
        track.setCornerRadius(height / 2f);
        container.setBackground(track);

        View thumb = new View(ctx);
        GradientDrawable thumbBg = new GradientDrawable();
        thumbBg.setShape(GradientDrawable.OVAL);
        thumbBg.setColor(Color.WHITE);
        thumb.setBackground(thumbBg);

        FrameLayout.LayoutParams tlp = new FrameLayout.LayoutParams(thumbSize, thumbSize);
        tlp.gravity = Gravity.CENTER_VERTICAL;
        tlp.leftMargin = checked ? (width - thumbSize - dp(ctx, 3)) : dp(ctx, 3);
        container.addView(thumb, tlp);

        return container;
    }

    private static void updateSwitchVisual(Context ctx, FrameLayout container, boolean checked) {
        int width = dp(ctx, 38);
        int height = dp(ctx, 22);
        int thumbSize = dp(ctx, 16);

        GradientDrawable track = new GradientDrawable();
        track.setColor(checked ? COLOR_SWITCH_ON : COLOR_SWITCH_OFF);
        track.setCornerRadius(height / 2f);
        container.setBackground(track);

        if (container.getChildCount() > 0) {
            View thumb = container.getChildAt(0);
            FrameLayout.LayoutParams tlp = (FrameLayout.LayoutParams) thumb.getLayoutParams();
            tlp.leftMargin = checked ? (width - thumbSize - dp(ctx, 3)) : dp(ctx, 3);
            thumb.setLayoutParams(tlp);
        }
    }

    private static EditText createInputField(Context ctx, String hint, String initialValue) {
        EditText et = new EditText(ctx);
        et.setText(initialValue);
        et.setHint(hint);
        et.setTextColor(COLOR_TEXT_PRIMARY);
        et.setHintTextColor(COLOR_TEXT_MUTED);
        et.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        et.setTypeface(Typeface.MONOSPACE);
        et.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
        et.setPadding(dp(ctx, 10), dp(ctx, 6), dp(ctx, 10), dp(ctx, 6));

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0x33121218);
        bg.setCornerRadius(dp(ctx, 8));
        bg.setStroke(dp(ctx, 1), COLOR_BORDER);
        et.setBackground(bg);
        return et;
    }

    private static View createInputRow(Context ctx, String label, EditText input) {
        LinearLayout row = new LinearLayout(ctx);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(ctx, 12), dp(ctx, 4), dp(ctx, 12), dp(ctx, 4));

        TextView tv = new TextView(ctx);
        tv.setText(label);
        tv.setTextColor(COLOR_TEXT_SECONDARY);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        row.addView(tv, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(dp(ctx, 140), ViewGroup.LayoutParams.WRAP_CONTENT);
        row.addView(input, ilp);
        return row;
    }

    private static View createChoiceRow(Context ctx, String title, boolean selected, Runnable onClick) {
        LinearLayout row = new LinearLayout(ctx);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(ctx, 12), dp(ctx, 10), dp(ctx, 12), dp(ctx, 10));

        TextView tv = new TextView(ctx);
        tv.setText(title);
        tv.setTextColor(selected ? COLOR_SWITCH_ON : COLOR_TEXT_PRIMARY);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        tv.setTypeface(Typeface.create("sans-serif-medium", selected ? Typeface.BOLD : Typeface.NORMAL));
        row.addView(tv, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        if (selected) {
            TextView chk = new TextView(ctx);
            chk.setText("✔");
            chk.setTextColor(COLOR_SWITCH_ON);
            chk.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
            row.addView(chk);
        }

        row.setOnClickListener(v -> {
            v.performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY);
            if (onClick != null) onClick.run();
        });
        return row;
    }

    private interface ChoiceCallback {
        void onChoice(int index);
    }

    private static void addSubLabel(Context ctx, LinearLayout parent, String text) {
        TextView tv = new TextView(ctx);
        tv.setText(text);
        tv.setTextColor(COLOR_TEXT_MUTED);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        tv.setPadding(dp(ctx, 8), dp(ctx, 10), dp(ctx, 8), dp(ctx, 4));
        parent.addView(tv);
    }

    /** Вертикальный выбор одного варианта; перерисовывается на месте, без переоткрытия панели. */
    private static LinearLayout createChoiceGroup(Context ctx, String[] titles, int selected, ChoiceCallback cb) {
        LinearLayout group = new LinearLayout(ctx);
        group.setOrientation(LinearLayout.VERTICAL);
        fillChoiceGroup(ctx, group, titles, selected, cb);
        return group;
    }

    private static void fillChoiceGroup(Context ctx, LinearLayout group, String[] titles, int selected, ChoiceCallback cb) {
        group.removeAllViews();
        for (int i = 0; i < titles.length; i++) {
            final int idx = i;
            group.addView(createChoiceRow(ctx, titles[i], i == selected, () -> {
                fillChoiceGroup(ctx, group, titles, idx, cb);
                cb.onChoice(idx);
            }));
        }
    }

    /** Горизонтальный ряд «чипов» для коротких значений (проценты). */
    private static LinearLayout createChipGroup(Context ctx, String[] labels, int selected, ChoiceCallback cb) {
        LinearLayout group = new LinearLayout(ctx);
        group.setOrientation(LinearLayout.HORIZONTAL);
        group.setPadding(dp(ctx, 4), dp(ctx, 2), dp(ctx, 4), dp(ctx, 6));
        fillChipGroup(ctx, group, labels, selected, cb);
        return group;
    }

    private static void fillChipGroup(Context ctx, LinearLayout group, String[] labels, int selected, ChoiceCallback cb) {
        group.removeAllViews();
        for (int i = 0; i < labels.length; i++) {
            final int idx = i;
            boolean sel = i == selected;
            TextView chip = new TextView(ctx);
            chip.setText(labels[i]);
            chip.setGravity(Gravity.CENTER);
            chip.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
            chip.setTextColor(sel ? COLOR_SWITCH_ON : COLOR_TEXT_PRIMARY);
            chip.setTypeface(Typeface.create("sans-serif-medium", sel ? Typeface.BOLD : Typeface.NORMAL));
            chip.setPadding(0, dp(ctx, 8), 0, dp(ctx, 8));

            GradientDrawable bg = new GradientDrawable();
            bg.setColor(sel ? 0x1800FF66 : COLOR_CARD_HOVER);
            bg.setCornerRadius(dp(ctx, 10));
            if (sel) bg.setStroke(dp(ctx, 1), 0x6600FF66);
            chip.setBackground(bg);

            chip.setOnClickListener(v -> {
                v.performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY);
                fillChipGroup(ctx, group, labels, idx, cb);
                cb.onChoice(idx);
            });

            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            if (i > 0) lp.leftMargin = dp(ctx, 6);
            group.addView(chip, lp);
        }
    }

    private static String[] levelLabels(int[] levels, String zeroLabel) {
        String[] out = new String[levels.length];
        for (int i = 0; i < levels.length; i++) {
            out[i] = levels[i] == 0 && zeroLabel != null ? zeroLabel : levels[i] + "%";
        }
        return out;
    }

    /** Индекс ближайшего уровня — на случай, если в настройках лежит значение не из списка. */
    private static int indexOfLevel(int[] levels, int value) {
        int best = 0;
        for (int i = 1; i < levels.length; i++) {
            if (Math.abs(levels[i] - value) < Math.abs(levels[best] - value)) best = i;
        }
        return best;
    }

    private static View createCard(Context ctx, int padH, int padV) {
        LinearLayout l = new LinearLayout(ctx);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(padH, padV, padH, padV);

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(COLOR_CARD);
        bg.setCornerRadius(dp(ctx, 16));
        bg.setStroke(dp(ctx, 1), COLOR_BORDER);
        l.setBackground(bg);
        return l;
    }

    private static View createMinimalButton(Context ctx, String text, int textColor, int hoverColor) {
        TextView b = new TextView(ctx);
        b.setText(text);
        b.setTextColor(textColor);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        b.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(ctx, 14), dp(ctx, 10), dp(ctx, 14), dp(ctx, 10));

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(COLOR_CARD);
        bg.setCornerRadius(dp(ctx, 12));
        bg.setStroke(dp(ctx, 1), COLOR_BORDER);
        b.setBackground(bg);
        return b;
    }

    private static void addSectionHeader(Context ctx, LinearLayout parent, String title) {
        TextView t = new TextView(ctx);
        t.setText(title);
        t.setTextColor(COLOR_TEXT_MUTED);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setLetterSpacing(0.08f);
        t.setPadding(dp(ctx, 4), dp(ctx, 12), dp(ctx, 4), dp(ctx, 6));
        parent.addView(t);
    }

    private static int dp(Context ctx, int val) {
        return (int) TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP, val, ctx.getResources().getDisplayMetrics()
        );
    }
    private static int dp(Context ctx, float val) {
        return (int) TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP, val, ctx.getResources().getDisplayMetrics()
        );
    }
    private static int dp4(Context ctx) { return dp(ctx, 4); }
    private static int dp10(Context ctx) { return dp(ctx, 10); }
    private static int dp14(Context ctx) { return dp(ctx, 14); }

    public static void openWallpaperGalleryPicker(Activity activity, PluginContext margyt, Callback callback) {
        if (activity == null || activity.isFinishing()) return;
        try {
            WallpaperPickerFragment frag = new WallpaperPickerFragment();
            frag.init(margyt, callback);
            activity.getFragmentManager()
                    .beginTransaction()
                    .add(frag, "rootmymargyt_wall_picker")
                    .commitAllowingStateLoss();
        } catch (Throwable t) {
            Toast.makeText(activity, "Ошибка открытия галереи: " + t.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    public static class WallpaperPickerFragment extends android.app.Fragment {
        private static final int REQ_WALL = 0x5741;
        private PluginContext margyt;
        private Callback callback;

        public void init(PluginContext margyt, Callback callback) {
            this.margyt = margyt;
            this.callback = callback;
        }

        @Override
        public void onActivityCreated(Bundle savedInstanceState) {
            super.onActivityCreated(savedInstanceState);
            try {
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("image/*");
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                startActivityForResult(Intent.createChooser(intent, "Выберите обои профиля"), REQ_WALL);
            } catch (Throwable t) {
                try {
                    Intent intent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    startActivityForResult(intent, REQ_WALL);
                } catch (Throwable t2) {
                    Toast.makeText(getActivity(), "Галерея недоступна: " + t2.getMessage(), Toast.LENGTH_SHORT).show();
                    removeSelf();
                }
            }
        }

        @Override
        public void onActivityResult(int requestCode, int resultCode, Intent data) {
            super.onActivityResult(requestCode, resultCode, data);
            if (requestCode == REQ_WALL && resultCode == Activity.RESULT_OK && data != null && data.getData() != null) {
                Uri uri = data.getData();
                Activity act = getActivity();
                if (act != null && !act.isFinishing()) {
                    RootMyMargyT.saveWallpaperFromUri(act, uri, margyt);
                    if (callback != null) callback.onApplyWallpaperNow();
                }
            }
            removeSelf();
        }

        private void removeSelf() {
            try {
                if (getFragmentManager() != null) {
                    getFragmentManager().beginTransaction().remove(this).commitAllowingStateLoss();
                }
            } catch (Throwable ignored) {}
        }
    }
}
