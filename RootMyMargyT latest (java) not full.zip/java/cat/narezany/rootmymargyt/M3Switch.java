package cat.narezany.rootmymargyt;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.animation.OvershootInterpolator;
import android.widget.CompoundButton;

/**
 * M3Switch — переключатель Material 3 Expressive.
 *
 * Дорожка 52×32dp. Выключен: контур и маленький ползунок 16dp слева. Включён: заливка
 * акцентом и ползунок 24dp справа с галочкой. При нажатии ползунок вырастает до 28dp.
 * Переход пружинит. Поведение — обычного CompoundButton: setChecked, слушатель, доступность.
 */
public final class M3Switch extends CompoundButton {

    private final Paint track = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint thumb = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint check = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private final float d;
    private int accent;
    private int offTrack;
    private int offOutline;

    /** 0 — выключен, 1 — включён; анимируется. */
    private float progress;
    private float press = 0f;
    private ValueAnimator anim;
    private ValueAnimator pressAnim;

    public M3Switch(Context ctx, int accent, int surface) {
        super(ctx);
        d = ctx.getResources().getDisplayMetrics().density;
        setColors(accent, surface);
        setBackground(null);
        setButtonDrawable(null);
        setClickable(true);
        setFocusable(true);
        check.setStyle(Paint.Style.STROKE);
        check.setStrokeCap(Paint.Cap.ROUND);
        check.setStrokeJoin(Paint.Join.ROUND);
        check.setStrokeWidth(2.2f * d);
        progress = isChecked() ? 1f : 0f;
    }

    public void setColors(int accent, int surface) {
        this.accent = accent | 0xFF000000;
        this.offTrack = M3X.mix(surface, 0xFF000000, 0.25f);
        this.offOutline = M3X.mix(surface, 0xFFFFFFFF, 0.35f);
        invalidate();
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        // Чуть больше дорожки — место под выросший ползунок и удобное касание
        setMeasuredDimension(Math.round(60 * d), Math.round(40 * d));
    }

    @Override
    public void setChecked(boolean checked) {
        boolean was = isChecked();
        super.setChecked(checked);
        if (was == checked) return;
        if (d == 0f) return; // вызов из конструктора CompoundButton, поля ещё не готовы
        if (anim != null) anim.cancel();
        if (!isAttachedToWindow()) {
            progress = checked ? 1f : 0f;
            invalidate();
            return;
        }
        anim = ValueAnimator.ofFloat(progress, checked ? 1f : 0f);
        anim.setDuration(360);
        anim.setInterpolator(new OvershootInterpolator(1.6f));
        anim.addUpdateListener(a -> {
            progress = (float) a.getAnimatedValue();
            invalidate();
        });
        anim.start();
    }

    @Override
    public boolean onTouchEvent(MotionEvent ev) {
        int action = ev.getActionMasked();
        if (action == MotionEvent.ACTION_DOWN) animatePress(1f);
        else if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) animatePress(0f);
        return super.onTouchEvent(ev);
    }

    private void animatePress(float to) {
        if (pressAnim != null) pressAnim.cancel();
        pressAnim = ValueAnimator.ofFloat(press, to);
        pressAnim.setDuration(to > 0 ? 100 : 260);
        pressAnim.addUpdateListener(a -> {
            press = (float) a.getAnimatedValue();
            invalidate();
        });
        pressAnim.start();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        float w = 52 * d, h = 32 * d;
        float left = (getWidth() - w) / 2f;
        float top = (getHeight() - h) / 2f;
        float p = Math.max(0f, Math.min(1f, progress));
        rect.set(left, top, left + w, top + h);

        // Дорожка: из контура в заливку акцентом
        track.setStyle(Paint.Style.FILL);
        track.setColor(M3X.mix(offTrack, accent, p));
        canvas.drawRoundRect(rect, h / 2f, h / 2f, track);
        if (p < 1f) {
            track.setStyle(Paint.Style.STROKE);
            track.setStrokeWidth(2f * d);
            track.setColor(M3X.mix(offOutline, accent, p));
            track.setAlpha(Math.round(255 * (1f - p)));
            rect.inset(d, d);
            canvas.drawRoundRect(rect, h / 2f - d, h / 2f - d, track);
            track.setAlpha(255);
        }

        // Ползунок: 16dp → 24dp, при нажатии 28dp; едет по дорожке (с перелётом пружины)
        float size = (16 + 8 * p) * d + (28 * d - (16 + 8 * p) * d) * press;
        float cxOff = left + h / 2f;
        float cxOn = left + w - h / 2f;
        float cx = cxOff + (cxOn - cxOff) * progress;
        float cy = top + h / 2f;
        thumb.setColor(M3X.mix(offOutline, M3X.onColor(accent) == 0xFFFFFFFF ? 0xFFFFFFFF : 0xFF1A1A1F, p));
        canvas.drawCircle(cx, cy, size / 2f, thumb);

        // Галочка на включённом
        if (p > 0.5f) {
            check.setColor(accent);
            check.setAlpha(Math.round(255 * Math.min(1f, (p - 0.5f) * 2f)));
            float s = 4.5f * d;
            canvas.drawLine(cx - s, cy, cx - s * 0.25f, cy + s * 0.75f, check);
            canvas.drawLine(cx - s * 0.25f, cy + s * 0.75f, cx + s, cy - s * 0.7f, check);
        }
    }
}
