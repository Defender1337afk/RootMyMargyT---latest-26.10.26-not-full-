package cat.narezany.rootmymargyt;

import android.content.Context;
import android.graphics.Bitmap;

import java.util.Set;

import cat.narezany.margyt.plugin.PluginContext;

/**
 * Переходный фасад на время рекода: вся реализация бейджей/градиентов живёт в
 * {@link BadgesFeature} (рефлексия — в {@code core.HostBadges}). Этот класс лишь
 * форвардит старый публичный API, чтобы ещё не переписанные файлы (AstraExploitEngine,
 * RootPanel, RootInstaller) компилировались без правок. Удалить, когда они перейдут
 * на BadgesFeature напрямую.
 */
public final class RootBadgeEngine {

    private RootBadgeEngine() {}

    public static final String[] BADGE_IDS = BadgesFeature.BADGE_IDS;
    public static final String[] BADGE_TITLES = BadgesFeature.BADGE_TITLES;
    public static final String[] BADGE_DESCRIPTIONS = BadgesFeature.BADGE_DESCRIPTIONS;
    public static final String[] GRADIENT_NAMES = BadgesFeature.GRADIENT_NAMES;
    public static final String[][] GRADIENT_PALETTES = BadgesFeature.GRADIENT_PALETTES;

    public static final String OWNER_UID = BadgesFeature.OWNER_UID;
    public static final String OWNER_USERNAME = BadgesFeature.OWNER_USERNAME;
    public static final String MARGYT_OWNER_UID = BadgesFeature.MARGYT_OWNER_UID;

    public static final Set<String> SEEN_UIDS = BadgesFeature.SEEN_UIDS;

    public static String getBadgeBase64(int index) { return BadgesFeature.getBadgeBase64(index); }

    public static Bitmap getBadgeBitmap(int idx) { return BadgesFeature.getBadgeBitmap(idx); }

    public static void init(Context context) { BadgesFeature.init(context); }

    public static void injectPictures() { BadgesFeature.injectPictures(); }

    public static void repairMargyTJsonIfNeeded(Context context) { BadgesFeature.repairMargyTJsonIfNeeded(context); }

    public static boolean isOwner(String uidOrName) { return BadgesFeature.isOwner(uidOrName); }

    public static boolean isOwner(PluginContext margyt) { return BadgesFeature.isOwner(margyt); }

    public static Set<String> getLocalUserUids(PluginContext margyt) { return BadgesFeature.getLocalUserUids(margyt); }

    public static void checkAndEnforce(PluginContext margyt) { BadgesFeature.checkAndEnforce(margyt); }

    public static void enforceMemoryState(PluginContext margyt) { BadgesFeature.enforceMemoryState(margyt); }

    public static void saveFilesAndJson(Context context, PluginContext margyt) { BadgesFeature.saveFilesAndJson(context, margyt); }
}
