package cat.narezany.rootmymargyt;

import android.util.DisplayMetrics;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * Общие локаторы по дереву профиля/ленты: найти настоящий ImageView аватарки, понять, что мы
 * строго в своём локальном профиле, и есть ли на экране разметка ленты видео.
 *
 * Раньше эти device-проверенные методы жили в {@code FemboyEarsView} (их зовут фон профиля,
 * живая аватарка, Liquid-часы, счётчики ленты, TouchSpy, Clawd-сенсоры). Ушки удалены как фича,
 * поэтому утилиты вынесены сюда без изменений логики. Тег {@link #TAG_EARS} оставлен для обратной
 * совместимости (вью ушек больше не создаётся — findViewWithTag вернёт null).
 */
public final class ProfileLocator {

    private ProfileLocator() {}

    public static final String TAG_EARS = "rootmymargyt_femboy_ears";

    /**
     * Поиск НАСТОЯЩЕГО ImageView аватарки: приоритет реальным ImageView/DraweeView,
     * исключая внешние контейнеры с кнопкой «+» и облачком статуса.
     */
    public static View findProfileAvatar(ViewGroup decor) {
        if (decor == null) return null;
        DisplayMetrics dm = decor.getResources().getDisplayMetrics();
        int screenW = dm.widthPixels;
        int screenH = dm.heightPixels;
        float density = dm.density;

        List<View> candidates = new ArrayList<>();
        int tabTop = RootWallpaperEngine.videoTabBarTop(decor);
        collectAvatarCandidates(decor, candidates, 0, screenW, screenH, density, tabTop);

        if (candidates.isEmpty()) return null;

        for (View v : candidates) {
            if (hasSingleLetterOrPlusMarker(v)) return v;
        }

        View bestImage = null;
        int maxImageArea = 0;
        for (View v : candidates) {
            String name = v.getClass().getName();
            if (v instanceof ImageView || name.contains("ImageView") ||
                name.contains("DraweeView") || name.contains("SmartImage") ||
                name.contains("RemoteImage")) {
                int w = v.getWidth() - v.getPaddingLeft() - v.getPaddingRight();
                int h = v.getHeight() - v.getPaddingTop() - v.getPaddingBottom();
                int area = w * h;
                if (area > maxImageArea) {
                    maxImageArea = area;
                    bestImage = v;
                }
            }
        }

        View bestCandidate = null;
        int maxCandidateArea = 0;
        for (View v : candidates) {
            int w = v.getWidth() - v.getPaddingLeft() - v.getPaddingRight();
            int h = v.getHeight() - v.getPaddingTop() - v.getPaddingBottom();
            int area = w * h;
            if (area > maxCandidateArea) {
                maxCandidateArea = area;
                bestCandidate = v;
            }
        }

        if (bestImage != null && maxImageArea >= maxCandidateArea * 0.75f) return bestImage;
        return bestCandidate;
    }

    private static boolean hasSingleLetterOrPlusMarker(View v) {
        if (v == null) return false;
        if (v instanceof TextView) {
            CharSequence cs = ((TextView) v).getText();
            if (cs != null) {
                String s = cs.toString().trim();
                if (s.length() == 1 && Character.isLetter(s.charAt(0))) return true;
            }
        }
        if (v instanceof ViewGroup) {
            ViewGroup vg = (ViewGroup) v;
            for (int i = 0; i < vg.getChildCount(); i++) {
                if (hasSingleLetterOrPlusMarker(vg.getChildAt(i))) return true;
            }
        }
        return false;
    }

    public static boolean isLocalUserProfile(ViewGroup decor) {
        if (decor == null) return false;

        int screenW = decor.getResources().getDisplayMetrics().widthPixels;
        int screenH = decor.getResources().getDisplayMetrics().heightPixels;

        boolean[] flags = new boolean[3]; // [hasMyProfileBtn, hasFollowBtn, hasCommentsSheet]
        scanProfileDecor(decor, flags, screenW, screenH, 0);

        if (flags[1] || flags[2]) return false;   // чужой профиль или открыты комментарии
        if (flags[0]) return true;                 // виден элемент управления своим профилем
        if (hasVideoFeedMarkers(decor, screenW, screenH)) return false;
        return isBottomProfileTabActive(decor);
    }

    public static boolean hasVideoFeedMarkers(ViewGroup decor) {
        if (decor == null) return false;
        int screenW = decor.getResources().getDisplayMetrics().widthPixels;
        int screenH = decor.getResources().getDisplayMetrics().heightPixels;
        return hasVideoFeedMarkers(decor, screenW, screenH);
    }

    public static boolean hasVideoFeedMarkers(ViewGroup decor, int screenW, int screenH) {
        if (decor == null) return false;
        return scanFeedMarkers(decor, screenW, screenH, 0);
    }

    private static boolean scanFeedMarkers(View v, int screenW, int screenH, int depth) {
        if (v == null || depth > 25 || !v.isShown()) return false;
        if (v instanceof TextView) {
            CharSequence cs = ((TextView) v).getText();
            if (cs != null) {
                String s = cs.toString().trim().toLowerCase();
                int[] loc = new int[2];
                v.getLocationOnScreen(loc);
                int vw = v.getWidth();
                int vh = v.getHeight();
                if (loc[0] >= 0 && (loc[0] + vw) <= screenW && vw > 0 && vh > 0 &&
                    loc[1] >= 0 && loc[1] < screenH * 0.16f && v.getAlpha() > 0.8f) {
                    if (s.equals("для вас") || s.equals("рекомендации") || s.equals("подписки") ||
                        s.equals("for you") || s.equals("following") || s.equals("друзья") || s.equals("friends")) {
                        return true;
                    }
                }
            }
        }
        if (v instanceof ViewGroup) {
            ViewGroup vg = (ViewGroup) v;
            for (int i = 0; i < vg.getChildCount(); i++) {
                if (scanFeedMarkers(vg.getChildAt(i), screenW, screenH, depth + 1)) return true;
            }
        }
        return false;
    }

    private static void scanProfileDecor(View v, boolean[] flags, int screenW, int screenH, int depth) {
        if (v == null || depth > 25 || !v.isShown()) return;

        int[] loc = new int[2];
        v.getLocationOnScreen(loc);
        if (loc[0] < -50 || loc[0] >= screenW + 50 || loc[1] < -50 || loc[1] >= screenH + 50) return;

        if (v instanceof TextView) {
            CharSequence cs = ((TextView) v).getText();
            if (cs != null) {
                String s = cs.toString().trim().toLowerCase();
                if (s.contains("изменить профиль") || s.contains("редактировать профиль") ||
                    s.equals("редактировать") || s.contains("edit profile") ||
                    s.contains("поделиться профилем") || s.contains("добавить друзей") ||
                    s.contains("добавить описание") || s.contains("добавить биографию") ||
                    s.contains("настройки и конфиденциальность")) {
                    if (loc[1] < screenH * 0.75f && v.getAlpha() > 0.5f) flags[0] = true;
                }
                if (s.equals("подписаться") || s.equals("follow") || s.equals("сообщение") || s.equals("message")) {
                    if (loc[1] < screenH * 0.75f && v.getAlpha() > 0.5f) flags[1] = true;
                }
                if (s.equals("комментарии") || s.equals("comments") || s.startsWith("добавить комментарий") ||
                    s.startsWith("ответить") || s.startsWith("add comment")) {
                    if (loc[1] > screenH * 0.30f && v.getAlpha() > 0.5f) flags[2] = true;
                }
            }
        }

        if (v instanceof ViewGroup) {
            ViewGroup vg = (ViewGroup) v;
            for (int i = 0; i < vg.getChildCount(); i++) {
                scanProfileDecor(vg.getChildAt(i), flags, screenW, screenH, depth + 1);
            }
        }
    }

    private static boolean isBottomProfileTabActive(ViewGroup decor) {
        int screenW = decor.getResources().getDisplayMetrics().widthPixels;
        int screenH = decor.getResources().getDisplayMetrics().heightPixels;
        return findSelectedProfileTab(decor, screenW, screenH, 0);
    }

    private static boolean findSelectedProfileTab(View v, int screenW, int screenH, int depth) {
        if (v == null || depth > 20 || !v.isShown()) return false;
        int[] loc = new int[2];
        v.getLocationOnScreen(loc);

        if (loc[0] >= screenW * 0.70f && loc[1] >= screenH * 0.80f) {
            if (v.isSelected() || v.isActivated()) return true;
            CharSequence cd = v.getContentDescription();
            if (cd != null) {
                String cds = cd.toString().toLowerCase();
                if ((cds.contains("профиль") || cds.contains("profile")) && (v.isSelected() || v.isActivated())) {
                    return true;
                }
            }
            ViewParent p = v.getParent();
            if (p instanceof View && (((View) p).isSelected() || ((View) p).isActivated())) return true;
        }

        if (v instanceof ViewGroup) {
            ViewGroup vg = (ViewGroup) v;
            for (int i = 0; i < vg.getChildCount(); i++) {
                if (findSelectedProfileTab(vg.getChildAt(i), screenW, screenH, depth + 1)) return true;
            }
        }
        return false;
    }

    private static void collectAvatarCandidates(ViewGroup group, List<View> out, int depth, int screenW, int screenH,
                                                float density, int tabTop) {
        if (group == null || depth > 50) return;
        String groupType = group.getClass().getName();
        if (tabTop > 0 && (groupType.contains("RecyclerView") || groupType.contains("GridView"))) {
            int[] at = new int[2];
            group.getLocationOnScreen(at);
            if (at[1] >= tabTop - (int) (8 * density)) return;
        }
        int count = group.getChildCount();

        int minSize = (int) (56 * density);
        int maxSize = (int) (200 * density);

        for (int i = 0; i < count; i++) {
            View child = group.getChildAt(i);
            if (child == null || !child.isShown() || child.getVisibility() != View.VISIBLE) continue;

            int w = child.getWidth();
            int h = child.getHeight();

            if (w >= minSize && w <= maxSize && h >= minSize && h <= maxSize) {
                float aspect = (float) w / (float) h;
                if (aspect >= 0.85f && aspect <= 1.18f) {
                    int[] loc = new int[2];
                    child.getLocationOnScreen(loc);
                    if (loc[1] >= screenH * 0.05f && loc[1] <= screenH * 0.58f &&
                        loc[0] >= screenW * 0.05f && loc[0] <= screenW * 0.96f &&
                        (tabTop <= 0 || loc[1] + h <= tabTop)) {
                        out.add(child);
                    }
                }
            }

            if (child instanceof ViewGroup) {
                collectAvatarCandidates((ViewGroup) child, out, depth + 1, screenW, screenH, density, tabTop);
            }
        }
    }
}
