package cat.narezany.rootmymargyt;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import cat.narezany.margyt.plugin.PluginContext;

/**
 * RootWallpaperEngine — движок кастомного фона своего профиля.
 *
 * Режимы:
 * - MODE_HEADER: фон только в шапке (от верха экрана до таб-бара видео), прокручивается вместе с шапкой.
 * - MODE_FULL: фон на всю страницу профиля, неподвижный, видео-сетка поверх него.
 *
 * Обновление вызывается из onPreDraw, поэтому всё тяжёлое (обход дерева) ограничено
 * по частоте, а повторное применение идемпотентно и не вызывает лишних перерисовок.
 */
public final class RootWallpaperEngine {

    public static final String KEY_WALLPAPER_ENABLED = "custom_profile_wallpaper_enabled";
    public static final String KEY_WALLPAPER_PATH = "custom_profile_wallpaper_path";
    public static final String KEY_WALLPAPER_PRESET = "custom_profile_wallpaper_preset";
    public static final String KEY_WALLPAPER_MODE = "custom_profile_wallpaper_mode";
    public static final String KEY_WALLPAPER_DIM = "custom_profile_wallpaper_dim";
    /** Своё фото — анимация (GIF/WebP), лежит в profile_wallpaper.anim. */
    public static final String KEY_WALLPAPER_ANIMATED = "custom_profile_wallpaper_animated";
    /** Проигрывать анимацию; выключено — показывается первый кадр. */
    public static final String KEY_WALLPAPER_PLAY_GIF = "custom_profile_wallpaper_play_gif";
    /** Своё фото — видео, лежит в profile_wallpaper.video. */
    public static final String KEY_WALLPAPER_VIDEO = "custom_profile_wallpaper_video";
    /** Подложки под статистикой и строкой вкладок видео: стекло / как в TikTok / без. */
    public static final String KEY_WALLPAPER_PANELS = "custom_profile_wallpaper_panels";

    public static final int PANELS_GLASS = 0;
    public static final int PANELS_SOLID = 1;
    public static final int PANELS_NONE = 2;
    public static final String[] PANELS_NAMES = {"Стекло", "Как в TikTok", "Без панелей"};

    /** Размытие фото фона: 0 — нет, 1 — слабое, 2 — сильное. GIF и видео не размываются. */
    public static final String KEY_WALLPAPER_BLUR = "custom_profile_wallpaper_blur";
    public static final String[] BLUR_NAMES = {"Без размытия", "Слабое", "Сильное"};

    public static final String TAG_PROFILE_WALLPAPER = "rootmymargyt_wallpaper_bg";

    public static final String PRESET_CUSTOM = "custom";
    public static final String PRESET_CYBER = "cyber";
    public static final String PRESET_ASTRA = "astra";
    public static final String PRESET_DARK = "dark";
    public static final String PRESET_TILKAJO = "tilkajo";

    public static final int MODE_HEADER = 0;
    public static final int MODE_FULL = 1;

    public static final int DEFAULT_DIM = 25;
    public static final int[] DIM_LEVELS = {0, 15, 25, 40, 60};

    public static final int TARGET_PROFILE = 0;
    public static final int TARGET_COMMENTS = 1;

    private static final long THROTTLE_MS = 250;
    private static final int MAX_BITMAP_DIM = 1920;
    private static final long MAX_ANIM_BYTES = 25L * 1024 * 1024;
    private static final int MAX_ANIM_DIM = 1080;
    private static final long MAX_VIDEO_BYTES = 60L * 1024 * 1024;

    private static final int TAG_KEY_ORIGINAL_BG = 0x7F0B9988;
    private static final int TAG_KEY_ORIGINAL_BANNER_DRAWABLE = 0x7F0B998A;
    private static final int TAG_KEY_ORIGINAL_STATUS_BAR_COLOR = 0x7F0B998B;
    private static final int TAG_KEY_ORIGINAL_UI_FLAGS = 0x7F0B998C;

    /** Метка «оригинального фона не было» — отличает null-фон от несохранённого. */
    static final Object NO_ORIGINAL = new Object();

    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    private static Bitmap cachedWallpaperBitmap = null;
    private static String cachedWallpaperPath = null;
    private static AnimatedWallpaper cachedAnim = null;
    private static boolean animLoadFailed = false;
    private static VideoWallpaper video = null;
    private static boolean videoFailed = false;

    /** Причина последней неудачной загрузки картинки — для текста тоста. */
    public static String lastSaveError = null;

    private static boolean isWallpaperApplied = false;
    private static WeakReference<Activity> appliedActivity = null;
    private static WeakReference<ViewGroup> appliedMaster = null;
    private static WeakReference<View> cachedTabBar = null;
    private static WeakReference<View> cachedStatsBlock = null;

    /** Что мы поставили и где — чтобы вернуть до отрисовки, если TikTok перезапишет. */
    private static SingleProfileWallpaperDrawable lastWallDrawable = null;
    private static final java.util.WeakHashMap<View, Drawable> placedPanels = new java.util.WeakHashMap<>();
    private static final java.util.WeakHashMap<ImageView, Boolean> clearedImages = new java.util.WeakHashMap<>();
    /** Наши «прозрачные» фоны — чтобы отличать их от панелей при проверке перекраски. */
    private static final java.util.WeakHashMap<Drawable, Boolean> clearDrawables = new java.util.WeakHashMap<>();
    private static final List<WeakReference<View>> touchedViews = new ArrayList<>();

    private static long lastRunAt = 0;
    private static boolean trailingScheduled = false;
    private static int profileMissCount = 0;

    private static boolean lastProfileResult = false;
    private static long lastProfileCheckAt = 0;
    private static WeakReference<ViewGroup> lastProfileDecor = null;

    private RootWallpaperEngine() {}

    // ───────────────────────────── Настройки ─────────────────────────────

    public static boolean isEnabled(PluginContext margyt) {
        return margyt != null && margyt.getBoolean(KEY_WALLPAPER_ENABLED, false);
    }

    public static void setEnabled(PluginContext margyt, boolean enabled) {
        if (margyt != null) {
            margyt.prefs().edit().putBoolean(KEY_WALLPAPER_ENABLED, enabled).apply();
        }
    }

    public static int getMode(PluginContext margyt) {
        int m = margyt != null ? margyt.getInt(KEY_WALLPAPER_MODE, MODE_HEADER) : MODE_HEADER;
        return m == MODE_FULL ? MODE_FULL : MODE_HEADER;
    }

    public static void setMode(PluginContext margyt, int mode) {
        if (margyt != null) margyt.prefs().edit().putInt(KEY_WALLPAPER_MODE, mode).apply();
    }

    public static int getDim(PluginContext margyt) {
        int d = margyt != null ? margyt.getInt(KEY_WALLPAPER_DIM, DEFAULT_DIM) : DEFAULT_DIM;
        return Math.max(0, Math.min(90, d));
    }

    public static void setDim(PluginContext margyt, int dim) {
        if (margyt != null) margyt.prefs().edit().putInt(KEY_WALLPAPER_DIM, dim).apply();
    }

    public static boolean isAnimated(PluginContext margyt) {
        return margyt != null && margyt.getBoolean(KEY_WALLPAPER_ANIMATED, false);
    }

    public static int getBlur(PluginContext margyt) {
        int v = margyt != null ? margyt.getInt(KEY_WALLPAPER_BLUR, 0) : 0;
        return v < 0 || v > 2 ? 0 : v;
    }

    public static void setBlur(PluginContext margyt, int level) {
        if (margyt != null) margyt.prefs().edit().putInt(KEY_WALLPAPER_BLUR, level).apply();
    }

    private static Bitmap blurSource = null;
    private static int blurLevel = 0;
    private static Bitmap blurResult = null;

    /**
     * Мягкое размытие двойным уменьшением: сильно вниз, затем до четверти размера — билинейная
     * фильтрация сглаживает, а остальное растягивание делает drawable. Результат кэшируется,
     * иначе фон пересоздавался бы на каждом проходе (drawable сравнивает битмап по ссылке).
     */
    private static synchronized Bitmap applyBlur(Bitmap src, int level) {
        if (level <= 0 || src == null || src.isRecycled()) return src;
        if (blurSource == src && blurLevel == level && blurResult != null && !blurResult.isRecycled()) return blurResult;
        try {
            int w = src.getWidth();
            int h = src.getHeight();
            int f = level == 1 ? 8 : 20;
            Bitmap small = Bitmap.createScaledBitmap(src, Math.max(1, w / f), Math.max(1, h / f), true);
            Bitmap result = Bitmap.createScaledBitmap(small, Math.max(1, w / 4), Math.max(1, h / 4), true);
            if (small != result && small != src) small.recycle();
            blurSource = src;
            blurLevel = level;
            blurResult = result;
            return result;
        } catch (Throwable t) {
            return src;
        }
    }

    public static int getPanels(PluginContext margyt) {
        int v = margyt != null ? margyt.getInt(KEY_WALLPAPER_PANELS, PANELS_GLASS) : PANELS_GLASS;
        return v == PANELS_SOLID || v == PANELS_NONE ? v : PANELS_GLASS;
    }

    public static void setPanels(PluginContext margyt, int panels) {
        if (margyt != null) margyt.prefs().edit().putInt(KEY_WALLPAPER_PANELS, panels).apply();
    }

    public static boolean isVideo(PluginContext margyt) {
        return margyt != null && margyt.getBoolean(KEY_WALLPAPER_VIDEO, false);
    }

    public static boolean isPlayGif(PluginContext margyt) {
        return margyt == null || margyt.getBoolean(KEY_WALLPAPER_PLAY_GIF, true);
    }

    public static void setPlayGif(PluginContext margyt, boolean play) {
        if (margyt != null) margyt.prefs().edit().putBoolean(KEY_WALLPAPER_PLAY_GIF, play).apply();
        if (!play) {
            stopAnimation();
            releaseVideo();
        }
    }

    // ───────────────────────────── Картинка ─────────────────────────────

    public static File getWallpaperFile(Context context) {
        File dir = new File(context.getFilesDir(), "rootmymargyt");
        if (!dir.exists()) dir.mkdirs();
        return new File(dir, "profile_wallpaper.jpg");
    }

    public static synchronized Bitmap getWallpaperBitmap(Context context, PluginContext margyt) {
        if (cachedWallpaperBitmap != null && !cachedWallpaperBitmap.isRecycled()) {
            return cachedWallpaperBitmap;
        }
        if (context == null) return null;

        try {
            String preset = margyt != null ? margyt.getString(KEY_WALLPAPER_PRESET, "") : "";

            // 1. Явно выбранный пресет важнее сохранённого фото
            if (PRESET_ASTRA.equals(preset) || PRESET_CYBER.equals(preset)) {
                cachedWallpaperBitmap = AstraBannerAssets.getBannerBitmap();
                return cachedWallpaperBitmap;
            }
            if (PRESET_TILKAJO.equals(preset)) {
                cachedWallpaperBitmap = TilkajoAssets.getTilkajoBgBitmap();
                return cachedWallpaperBitmap;
            }

            // 2. Своё фото, скопированное во внутреннюю память
            File file = getWallpaperFile(context);
            if (file.exists() && file.length() > 0) {
                Bitmap b = decodeSampled(file.getAbsolutePath(), MAX_BITMAP_DIM);
                if (b != null) {
                    cachedWallpaperPath = file.getAbsolutePath();
                    cachedWallpaperBitmap = b;
                    return b;
                }
            }

            // 3. Путь из настроек (старые версии плагина)
            if (margyt != null) {
                String p = margyt.getString(KEY_WALLPAPER_PATH, "");
                if (p != null && !p.isEmpty() && new File(p).length() > 0) {
                    Bitmap b = decodeSampled(p, MAX_BITMAP_DIM);
                    if (b != null) {
                        cachedWallpaperPath = p;
                        cachedWallpaperBitmap = b;
                        return b;
                    }
                }
            }

            // 4. По умолчанию — баннер Astra
            cachedWallpaperBitmap = AstraBannerAssets.getBannerBitmap();
            return cachedWallpaperBitmap;
        } catch (Throwable ignored) {
            return null;
        }
    }

    public static File getAnimFile(Context context) {
        File dir = new File(context.getFilesDir(), "rootmymargyt");
        if (!dir.exists()) dir.mkdirs();
        return new File(dir, "profile_wallpaper.anim");
    }

    /**
     * Анимация своего фото, или null: выбран пресет, фото статичное, анимация выключена
     * или файл не декодируется (тогда остаётся первый кадр из getWallpaperBitmap).
     */
    public static synchronized AnimatedWallpaper getAnimatedSource(Context context, PluginContext margyt) {
        if (context == null || !isAnimated(margyt) || isVideo(margyt) || !isPlayGif(margyt)) return null;
        String preset = margyt.getString(KEY_WALLPAPER_PRESET, "");
        if (preset != null && !preset.isEmpty() && !PRESET_CUSTOM.equals(preset)) return null;
        if (cachedAnim != null) return cachedAnim;
        if (animLoadFailed) return null;

        cachedAnim = AnimatedWallpaper.load(getAnimFile(context), MAX_ANIM_DIM);
        if (cachedAnim == null) {
            animLoadFailed = true;
            margyt.log("wallpaper: animation could not be decoded, showing first frame");
        }
        return cachedAnim;
    }

    public static synchronized void stopAnimation() {
        if (cachedAnim != null) cachedAnim.stop();
    }

    public static File getVideoFile(Context context) {
        File dir = new File(context.getFilesDir(), "rootmymargyt");
        if (!dir.exists()) dir.mkdirs();
        return new File(dir, "profile_wallpaper.video");
    }

    private static boolean wantsVideo(Context context, PluginContext margyt) {
        if (context == null || !isVideo(margyt) || !isPlayGif(margyt) || videoFailed) return false;
        String preset = margyt.getString(KEY_WALLPAPER_PRESET, "");
        if (preset != null && !preset.isEmpty() && !PRESET_CUSTOM.equals(preset)) return false;
        return getVideoFile(context).length() > 0;
    }

    static void releaseVideo() {
        if (video != null) {
            video.release();
            video = null;
        }
    }

    /**
     * Activity ушла с экрана — видео на паузу. Раньше плеер освобождался вместе с TextureView,
     * а затемнение профиля оставалось «под видео»: после возврата фон мог остаться пустым.
     * Если Android сам уничтожит поверхность в фоне, VideoWallpaper пересоздаст плеер.
     */
    public static void onPaused(Activity activity) {
        Activity owner = appliedActivity != null ? appliedActivity.get() : null;
        if (owner == activity && video != null) video.pause();
    }

    /** Сбрасывает кэш, следующий кадр перечитает картинку и пересоздаст фон. */
    public static synchronized void invalidateBitmap() {
        // Не вызываем recycle(): старый битмап ещё может рисоваться текущим drawable.
        cachedWallpaperBitmap = null;
        cachedWallpaperPath = null;
        if (cachedAnim != null) cachedAnim.stop();
        cachedAnim = null;
        animLoadFailed = false;
        releaseVideo();
        videoFailed = false;
    }

    static Bitmap decodeSampled(String path, int maxDim) {
        try {
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(path, bounds);
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null;

            BitmapFactory.Options opts = new BitmapFactory.Options();
            opts.inSampleSize = sampleSize(bounds.outWidth, bounds.outHeight, maxDim);
            return scaleDown(BitmapFactory.decodeFile(path, opts), maxDim);
        } catch (Throwable t) {
            return null;
        }
    }

    static Bitmap decodeSampled(Context context, Uri uri, int maxDim) {
        try {
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            InputStream in = context.getContentResolver().openInputStream(uri);
            if (in == null) return null;
            try {
                BitmapFactory.decodeStream(in, null, bounds);
            } finally {
                in.close();
            }
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null;

            BitmapFactory.Options opts = new BitmapFactory.Options();
            opts.inSampleSize = sampleSize(bounds.outWidth, bounds.outHeight, maxDim);
            in = context.getContentResolver().openInputStream(uri);
            if (in == null) return null;
            try {
                return scaleDown(BitmapFactory.decodeStream(in, null, opts), maxDim);
            } finally {
                in.close();
            }
        } catch (Throwable t) {
            return null;
        }
    }

    private static int sampleSize(int w, int h, int maxDim) {
        int sample = 1;
        while (w / (sample * 2) >= maxDim || h / (sample * 2) >= maxDim) sample *= 2;
        return sample;
    }

    private static Bitmap scaleDown(Bitmap b, int maxDim) {
        if (b == null) return null;
        int w = b.getWidth();
        int h = b.getHeight();
        if (w <= maxDim && h <= maxDim) return b;
        float ratio = Math.min((float) maxDim / w, (float) maxDim / h);
        Bitmap scaled = Bitmap.createScaledBitmap(b, Math.round(w * ratio), Math.round(h * ratio), true);
        if (scaled != b) b.recycle();
        return scaled;
    }

    /** Пишет JPEG через временный файл, чтобы обрыв записи не оставил битый фон. */
    static boolean writeJpeg(Bitmap bmp, File dest) {
        File tmp = new File(dest.getParentFile(), dest.getName() + ".tmp");
        try {
            FileOutputStream fos = new FileOutputStream(tmp);
            try {
                bmp.compress(Bitmap.CompressFormat.JPEG, 92, fos);
                fos.flush();
            } finally {
                fos.close();
            }
            if (dest.exists()) dest.delete();
            return tmp.renameTo(dest);
        } catch (Throwable t) {
            tmp.delete();
            return false;
        }
    }

    private interface StreamOpener {
        InputStream open() throws Exception;
    }

    public static boolean saveWallpaperFromUri(final Context context, final Uri uri, PluginContext margyt) {
        lastSaveError = null;
        if (context == null || uri == null) return false;
        StreamOpener opener = () -> context.getContentResolver().openInputStream(uri);
        byte[] head = readHead(opener);
        String mime = null;
        try {
            mime = context.getContentResolver().getType(uri);
        } catch (Throwable ignored) {}
        if (looksVideo(head) || (mime != null && mime.startsWith("video/"))) {
            return storeVideo(context, opener, margyt);
        }
        if (AnimatedWallpaper.looksAnimated(head)) {
            return storeAnimated(context, opener, margyt);
        }
        Bitmap bmp = decodeSampled(context, uri, MAX_BITMAP_DIM);
        if (bmp == null) lastSaveError = "Файл не похож на картинку";
        return bmp != null && storeCustom(context, bmp, margyt);
    }

    public static boolean saveWallpaperFromPath(Context context, final String path, PluginContext margyt) {
        lastSaveError = null;
        if (context == null || path == null || !new File(path).exists()) return false;
        StreamOpener opener = () -> new java.io.FileInputStream(path);
        byte[] head = readHead(opener);
        if (looksVideo(head)) {
            return storeVideo(context, opener, margyt);
        }
        if (AnimatedWallpaper.looksAnimated(head)) {
            return storeAnimated(context, opener, margyt);
        }
        Bitmap bmp = decodeSampled(path, MAX_BITMAP_DIM);
        if (bmp == null) lastSaveError = "Файл не похож на картинку";
        return bmp != null && storeCustom(context, bmp, margyt);
    }

    private static byte[] readHead(StreamOpener opener) {
        try {
            InputStream in = opener.open();
            if (in == null) return null;
            try {
                byte[] head = new byte[12];
                int n = 0;
                while (n < head.length) {
                    int r = in.read(head, n, head.length - n);
                    if (r < 0) break;
                    n += r;
                }
                return n == head.length ? head : null;
            } finally {
                in.close();
            }
        } catch (Throwable t) {
            return null;
        }
    }

    /** MP4/MOV/3GP (box "ftyp" по смещению 4) или WebM/MKV (EBML 1A 45 DF A3). */
    static boolean looksVideo(byte[] head) {
        if (head == null || head.length < 12) return false;
        if (head[4] == 'f' && head[5] == 't' && head[6] == 'y' && head[7] == 'p') {
            // HEIC/AVIF — тоже ftyp, но это картинки
            String brand = new String(head, 8, 4, java.nio.charset.StandardCharsets.US_ASCII);
            return !brand.startsWith("hei") && !brand.startsWith("hev") && !brand.startsWith("mif")
                && !brand.startsWith("avi") && !brand.startsWith("msf");
        }
        return (head[0] & 0xFF) == 0x1A && (head[1] & 0xFF) == 0x45 && (head[2] & 0xFF) == 0xDF && (head[3] & 0xFF) == 0xA3;
    }

    /** Копирует поток во временный файл рядом с dest; null — ошибка (причина в lastSaveError). */
    private static File copyLimited(StreamOpener opener, File dest, long limit, String tooBig) throws Exception {
        File tmp = new File(dest.getParentFile(), dest.getName() + ".tmp");
        InputStream in = opener.open();
        if (in == null) return null;
        boolean ok = false;
        FileOutputStream out = new FileOutputStream(tmp);
        try {
            byte[] buf = new byte[64 * 1024];
            long total = 0;
            int r;
            while ((r = in.read(buf)) > 0) {
                total += r;
                if (total > limit) {
                    lastSaveError = tooBig;
                    return null;
                }
                out.write(buf, 0, r);
            }
            ok = true;
            return tmp;
        } finally {
            out.close();
            in.close();
            if (!ok) tmp.delete();
        }
    }

    /**
     * Видео копируется как есть; проверяется, что в нём есть видеодорожка, и первый кадр
     * сохраняется JPEG-ом — для комментариев, заглушки до старта плеера и запасного варианта.
     */
    private static boolean storeVideo(Context context, StreamOpener opener, PluginContext margyt) {
        File dest = getVideoFile(context);
        File tmp = null;
        android.media.MediaMetadataRetriever mmr = new android.media.MediaMetadataRetriever();
        try {
            tmp = copyLimited(opener, dest, MAX_VIDEO_BYTES,
                "Видео больше " + (MAX_VIDEO_BYTES / 1024 / 1024) + " МБ — обрежь или сожми его");
            if (tmp == null) return false;

            mmr.setDataSource(tmp.getAbsolutePath());
            if (!"yes".equals(mmr.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_HAS_VIDEO))) {
                lastSaveError = "В файле нет видеодорожки";
                tmp.delete();
                return false;
            }
            Bitmap first = scaleDown(mmr.getFrameAtTime(0), MAX_BITMAP_DIM);
            if (first == null) {
                lastSaveError = "Не удалось прочитать видео";
                tmp.delete();
                return false;
            }
            if (dest.exists()) dest.delete();
            if (!tmp.renameTo(dest)) {
                tmp.delete();
                return false;
            }
            writeJpeg(first, getWallpaperFile(context));
            getAnimFile(context).delete();

            synchronized (RootWallpaperEngine.class) {
                invalidateBitmap();
                cachedWallpaperBitmap = first;
            }
            if (margyt != null) {
                margyt.prefs().edit()
                    .putString(KEY_WALLPAPER_PATH, getWallpaperFile(context).getAbsolutePath())
                    .putString(KEY_WALLPAPER_PRESET, PRESET_CUSTOM)
                    .putBoolean(KEY_WALLPAPER_VIDEO, true)
                    .putBoolean(KEY_WALLPAPER_ANIMATED, false)
                    .putBoolean(KEY_WALLPAPER_ENABLED, true)
                    .apply();
            }
            return true;
        } catch (Throwable t) {
            if (tmp != null) tmp.delete();
            if (lastSaveError == null) lastSaveError = "Этот формат видео телефон не читает";
            if (margyt != null) margyt.log("wallpaper: video save failed: " + t);
            return false;
        } finally {
            try {
                mmr.release();
            } catch (Throwable ignored) {}
        }
    }

    /**
     * Анимация копируется как есть (перекодировать GIF нечем), с ограничением размера.
     * Первый кадр дополнительно сохраняется JPEG-ом: он нужен комментариям и как запасной вариант.
     */
    private static boolean storeAnimated(Context context, StreamOpener opener, PluginContext margyt) {
        File dest = getAnimFile(context);
        File tmp = new File(dest.getParentFile(), dest.getName() + ".tmp");
        try {
            InputStream in = opener.open();
            if (in == null) return false;
            long total = 0;
            FileOutputStream out = new FileOutputStream(tmp);
            try {
                byte[] buf = new byte[64 * 1024];
                int r;
                while ((r = in.read(buf)) > 0) {
                    total += r;
                    if (total > MAX_ANIM_BYTES) {
                        lastSaveError = "GIF больше " + (MAX_ANIM_BYTES / 1024 / 1024) + " МБ — выбери файл поменьше";
                        return false;
                    }
                    out.write(buf, 0, r);
                }
            } finally {
                out.close();
                in.close();
                if (lastSaveError != null) tmp.delete();
            }

            Bitmap first = decodeSampled(tmp.getAbsolutePath(), MAX_BITMAP_DIM);
            if (first == null) {
                tmp.delete();
                lastSaveError = "Не удалось прочитать GIF";
                return false;
            }
            if (dest.exists()) dest.delete();
            if (!tmp.renameTo(dest)) {
                tmp.delete();
                return false;
            }
            writeJpeg(first, getWallpaperFile(context));
            getVideoFile(context).delete();

            synchronized (RootWallpaperEngine.class) {
                invalidateBitmap();
                cachedWallpaperBitmap = first;
            }
            if (margyt != null) {
                margyt.prefs().edit()
                    .putString(KEY_WALLPAPER_PATH, getWallpaperFile(context).getAbsolutePath())
                    .putString(KEY_WALLPAPER_PRESET, PRESET_CUSTOM)
                    .putBoolean(KEY_WALLPAPER_VIDEO, false)
                    .putBoolean(KEY_WALLPAPER_ANIMATED, true)
                    .putBoolean(KEY_WALLPAPER_ENABLED, true)
                    .apply();
            }
            return true;
        } catch (Throwable t) {
            tmp.delete();
            if (margyt != null) margyt.log("wallpaper: gif save failed: " + t);
            return false;
        }
    }

    private static synchronized boolean storeCustom(Context context, Bitmap bmp, PluginContext margyt) {
        File dest = getWallpaperFile(context);
        if (!writeJpeg(bmp, dest)) return false;

        invalidateBitmap();
        getAnimFile(context).delete();
        getVideoFile(context).delete();
        cachedWallpaperBitmap = bmp;
        cachedWallpaperPath = dest.getAbsolutePath();

        if (margyt != null) {
            margyt.prefs().edit()
                .putString(KEY_WALLPAPER_PATH, dest.getAbsolutePath())
                .putString(KEY_WALLPAPER_PRESET, PRESET_CUSTOM)
                .putBoolean(KEY_WALLPAPER_ANIMATED, false)
                .putBoolean(KEY_WALLPAPER_VIDEO, false)
                .putBoolean(KEY_WALLPAPER_ENABLED, true)
                .apply();
        }
        return true;
    }

    public static void setPreset(Context context, PluginContext margyt, String preset) {
        if (margyt != null) {
            margyt.prefs().edit()
                .putString(KEY_WALLPAPER_PRESET, preset)
                .putBoolean(KEY_WALLPAPER_ENABLED, true)
                .apply();
        }
        invalidateBitmap();
        getWallpaperBitmap(context, margyt);
    }

    public static Bitmap createCenterCropBitmap(Bitmap src, int targetW, int targetH) {
        if (src == null || targetW <= 0 || targetH <= 0) return null;
        try {
            Bitmap output = Bitmap.createBitmap(targetW, targetH, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(output);
            float scale = Math.max((float) targetW / src.getWidth(), (float) targetH / src.getHeight());
            float dx = (targetW - src.getWidth() * scale) * 0.5f;
            float dy = (targetH - src.getHeight() * scale) * 0.5f;
            android.graphics.Matrix m = new android.graphics.Matrix();
            m.setScale(scale, scale);
            m.postTranslate(dx, dy);
            Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
            canvas.drawBitmap(src, m, paint);
            canvas.drawColor(0x38000000);
            return output;
        } catch (Throwable t) {
            return null;
        }
    }

    // ───────────────────────────── Окно ─────────────────────────────

    /**
     * Прозрачный статус-бар и отрисовка в вырез камеры, чтобы фон начинался от y = 0.
     * Исходные значения запоминаются на decor и возвращаются в restoreWindow().
     */
    private static void applyEdgeToEdgeWindow(Activity activity, ViewGroup decor) {
        if (activity == null || decor == null) return;
        try {
            Window window = activity.getWindow();
            if (window == null) return;

            if (decor.getTag(TAG_KEY_ORIGINAL_STATUS_BAR_COLOR) == null) {
                decor.setTag(TAG_KEY_ORIGINAL_STATUS_BAR_COLOR, window.getStatusBarColor());
                decor.setTag(TAG_KEY_ORIGINAL_UI_FLAGS, decor.getSystemUiVisibility());
            }

            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            if (window.getStatusBarColor() != Color.TRANSPARENT) {
                window.setStatusBarColor(Color.TRANSPARENT);
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                WindowManager.LayoutParams lp = window.getAttributes();
                if (lp != null && lp.layoutInDisplayCutoutMode != WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES) {
                    lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
                    window.setAttributes(lp);
                }
            }
            if (Build.VERSION.SDK_INT >= 29) {
                window.setStatusBarContrastEnforced(false);
            }

            int flags = decor.getSystemUiVisibility();
            int wanted = (flags | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
                & ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR; // белые иконки поверх затемнённого фона
            if (wanted != flags) decor.setSystemUiVisibility(wanted);
        } catch (Throwable ignored) {}
    }

    private static void restoreWindow(Activity activity) {
        if (activity == null) return;
        try {
            Window window = activity.getWindow();
            if (window == null) return;
            View decor = window.getDecorView();
            Object color = decor.getTag(TAG_KEY_ORIGINAL_STATUS_BAR_COLOR);
            Object flags = decor.getTag(TAG_KEY_ORIGINAL_UI_FLAGS);
            if (color instanceof Integer) window.setStatusBarColor((Integer) color);
            if (flags instanceof Integer) decor.setSystemUiVisibility((Integer) flags);
            decor.setTag(TAG_KEY_ORIGINAL_STATUS_BAR_COLOR, null);
            decor.setTag(TAG_KEY_ORIGINAL_UI_FLAGS, null);
        } catch (Throwable ignored) {}
    }

    // ───────────────────────────── Применение ─────────────────────────────

    /** Немедленное обновление (смена настроек, onResume, onScreen). */
    public static void updateProfileWallpaper(Activity activity, PluginContext margyt) {
        updateProfileWallpaper(activity, margyt, true);
    }

    /**
     * @param force false — вызов из onPreDraw: не чаще раза в THROTTLE_MS,
     *              пропущенный вызов досылается отложенно, чтобы не потерять последнее состояние.
     */
    public static void updateProfileWallpaper(final Activity activity, final PluginContext margyt, boolean force) {
        if (activity == null || activity.isFinishing()) return;

        // Дешёвый выход: фон выключен и ничего не применено — дерево не обходим вовсе.
        if (!isEnabled(margyt) && !isWallpaperApplied) return;

        // Каждый кадр, до отрисовки: если TikTok перезаписал наш фон или подложку
        // (так он делает при обновлении счётчиков), возвращаем сразу — иначе мигало бы
        // до следующего прохода через 250 мс.
        if (isWallpaperApplied) reassertPlaced();

        if (!force) {
            long wait = THROTTLE_MS - (SystemClock.uptimeMillis() - lastRunAt);
            if (wait > 0) {
                if (!trailingScheduled) {
                    trailingScheduled = true;
                    final WeakReference<Activity> ref = new WeakReference<>(activity);
                    MAIN.postDelayed(() -> {
                        trailingScheduled = false;
                        Activity a = ref.get();
                        if (a != null && !a.isFinishing()) updateProfileWallpaper(a, margyt, false);
                    }, wait);
                }
                return;
            }
        }
        lastRunAt = SystemClock.uptimeMillis();

        try {
            doUpdate(activity, margyt, force);
        } catch (Throwable t) {
            if (margyt != null) margyt.log("wallpaper: " + t);
        }
    }

    private static long lastNoteAt = 0L;
    private static String lastNote = "";

    /** Строка в журнал мода о том, почему фон не встал; одна и та же — не чаще раза в 20 секунд. */
    private static void note(PluginContext margyt, String line) {
        long now = SystemClock.uptimeMillis();
        if (margyt == null || (line.equals(lastNote) && now - lastNoteAt < 20000L)) return;
        lastNote = line;
        lastNoteAt = now;
        margyt.log(line);
    }

    /**
     * Возврат в приложение: экран профиля достраивается не сразу, а статичный профиль может
     * не перерисовываться — проверяем ещё трижды сами, не дожидаясь кадров.
     */
    public static void onResumed(final Activity activity, final PluginContext margyt) {
        if (activity == null || !isEnabled(margyt)) return;
        if (video != null) video.resume();
        final WeakReference<Activity> ref = new WeakReference<>(activity);
        for (long delay : new long[] {350L, 1000L, 2000L}) {
            MAIN.postDelayed(() -> {
                Activity a = ref.get();
                if (a != null && !a.isFinishing()) updateProfileWallpaper(a, margyt, true);
            }, delay);
        }
    }

    /** Дёшево: только проверки ссылок, без обхода дерева. */
    private static void reassertPlaced() {
        try {
            ViewGroup master = appliedMaster != null ? appliedMaster.get() : null;
            if (master != null && lastWallDrawable != null && master.isAttachedToWindow()
                    && master.getBackground() != lastWallDrawable) {
                master.setBackground(lastWallDrawable);
            }
            if (!placedPanels.isEmpty()) {
                for (java.util.Map.Entry<View, Drawable> e : placedPanels.entrySet()) {
                    View v = e.getKey();
                    if (v == null || !v.isAttachedToWindow()) continue;
                    Drawable ours = e.getValue();
                    if (v.getBackground() != ours) {
                        v.setBackground(ours);
                    } else if (ours instanceof ColorDrawable && !(ours instanceof PanelDrawable)
                            && ((ColorDrawable) ours).getAlpha() != 0 && clearDrawables.containsKey(ours)) {
                        // setBackgroundColor() перекрасил наш прозрачный фон на месте — обратно
                        ((ColorDrawable) ours).setColor(Color.TRANSPARENT);
                    }
                }
            }
            // Обложку профиля TikTok догружает заново — снова убираем, пока она не нарисована
            if (!clearedImages.isEmpty()) {
                for (ImageView iv : clearedImages.keySet()) {
                    if (iv != null && iv.isAttachedToWindow() && iv.getDrawable() != null) iv.setImageDrawable(null);
                }
            }
        } catch (Throwable ignored) {}
    }

    private static void doUpdate(Activity activity, PluginContext margyt, boolean force) {
        ViewGroup decor = (ViewGroup) activity.getWindow().getDecorView();
        if (decor == null) return;

        Activity owner = appliedActivity != null ? appliedActivity.get() : null;
        boolean sameActivity = owner == activity;

        if (!isEnabled(margyt)) {
            if (isWallpaperApplied && (sameActivity || owner == null)) removeProfileWallpaper(decor);
            return;
        }

        boolean isProfile = isLocalUserProfileThrottled(decor, true);
        if (!isProfile) {
            // Другая activity (например, настройки) не трогает фон, применённый в MainActivity.
            if (!isWallpaperApplied || !sameActivity) return;
            // Гистерезис: один «промах» детектора не снимает фон — в том числе при возврате
            // в приложение, когда экран ещё строится. Раньше принудительная проверка снимала
            // сразу, а на статичном профиле следующего кадра для повторной могло и не быть.
            if (++profileMissCount >= 2) {
                removeProfileWallpaper(decor);
                note(margyt, "wallpaper: removed — own profile is not on screen");
            }
            return;
        }
        profileMissCount = 0;

        if (isWallpaperApplied && !sameActivity) {
            removeProfileWallpaper(null);
        }

        Bitmap bmp = getWallpaperBitmap(activity, margyt);
        if (bmp == null || bmp.isRecycled()) {
            if (isWallpaperApplied) removeProfileWallpaper(decor);
            return;
        }

        int screenW = decor.getWidth();
        int screenH = decor.getHeight();
        if (screenW <= 0 || screenH <= 0) {
            screenW = activity.getResources().getDisplayMetrics().widthPixels;
            screenH = activity.getResources().getDisplayMetrics().heightPixels;
        }

        UpperProfileTarget target = findUpperProfile(decor, screenW, screenH);
        if (target == null || target.masterContainer == null) {
            note(margyt, "wallpaper: profile is on screen, but its container was not found");
            return;
        }

        ViewGroup master = target.masterContainer;
        ViewGroup prevMaster = appliedMaster != null ? appliedMaster.get() : null;
        if (isWallpaperApplied && prevMaster != null && prevMaster != master) {
            removeProfileWallpaper(decor);
        }

        applyEdgeToEdgeWindow(activity, decor);

        int mode = getMode(margyt);
        int dim = getDim(margyt);
        boolean full = mode == MODE_FULL;
        int masterY = getScreenY(master);
        int headerBottom = target.tabBarFound ? target.totalHeaderH : -1;

        AnimatedWallpaper anim = getAnimatedSource(activity, margyt);

        // Видео играет в TextureView под окном; фон контейнера остаётся только затемнением.
        // Пока первый кадр не пошёл, рисуем вместо видео его первый кадр картинкой.
        Bitmap drawableBmp = bmp;
        if (wantsVideo(activity, margyt) && target.tabBarFound) {
            if (video == null || !video.isAttachedTo(decor)) {
                releaseVideo();
                final WeakReference<Activity> ref = new WeakReference<>(activity);
                note(margyt, "wallpaper: video starting");
                video = VideoWallpaper.attach(decor, getVideoFile(activity), new VideoWallpaper.Listener() {
                    @Override
                    public void onReady() {
                        note(margyt, "wallpaper: video playing");
                        Activity a = ref.get();
                        if (a != null && !a.isFinishing()) updateProfileWallpaper(a, margyt);
                    }

                    @Override
                    public void onError(String what) {
                        videoFailed = true;
                        if (margyt != null) margyt.log("wallpaper: video playback failed, showing first frame: " + what);
                        MAIN.post(() -> {
                            releaseVideo();
                            Activity a = ref.get();
                            if (a != null && !a.isFinishing()) updateProfileWallpaper(a, margyt);
                        });
                    }
                });
            }
            clearAncestors(master, decor, screenW);
            int[] mLoc = new int[2];
            int[] dLoc = new int[2];
            master.getLocationInWindow(mLoc);
            decor.getLocationInWindow(dLoc);
            int left = mLoc[0] - dLoc[0];
            int top = mLoc[1] - dLoc[1];
            android.graphics.Rect masterRect = new android.graphics.Rect(left, top, left + master.getWidth(), top + master.getHeight());
            video.setTarget(masterRect, full ? -1 : headerBottom - (masterY - top));
            if (video.isReady()) drawableBmp = null;
        } else if (video != null) {
            releaseVideo();
        }
        bmp = drawableBmp;
        if (bmp != null && anim == null) bmp = applyBlur(bmp, getBlur(margyt));

        Drawable current = master.getBackground();
        if (current instanceof SingleProfileWallpaperDrawable
                && ((SingleProfileWallpaperDrawable) current).matches(bmp, anim, full, dim)) {
            SingleProfileWallpaperDrawable wall = (SingleProfileWallpaperDrawable) current;
            wall.setHeaderHeight(headerBottom, masterY);
            lastWallDrawable = wall;
            if (anim != null) anim.start(wall);
        } else {
            Drawable original = current instanceof SingleProfileWallpaperDrawable
                ? ((SingleProfileWallpaperDrawable) current).fallback : current;
            rememberOriginalBackground(master, original);
            int initialH = headerBottom > 0 ? headerBottom : (int) (screenH * 0.44f);
            SingleProfileWallpaperDrawable wall =
                new SingleProfileWallpaperDrawable(bmp, anim, initialH, masterY, full, dim, original);
            master.setBackground(wall);
            lastWallDrawable = wall;
            if (anim != null) anim.start(wall);
        }

        // Пока таб-бар не найден (например, страница ещё строится), не трогаем детей:
        // без его координаты нельзя отличить шапку от сетки видео.
        if (target.tabBarFound) {
            View avatarView = ProfileLocator.findProfileAvatar(decor);
            // Статистика и строка вкладок видео получают свою подложку, а не прозрачность.
            // Строка вкладок лежит под фоном только в режиме «весь профиль».
            View stats = findStatsBlock(decor, screenW, screenH);
            View tabBar = cachedTabBar != null ? cachedTabBar.get() : null;
            if (tabBar == stats) tabBar = null;
            View[] panels = {stats, full ? tabBar : null};
            if (!full && tabBar != null && placedPanels.containsKey(tabBar)) restoreOne(tabBar);
            makeChildrenTransparent(master, avatarView, full ? -1 : headerBottom, headerBottom, screenW, panels, 0);
            stylePanels(panels, getPanels(margyt), master);

            if (target.topBarView != null && !isDescendant(target.topBarView, master)) {
                clearBackground(target.topBarView, screenW);
            }

            View banner = findSingleCoverBannerView(decor, screenW, screenH);
            if (banner != null && banner != master && getScreenY(banner) + banner.getHeight() <= headerBottom + dp(banner.getContext(), 8)) {
                clearBackground(banner, 0);
                if (banner instanceof ImageView) clearImage((ImageView) banner);
            }
        }

        ProfileTextEngine.applyProfileTextStyles(activity, master, margyt);

        appliedMaster = new WeakReference<>(master);
        appliedActivity = new WeakReference<>(activity);
        isWallpaperApplied = true;
    }

    private static void rememberOriginalBackground(View v, Drawable original) {
        if (v.getTag(TAG_KEY_ORIGINAL_BG) == null) {
            v.setTag(TAG_KEY_ORIGINAL_BG, original != null ? original : NO_ORIGINAL);
            touchedViews.add(new WeakReference<>(v));
        }
    }

    /** Видео лежит под окном — всё между ним и профилем должно быть сквозным. */
    private static void clearAncestors(View master, ViewGroup decor, int screenW) {
        ViewParent p = master.getParent();
        while (p instanceof ViewGroup && p != decor) {
            clearBackground((View) p, screenW);
            p = p.getParent();
        }
    }

    /**
     * Делает фон прозрачным, запоминая оригинал. Идемпотентно: уже прозрачный фон
     * не переустанавливается, иначе каждый проход из onPreDraw снова запрашивал бы перерисовку.
     */
    private static void clearBackground(View v, int screenW) {
        Drawable bg = v.getBackground();
        if (bg == null || bg instanceof SingleProfileWallpaperDrawable) return;
        if (bg instanceof ColorDrawable && ((ColorDrawable) bg).getAlpha() == 0) return;
        // Кнопки («Изменить профиль» и т.п.) оставляем с их подложкой.
        // screenW <= 0 — защиту кнопок не применять (ячейки внутри наших панелей:
        // «Подписки 12» кликабельны, но это не кнопки, их родной фон и мелькал поверх стекла).
        if (screenW > 0 && v.isClickable() && v.getWidth() < screenW * 0.9f) return;
        // Полоска под выбранной вкладкой и разделители — это не подложка
        if (v.getHeight() > 0 && v.getHeight() < dp(v.getContext(), 6)) return;

        rememberOriginalBackground(v, bg);
        // Новый ColorDrawable, а не setBackgroundColor(): тот перекрашивает
        // существующий ColorDrawable на месте и портит сохранённый оригинал.
        Drawable clear = new ColorDrawable(Color.TRANSPARENT);
        clearDrawables.put(clear, Boolean.TRUE);
        v.setBackground(clear);
        // TikTok возвращает свои подложки при обновлении экрана — reassertPlaced
        // снова снимет их до отрисовки, и родной фон не успеет мелькнуть.
        placedPanels.put(v, clear);
    }

    private static void clearImage(ImageView iv) {
        Drawable d = iv.getDrawable();
        if (d == null) return;
        if (iv.getTag(TAG_KEY_ORIGINAL_BANNER_DRAWABLE) == null) {
            iv.setTag(TAG_KEY_ORIGINAL_BANNER_DRAWABLE, d);
            touchedViews.add(new WeakReference<View>(iv));
        }
        iv.setImageDrawable(null);
        clearedImages.put(iv, Boolean.TRUE);
    }

    /**
     * @param regionBottom экранная Y, ниже которой ничего не трогаем (-1 — без ограничения, режим «весь профиль»)
     * @param headerBottom экранная Y таб-бара: картинки баннера чистим только выше неё
     */
    private static void makeChildrenTransparent(ViewGroup parent, View avatarView, int regionBottom,
                                                int headerBottom, int screenW, View[] panels, int depth) {
        if (parent == null || depth > 20) return;
        int[] loc = new int[2];
        int slack = dp(parent.getContext(), 6);
        for (int i = 0; i < parent.getChildCount(); i++) {
            View child = parent.getChildAt(i);
            if (child == null || child.getVisibility() != View.VISIBLE) continue;
            // Аватарку и всё внутри неё не трогаем
            if (avatarView != null && (child == avatarView || isDescendant(child, avatarView))) {
                continue;
            }
            // Панели статистики и вкладок оформляет stylePanels
            if (isPanelOrInside(child, panels)) continue;

            child.getLocationOnScreen(loc);
            if (regionBottom > 0 && loc[1] >= regionBottom - slack) continue;
            if (isBottomNavBar(child, loc[1], screenW)) continue;

            clearBackground(child, screenW);

            if (child instanceof ImageView && headerBottom > 0
                    && loc[1] + child.getHeight() <= headerBottom + slack
                    && child.getHeight() >= dp(child.getContext(), 50)
                    && child.getWidth() >= dp(child.getContext(), 150)) {
                clearImage((ImageView) child);
            }

            if (child instanceof ViewGroup) {
                makeChildrenTransparent((ViewGroup) child, avatarView, regionBottom, headerBottom, screenW, panels, depth + 1);
            }
        }
    }

    private static void restoreOne(View v) {
        placedPanels.remove(v);
        Object bg = v.getTag(TAG_KEY_ORIGINAL_BG);
        if (bg != null) {
            v.setBackground(bg instanceof Drawable ? (Drawable) bg : null);
            v.setTag(TAG_KEY_ORIGINAL_BG, null);
        }
    }

    private static boolean isPanelOrInside(View v, View[] panels) {
        for (View p : panels) {
            if (p != null && (v == p || isDescendant(v, p))) return true;
        }
        return false;
    }

    /** Подложка панели профиля; по классу и режиму видно, что она уже наша. */
    static final class PanelDrawable extends GradientDrawable {
        final int mode;

        PanelDrawable(int mode, int fill, int stroke, float radius, float strokeW) {
            this.mode = mode;
            setColor(fill);
            setCornerRadius(radius);
            if (stroke != 0) setStroke(Math.max(1, Math.round(strokeW)), stroke);
        }
    }

    /**
     * Стекло — полупрозрачная скруглённая подложка, сквозь которую виден фон;
     * «Как в TikTok» — сплошная подложка цвета темы; «Без панелей» — прозрачно.
     */
    private static void stylePanels(View[] panels, int mode, ViewGroup master) {
        for (View panel : panels) {
            if (panel == null) continue;
            if (panel instanceof ViewGroup) clearInside((ViewGroup) panel, 0);
            Drawable bg = panel.getBackground();
            if (bg instanceof PanelDrawable && ((PanelDrawable) bg).mode == mode) continue;

            Drawable original = bg instanceof PanelDrawable ? null : bg;
            rememberOriginalBackground(panel, original);
            Drawable d;
            if (mode == PANELS_NONE) {
                d = new ColorDrawable(Color.TRANSPARENT);
            } else {
                float density = panel.getResources().getDisplayMetrics().density;
                d = mode == PANELS_GLASS
                    ? new PanelDrawable(mode, 0x66000000, 0x33FFFFFF, 14 * density, density)
                    : new PanelDrawable(mode, themeColor(master, panel), 0, 0f, 0f);
            }
            placedPanels.put(panel, d);
            panel.setBackground(d);
        }
    }

    /** Подложки внутри панели — прозрачные, чтобы не перекрывали её фон. Тонкие полоски-индикаторы остаются. */
    private static void clearInside(ViewGroup parent, int depth) {
        if (depth > 6) return;
        for (int i = 0; i < parent.getChildCount(); i++) {
            View c = parent.getChildAt(i);
            if (c == null || c instanceof ImageView) continue;
            clearBackground(c, 0);
            if (c instanceof ViewGroup) clearInside((ViewGroup) c, depth + 1);
        }
    }

    /** Цвет фона темы TikTok: исходный фон контейнера профиля, а если его не было — по цвету текста. */
    private static int themeColor(ViewGroup master, View panel) {
        Object saved = master.getTag(TAG_KEY_ORIGINAL_BG);
        if (saved instanceof ColorDrawable) return ((ColorDrawable) saved).getColor() | 0xFF000000;
        Object own = panel.getTag(TAG_KEY_ORIGINAL_BG);
        if (own instanceof ColorDrawable && ((ColorDrawable) own).getAlpha() > 0) return ((ColorDrawable) own).getColor() | 0xFF000000;
        TextView text = firstTextView(panel, 0);
        if (text != null) {
            int c = text.getCurrentTextColor();
            double lum = (0.299 * Color.red(c) + 0.587 * Color.green(c) + 0.114 * Color.blue(c)) / 255.0;
            return lum < 0.5 ? 0xFFFFFFFF : 0xFF121212;
        }
        return 0xFF121212;
    }

    private static TextView firstTextView(View v, int depth) {
        if (v instanceof TextView) return (TextView) v;
        if (!(v instanceof ViewGroup) || depth > 6) return null;
        ViewGroup g = (ViewGroup) v;
        for (int i = 0; i < g.getChildCount(); i++) {
            TextView t = firstTextView(g.getChildAt(i), depth + 1);
            if (t != null) return t;
        }
        return null;
    }

    /** Блок статистики профиля для других движков (часы раздвигают его от себя). */
    public static View statsBlockFor(ViewGroup decor) {
        if (decor == null) return null;
        int screenW = decor.getResources().getDisplayMetrics().widthPixels;
        int screenH = decor.getResources().getDisplayMetrics().heightPixels;
        return findStatsBlock(decor, screenW, screenH);
    }

    /** Блок «подписки / подписчики / лайки»: невысокий предок, где есть хотя бы две подписи. */
    private static View findStatsBlock(ViewGroup decor, int screenW, int screenH) {
        View cached = cachedStatsBlock != null ? cachedStatsBlock.get() : null;
        if (cached != null && cached.isShown() && cached.getRootView() == decor) return cached;

        View label = findProfileStatsView(decor, screenH);
        if (label == null) return null;
        int maxH = dp(decor.getContext(), 130);
        View best = null;
        View cur = label;
        while (cur.getParent() instanceof ViewGroup) {
            ViewGroup p = (ViewGroup) cur.getParent();
            if (p == decor || p.getId() == android.R.id.content || p.getHeight() > maxH) break;
            if (p.getWidth() >= screenW * 0.55f && countStatLabels(p, 0) >= 2) best = p;
            cur = p;
        }
        cachedStatsBlock = best != null ? new WeakReference<>(best) : null;
        return best;
    }

    static int countStatLabels(View v, int depth) {
        if (v instanceof TextView) {
            CharSequence cs = ((TextView) v).getText();
            if (cs == null) return 0;
            String s = cs.toString().toLowerCase();
            return s.contains("подпис") || s.contains("лайк") || s.contains("follow") || s.contains("like") ? 1 : 0;
        }
        if (!(v instanceof ViewGroup) || depth > 6) return 0;
        int n = 0;
        ViewGroup g = (ViewGroup) v;
        for (int i = 0; i < g.getChildCount(); i++) n += countStatLabels(g.getChildAt(i), depth + 1);
        return n;
    }

    /** Нижняя панель вкладок TikTok: в режиме «весь профиль» её подложку не убираем. */
    private static boolean isBottomNavBar(View v, int screenY, int screenW) {
        int screenH = v.getResources().getDisplayMetrics().heightPixels;
        return screenY >= screenH * 0.85f
            && v.getHeight() <= dp(v.getContext(), 100)
            && v.getWidth() >= screenW * 0.9f;
    }

    private static boolean isDescendant(View child, View root) {
        if (child == null || root == null) return false;
        ViewParent p = child.getParent();
        while (p instanceof View) {
            if (p == root) return true;
            p = p.getParent();
        }
        return false;
    }

    public static class UpperProfileTarget {
        public ViewGroup masterContainer = null;
        public View topBarView = null;
        public ViewGroup profileCardView = null;
        public int totalHeaderH = 0;
        public boolean tabBarFound = false;
    }

    public static void removeProfileWallpaper(ViewGroup decor) {
        removeProfileWallpaper(decor, null);
    }

    public static void removeProfileWallpaper(ViewGroup decor, ViewGroup profileHeader) {
        try {
            isWallpaperApplied = false;
            profileMissCount = 0;
            stopAnimation();
            releaseVideo();
            lastWallDrawable = null;
            placedPanels.clear();
            clearedImages.clear();

            for (WeakReference<View> ref : touchedViews) {
                View v = ref.get();
                if (v == null) continue;
                Object bg = v.getTag(TAG_KEY_ORIGINAL_BG);
                if (bg != null) {
                    v.setBackground(bg instanceof Drawable ? (Drawable) bg : null);
                    v.setTag(TAG_KEY_ORIGINAL_BG, null);
                }
                Object img = v.getTag(TAG_KEY_ORIGINAL_BANNER_DRAWABLE);
                if (img instanceof Drawable && v instanceof ImageView) {
                    ImageView iv = (ImageView) v;
                    // Если TikTok уже сам подставил новую картинку — её не перетираем
                    if (iv.getDrawable() == null) iv.setImageDrawable((Drawable) img);
                }
                v.setTag(TAG_KEY_ORIGINAL_BANNER_DRAWABLE, null);
            }
            touchedViews.clear();

            ViewGroup master = appliedMaster != null ? appliedMaster.get() : null;
            if (master == null) master = profileHeader;
            if (master != null) ProfileTextEngine.resetProfileTextStyles(master);
            if (decor != null) ProfileTextEngine.resetProfileTextStyles(decor);

            Activity owner = appliedActivity != null ? appliedActivity.get() : null;
            restoreWindow(owner);

            appliedMaster = null;
            appliedActivity = null;

            if (decor != null) {
                View wv = decor.findViewWithTag(TAG_PROFILE_WALLPAPER);
                if (wv instanceof ImageView && wv.getVisibility() != View.GONE) {
                    wv.setVisibility(View.GONE);
                    ((ImageView) wv).setImageDrawable(null);
                }
            }
        } catch (Throwable ignored) {}
    }

    /** Убирает мёртвые ссылки, чтобы список не рос бесконечно при пересоздании экранов. */
    private static void pruneTouched() {
        Iterator<WeakReference<View>> it = touchedViews.iterator();
        while (it.hasNext()) {
            if (it.next().get() == null) it.remove();
        }
    }

    // ───────────────────────────── Поиск элементов профиля ─────────────────────────────

    public static UpperProfileTarget findUpperProfile(ViewGroup decor, int screenW, int screenH) {
        if (decor == null) return null;
        pruneTouched();
        UpperProfileTarget target = new UpperProfileTarget();

        View tabBar = findTabBarCached(decor, screenW, screenH);
        target.tabBarFound = tabBar != null;
        target.totalHeaderH = tabBar != null ? getScreenY(tabBar) : (int) (screenH * 0.44f);
        int tabBarTop = tabBar != null ? target.totalHeaderH : -1;

        // 1. Карточка профиля (ник, кнопки, статистика)
        View marker = findProfileMarkerView(decor);
        if (marker == null) marker = findProfileStatsView(decor, screenH);

        ViewGroup card = null;
        if (marker != null) {
            View curr = marker;
            while (curr.getParent() instanceof ViewGroup) {
                ViewGroup p = (ViewGroup) curr.getParent();
                if (p == decor || p.getId() == android.R.id.content) break;
                int h = p.getHeight();
                int w = p.getWidth();
                int y = getScreenY(p);
                if (w >= screenW * 0.65f && h >= dp(p.getContext(), 100) && h <= screenH * 0.62f) {
                    card = p;
                    if (tabBarTop > 0 && Math.abs((y + h) - tabBarTop) <= dp(p.getContext(), 65)) break;
                }
                curr = p;
            }
        }
        target.profileCardView = card;

        // 2. Верхний тулбар
        int cardTop = card != null ? getScreenY(card) : (int) (screenH * 0.16f);
        target.topBarView = findTopToolbar(decor, screenW, screenH, cardTop);

        // 3. Общий контейнер страницы профиля
        ViewGroup master = null;
        View anchor = card != null ? card : marker;
        if (target.topBarView != null && anchor != null) {
            ViewGroup common = findCommonAncestor(target.topBarView, anchor);
            if (common != null) {
                if (common == decor || common.getId() == android.R.id.content) {
                    master = childOfContent(anchor, decor);
                } else {
                    master = common;
                }
            }
        }

        if (master == null) {
            View curr = anchor != null ? anchor : tabBar;
            if (curr != null) {
                while (curr.getParent() instanceof ViewGroup) {
                    ViewGroup p = (ViewGroup) curr.getParent();
                    if (p == decor || p.getId() == android.R.id.content) {
                        if (curr instanceof ViewGroup) master = (ViewGroup) curr;
                        break;
                    }
                    if (getScreenY(p) <= dp(p.getContext(), 56) && p.getWidth() >= screenW * 0.75f) {
                        master = p;
                    }
                    curr = p;
                }
            }
        }

        // Поднимаемся к самому внешнему контейнеру внутри content, начинающемуся у верха экрана
        if (master != null) {
            ViewParent p = master.getParent();
            while (p instanceof ViewGroup) {
                ViewGroup vg = (ViewGroup) p;
                if (vg == decor || vg.getId() == android.R.id.content) break;
                if (getScreenY(vg) <= dp(vg.getContext(), 56) && vg.getWidth() >= screenW * 0.75f) {
                    if (target.topBarView == null || target.topBarView == vg || isDescendant(target.topBarView, vg)) {
                        master = vg;
                    }
                }
                p = vg.getParent();
            }
        }

        target.masterContainer = master;
        return target;
    }

    private static ViewGroup childOfContent(View from, ViewGroup decor) {
        View curr = from;
        while (curr.getParent() instanceof ViewGroup) {
            ViewGroup p = (ViewGroup) curr.getParent();
            if (p == decor || p.getId() == android.R.id.content) {
                return curr instanceof ViewGroup ? (ViewGroup) curr : null;
            }
            curr = p;
        }
        return null;
    }

    /** Экранная Y строки вкладок видео в профиле или -1, если её не видно. */
    public static int videoTabBarTop(ViewGroup decor) {
        if (decor == null) return -1;
        int screenW = decor.getResources().getDisplayMetrics().widthPixels;
        int screenH = decor.getResources().getDisplayMetrics().heightPixels;
        View bar = findTabBarCached(decor, screenW, screenH);
        return bar != null ? getScreenY(bar) : -1;
    }

    /**
     * Таб-бар видео ищется только в «спокойной» зоне экрана (20–55%), но при прокрутке он
     * прилипает к верху и выходит из неё. Поэтому найденный однажды таб-бар запоминаем
     * и дальше берём его живую координату, пока он на экране.
     */
    private static View findTabBarCached(ViewGroup decor, int screenW, int screenH) {
        View cached = cachedTabBar != null ? cachedTabBar.get() : null;
        if (cached != null && cached.isShown() && cached.isAttachedToWindow()
                && cached.getRootView() == decor && getScreenY(cached) < screenH * 0.6f) {
            return cached;
        }
        View found = findVideoTabBar(decor, screenW, screenH, 0);
        cachedTabBar = found != null ? new WeakReference<>(found) : null;
        return found;
    }

    public static View findSingleCoverBannerView(ViewGroup decor, int screenW, int screenH) {
        if (decor == null) return null;
        List<View> candidates = new ArrayList<>();
        collectCoverCandidates(decor, candidates, screenW, screenH, 0);

        View best = null;
        int maxArea = 0;
        for (View v : candidates) {
            int area = v.getWidth() * v.getHeight();
            if (area > maxArea) {
                maxArea = area;
                best = v;
            }
        }
        return best;
    }

    private static void collectCoverCandidates(View root, List<View> out, int screenW, int screenH, int depth) {
        if (root == null || depth > 60 || !root.isShown()) return;
        int[] loc = new int[2];
        root.getLocationOnScreen(loc);
        int w = root.getWidth();
        int h = root.getHeight();

        // Обложка профиля: у верха экрана, почти во всю ширину, высота от 60dp до 42% экрана
        if (loc[1] <= dp(root.getContext(), 35) && w >= screenW * 0.75f &&
            h >= dp(root.getContext(), 60) && h <= screenH * 0.42f) {
            if (!isToolbarOrHeaderCard(root)) out.add(root);
        }

        if (root instanceof ViewGroup) {
            ViewGroup vg = (ViewGroup) root;
            for (int i = 0; i < vg.getChildCount(); i++) {
                collectCoverCandidates(vg.getChildAt(i), out, screenW, screenH, depth + 1);
            }
        }
    }

    private static boolean isToolbarOrHeaderCard(View v) {
        if (v == null) return false;
        if (findProfileMarkerView(v) != null) return true;
        if (v instanceof ViewGroup) {
            ViewGroup vg = (ViewGroup) v;
            for (int i = 0; i < vg.getChildCount(); i++) {
                View ch = vg.getChildAt(i);
                if (ch instanceof TextView) {
                    CharSequence cs = ((TextView) ch).getText();
                    if (cs != null) {
                        String s = cs.toString().trim();
                        if (s.contains("☰") || s.contains("Подпис") || s.contains("Лайк")) return true;
                    }
                }
            }
        }
        return false;
    }

    public static ViewGroup findProfileHeaderContainer(ViewGroup decor) {
        if (decor == null) return null;
        int screenW = decor.getWidth();
        int screenH = decor.getHeight();
        if (screenW <= 0 || screenH <= 0) {
            screenW = decor.getResources().getDisplayMetrics().widthPixels;
            screenH = decor.getResources().getDisplayMetrics().heightPixels;
        }
        UpperProfileTarget target = findUpperProfile(decor, screenW, screenH);
        if (target != null) {
            if (target.masterContainer != null) return target.masterContainer;
            if (target.profileCardView != null) return target.profileCardView;
        }
        return null;
    }

    public static View findTopToolbar(ViewGroup root, int screenW, int screenH, int cardTop) {
        if (root == null || !root.isShown()) return null;
        List<View> candidates = new ArrayList<>();
        collectTopBarCandidates(root, candidates, screenW, screenH, cardTop, 0);

        View best = null;
        int maxScore = -1;
        for (View v : candidates) {
            int score = v.getWidth();
            if (v instanceof ViewGroup) score += ((ViewGroup) v).getChildCount() * 50;
            if (score > maxScore) {
                maxScore = score;
                best = v;
            }
        }
        return best;
    }

    private static void collectTopBarCandidates(View v, List<View> out, int screenW, int screenH, int cardTop, int depth) {
        if (v == null || depth > 25 || !v.isShown()) return;
        int[] loc = new int[2];
        v.getLocationOnScreen(loc);
        int w = v.getWidth();
        int h = v.getHeight();

        if (loc[1] <= dp(v.getContext(), 56) &&
            w >= screenW * 0.60f &&
            h >= dp(v.getContext(), 36) && h <= dp(v.getContext(), 120) &&
            (loc[1] + h <= cardTop + dp(v.getContext(), 30))) {
            out.add(v);
        }

        if (v instanceof ViewGroup) {
            ViewGroup vg = (ViewGroup) v;
            for (int i = 0; i < vg.getChildCount(); i++) {
                collectTopBarCandidates(vg.getChildAt(i), out, screenW, screenH, cardTop, depth + 1);
            }
        }
    }

    public static View findTopToolbarView(ViewGroup root, int screenW, int screenH) {
        return findTopToolbar(root, screenW, screenH, (int) (screenH * 0.20f));
    }

    private static View findProfileStatsView(View v, int screenH) {
        if (v == null || !v.isShown()) return null;
        if (v instanceof TextView) {
            CharSequence cs = ((TextView) v).getText();
            if (cs != null) {
                String s = cs.toString().trim().toLowerCase();
                int[] loc = new int[2];
                v.getLocationOnScreen(loc);
                if (loc[1] <= screenH * 0.58f) {
                    if (s.contains("подпис") || s.contains("лайк") || s.contains("публикац") ||
                        s.contains("following") || s.contains("followers") || s.contains("likes")) {
                        return v;
                    }
                }
            }
        }
        if (v instanceof ViewGroup) {
            ViewGroup vg = (ViewGroup) v;
            for (int i = 0; i < vg.getChildCount(); i++) {
                View res = findProfileStatsView(vg.getChildAt(i), screenH);
                if (res != null) return res;
            }
        }
        return null;
    }

    static ViewGroup findCommonAncestor(View a, View b) {
        if (a == null || b == null) return null;
        List<ViewGroup> parentsA = new ArrayList<>();
        if (a instanceof ViewGroup) parentsA.add((ViewGroup) a);
        ViewParent pa = a.getParent();
        while (pa instanceof ViewGroup) {
            parentsA.add((ViewGroup) pa);
            pa = pa.getParent();
        }
        if (b instanceof ViewGroup && parentsA.contains(b)) return (ViewGroup) b;
        ViewParent pb = b.getParent();
        while (pb instanceof ViewGroup) {
            if (parentsA.contains(pb)) return (ViewGroup) pb;
            pb = pb.getParent();
        }
        return null;
    }

    public static View findVideoTabBar(View root, int screenW, int screenH, int depth) {
        if (root == null || depth > 20 || !root.isShown()) return null;
        if (root instanceof ViewGroup) {
            ViewGroup vg = (ViewGroup) root;
            int[] loc = new int[2];
            vg.getLocationOnScreen(loc);
            int h = vg.getHeight();
            int w = vg.getWidth();

            // Таб-бар видео в профиле: высота 32–68dp, Y между 20% и 55% экрана, ширина >= 65%
            if (loc[1] >= screenH * 0.20f && loc[1] <= screenH * 0.55f &&
                w >= screenW * 0.65f && h >= dp(vg.getContext(), 32) && h <= dp(vg.getContext(), 68) &&
                vg.getChildCount() >= 2 && countStatLabels(vg, 0) < 2) {
                // Блок «подписки / подписчики / лайки» той же формы; если его принять за
                // вкладки, высота шапки прыгает между ним и настоящей строкой вкладок.
                return vg;
            }

            for (int i = 0; i < vg.getChildCount(); i++) {
                View res = findVideoTabBar(vg.getChildAt(i), screenW, screenH, depth + 1);
                if (res != null) return res;
            }
        }
        return null;
    }

    static int getScreenY(View v) {
        int[] loc = new int[2];
        v.getLocationOnScreen(loc);
        return loc[1];
    }

    private static View findProfileMarkerView(View v) {
        if (v == null || !v.isShown()) return null;
        if (v instanceof TextView) {
            CharSequence cs = ((TextView) v).getText();
            if (cs != null) {
                String s = cs.toString().trim().toLowerCase();
                if (s.contains("изменить профиль") || s.contains("редактировать профиль") ||
                    s.equals("редактировать") || s.contains("edit profile") ||
                    s.contains("поделиться профилем") || s.contains("добавить описание") ||
                    s.contains("добавить биографию")) {
                    return v;
                }
            }
        }
        if (v instanceof ViewGroup) {
            ViewGroup vg = (ViewGroup) v;
            for (int i = 0; i < vg.getChildCount(); i++) {
                View res = findProfileMarkerView(vg.getChildAt(i));
                if (res != null) return res;
            }
        }
        return null;
    }

    public static boolean isLocalUserProfile(ViewGroup decor) {
        if (decor == null) return false;
        return ProfileLocator.isLocalUserProfile(decor);
    }

    /**
     * То же, что isLocalUserProfile, но с кэшем на THROTTLE_MS: детектор обходит всё дерево,
     * а спрашивают его несколько движков на каждом кадре.
     */
    public static boolean isLocalUserProfileThrottled(ViewGroup decor) {
        return isLocalUserProfileThrottled(decor, false);
    }

    private static boolean isLocalUserProfileThrottled(ViewGroup decor, boolean refresh) {
        if (decor == null) return false;
        long now = SystemClock.uptimeMillis();
        ViewGroup last = lastProfileDecor != null ? lastProfileDecor.get() : null;
        if (!refresh && last == decor && now - lastProfileCheckAt < THROTTLE_MS) {
            return lastProfileResult;
        }
        lastProfileResult = isLocalUserProfile(decor);
        lastProfileCheckAt = now;
        lastProfileDecor = new WeakReference<>(decor);
        return lastProfileResult;
    }

    // ───────────────────────────── Drawable ─────────────────────────────

    /**
     * Фон профиля.
     * full = false: рисуется от верха контейнера до таб-бара; масштаб берётся по самой высокой
     * замеченной шапке, а при её схлопывании картинка уезжает вверх вместе с контентом
     * (а не перемасштабируется на каждом кадре). Ниже шапки рисуется исходный фон контейнера.
     * full = true: center-crop на весь контейнер, неподвижно.
     */
    public static class SingleProfileWallpaperDrawable extends Drawable implements Drawable.Callback {
        private final Bitmap bitmap;
        private final AnimatedWallpaper anim;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        private final Paint dimPaint = new Paint();
        private final android.graphics.BitmapShader shader;
        private final android.graphics.Matrix matrix = new android.graphics.Matrix();
        private final boolean full;
        private final int dim;
        final Drawable fallback;
        private int headerBottom;
        private int masterScreenY;
        private int maxLocalHeaderH = 0;
        /** Зафиксированная при первом layout высота шапки: overscroll её не растягивает — фон статичен. */
        private int baseHeaderH = 0;

        public SingleProfileWallpaperDrawable(Bitmap bitmap, int headerBottom, int masterScreenY,
                                              boolean full, int dim, Drawable fallback) {
            this(bitmap, null, headerBottom, masterScreenY, full, dim, fallback);
        }

        SingleProfileWallpaperDrawable(Bitmap bitmap, AnimatedWallpaper anim, int headerBottom, int masterScreenY,
                                       boolean full, int dim, Drawable fallback) {
            this.bitmap = bitmap;
            this.anim = anim;
            this.headerBottom = headerBottom;
            this.masterScreenY = masterScreenY;
            this.full = full;
            this.dim = dim;
            this.fallback = fallback;
            this.shader = bitmap != null
                ? new android.graphics.BitmapShader(bitmap, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP) : null;
            this.paint.setShader(shader);
            this.dimPaint.setColor(Color.argb(dim * 255 / 100, 0, 0, 0));
        }

        /** Старый конструктор: шапка, затемнение 25%. */
        public SingleProfileWallpaperDrawable(Bitmap bitmap, int initialHeaderH, int screenW, int masterScreenY) {
            this(bitmap, initialHeaderH, masterScreenY, false, DEFAULT_DIM, null);
        }

        boolean matches(Bitmap bmp, AnimatedWallpaper anim, boolean full, int dim) {
            return bitmap == bmp && this.anim == anim && this.full == full && this.dim == dim;
        }

        public void setHeaderHeight(int newHeaderBottom, int newMasterScreenY) {
            boolean changed = false;
            if (newHeaderBottom > 0 && newHeaderBottom != headerBottom) {
                headerBottom = newHeaderBottom;
                changed = true;
            }
            if (newMasterScreenY != masterScreenY) {
                masterScreenY = newMasterScreenY;
                changed = true;
            }
            if (changed && !full) {
                updateMatrix();
                invalidateSelf();
            }
        }

        private int localHeaderH() {
            return Math.max(0, headerBottom - masterScreenY);
        }

        private void updateMatrix() {
            android.graphics.Rect b = getBounds();
            if (anim == null && bitmap == null) return;
            float bw = anim != null ? anim.width() : bitmap.getWidth();
            float bh = anim != null ? anim.height() : bitmap.getHeight();
            if (bw <= 0 || bh <= 0 || b.width() <= 0) return;

            float scale;
            float dx;
            float dy;
            if (full) {
                float th = b.height() > 0 ? b.height() : bh;
                scale = Math.max(b.width() / bw, th / bh);
                dx = (b.width() - bw * scale) * 0.5f;
                dy = (th - bh * scale) * 0.5f;
            } else {
                // Статичный фон шапки: масштаб и позиция НЕ зависят от прокрутки и оттягивания.
                // Высоту-референс фиксируем один раз при первом layout; overscroll (растяжение
                // шапки) её больше не растягивает, поэтому картинка не «перестраивается».
                int local = localHeaderH();
                if (local > 0 && baseHeaderH == 0) baseHeaderH = local;
                float th = baseHeaderH > 0 ? baseHeaderH : (local > 0 ? local : bh);
                scale = Math.max(b.width() / bw, th / bh);
                dx = (b.width() - bw * scale) * 0.5f;
                dy = (th - bh * scale) * 0.35f;
                // Без параллакса: картинка стоит на месте, при прокрутке/оттягивании
                // меняется только область клипа в draw(), а не сама картинка.
            }
            matrix.setScale(scale, scale);
            matrix.postTranslate(b.left + dx, b.top + dy);
            shader.setLocalMatrix(matrix);
        }

        @Override
        protected void onBoundsChange(android.graphics.Rect bounds) {
            super.onBoundsChange(bounds);
            if (fallback != null) fallback.setBounds(bounds);
            updateMatrix();
        }

        @Override
        public void draw(Canvas canvas) {
            android.graphics.Rect b = getBounds();
            int bottom = b.bottom;
            if (!full) {
                int local = localHeaderH();
                if (local > 0) bottom = Math.min(b.bottom, b.top + local);
                if (fallback != null && bottom < b.bottom) {
                    canvas.save();
                    canvas.clipRect(b.left, bottom, b.right, b.bottom);
                    fallback.draw(canvas);
                    canvas.restore();
                }
            }
            if (bottom <= b.top) return;
            if (anim != null) {
                canvas.save();
                canvas.clipRect(b.left, b.top, b.right, bottom);
                canvas.concat(matrix);
                anim.draw(canvas);
                canvas.restore();
            } else if (bitmap != null) {
                canvas.drawRect(b.left, b.top, b.right, bottom, paint);
            }
            if (dim > 0) canvas.drawRect(b.left, b.top, b.right, bottom, dimPaint);
        }

        // Кадры анимации приходят сюда и пробрасываются во View, на котором висит фон
        @Override
        public void invalidateDrawable(Drawable who) {
            invalidateSelf();
        }

        @Override
        public void scheduleDrawable(Drawable who, Runnable what, long when) {
            scheduleSelf(what, when);
        }

        @Override
        public void unscheduleDrawable(Drawable who, Runnable what) {
            unscheduleSelf(what);
        }

        @Override
        public void setAlpha(int alpha) {
            paint.setAlpha(alpha);
        }

        @Override
        public void setColorFilter(android.graphics.ColorFilter colorFilter) {
            paint.setColorFilter(colorFilter);
        }

        @Override
        public int getOpacity() {
            return android.graphics.PixelFormat.TRANSLUCENT;
        }
    }

    public static class CenterCropWallpaperDrawable extends Drawable {
        private final Bitmap bitmap;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        private final android.graphics.BitmapShader shader;
        private final android.graphics.Matrix matrix = new android.graphics.Matrix();

        public CenterCropWallpaperDrawable(Bitmap bitmap) {
            this.bitmap = bitmap;
            this.shader = new android.graphics.BitmapShader(bitmap, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
            this.paint.setShader(shader);
        }

        @Override
        protected void onBoundsChange(android.graphics.Rect bounds) {
            super.onBoundsChange(bounds);
            if (bounds.width() <= 0 || bounds.height() <= 0 || bitmap.getWidth() <= 0 || bitmap.getHeight() <= 0) return;
            float scale = Math.max((float) bounds.width() / bitmap.getWidth(), (float) bounds.height() / bitmap.getHeight());
            float dx = (bounds.width() - bitmap.getWidth() * scale) * 0.5f;
            float dy = (bounds.height() - bitmap.getHeight() * scale) * 0.5f;
            matrix.setScale(scale, scale);
            matrix.postTranslate(bounds.left + dx, bounds.top + dy);
            shader.setLocalMatrix(matrix);
        }

        @Override
        public void draw(Canvas canvas) {
            canvas.drawRect(getBounds(), paint);
            canvas.drawColor(0x55000000);
        }

        @Override
        public void setAlpha(int alpha) {
            paint.setAlpha(alpha);
        }

        @Override
        public void setColorFilter(android.graphics.ColorFilter colorFilter) {
            paint.setColorFilter(colorFilter);
        }

        @Override
        public int getOpacity() {
            return android.graphics.PixelFormat.TRANSLUCENT;
        }
    }

    // ───────────────────────────── Выбор картинки ─────────────────────────────

    public static void openWallpaperGalleryPicker(Activity activity, PluginContext margyt, final Runnable onDone) {
        openWallpaperGalleryPicker(activity, margyt, TARGET_PROFILE, onDone);
    }

    public static void openWallpaperGalleryPicker(Activity activity, PluginContext margyt, int target, final Runnable onDone) {
        if (activity == null || activity.isFinishing()) return;
        try {
            WallpaperPickerFragment frag = new WallpaperPickerFragment();
            frag.init(margyt, target, onDone);
            activity.getFragmentManager()
                .beginTransaction()
                .add(frag, "astra_wallpaper_picker")
                .commitAllowingStateLoss();
        } catch (Throwable t) {
            Toast.makeText(activity, "Не удалось открыть выбор фото: " + t.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    public static class WallpaperPickerFragment extends android.app.Fragment {
        private static final int REQ_WALL = 0x574C;
        private PluginContext margyt;
        private Runnable onDone;
        private int target = TARGET_PROFILE;
        private boolean launched = false;

        public void init(PluginContext margyt, Runnable onDone) {
            init(margyt, TARGET_PROFILE, onDone);
        }

        public void init(PluginContext margyt, int target, Runnable onDone) {
            this.margyt = margyt;
            this.target = target;
            this.onDone = onDone;
        }

        @Override
        public void onActivityCreated(android.os.Bundle savedInstanceState) {
            super.onActivityCreated(savedInstanceState);
            if (launched) return;
            launched = true;
            String title = target == TARGET_COMMENTS ? "Выберите фон комментариев" : "Фото, GIF или видео для фона";
            try {
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                if (target == TARGET_COMMENTS) {
                    intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[] {"image/*"});
                } else {
                    // Галереи по "image/*" часто прячут GIF; список типов открывает
                    // выбор файлов, где видны и GIF, и видео.
                    intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[] {"image/*", "video/*"});
                }
                startActivityForResult(Intent.createChooser(intent, title), REQ_WALL);
            } catch (Throwable t) {
                try {
                    Intent intent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    startActivityForResult(intent, REQ_WALL);
                } catch (Throwable t2) {
                    Toast.makeText(getActivity(), "Не удалось открыть выбор фото: " + t2.getMessage(), Toast.LENGTH_SHORT).show();
                    removeSelf();
                }
            }
        }

        @Override
        public void onActivityResult(int requestCode, int resultCode, Intent data) {
            super.onActivityResult(requestCode, resultCode, data);
            if (requestCode == REQ_WALL && resultCode == Activity.RESULT_OK && data != null && data.getData() != null) {
                Activity act = getActivity();
                if (act != null && !act.isFinishing()) {
                    boolean ok = target == TARGET_COMMENTS
                        ? CommentWallpaperEngine.saveFromUri(act, data.getData(), margyt)
                        : saveWallpaperFromUri(act, data.getData(), margyt);
                    if (ok) {
                        Toast.makeText(act, target == TARGET_COMMENTS ? "Фон комментариев сохранён" : "Фон профиля сохранён", Toast.LENGTH_SHORT).show();
                        if (onDone != null) onDone.run();
                    } else {
                        Toast.makeText(act, lastSaveError != null ? lastSaveError : "Не удалось сохранить изображение", Toast.LENGTH_LONG).show();
                    }
                }
            }
            removeSelf();
        }

        private void removeSelf() {
            try {
                if (getFragmentManager() != null) {
                    getFragmentManager().beginTransaction().remove(this).commitAllowingStateLoss();
                }
            } catch (Throwable ignored) {}
        }
    }

    public static void showStorageImagePicker(final Activity activity, final OnPathSelected callback) {
        if (activity == null || activity.isFinishing()) return;

        final Dialog dialog = new Dialog(activity);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            dialog.getWindow().setDimAmount(0.65f);
        }

        int dp16 = dp(activity, 16);
        int dp20 = dp(activity, 20);
        int dp12 = dp(activity, 12);
        int dp8 = dp(activity, 8);

        LinearLayout box = new LinearLayout(activity);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp20, dp20, dp20, dp16);

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xFF161823);
        bg.setCornerRadius(dp(activity, 20));
        box.setBackground(bg);

        TextView t = new TextView(activity);
        t.setText("Файлы изображений в памяти");
        t.setTextColor(0xFFFFFFFF);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17);
        t.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        box.addView(t);

        TextView sub = new TextView(activity);
        sub.setText("Выберите найденный файл обоев (/sdcard/...):");
        sub.setTextColor(0x99FFFFFF);
        sub.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        sub.setPadding(0, dp(activity, 4), 0, dp12);
        box.addView(sub);

        ScrollView scroll = new ScrollView(activity);
        LinearLayout list = new LinearLayout(activity);
        list.setOrientation(LinearLayout.VERTICAL);

        final List<File> images = new ArrayList<>();
        findImagesInDir(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), images, 0);
        findImagesInDir(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), images, 0);
        findImagesInDir(new File(Environment.getExternalStorageDirectory(), "DCIM/Camera"), images, 0);

        if (images.isEmpty()) {
            TextView none = new TextView(activity);
            none.setText("Изображения в стандартных папках не найдены.\nВоспользуйтесь пунктом «Выбрать из галереи».");
            none.setTextColor(0x88FFFFFF);
            none.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
            none.setPadding(0, dp16, 0, dp16);
            list.addView(none);
        } else {
            for (int i = 0; i < Math.min(25, images.size()); i++) {
                final File f = images.get(i);
                TextView row = new TextView(activity);
                row.setText(f.getName() + " (" + (f.length() / 1024) + " KB)");
                row.setTextColor(0xFFFFFFFF);
                row.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
                row.setPadding(dp12, dp12, dp12, dp12);

                GradientDrawable rbg = new GradientDrawable();
                rbg.setColor(0x0AFFFFFF);
                rbg.setCornerRadius(dp(activity, 10));
                row.setBackground(rbg);

                row.setOnClickListener(v -> {
                    dialog.dismiss();
                    if (callback != null) callback.onSelected(f.getAbsolutePath());
                });

                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                if (i > 0) lp.topMargin = dp8;
                list.addView(row, lp);
            }
        }

        scroll.addView(list);
        box.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(activity, 280)));

        M3X.expressify(box);

        dialog.setContentView(box);
        dialog.show();
    }

    public static void showWallpaperPresetDialog(final Activity activity, final PluginContext margyt, final Runnable onDone) {
        Dialog d = new Dialog(activity);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        if (d.getWindow() != null) {
            d.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            d.getWindow().setDimAmount(0.65f);
        }

        int dp16 = dp(activity, 16);
        int dp20 = dp(activity, 20);
        int dp8 = dp(activity, 8);
        int dp12 = dp(activity, 12);

        LinearLayout box = new LinearLayout(activity);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp20, dp20, dp20, dp16);

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xFF161823);
        bg.setCornerRadius(dp(activity, 20));
        box.setBackground(bg);

        TextView t = new TextView(activity);
        t.setText("Пресеты фона профиля");
        t.setTextColor(0xFFFFFFFF);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17);
        t.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        t.setPadding(0, 0, 0, dp12);
        box.addView(t);

        final String[] presets = new String[] {
            "Astra 0.1 Cyber (Космические кольца)",
            "Тилкайо (Пушистый котик)",
            "Собственное фото из галереи"
        };
        final String[] keys = new String[] {
            PRESET_ASTRA,
            PRESET_TILKAJO,
            PRESET_CUSTOM
        };

        for (int i = 0; i < presets.length; i++) {
            final int idx = i;
            TextView item = new TextView(activity);
            item.setText(presets[i]);
            item.setTextColor(0xFFFFFFFF);
            item.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
            item.setPadding(dp12, dp12, dp12, dp12);
            GradientDrawable ib = new GradientDrawable();
            ib.setColor(0x0AFFFFFF);
            ib.setCornerRadius(dp(activity, 10));
            item.setBackground(ib);

            item.setOnClickListener(v -> {
                d.dismiss();
                if (PRESET_CUSTOM.equals(keys[idx])) {
                    openWallpaperGalleryPicker(activity, margyt, onDone);
                } else {
                    setPreset(activity, margyt, keys[idx]);
                    Toast.makeText(activity, "Установлен пресет: " + presets[idx], Toast.LENGTH_SHORT).show();
                    if (onDone != null) onDone.run();
                }
            });

            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            if (i > 0) lp.topMargin = dp8;
            box.addView(item, lp);
        }

        M3X.expressify(box);

        d.setContentView(box);
        d.show();
    }

    private static void findImagesInDir(File dir, List<File> out, int depth) {
        if (dir == null || !dir.exists() || !dir.canRead() || depth > 2) return;
        File[] files = dir.listFiles();
        if (files == null) return;
        for (File f : files) {
            if (f.isDirectory() && !f.isHidden()) {
                findImagesInDir(f, out, depth + 1);
            } else if (f.isFile()) {
                String n = f.getName().toLowerCase();
                if (n.endsWith(".jpg") || n.endsWith(".jpeg") || n.endsWith(".png") || n.endsWith(".webp") || n.endsWith(".gif")
                    || n.endsWith(".mp4") || n.endsWith(".webm") || n.endsWith(".mov")) {
                    out.add(f);
                }
            }
        }
    }

    public interface OnPathSelected {
        void onSelected(String path);
    }

    static int dp(Context ctx, int val) {
        return (int) TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP, val, ctx.getResources().getDisplayMetrics()
        );
    }
}
