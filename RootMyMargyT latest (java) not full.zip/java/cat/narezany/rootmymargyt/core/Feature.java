package cat.narezany.rootmymargyt.core;

import android.app.Activity;
import android.content.Context;

/**
 * Один самодостаточный модуль плагина (бейджи, фон профиля, Тилкайо, …).
 *
 * Фича подписывается только на нужные ей хуки — у всех методов пустое тело по умолчанию.
 * Реестр {@link Root} ловит исключения каждого вызова по-отдельности: упавшая фича пишет
 * строку в журнал и выключается, но не роняет ни соседние фичи, ни TikTok.
 *
 * Поток: все методы вызываются на главном потоке. Тяжёлую работу фича уводит сама.
 */
public interface Feature {

    /** Короткий id для журнала (например {@code "badges"}). */
    String id();

    /** Процесс стартовал (до {@code Application.onCreate} TikTok). Разовая инициализация. */
    default void onStart(Context ctx) {}

    /** Активити вышла на передний план. */
    default void onResume(Activity activity) {}

    /** Активити ушла. */
    default void onPause(Activity activity) {}

    /** Появился экран (по имени класса TikTok). {@code name} — имя мода/TikTok, нестабильно между релизами. */
    default void onScreen(Activity activity, String name) {}

    /**
     * Кадр перед отрисовкой. Вызывается очень часто — держи дёшево.
     * Тяжёлые проверки выполняй только при {@link Tick#heavy} (раз в ~250 мс).
     */
    default void onTick(Activity activity, Tick tick) {}

    /** Фичу выключили (хук {@code onStop} мода). Снять оверлеи, отпустить ресурсы. */
    default void onStop() {}

    /** Сменился активный аккаунт ({@code uid}=null — вышли). Перечитать per-account настройки. */
    default void onAccountChanged(String uid) {}

    // ─────────────── трансформирующие хуки (значение → значение, цепочкой по фичам) ───────────────
    // Реестр пропускает значение через каждую фичу по очереди; верни аргумент как есть, чтобы не трогать.

    /** Имя аккаунта на пути в UI (с его uid). Бейджи мода вешаются после — голое имя их не снимает. */
    default String onName(String uid, String name) { return name; }

    /** Текст на пути во View. */
    default CharSequence onText(CharSequence text) { return text; }

    /** Цвет на пути на экран. В горячем пути отрисовки — без аллокаций/логов/поиска. */
    default int onColour(int colour) { return colour; }

    /** Ответ о регионе телефона ({@code key} — sim_country/network_operator/…). */
    default String onRegion(String key, String value) { return value; }

    /** Страница ленты до отрисовки. Верни как пришла или с удалёнными элементами. */
    default java.util.List onFeed(java.util.List posts) { return posts; }

    /** Снимок одного кадра для {@link #onTick}. */
    final class Tick {
        /** {@code SystemClock.uptimeMillis()} этого кадра. */
        public final long now;
        /** true не чаще раза в ~250 мс — для дорогих обходов дерева. */
        public final boolean heavy;
        /** Мы строго в своём профиле (кэшируется на время тяжёлого тика). */
        public final boolean inProfile;

        Tick(long now, boolean heavy, boolean inProfile) {
            this.now = now;
            this.heavy = heavy;
            this.inProfile = inProfile;
        }
    }
}
