package cat.narezany.rootmymargyt.core;

import android.content.Context;
import android.graphics.Bitmap;
import android.widget.TextView;

import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Map;

/**
 * Единая точка рефлексии бейджей/градиентов MargyT.
 *
 * Собирает весь доступ к {@code cat.narezany.margyt.Badges}, {@code Badges$Badge},
 * {@code Looks} и рисующему {@code Badge}: конструктор бейджа, статические карты
 * {@code pictures/asked/numbered/known}, {@code apply/tag/refresh}, {@code Looks.gradients},
 * диапазон меток ника ({@code Badges.FIRST/MOST} + {@code Looks.MOST}) и {@code Badge.setText}.
 *
 * Все члены разрешаются лениво и кэшируются. Любой промах не бросает наружу: геттеры
 * возвращают null/фолбэк, а {@link #available()} говорит, есть ли вообще класс бейджей.
 * Фичи работают только через этот фасад — ни одного {@code Class.forName} в них нет.
 */
public final class HostBadges {

    private HostBadges() {}

    private static boolean tried;
    private static Class<?> badgesCls;      // cat.narezany.margyt.Badges
    private static Class<?> badgeModelCls;  // cat.narezany.margyt.Badges$Badge (модель данных)
    private static Class<?> badgeDrawCls;   // cat.narezany.margyt.Badge (рисование)
    private static Class<?> looksCls;       // cat.narezany.margyt.Looks

    private static Constructor<?> badgeCtor;           // (id, image, tier, title, text, button)
    private static Method badgeCrop;                   // Badge.crop(Bitmap) → Bitmap
    private static Method badgeSetText;                // Badge.setText(TextView, CharSequence)
    private static Method badgesApply;                 // Badges.apply(byte[], boolean)
    private static Method badgesRefreshCtx, badgesRefresh;
    private static Field fPictures, fAsked, fNumbered, fKnown, fTag;
    private static Field fLooksGradients;

    private static boolean markTried;
    private static int markFirst = -1, markEnd = -1;

    private static synchronized void init() {
        if (tried) return;
        tried = true;
        try {
            badgesCls = Class.forName("cat.narezany.margyt.Badges");
            badgeModelCls = Class.forName("cat.narezany.margyt.Badges$Badge");

            badgeCtor = badgeModelCls.getDeclaredConstructor(
                    String.class, String.class, int.class, String.class, String.class, String.class);
            badgeCtor.setAccessible(true);

            fPictures = field(badgesCls, "pictures");
            fAsked = field(badgesCls, "asked");
            fNumbered = field(badgesCls, "numbered");
            fKnown = field(badgesCls, "known");
            fTag = field(badgesCls, "tag");

            badgesApply = method(badgesCls, "apply", byte[].class, boolean.class);
            try { badgesRefreshCtx = method(badgesCls, "refresh", Context.class); } catch (Throwable ignored) {}
            try { badgesRefresh = method(badgesCls, "refresh"); } catch (Throwable ignored) {}

            try {
                badgeDrawCls = Class.forName("cat.narezany.margyt.Badge");
                try { badgeCrop = method(badgeDrawCls, "crop", Bitmap.class); } catch (Throwable ignored) {}
                try { badgeSetText = badgeDrawCls.getMethod("setText", TextView.class, CharSequence.class); } catch (Throwable ignored) {}
            } catch (Throwable ignored) {}

            try {
                looksCls = Class.forName("cat.narezany.margyt.Looks");
                fLooksGradients = field(looksCls, "gradients");
            } catch (Throwable ignored) {}
        } catch (Throwable t) {
            badgesCls = null; // старая/иная сборка — фича бейджей тихо не работает
        }
    }

    private static Field field(Class<?> c, String name) throws NoSuchFieldException {
        Field f = c.getDeclaredField(name);
        f.setAccessible(true);
        return f;
    }

    private static Method method(Class<?> c, String name, Class<?>... args) throws NoSuchMethodException {
        Method m = c.getDeclaredMethod(name, args);
        m.setAccessible(true);
        return m;
    }

    /** true, если класс бейджей мода доступен. */
    public static boolean available() { init(); return badgesCls != null && badgeModelCls != null; }

    // ─────────────────────────── модель бейджа ───────────────────────────

    /** Новый экземпляр {@code Badges$Badge}, или null при промахе. */
    public static Object newBadge(String id, String image, int tier, String title, String text, String button) {
        init();
        if (badgeCtor == null) return null;
        try { return badgeCtor.newInstance(id, image, tier, title, text, button); }
        catch (Throwable t) { return null; }
    }

    /** Типизированный массив {@code Badges$Badge[]} длины {@code n} (для записи в поля мода). */
    public static Object[] newBadgeArray(int n) {
        init();
        if (badgeModelCls == null) return new Object[0];
        return (Object[]) Array.newInstance(badgeModelCls, n);
    }

    /** id бейджа через его публичное поле {@code id}, или null. */
    public static String badgeId(Object badge) {
        if (badge == null) return null;
        try { return (String) badge.getClass().getField("id").get(badge); }
        catch (Throwable t) { return null; }
    }

    /** Обрезка картинки бейджа методом мода {@code Badge.crop}; при отсутствии — исходник. */
    public static Bitmap crop(Bitmap src) {
        init();
        if (badgeCrop == null || src == null) return src;
        try { Bitmap c = (Bitmap) badgeCrop.invoke(null, src); return c != null ? c : src; }
        catch (Throwable t) { return src; }
    }

    // ─────────────────────────── статические карты ───────────────────────────

    @SuppressWarnings("rawtypes")
    public static Map pictures() { init(); return (Map) read(fPictures); }

    @SuppressWarnings("rawtypes")
    public static void clearAsked() {
        init();
        Map asked = (Map) read(fAsked);
        if (asked != null) synchronized (asked) { asked.clear(); }
    }

    public static Object[] numbered() { init(); Object v = read(fNumbered); return v instanceof Object[] ? (Object[]) v : null; }

    public static void setNumbered(Object[] arr) { init(); write(fNumbered, arr); }

    @SuppressWarnings("rawtypes")
    public static Map known() { init(); return (Map) read(fKnown); }

    public static void setKnown(Map<?, ?> map) { init(); write(fKnown, map); }

    @SuppressWarnings("rawtypes")
    public static Map looksGradients() { init(); return (Map) read(fLooksGradients); }

    public static void setLooksGradients(Map<?, ?> map) { init(); write(fLooksGradients, map); }

    private static Object read(Field f) {
        if (f == null) return null;
        try { return f.get(null); } catch (Throwable t) { return null; }
    }

    private static void write(Field f, Object v) {
        if (f == null) return;
        try { f.set(null, v); } catch (Throwable ignored) {}
    }

    // ─────────────────────────── перезагрузка badges.json ───────────────────────────

    /** Применить сырой JSON бейджей ({@code Badges.apply}). No-op при отсутствии метода. */
    public static void apply(byte[] raw, boolean flag) {
        init();
        if (badgesApply == null) return;
        try { badgesApply.invoke(null, raw, flag); } catch (Throwable ignored) {}
    }

    /** Сбросить кэш-тег мода, чтобы он перечитал бейджи. */
    public static void clearTag() { init(); write(fTag, null); }

    /** Попросить мод перечитать бейджи (сначала с Context, потом без). */
    public static void refresh(Context ctx) {
        init();
        try {
            if (badgesRefreshCtx != null && ctx != null) { badgesRefreshCtx.invoke(null, ctx.getApplicationContext()); return; }
        } catch (Throwable ignored) {}
        try { if (badgesRefresh != null) badgesRefresh.invoke(null); } catch (Throwable ignored) {}
    }

    // ─────────────────────────── метки ника и Badge.setText ───────────────────────────

    private static void initMarkRange() {
        if (markTried) return;
        markTried = true;
        init();
        try {
            Field first = field(badgesCls, "FIRST");
            Field most = field(badgesCls, "MOST");
            Field looksMost = field(looksCls, "MOST");
            markFirst = first.getChar(null);
            markEnd = markFirst + most.getInt(null) + looksMost.getInt(null);
        } catch (Throwable t) {
            markFirst = -2; markEnd = -2;
        }
    }

    /** Начало диапазона private-use меток мода в этом запуске, или &lt;0 если неизвестно. */
    public static int markFirst() { initMarkRange(); return markFirst; }

    /** Конец (исключительно) диапазона меток мода, или &lt;0 если неизвестно. */
    public static int markEnd() { initMarkRange(); return markEnd; }

    /** true, если символ — метка мода текущего запуска. */
    public static boolean isModMark(char c) {
        initMarkRange();
        return markFirst >= 0 && c >= markFirst && c < markEnd;
    }

    /**
     * Отдать ник обработчику мода ({@code Badge.setText}): свои метки он превратит в
     * градиент и картинки бейджей. true, если метод применился.
     */
    public static boolean setText(TextView tv, CharSequence cs) {
        init();
        if (badgeSetText == null || tv == null) return false;
        try { badgeSetText.invoke(null, tv, cs); return true; }
        catch (Throwable t) { return false; }
    }
}
