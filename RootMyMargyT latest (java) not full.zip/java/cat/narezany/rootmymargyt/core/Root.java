package cat.narezany.rootmymargyt.core;

import android.app.Activity;
import android.content.Context;

import java.util.ArrayList;
import java.util.List;

import cat.narezany.margyt.plugin.PluginContext;

/**
 * Реестр фич и единая точка раздачи хуков {@code MargyPlugin}.
 *
 * Тонкая точка входа ({@code RootMyMargyT}) только пересылает сюда вызовы жизненного цикла,
 * а реестр раздаёт их зарегистрированным {@link Feature}. Каждый вызов обёрнут в try/catch
 * по-отдельности: упавшая фича пишется в журнал и выключается, соседи и TikTok живут дальше.
 */
public final class Root {

    private static final List<Feature> FEATURES = new ArrayList<>();
    private static PluginContext margyt;
    private static ProfileProbe profileProbe;

    private Root() {}

    /** Как узнать, что мы строго в своём профиле — регистрирует фон-профиля. */
    public interface ProfileProbe {
        boolean inProfile(Activity activity);
    }

    public static void bind(PluginContext ctx) { margyt = ctx; }

    public static PluginContext margyt() { return margyt; }

    public static void log(String msg) {
        if (margyt != null) margyt.log("[rmm] " + msg);
    }

    /** Зарегистрировать фичу. Вызывается из точки входа при старте, до раздачи хуков. */
    public static void register(Feature f) {
        if (f != null) FEATURES.add(f);
    }

    public static void setProfileProbe(ProfileProbe probe) { profileProbe = probe; }

    static boolean probeProfile(Activity activity) {
        ProfileProbe p = profileProbe;
        if (p == null || activity == null) return false;
        try { return p.inProfile(activity); }
        catch (Throwable t) { return false; }
    }

    // ─────────────────────────── раздача хуков ───────────────────────────

    public static void dispatchStart(Context ctx) {
        for (Feature f : FEATURES) {
            try { f.onStart(ctx); }
            catch (Throwable t) { fail(f, "onStart", t); }
        }
    }

    public static void dispatchResume(Activity a) {
        for (Feature f : FEATURES) {
            try { f.onResume(a); }
            catch (Throwable t) { fail(f, "onResume", t); }
        }
    }

    public static void dispatchPause(Activity a) {
        for (Feature f : FEATURES) {
            try { f.onPause(a); }
            catch (Throwable t) { fail(f, "onPause", t); }
        }
    }

    public static void dispatchScreen(Activity a, String name) {
        for (Feature f : FEATURES) {
            try { f.onScreen(a, name); }
            catch (Throwable t) { fail(f, "onScreen", t); }
        }
    }

    public static void dispatchTick(Activity a, Feature.Tick tick) {
        for (Feature f : FEATURES) {
            try { f.onTick(a, tick); }
            catch (Throwable t) { fail(f, "onTick", t); }
        }
    }

    /** Собрать {@link Feature.Tick} и раздать (конструктор Tick package-private — строим здесь). */
    public static void dispatchTick(Activity a, long now, boolean heavy, boolean inProfile) {
        dispatchTick(a, new Feature.Tick(now, heavy, inProfile));
    }

    public static void dispatchStop() {
        for (Feature f : FEATURES) {
            try { f.onStop(); }
            catch (Throwable t) { fail(f, "onStop", t); }
        }
    }

    public static void dispatchAccountChanged(String uid) {
        for (Feature f : FEATURES) {
            try { f.onAccountChanged(uid); }
            catch (Throwable t) { fail(f, "onAccountChanged", t); }
        }
    }

    // ─────────────────────────── трансформирующие хуки (цепочкой) ───────────────────────────

    public static String dispatchName(String uid, String name) {
        for (Feature f : FEATURES) {
            try { name = f.onName(uid, name); }
            catch (Throwable t) { fail(f, "onName", t); }
        }
        return name;
    }

    public static CharSequence dispatchText(CharSequence text) {
        for (Feature f : FEATURES) {
            try { text = f.onText(text); }
            catch (Throwable t) { fail(f, "onText", t); }
        }
        return text;
    }

    public static int dispatchColour(int colour) {
        // Горячий путь отрисовки: без логов и аллокаций; ловим только чтобы не уронить кадр.
        for (Feature f : FEATURES) {
            try { colour = f.onColour(colour); }
            catch (Throwable ignored) {}
        }
        return colour;
    }

    public static String dispatchRegion(String key, String value) {
        for (Feature f : FEATURES) {
            try { value = f.onRegion(key, value); }
            catch (Throwable t) { fail(f, "onRegion", t); }
        }
        return value;
    }

    @SuppressWarnings("rawtypes")
    public static java.util.List dispatchFeed(java.util.List posts) {
        for (Feature f : FEATURES) {
            try { posts = f.onFeed(posts); }
            catch (Throwable t) { fail(f, "onFeed", t); }
        }
        return posts;
    }

    private static void fail(Feature f, String hook, Throwable t) {
        // В отличие от политики мода (уронил — выключил весь плагин), глушим на уровне фичи:
        // одна сломанная фича не должна гасить остальные.
        log(f.id() + "." + hook + " error: " + t);
    }
}
