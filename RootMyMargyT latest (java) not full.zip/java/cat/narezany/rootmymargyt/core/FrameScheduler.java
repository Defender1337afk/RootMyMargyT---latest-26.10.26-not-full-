package cat.narezany.rootmymargyt.core;

import android.app.Activity;
import android.os.SystemClock;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;

/**
 * Один {@link ViewTreeObserver.OnPreDrawListener} на активити, со встроенным троттлингом.
 *
 * Старый плагин вешал обход дерева и собственный таймер в каждом движке — здесь это один
 * слушатель, который раздаёт кадры всем фичам через {@link Root#dispatchTick}. Фичи делят
 * общий «тяжёлый тик» (раз в ~250 мс) и общий кэш «мы в профиле», не переизобретая троттлинг.
 */
public final class FrameScheduler {

    /** Тяжёлые проверки — не чаще раза в 250 мс: при GIF/видео/блёстках кадры идут непрерывно. */
    private static final long HEAVY_INTERVAL_MS = 250L;

    private static final int TAG_INSTALLED = 0x7F0B9901;

    private FrameScheduler() {}

    /** Повесить планировщик на декор активити (идемпотентно). */
    public static void install(final Activity activity) {
        if (activity == null || activity.isFinishing()) return;
        final View decor = activity.getWindow() != null ? activity.getWindow().getDecorView() : null;
        if (!(decor instanceof ViewGroup)) return;
        if (decor.getTag(TAG_INSTALLED) != null) return;
        decor.setTag(TAG_INSTALLED, Boolean.TRUE);

        decor.getViewTreeObserver().addOnPreDrawListener(new ViewTreeObserver.OnPreDrawListener() {
            private long lastHeavyAt = 0L;
            private boolean cachedInProfile = false;

            @Override
            public boolean onPreDraw() {
                if (activity.isFinishing()) return true;

                long now = SystemClock.uptimeMillis();
                boolean heavy = now - lastHeavyAt >= HEAVY_INTERVAL_MS;
                if (heavy) {
                    lastHeavyAt = now;
                    // «В профиле» определяем на тяжёлом тике и кэшируем для дешёвых кадров.
                    cachedInProfile = Root.probeProfile(activity);
                }

                Root.dispatchTick(activity, new Feature.Tick(now, heavy, cachedInProfile));
                return true;
            }
        });
    }
}
