package cat.narezany.rootmymargyt.core;

import android.app.Activity;
import android.content.Context;
import android.view.View;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

/**
 * Единственная точка соприкосновения с внутренностями MargyT.
 *
 * Весь рефлексивный доступ к классам мода ({@code cat.narezany.margyt.*}) живёт здесь —
 * имена классов, полей и методов, которые мод переименовывает между релизами, собраны
 * в одном проверяемом месте. Фичи плагина обращаются к моду только через этот фасад и
 * не содержат ни одного {@code Class.forName}.
 *
 * Контракты (сверено с исходником MargyT, API плагина 5):
 *  - {@code Skin.remembered(Context)} → инстанс темы; поля {@code page/card/text} (int),
 *    метод {@code muted()} → int (цвет текста с альфой 0x99). Всё package-private.
 *  - {@code Accent.colour()} → int — текущий акцент.
 *  - {@code CommentStyle.enabled()} / {@code set(boolean)} — своя покраска панели комментов мода.
 *  - {@code SettingsActivity.settingsPage} (String; null = лендинг-полка) и
 *    {@code person(title, sub, extra)} → строка-View настроек.
 *
 * Любой промах рефлексии не бросает наружу: методы возвращают фолбэк/флаг, фича остаётся живой.
 */
public final class Host {

    private Host() {}

    // ─────────────────────────── кэш классов/членов ───────────────────────────
    // Разрешаем лениво и один раз. null-кэш отличаем от «ещё не пробовали» флагом tried.

    private static Class<?> skinCls;
    private static Method skinRemembered, skinMuted;
    private static Field skinPage, skinCard, skinText;
    private static boolean skinTried;

    private static Class<?> accentCls;
    private static Method accentColour;
    private static boolean accentTried;

    private static Class<?> commentStyleCls;
    private static Method commentStyleEnabled, commentStyleSet;
    private static boolean commentStyleTried, commentStyleBroken;

    private static Class<?> settingsCls;
    private static Field settingsPageField;
    private static Method settingsPerson;
    private static boolean settingsTried;

    private static void initSkin() {
        if (skinTried) return;
        skinTried = true;
        try {
            skinCls = Class.forName("cat.narezany.margyt.Skin");
            skinRemembered = skinCls.getDeclaredMethod("remembered", Context.class);
            skinRemembered.setAccessible(true);
            skinPage = skinCls.getDeclaredField("page"); skinPage.setAccessible(true);
            skinCard = skinCls.getDeclaredField("card"); skinCard.setAccessible(true);
            skinText = skinCls.getDeclaredField("text"); skinText.setAccessible(true);
            try { skinMuted = skinCls.getDeclaredMethod("muted"); skinMuted.setAccessible(true); }
            catch (Throwable ignored) { skinMuted = null; }
        } catch (Throwable t) {
            skinCls = null; // старая сборка без Skin
        }
    }

    private static Object skinInstance(Context ctx) {
        initSkin();
        if (skinCls == null || ctx == null) return null;
        try { return skinRemembered.invoke(null, ctx); }
        catch (Throwable t) { return null; }
    }

    /** true, если тема мода доступна (есть класс {@code Skin}). */
    public static boolean hasTheme() { initSkin(); return skinCls != null; }

    private static int skinInt(Context ctx, Field f, int fallback) {
        Object skin = skinInstance(ctx);
        if (skin == null || f == null) return fallback;
        try { return f.getInt(skin) | 0xFF000000; }
        catch (Throwable t) { return fallback; }
    }

    /** Цвет фона страницы темы (непрозрачный), или {@code fallback}. */
    public static int skinPage(Context ctx, int fallback) { return skinInt(ctx, skinPage, fallback); }

    /** Цвет карточки темы (непрозрачный), или {@code fallback}. */
    public static int skinCard(Context ctx, int fallback) { return skinInt(ctx, skinCard, fallback); }

    /** Цвет основного текста темы (непрозрачный), или {@code fallback}. */
    public static int skinText(Context ctx, int fallback) { return skinInt(ctx, skinText, fallback); }

    /**
     * Приглушённый цвет текста темы, как его отдаёт мод (с исходной альфой 0x99).
     * Возвращает {@code fallback}, если метода нет.
     */
    public static int skinMuted(Context ctx, int fallback) {
        Object skin = skinInstance(ctx);
        if (skin == null || skinMuted == null) return fallback;
        try { return (Integer) skinMuted.invoke(skin); }
        catch (Throwable t) { return fallback; }
    }

    /** Текущий акцентный цвет мода (непрозрачный), или {@code fallback}. */
    public static int accent(int fallback) {
        if (!accentTried) {
            accentTried = true;
            try {
                accentCls = Class.forName("cat.narezany.margyt.Accent");
                accentColour = accentCls.getDeclaredMethod("colour");
                accentColour.setAccessible(true);
            } catch (Throwable t) { accentCls = null; }
        }
        if (accentCls == null) return fallback;
        try { return (Integer) accentColour.invoke(null) | 0xFF000000; }
        catch (Throwable t) { return fallback; }
    }

    // ─────────────────────────── CommentStyle (анти-моргание) ───────────────────────────

    private static void initCommentStyle() {
        if (commentStyleTried) return;
        commentStyleTried = true;
        try {
            commentStyleCls = Class.forName("cat.narezany.margyt.CommentStyle");
            commentStyleEnabled = commentStyleCls.getDeclaredMethod("enabled");
            commentStyleEnabled.setAccessible(true);
            commentStyleSet = commentStyleCls.getDeclaredMethod("set", boolean.class);
            commentStyleSet.setAccessible(true);
        } catch (Throwable t) {
            commentStyleBroken = true; // старая сборка без CommentStyle
        }
    }

    /** true, если мод имеет свою покраску панели комментов ({@code CommentStyle}). */
    public static boolean hasCommentStyle() { initCommentStyle(); return !commentStyleBroken; }

    /** Включена ли сейчас покраска комментов мода. {@code false}, если класса нет. */
    public static boolean commentStyleEnabled() {
        initCommentStyle();
        if (commentStyleBroken) return false;
        try { return (Boolean) commentStyleEnabled.invoke(null); }
        catch (Throwable t) { commentStyleBroken = true; return false; }
    }

    /** Включить/выключить покраску комментов мода. No-op, если класса нет. */
    public static void setCommentStyle(boolean on) {
        initCommentStyle();
        if (commentStyleBroken) return;
        try { commentStyleSet.invoke(null, on); }
        catch (Throwable t) { commentStyleBroken = true; }
    }

    // ─────────────────────────── SettingsActivity ───────────────────────────

    private static void initSettings() {
        if (settingsTried) return;
        settingsTried = true;
        try {
            settingsCls = Class.forName("cat.narezany.margyt.SettingsActivity");
            try { settingsPageField = settingsCls.getDeclaredField("settingsPage"); settingsPageField.setAccessible(true); }
            catch (Throwable ignored) { settingsPageField = null; }
            try {
                settingsPerson = settingsCls.getDeclaredMethod("person", String.class, String.class, String.class);
                settingsPerson.setAccessible(true);
            } catch (Throwable ignored) { settingsPerson = null; }
        } catch (Throwable t) { settingsCls = null; }
    }

    /** Класс экрана настроек мода, или null (для {@code Intent}). */
    public static Class<?> settingsActivityClass() { initSettings(); return settingsCls; }

    /** true, если {@code activity} — экран настроек мода. */
    public static boolean isSettingsActivity(Activity activity) {
        initSettings();
        return settingsCls != null && activity != null && settingsCls.isInstance(activity);
    }

    /**
     * Текущая под-вкладка настроек: null = лендинг-полка (куда и вставляем карточки плагина,
     * иначе они задвоятся в каждую под-вкладку). Возвращает {@code ""} как «неизвестно/не настройки».
     */
    public static String settingsPage(Activity activity) {
        initSettings();
        if (settingsPageField == null || !isSettingsActivity(activity)) return "";
        try {
            Object v = settingsPageField.get(activity);
            return v == null ? null : v.toString();
        } catch (Throwable t) { return ""; }
    }

    /** true, если открыта лендинг-полка настроек (settingsPage == null). */
    public static boolean onSettingsLanding(Activity activity) {
        return settingsPage(activity) == null;
    }

    /**
     * Строка настроек в нативном стиле мода ({@code person}), например для «Благодарностей».
     * {@code extra} может быть null. Возвращает null, если метод недоступен.
     */
    public static View personRow(Activity activity, String title, String subtitle, String extra) {
        initSettings();
        if (settingsPerson == null || activity == null) return null;
        try { return (View) settingsPerson.invoke(activity, title, subtitle, extra); }
        catch (Throwable t) { return null; }
    }
}
