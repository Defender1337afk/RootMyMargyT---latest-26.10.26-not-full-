package cat.narezany.rootmymargyt;

import android.app.Activity;

import cat.narezany.margyt.plugin.PluginContext;
import cat.narezany.rootmymargyt.core.Feature;
import cat.narezany.rootmymargyt.core.Root;

/**
 * Все покадровые оверлеи профиля и ленты, раньше жившие в god-слушателе onPreDraw:
 * живая GIF-аватарка, блёстки, Liquid-часы, Clawd-питомец, счётчики ленты, режим Тилкайо,
 * позиция навбара; по тяжёлому тику — жук-лимитоед и «сенсоры» Clawd.
 *
 * Регистрируется ПОСЛЕДНЕЙ, чтобы сохранить исходный порядок кадра (бейджи/фоны/текст → оверлеи).
 * Движки device-проверенные — не переписаны, а выведены из entry в реестр через {@link FrameScheduler}.
 */
public final class OverlaysFeature implements Feature {

    @Override public String id() { return "overlays"; }

    private static PluginContext m() { return Root.margyt(); }

    @Override
    public void onTick(Activity activity, Tick tick) {
        if (tick.heavy) {
            // Жук в «Смешнявках» MargyT запускает Clawd Run; Clawd читает комменты/видео (свои интервалы внутри).
            LimitBugSwap.hookFunCat(activity, m());
            ClawdSenses.update(activity, m());
        }

        boolean inProfile = tick.inProfile;
        LiveAvatarEngine.update(activity, m(), inProfile);
        SparkleOverlayView.update(activity, m(), inProfile);
        LiquidClockView.update(activity, m(), inProfile);
        ClawdPetView.update(activity, m(), inProfile);

        // Счётчики у кнопок ленты — проверка скрытия каждый кадр.
        FeedCountsEngine.update(activity, m());

        // Режим Тилкайо держит иконки прозрачными каждый кадр (реестры пересканирует сам ~раз в 400мс).
        TilkajoModeEngine.update(activity, m());

        // Позиция навигационной панели.
        NavBarPositionEngine.update(activity, m());
    }

    @Override
    public void onPause(Activity activity) {
        LiveAvatarEngine.onPause();
    }
}
