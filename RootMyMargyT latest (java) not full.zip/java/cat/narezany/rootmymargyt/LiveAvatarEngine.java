package cat.narezany.rootmymargyt;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.drawable.Animatable;
import android.graphics.drawable.Drawable;
import android.os.SystemClock;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import java.io.File;
import java.lang.ref.WeakReference;

import cat.narezany.margyt.plugin.PluginContext;

/**
 * LiveAvatarEngine — живая аватарка (GIF / анимированный WebP) в своём профиле.
 *
 * Поверх настоящей аватарки кладётся прозрачный оверлей на весь экран (как у ушек фембоя), он
 * рисует GIF строго в рамке аватарки и обрезает её формой, которую выбрал пользователь в MargyT:
 * контур берётся из публичного AvatarShape.addCircle, того же вызова, которым сама TikTok режет
 * аватарки. Края сглаживаются маской DST_IN, а не clipPath, поэтому не «лесенкой».
 *
 * Оверлей виден только в своём профиле и только пока аватарка на экране. Все вызовы обёрнуты
 * в try/catch: код выполняется внутри OnPreDrawListener, и исключение уронило бы TikTok.
 */
public final class LiveAvatarEngine {

    public static final String KEY_ENABLED = "live_avatar_enabled";
    public static final String TAG_VIEW = "rootmymargyt_live_avatar";

    private static WeakReference<LiveAvatarView> overlayRef = new WeakReference<LiveAvatarView>(null);
    private static WeakReference<View> avatarRef = new WeakReference<View>(null);
    /** decor, в который оверлей уже поставлен в очередь на добавление (чтобы не создать второй). */
    private static WeakReference<ViewGroup> pendingFor = new WeakReference<ViewGroup>(null);
    private static long lastFind = 0L;
    private static String failedSig = "";
    private static long lastErrorLog = 0L;
    /** Файл слота ищется на диске только при смене версии, а не на каждом кадре. */
    private static long fileCacheVersion = Long.MIN_VALUE;
    private static File fileCache = null;

    private static final int[] AT_AVATAR = new int[2];
    private static final int[] AT_OVERLAY = new int[2];
    private static final Rect VISIBLE = new Rect();

    private LiveAvatarEngine() {}

    public static boolean isEnabled(PluginContext m) {
        return m != null && m.getBoolean(KEY_ENABLED, false);
    }

    /** Файл слота сменился или удалён: оверлей соберётся заново. */
    public static void invalidate() {
        failedSig = "";
        fileCacheVersion = Long.MIN_VALUE;
        LiveAvatarView v = overlayRef.get();
        if (v != null) v.clearMedia();
    }

    /** Активити ушла с экрана: гифка на паузу. */
    public static void onPause() {
        LiveAvatarView v = overlayRef.get();
        if (v != null) v.hideNow();
    }

    /**
     * Вызывается из preDraw-наблюдателя, поэтому дешёвая: геометрия считается без выделения памяти,
     * файл читается только при смене.
     *
     * @param profileShown результат isLocalUserProfile, уже посчитанный наблюдателем
     */
    public static void update(Activity activity, PluginContext m, boolean profileShown) {
        try {
            updateInternal(activity, m, profileShown);
        } catch (Throwable t) {
            try {
                LiveAvatarView v = overlayRef.get();
                if (v != null) v.hideNow();
                long now = SystemClock.uptimeMillis();
                if (m != null && now - lastErrorLog > 15000L) {
                    lastErrorLog = now;
                    m.log("live avatar: " + t);
                }
            } catch (Throwable ignored) {}
        }
    }

    private static void updateInternal(final Activity activity, PluginContext m, boolean profileShown) {
        if (activity == null || activity.isFinishing() || m == null) return;
        if (activity.getWindow() == null) return;
        View root = activity.getWindow().getDecorView();
        if (!(root instanceof ViewGroup)) return;
        final ViewGroup decor = (ViewGroup) root;

        LiveAvatarView overlay = overlayRef.get();
        if (overlay != null && overlay.getParent() != decor) overlay = null;
        if (overlay == null && pendingFor.get() == decor) return;

        File file = (isEnabled(m) && profileShown) ? slotFile(activity, m) : null;
        if (file == null) {
            if (overlay != null) overlay.hideNow();
            return;
        }

        if (overlay == null) {
            // оверлей добавляется после текущего прохода: менять иерархию внутри preDraw не стоит
            final LiveAvatarView fresh = new LiveAvatarView(activity);
            fresh.setTag(TAG_VIEW);
            pendingFor = new WeakReference<ViewGroup>(decor);
            decor.post(new Runnable() {
                @Override
                public void run() {
                    try {
                        pendingFor = new WeakReference<ViewGroup>(null);
                        if (fresh.getParent() == null && !activity.isFinishing()) {
                            decor.addView(fresh, new FrameLayout.LayoutParams(
                                    ViewGroup.LayoutParams.MATCH_PARENT,
                                    ViewGroup.LayoutParams.MATCH_PARENT));
                            overlayRef = new WeakReference<LiveAvatarView>(fresh);
                            // ушки фембоя должны оставаться поверх аватарки
                            View ears = decor.findViewWithTag(ProfileLocator.TAG_EARS);
                            if (ears != null) ears.bringToFront();
                        }
                    } catch (Throwable ignored) {}
                }
            });
            return;
        }

        String sig = file.getAbsolutePath() + "|" + BackdropMedia.version(m, BackdropMedia.SLOT_AVATAR);
        if (!sig.equals(overlay.signature)) {
            if (sig.equals(failedSig)) {
                overlay.hideNow();
                return;
            }
            Drawable d = BackdropMedia.load(activity, file, 512);
            if (d == null) {
                failedSig = sig;
                m.log("live avatar: не удалось прочитать файл");
                overlay.hideNow();
                return;
            }
            overlay.setMedia(d, sig);
        }

        View avatar = avatarRef.get();
        boolean usable = avatar != null && avatar.isShown() && avatar.getWidth() > 0;
        if (!usable) {
            long now = SystemClock.uptimeMillis();
            if (now - lastFind < 300L) {
                overlay.hideNow();
                return;
            }
            lastFind = now;
            avatar = ProfileLocator.findProfileAvatar(decor);
            avatarRef = new WeakReference<View>(avatar);
            if (avatar == null || !avatar.isShown() || avatar.getWidth() <= 0) {
                overlay.hideNow();
                return;
            }
        }

        // та же геометрия, что у ушек: внутренняя область вьюхи без отступов, круг по меньшей стороне
        avatar.getLocationOnScreen(AT_AVATAR);
        overlay.getLocationOnScreen(AT_OVERLAY);

        int padL = avatar.getPaddingLeft();
        int padT = avatar.getPaddingTop();
        float w = avatar.getWidth() - padL - avatar.getPaddingRight();
        float h = avatar.getHeight() - padT - avatar.getPaddingBottom();
        if (w <= 0 || h <= 0) {
            w = avatar.getWidth();
            h = avatar.getHeight();
            padL = 0;
            padT = 0;
        }

        float cx = AT_AVATAR[0] - AT_OVERLAY[0] + padL + w / 2f;
        float cy = AT_AVATAR[1] - AT_OVERLAY[1] + padT + h / 2f;
        float r = Math.min(w, h) / 2f;

        boolean seen = avatar.getGlobalVisibleRect(VISIBLE);
        if (seen) VISIBLE.offset(-AT_OVERLAY[0], -AT_OVERLAY[1]);

        overlay.show(cx, cy, r, seen ? VISIBLE : null);
    }

    private static File slotFile(Activity activity, PluginContext m) {
        long ver = BackdropMedia.version(m, BackdropMedia.SLOT_AVATAR);
        if (ver != fileCacheVersion || (fileCache != null && !fileCache.isFile())) {
            fileCache = BackdropMedia.fileOf(activity, BackdropMedia.SLOT_AVATAR);
            fileCacheVersion = ver;
        }
        return fileCache;
    }

    // ================================================================== оверлей

    /** Прозрачный оверлей на весь экран, который рисует GIF в рамке аватарки. */
    public static final class LiveAvatarView extends View {

        public String signature = "";

        private Drawable media;
        private boolean shown = false;
        private float cx = -1f, cy = -1f, r = 0f;
        private final Rect clipTo = new Rect();
        private boolean hasClip = false;

        private final Path shape = new Path();
        private boolean shapeValid = false;
        private float shapeCx, shapeCy, shapeR;

        private final Paint mask = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Rect box = new Rect();

        public LiveAvatarView(Context context) {
            super(context);
            setWillNotDraw(false);
            setClickable(false);
            setFocusable(false);
            setVisibility(GONE);
            mask.setStyle(Paint.Style.FILL);
            mask.setColor(0xFF000000);
            mask.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
        }

        void setMedia(Drawable d, String sig) {
            clearMedia();
            media = d;
            signature = sig;
            d.setCallback(this);
            shapeValid = false;
            if (shown) startMedia();
            invalidate();
        }

        void clearMedia() {
            Drawable d = media;
            media = null;
            signature = "";
            if (d == null) return;
            try {
                if (d instanceof Animatable) ((Animatable) d).stop();
                d.setCallback(null);
            } catch (Throwable ignored) {}
        }

        void show(float cx, float cy, float r, Rect visible) {
            boolean moved = Math.abs(cx - this.cx) > 0.5f || Math.abs(cy - this.cy) > 0.5f
                    || Math.abs(r - this.r) > 0.5f;
            this.cx = cx;
            this.cy = cy;
            this.r = r;

            boolean clipChanged;
            if (visible == null) {
                clipChanged = hasClip;
                hasClip = false;
            } else {
                clipChanged = !hasClip || !clipTo.equals(visible);
                clipTo.set(visible);
                hasClip = true;
            }

            if (!shown) {
                shown = true;
                setVisibility(VISIBLE);
                bringToFrontKeepingEars();
                startMedia();
                invalidate();
            } else if (moved || clipChanged) {
                invalidate();
            }
        }

        void hideNow() {
            if (!shown && getVisibility() == GONE) return;
            shown = false;
            setVisibility(GONE);
            stopMedia();
        }

        private void startMedia() {
            Drawable d = media;
            if (d instanceof Animatable && !((Animatable) d).isRunning()) {
                try {
                    ((Animatable) d).start();
                } catch (Throwable ignored) {}
            }
        }

        private void stopMedia() {
            Drawable d = media;
            if (d instanceof Animatable && ((Animatable) d).isRunning()) {
                try {
                    ((Animatable) d).stop();
                } catch (Throwable ignored) {}
            }
        }

        private void bringToFrontKeepingEars() {
            try {
                bringToFront();
                ViewGroup parent = (ViewGroup) getParent();
                if (parent != null) {
                    View ears = parent.findViewWithTag(ProfileLocator.TAG_EARS);
                    if (ears != null) ears.bringToFront();
                }
            } catch (Throwable ignored) {}
        }

        /** Без этого View не пересчитывает кадры анимации: он слушает только фон и foreground. */
        @Override
        protected boolean verifyDrawable(Drawable who) {
            return who == media || super.verifyDrawable(who);
        }

        private void rebuildShape() {
            shape.rewind();
            try {
                // тот самый вызов, которым TikTok режет аватарки: контур выбранной в MargyT формы
                cat.narezany.margyt.AvatarShape.addCircle(shape, cx, cy, r, Path.Direction.CW);
            } catch (Throwable t) {
                shape.rewind();
                shape.addCircle(cx, cy, r, Path.Direction.CW);
            }
            shapeCx = cx;
            shapeCy = cy;
            shapeR = r;
            shapeValid = true;
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            Drawable d = media;
            if (!shown || d == null || r <= 15f) return;

            if (!shapeValid || Math.abs(shapeCx - cx) > 0.25f || Math.abs(shapeCy - cy) > 0.25f
                    || Math.abs(shapeR - r) > 0.25f) {
                rebuildShape();
            }

            box.set(Math.round(cx - r), Math.round(cy - r), Math.round(cx + r), Math.round(cy + r));

            int outer = canvas.save();
            if (hasClip) canvas.clipRect(clipTo);

            int layer = canvas.saveLayer(box.left, box.top, box.right, box.bottom, null);
            int iw = d.getIntrinsicWidth();
            int ih = d.getIntrinsicHeight();
            if (iw > 0 && ih > 0) {
                // center crop в квадрат аватарки
                float scale = Math.max(box.width() / (float) iw, box.height() / (float) ih);
                int dw = Math.round(iw * scale);
                int dh = Math.round(ih * scale);
                int left = box.left + (box.width() - dw) / 2;
                int top = box.top + (box.height() - dh) / 2;
                d.setBounds(left, top, left + dw, top + dh);
            } else {
                d.setBounds(box);
            }
            d.draw(canvas);
            canvas.drawPath(shape, mask);
            canvas.restoreToCount(layer);

            canvas.restoreToCount(outer);
        }
    }
}
