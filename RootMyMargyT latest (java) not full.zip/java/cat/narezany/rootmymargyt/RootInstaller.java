package cat.narezany.rootmymargyt;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import cat.narezany.margyt.plugin.PluginContext;

/**
 * RootInstaller — интерактивный установщик Superuser Root-прав для MargyT.
 * На первом запуске показывает окно подтверждения, затем разворачивает
 * полноэкранный терминал со строчками патчинга ядра в стиле hacker/matrix,
 * фиксирует права суперпользователя и открывает панель.
 */
public final class RootInstaller {

    private static final String PREF_ROOT_INSTALLED = "root_rights_installed";

    public interface InstallCallback {
        void onInstalled();
    }

    private RootInstaller() {}

    public static boolean isInstalled(PluginContext margyt) {
        if (margyt == null) return false;
        return margyt.getBoolean(PREF_ROOT_INSTALLED, false);
    }

    public static void setInstalled(PluginContext margyt, boolean installed) {
        if (margyt == null) return;
        margyt.prefs().edit().putBoolean(PREF_ROOT_INSTALLED, installed).apply();
    }

    public static void showInstallPrompt(Activity activity, PluginContext margyt, InstallCallback callback) {
        if (activity == null || activity.isFinishing()) return;

        Dialog dialog = new Dialog(activity);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            window.setDimAmount(0.80f);
        }

        LinearLayout root = new LinearLayout(activity);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(activity, 24), dp(activity, 24), dp(activity, 24), dp(activity, 20));

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xFF121216);
        bg.setCornerRadius(dp(activity, 24));
        bg.setStroke(dp(activity, 1), 0xFF2C2C36);
        root.setBackground(bg);

        // Header icon
        TextView icon = new TextView(activity);
        icon.setText("⚡");
        icon.setTextSize(TypedValue.COMPLEX_UNIT_SP, 36);
        icon.setGravity(Gravity.CENTER);
        root.addView(icon);

        TextView title = new TextView(activity);
        title.setText("Superuser Root MargyT");
        title.setTextColor(0xFFF1F1F4);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, dp(activity, 8), 0, dp(activity, 4));
        root.addView(title);

        TextView desc = new TextView(activity);
        desc.setText("Для работы эксклюзивных Superuser функций (16 бейджей без сброса, Famous Mode, 120 FPS и защита ядра) требуются Root-права.\n\nЗапустить автоматический патчер ядра?");
        desc.setTextColor(0xFF9E9EA8);
        desc.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        desc.setGravity(Gravity.CENTER);
        desc.setPadding(0, 0, 0, dp(activity, 20));
        root.addView(desc);

        // Кнопка Установить
        TextView btnInstall = new TextView(activity);
        btnInstall.setText("УСТАНОВИТЬ ROOT ПРАВА ⚡");
        btnInstall.setTextColor(0xFF00FF66);
        btnInstall.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        btnInstall.setTypeface(Typeface.DEFAULT_BOLD);
        btnInstall.setGravity(Gravity.CENTER);
        btnInstall.setPadding(dp(activity, 16), dp(activity, 13), dp(activity, 16), dp(activity, 13));

        GradientDrawable btnBg = new GradientDrawable();
        btnBg.setColor(0x1A00FF66);
        btnBg.setCornerRadius(dp(activity, 14));
        btnBg.setStroke(dp(activity, 1), 0x6600FF66);
        btnInstall.setBackground(btnBg);

        btnInstall.setOnClickListener(v -> {
            v.performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY);
            dialog.dismiss();
            runHackerTerminal(activity, margyt, callback);
        });
        root.addView(btnInstall);

        dialog.setContentView(root);
        dialog.show();
    }

    /**
     * Полноэкранный терминал патчинга ядра со строчками кода.
     */
    private static void runHackerTerminal(Activity activity, PluginContext margyt, InstallCallback callback) {
        if (activity == null || activity.isFinishing()) return;

        Dialog termDialog = new Dialog(activity, android.R.style.Theme_Black_NoTitleBar_Fullscreen);
        if (termDialog.getWindow() != null) {
            termDialog.getWindow().setBackgroundDrawable(new ColorDrawable(0xFF0A0A0E));
        }

        LinearLayout termRoot = new LinearLayout(activity);
        termRoot.setOrientation(LinearLayout.VERTICAL);
        termRoot.setPadding(dp(activity, 16), dp(activity, 32), dp(activity, 16), dp(activity, 20));
        termRoot.setBackgroundColor(0xFF0A0A0E);

        // Terminal Header
        LinearLayout tHeader = new LinearLayout(activity);
        tHeader.setOrientation(LinearLayout.HORIZONTAL);
        tHeader.setGravity(Gravity.CENTER_VERTICAL);

        TextView tTitle = new TextView(activity);
        tTitle.setText("root@margyt:~# ./install_su_core.sh --force --bypass-integrity");
        tTitle.setTextColor(0xFF00FF66);
        tTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        tTitle.setTypeface(Typeface.MONOSPACE);
        tHeader.addView(tTitle, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        termRoot.addView(tHeader);

        View div = new View(activity);
        div.setBackgroundColor(0x3300FF66);
        termRoot.addView(div, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(activity, 1)));

        ScrollView scroll = new ScrollView(activity);
        scroll.setVerticalScrollBarEnabled(false);
        LinearLayout logsLayout = new LinearLayout(activity);
        logsLayout.setOrientation(LinearLayout.VERTICAL);
        logsLayout.setPadding(0, dp(activity, 12), 0, dp(activity, 12));
        scroll.addView(logsLayout);

        termRoot.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        final TextView btnDone = new TextView(activity);
        btnDone.setText("⚡ ПЕРЕЗАПУСТИТЬ MARGYT / ВОЙТИ В ROOT ПАНЕЛЬ");
        btnDone.setTextColor(0xFF0A0A0E);
        btnDone.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        btnDone.setTypeface(Typeface.DEFAULT_BOLD);
        btnDone.setGravity(Gravity.CENTER);
        btnDone.setPadding(dp(activity, 16), dp(activity, 13), dp(activity, 16), dp(activity, 13));

        GradientDrawable doneBg = new GradientDrawable();
        doneBg.setColor(0xFF00FF66);
        doneBg.setCornerRadius(dp(activity, 12));
        btnDone.setBackground(doneBg);
        btnDone.setVisibility(View.GONE);

        btnDone.setOnClickListener(v -> {
            v.performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY);
            termDialog.dismiss();
            setInstalled(margyt, true);
            RootBadgeEngine.enforceMemoryState(margyt);
            if (activity != null) {
                RootBadgeEngine.saveFilesAndJson(activity, margyt);
            }
            if (callback != null) callback.onInstalled();
        });
        termRoot.addView(btnDone);

        termDialog.setContentView(termRoot);
        termDialog.show();

        // Сценарий строчек кода терминала
        final String[] logs = new String[] {
            "[+] Initializing MargyT Kernel SU v3.5 Environment...",
            "[+] Mounting /system/xbin/su (Permissions: rwsr-xr-x UID 0 GID 0)...",
            "[+] SELinux Policy: switching Enforcing -> Permissive [BYPASSED]",
            "[+] Analyzing live TikTok process (com.ss.android.ugc.trill)...",
            "[+] Scanning Dalvik/ART runtime memory address space...",
            "[+] Bypassing TikTok SSL Pinning & TLS Fingerprint telemetry...",
            "[+] Patching cat.narezany.margyt.Badges pipeline (enforcing 16/16 slots)...",
            "[+] Pre-loading HD Bitmap buffers into Badges.pictures (zero-null guarantee)...",
            "[+] Hooking Looks & Profile layout models (Famous Mode active)...",
            "[+] Neutralizing TikTok anti-mod heuristics & analytics beacons...",
            "[+] Uncapping display refresh rate to 120/144 FPS...",
            "[+] Superuser Access Granted: UID 0 (root) context=u:r:su:s0",
            "[✔] ROOT ПРАВА УСПЕШНО УСТАНОВЛЕНЫ И ЗАФИКСИРОВАНЫ В ЯДРЕ!",
            "[!] Система готова. Нажмите кнопку ниже для применения и входа."
        };

        final Handler handler = new Handler(Looper.getMainLooper());
        for (int i = 0; i < logs.length; i++) {
            final int index = i;
            handler.postDelayed(() -> {
                TextView line = new TextView(activity);
                line.setText(logs[index]);
                line.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
                line.setTypeface(Typeface.MONOSPACE);
                if (index == logs.length - 2) {
                    line.setTextColor(0xFF00FF66);
                    line.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
                } else if (index == logs.length - 1) {
                    line.setTextColor(0xFF60EFFF);
                } else {
                    line.setTextColor(0xDD00FF66);
                }
                line.setPadding(0, dp(activity, 2), 0, dp(activity, 2));
                logsLayout.addView(line);
                scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));

                if (index == logs.length - 1) {
                    setInstalled(margyt, true);
                    RootBadgeEngine.enforceMemoryState(margyt);
                    btnDone.setVisibility(View.VISIBLE);
                }
            }, (i + 1) * 260);
        }
    }

    private static int dp(Context ctx, int val) {
        return (int) TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP, val, ctx.getResources().getDisplayMetrics()
        );
    }
}
