package cat.narezany.rootmymargyt;

import android.app.Activity;
import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import java.lang.ref.WeakReference;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.Arrays;

import cat.narezany.margyt.plugin.PluginContext;

/**
 * LimitBugSwap — жук-лимитоед вместо жирного тилкайо в «Смешнявках» MargyT.
 *
 * Жирного тилкайо MargyT один раз скачивает и дальше берёт из своего кэша
 * files/margyt/cats/tilcayo.jpg (Cats.fat): оттуда его рисуют раздел «Смешнявки → Жирный
 * тилкайо», скример и виджет на рабочем столе. Скачивает заново он только если файла нет.
 *
 * Поэтому подмена — это просто наш JPEG в этом файле. Оригинал перед этим откладывается
 * в папку плагина и возвращается при выключении; если отложить было нечего, файл кэша
 * удаляется и MargyT сам скачает тилкайо заново.
 *
 * Картинка, которую мод уже держит в памяти, сменится после перезапуска TikTok.
 */
public final class LimitBugSwap {

    public static final String KEY_ENABLED = "limitbug_instead_of_tilcayo";

    private LimitBugSwap() {}

    public static boolean isEnabled(PluginContext m) {
        return m != null && m.getBoolean(KEY_ENABLED, false);
    }

    public static void setEnabled(Context ctx, PluginContext m, boolean on) {
        if (m != null) m.prefs().edit().putBoolean(KEY_ENABLED, on).apply();
        apply(ctx, m);
    }

    /** Подписи картинки тилкайо в MargyT (Text.FUN_CAT) на всех его языках. */
    private static final String[] FUN_CAT_LABELS = {"Жирный тилкайо", "Жирний тілкайо", "Fat tilcayo"};
    private static WeakReference<View> hooked = new WeakReference<>(null);

    /**
     * В «Смешнявках» MargyT картинка, где теперь жук, по нажатию запускает Clawd Run.
     * Ищется по contentDescription, который ставит сам MargyT; только в его экране настроек.
     */
    public static void hookFunCat(final Activity activity, final PluginContext m) {
        try {
            if (!isEnabled(m) || activity == null || activity.getWindow() == null) return;
            if (!activity.getClass().getName().contains("Settings")) return;
            View done = hooked.get();
            if (done != null && done.isAttachedToWindow() && done.getRootView() == activity.getWindow().getDecorView()) return;
            View cat = findFunCat(activity.getWindow().getDecorView(), 0);
            if (cat == null) return;
            cat.setClickable(true);
            cat.setOnClickListener(v -> ClawdRunGame.show(activity, m));
            hooked = new WeakReference<>(cat);
        } catch (Throwable ignored) {}
    }

    private static View findFunCat(View v, int depth) {
        if (v == null || depth > 40 || v.getVisibility() != View.VISIBLE) return null;
        if (v instanceof ImageView) {
            CharSequence cd = v.getContentDescription();
            if (cd != null) {
                String s = cd.toString();
                for (String label : FUN_CAT_LABELS) if (label.equals(s)) return v;
            }
        }
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) {
                View r = findFunCat(g.getChildAt(i), depth + 1);
                if (r != null) return r;
            }
        }
        return null;
    }

    private static File cacheFile(Context ctx) {
        return new File(ctx.getFilesDir(), "margyt/cats/tilcayo.jpg");
    }

    private static File backupFile(Context ctx) {
        File dir = new File(ctx.getFilesDir(), "rootmymargyt");
        if (!dir.exists()) dir.mkdirs();
        return new File(dir, "tilcayo_original.jpg");
    }

    /** Приводит кэш MargyT в соответствие с настройкой. Вызывается при старте и при переключении. */
    public static void apply(Context ctx, PluginContext m) {
        if (ctx == null) return;
        try {
            File cache = cacheFile(ctx);
            File backup = backupFile(ctx);
            byte[] ours = LimitBugAssets.getJpegBytes();
            boolean isOurs = sameContent(cache, ours);

            if (isEnabled(m)) {
                if (isOurs) return;
                // Отложить оригинал, если он есть и ещё не отложен
                if (cache.length() > 0 && !backup.exists()) copy(cache, backup);
                File dir = cache.getParentFile();
                if (dir != null && !dir.exists()) dir.mkdirs();
                write(ours, cache);
            } else if (isOurs) {
                if (backup.length() > 0) {
                    copy(backup, cache);
                    backup.delete();
                } else {
                    cache.delete();
                }
            }
        } catch (Throwable t) {
            if (m != null) m.log("limit bug swap: " + t);
        }
    }

    private static boolean sameContent(File f, byte[] bytes) {
        if (f == null || !f.isFile() || f.length() != bytes.length) return false;
        try {
            byte[] have = new byte[bytes.length];
            InputStream in = new FileInputStream(f);
            try {
                int n = 0;
                while (n < have.length) {
                    int r = in.read(have, n, have.length - n);
                    if (r < 0) return false;
                    n += r;
                }
            } finally {
                in.close();
            }
            return Arrays.equals(have, bytes);
        } catch (Throwable t) {
            return false;
        }
    }

    private static void copy(File from, File to) throws Exception {
        InputStream in = new FileInputStream(from);
        try {
            byte[] all = new byte[(int) from.length()];
            int n = 0;
            while (n < all.length) {
                int r = in.read(all, n, all.length - n);
                if (r < 0) break;
                n += r;
            }
            write(Arrays.copyOf(all, n), to);
        } finally {
            in.close();
        }
    }

    /** Через временный файл: MargyT может читать кэш в этот же момент. */
    private static void write(byte[] bytes, File to) throws Exception {
        File tmp = new File(to.getParentFile(), to.getName() + ".rmm.tmp");
        FileOutputStream out = new FileOutputStream(tmp);
        try {
            out.write(bytes);
            out.flush();
        } finally {
            out.close();
        }
        if (to.exists()) to.delete();
        if (!tmp.renameTo(to)) {
            tmp.delete();
            throw new java.io.IOException("rename failed: " + to);
        }
    }
}
