package cat.narezany.rootmymargyt;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.ImageDecoder;
import android.graphics.drawable.AnimatedImageDrawable;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.util.Size;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;

import cat.narezany.margyt.plugin.PluginContext;

/**
 * BackdropMedia — общее хранилище картинок и GIF для трёх пользовательских слотов:
 * фон профиля, фон комментариев и живая аватарка.
 *
 * Файл копируется во внутреннюю память «как есть» (без перекодирования в JPEG), поэтому
 * GIF и анимированный WebP сохраняют анимацию. Тип определяется по сигнатуре файла и
 * записывается в расширение:
 *   slot.gif  — GIF (анимированный)
 *   slot.webp — анимированный WebP
 *   slot.img  — всё остальное (JPEG, PNG, статичный WebP ...)
 *
 * Анимация проигрывается через ImageDecoder / AnimatedImageDrawable (Android 9+).
 * На более старых Android гифка показывается первым кадром.
 */
public final class BackdropMedia {

    public static final String SLOT_PROFILE = "profile_bg";
    public static final String SLOT_COMMENTS = "comments_bg";
    public static final String SLOT_AVATAR = "live_avatar";

    public static final int KIND_NONE = 0;
    public static final int KIND_STATIC = 1;
    public static final int KIND_ANIMATED = 2;

    /** Больше этого не копируем: гифка на 100 МБ не нужна ни профилю, ни памяти телефона. */
    public static final long MAX_BYTES = 40L * 1024L * 1024L;

    public static final String[] SCRIM_NAMES = new String[] {
        "Без затемнения", "Тёмная подложка 25%", "Тёмная подложка 45%", "Светлая подложка 35%"
    };
    public static final int[] SCRIM_COLORS = new int[] {
        0x00000000, 0x40000000, 0x73000000, 0x59FFFFFF
    };
    public static final int DEFAULT_SCRIM = 1;

    private static final String[] EXTENSIONS = new String[] { "gif", "webp", "img" };

    private static volatile String lastError = "";

    private BackdropMedia() {}

    public static String lastError() {
        return lastError;
    }

    public static int scrimColor(int index) {
        if (index < 0 || index >= SCRIM_COLORS.length) index = DEFAULT_SCRIM;
        return SCRIM_COLORS[index];
    }

    // ------------------------------------------------------------------ файлы

    public static File dir(Context ctx) {
        File d = new File(ctx.getFilesDir(), "rootmymargyt/media");
        if (!d.exists()) d.mkdirs();
        return d;
    }

    /** Сохранённый файл слота или null. */
    public static File fileOf(Context ctx, String slot) {
        if (ctx == null || slot == null) return null;
        File d = dir(ctx);
        for (String e : EXTENSIONS) {
            File f = new File(d, slot + "." + e);
            if (f.isFile() && f.length() > 0) return f;
        }
        return null;
    }

    public static boolean has(Context ctx, String slot) {
        return fileOf(ctx, slot) != null;
    }

    public static boolean isAnimated(File f) {
        if (f == null) return false;
        String n = f.getName();
        return n.endsWith(".gif") || n.endsWith(".webp");
    }

    /** Меняется при каждом сохранении или удалении: по нему движки понимают, что надо перечитать файл. */
    public static long version(PluginContext m, String slot) {
        return m == null ? 0L : m.prefs().getLong(slot + "_ver", 0L);
    }

    private static void bump(PluginContext m, String slot) {
        if (m != null) m.prefs().edit().putLong(slot + "_ver", System.currentTimeMillis()).apply();
    }

    private static void deleteFinal(Context ctx, String slot) {
        File d = dir(ctx);
        for (String e : EXTENSIONS) {
            new File(d, slot + "." + e).delete();
        }
    }

    public static void clear(Context ctx, PluginContext m, String slot) {
        if (ctx == null) return;
        try {
            deleteFinal(ctx, slot);
            new File(dir(ctx), slot + ".tmp").delete();
        } catch (Throwable ignored) {}
        bump(m, slot);
    }

    // ------------------------------------------------------------------ сохранение

    public static int saveFromUri(Context ctx, Uri uri, String slot, PluginContext m) {
        if (ctx == null || uri == null) return KIND_NONE;
        InputStream in = null;
        try {
            in = ctx.getContentResolver().openInputStream(uri);
            if (in == null) {
                lastError = "Файл недоступен";
                return KIND_NONE;
            }
            return saveFromStream(ctx, in, slot, m);
        } catch (Throwable t) {
            lastError = "Не удалось открыть файл";
            return KIND_NONE;
        } finally {
            closeQuietly(in);
        }
    }

    public static int saveFromPath(Context ctx, String path, String slot, PluginContext m) {
        if (ctx == null || path == null || path.isEmpty()) return KIND_NONE;
        FileInputStream in = null;
        try {
            File src = new File(path);
            if (!src.isFile()) {
                lastError = "Файл не найден";
                return KIND_NONE;
            }
            in = new FileInputStream(src);
            return saveFromStream(ctx, in, slot, m);
        } catch (Throwable t) {
            lastError = "Не удалось прочитать файл";
            return KIND_NONE;
        } finally {
            closeQuietly(in);
        }
    }

    public static int saveFromStream(Context ctx, InputStream in, String slot, PluginContext m) {
        File d = dir(ctx);
        File tmp = new File(d, slot + ".tmp");
        FileOutputStream out = null;
        try {
            out = new FileOutputStream(tmp);
            byte[] buf = new byte[32 * 1024];
            long total = 0;
            int n;
            while ((n = in.read(buf)) > 0) {
                total += n;
                if (total > MAX_BYTES) {
                    lastError = "Файл больше 40 МБ";
                    closeQuietly(out);
                    out = null;
                    tmp.delete();
                    return KIND_NONE;
                }
                out.write(buf, 0, n);
            }
            out.flush();
            closeQuietly(out);
            out = null;

            if (total < 12) {
                lastError = "Файл пустой";
                tmp.delete();
                return KIND_NONE;
            }

            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(tmp.getAbsolutePath(), bounds);
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) {
                lastError = "Это не картинка";
                tmp.delete();
                return KIND_NONE;
            }

            String ext = sniff(tmp);
            deleteFinal(ctx, slot);
            File dest = new File(d, slot + "." + ext);
            if (!tmp.renameTo(dest)) {
                lastError = "Не удалось сохранить файл";
                tmp.delete();
                return KIND_NONE;
            }
            bump(m, slot);
            return "img".equals(ext) ? KIND_STATIC : KIND_ANIMATED;
        } catch (Throwable t) {
            lastError = "Ошибка сохранения";
            closeQuietly(out);
            tmp.delete();
            return KIND_NONE;
        }
    }

    /** gif | webp (анимированный) | img (всё остальное). */
    private static String sniff(File f) {
        byte[] h = new byte[32];
        int r = 0;
        FileInputStream in = null;
        try {
            in = new FileInputStream(f);
            r = in.read(h);
        } catch (Throwable t) {
            return "img";
        } finally {
            closeQuietly(in);
        }
        if (r < 12) return "img";
        if (h[0] == 'G' && h[1] == 'I' && h[2] == 'F' && h[3] == '8') return "gif";
        if (h[0] == 'R' && h[1] == 'I' && h[2] == 'F' && h[3] == 'F'
                && h[8] == 'W' && h[9] == 'E' && h[10] == 'B' && h[11] == 'P') {
            // расширенный заголовок VP8X: бит анимации (0x02) лежит в байте флагов со смещением 20
            if (r >= 21 && h[12] == 'V' && h[13] == 'P' && h[14] == '8' && h[15] == 'X'
                    && (h[20] & 0x02) != 0) {
                return "webp";
            }
        }
        return "img";
    }

    // ------------------------------------------------------------------ загрузка

    /**
     * Читает файл слота в Drawable: AnimatedImageDrawable для GIF/WebP (Android 9+),
     * иначе BitmapDrawable. Большие картинки уменьшаются до maxDim по длинной стороне.
     * Возвращает null, если прочитать не удалось.
     */
    public static Drawable load(Context ctx, File f, int maxDim) {
        if (ctx == null || f == null || !f.isFile()) return null;
        if (Build.VERSION.SDK_INT >= 28) {
            try {
                Drawable d = loadWithDecoder(f, maxDim);
                if (d != null) return d;
            } catch (Throwable ignored) {
                // упадём на обычный декодер ниже
            }
        }
        Bitmap b = decodeBitmap(f, maxDim);
        if (b == null) return null;
        return new BitmapDrawable(ctx.getResources(), b);
    }

    private static Drawable loadWithDecoder(File f, final int maxDim) throws Exception {
        ImageDecoder.Source src = ImageDecoder.createSource(f);
        Drawable d = ImageDecoder.decodeDrawable(src, new ImageDecoder.OnHeaderDecodedListener() {
            @Override
            public void onHeaderDecoded(ImageDecoder decoder, ImageDecoder.ImageInfo info,
                                        ImageDecoder.Source source) {
                Size s = info.getSize();
                int big = Math.max(s.getWidth(), s.getHeight());
                if (big > maxDim) {
                    // точное уменьшение до maxDim (для GIF масштабируются все кадры)
                    float k = maxDim / (float) big;
                    decoder.setTargetSize(Math.max(1, Math.round(s.getWidth() * k)),
                            Math.max(1, Math.round(s.getHeight() * k)));
                }
                decoder.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE);
            }
        });
        if (d instanceof AnimatedImageDrawable) {
            ((AnimatedImageDrawable) d).setRepeatCount(AnimatedImageDrawable.REPEAT_INFINITE);
        }
        return d;
    }

    /** Первый кадр (для GIF) или вся картинка, уменьшенная до maxDim по длинной стороне. */
    public static Bitmap decodeBitmap(File f, int maxDim) {
        if (f == null || !f.isFile()) return null;
        try {
            String p = f.getAbsolutePath();
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(p, o);
            if (o.outWidth <= 0 || o.outHeight <= 0) return null;
            int big = Math.max(o.outWidth, o.outHeight);
            // степень двойки, при которой картинка ещё не меньше maxDim: дальше доведём точным масштабом
            int sample = 1;
            while (big / (sample * 2) >= maxDim) sample *= 2;
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = sample;
            Bitmap b = BitmapFactory.decodeFile(p, o2);
            if (b == null) return null;
            int mx = Math.max(b.getWidth(), b.getHeight());
            if (mx > maxDim) {
                float k = maxDim / (float) mx;
                Bitmap scaled = Bitmap.createScaledBitmap(b,
                        Math.max(1, Math.round(b.getWidth() * k)),
                        Math.max(1, Math.round(b.getHeight() * k)), true);
                if (scaled != b) b.recycle();
                b = scaled;
            }
            return b;
        } catch (Throwable t) {
            return null;
        }
    }

    private static void closeQuietly(java.io.Closeable c) {
        if (c == null) return;
        try {
            c.close();
        } catch (Throwable ignored) {}
    }
}
