package cat.narezany.rootmymargyt;

import android.graphics.Matrix;
import android.graphics.Rect;
import android.graphics.SurfaceTexture;
import android.media.MediaPlayer;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import java.io.File;

/**
 * Видеофон профиля: беззвучный зацикленный ролик в TextureView.
 *
 * Видео нельзя нарисовать обычным Drawable, поэтому TextureView кладётся первым ребёнком
 * DecorView — под всё содержимое окна, но над фоном окна. Профиль должен быть сквозным
 * до него: RootWallpaperEngine снимает подложки с контейнера профиля и его предков.
 *
 * View всегда во весь decor и никогда не переразмечается: место и кадрирование задаются
 * матрицей setTransform, видимая область — setClipBounds. Поэтому обновление при
 * прокрутке шапки стоит одну перерисовку, без requestLayout.
 */
final class VideoWallpaper implements TextureView.SurfaceTextureListener {

    static final String VIEW_TAG = "rootmymargyt_video_wallpaper";

    interface Listener {
        /** Пошёл первый кадр — можно убирать статичную заглушку. */
        void onReady();

        void onError(String what);
    }

    private final TextureView view;
    private final File file;
    private final Listener listener;
    private MediaPlayer player;
    private Surface surface;
    private boolean ready = false;
    private boolean released = false;
    private int videoW = 0;
    private int videoH = 0;

    private final Rect area = new Rect();
    private final Rect clip = new Rect();
    private boolean full = true;
    private int maxLocalHeaderH = 0;

    private VideoWallpaper(ViewGroup decor, File file, Listener listener) {
        this.file = file;
        this.listener = listener;
        this.view = new TextureView(decor.getContext());
        view.setTag(VIEW_TAG);
        view.setOpaque(false);
        view.setFocusable(false);
        view.setClickable(false);
        view.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        view.setSurfaceTextureListener(this);
        view.setVisibility(View.INVISIBLE);
        decor.addView(view, 0, new FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    static VideoWallpaper attach(ViewGroup decor, File file, Listener listener) {
        View stale = decor.findViewWithTag(VIEW_TAG);
        if (stale != null) decor.removeView(stale);
        return new VideoWallpaper(decor, file, listener);
    }

    boolean isReady() {
        return ready && !released;
    }

    boolean isAttachedTo(ViewGroup decor) {
        return !released && view.getParent() == decor;
    }

    /**
     * @param masterRect   контейнер профиля в координатах decor
     * @param headerBottom низ шапки в координатах decor; &lt;= 0 — режим «весь профиль»
     */
    void setTarget(Rect masterRect, int headerBottom) {
        full = headerBottom <= 0;
        if (full) {
            area.set(masterRect);
            clip.set(masterRect);
        } else {
            int local = Math.max(0, headerBottom - masterRect.top);
            if (local > maxLocalHeaderH) maxLocalHeaderH = local;
            // Как у картинки: масштаб по самой высокой шапке, при схлопывании ролик уезжает вверх
            int shift = maxLocalHeaderH - local;
            area.set(masterRect.left, masterRect.top - shift, masterRect.right, masterRect.top - shift + maxLocalHeaderH);
            clip.set(masterRect.left, masterRect.top, masterRect.right, headerBottom);
        }
        applyTransform();
        if (!clip.equals(view.getClipBounds())) view.setClipBounds(new Rect(clip));
    }

    private void applyTransform() {
        int w = view.getWidth();
        int h = view.getHeight();
        if (w <= 0 || h <= 0 || videoW <= 0 || videoH <= 0 || area.isEmpty()) return;

        // TextureView растягивает кадр на свои границы; сначала возвращаем пропорции,
        // затем center-crop в area.
        float scale = Math.max((float) area.width() / videoW, (float) area.height() / videoH);
        float shownW = videoW * scale;
        float shownH = videoH * scale;
        Matrix m = new Matrix();
        m.setScale(shownW / w, shownH / h);
        m.postTranslate(area.centerX() - shownW / 2f, area.centerY() - shownH / 2f);
        view.setTransform(m);
        view.invalidate();
    }

    /** Свернули приложение: пауза, а не разборка — по возвращении видео просто продолжится. */
    void pause() {
        try {
            if (player != null && player.isPlaying()) player.pause();
        } catch (Throwable ignored) {}
    }

    void resume() {
        try {
            if (player != null && !player.isPlaying()) player.start();
        } catch (Throwable ignored) {
            // плеер ещё готовится — запустится сам в onPrepared
        }
    }

    void release() {
        if (released) return;
        released = true;
        releasePlayer();
        ViewGroup parent = (ViewGroup) view.getParent();
        if (parent != null) parent.removeView(view);
    }

    private void releasePlayer() {
        if (player != null) {
            try {
                player.release();
            } catch (Throwable ignored) {}
            player = null;
        }
        if (surface != null) {
            surface.release();
            surface = null;
        }
    }

    @Override
    public void onSurfaceTextureAvailable(SurfaceTexture st, int width, int height) {
        if (released) return;
        try {
            surface = new Surface(st);
            MediaPlayer mp = new MediaPlayer();
            player = mp;
            mp.setDataSource(file.getAbsolutePath());
            mp.setSurface(surface);
            mp.setLooping(true);
            mp.setVolume(0f, 0f);
            mp.setOnVideoSizeChangedListener((p, vw, vh) -> {
                videoW = vw;
                videoH = vh;
                applyTransform();
            });
            mp.setOnInfoListener((p, what, extra) -> {
                if (what == MediaPlayer.MEDIA_INFO_VIDEO_RENDERING_START && !released) {
                    ready = true;
                    view.setVisibility(View.VISIBLE);
                    if (listener != null) listener.onReady();
                }
                return false;
            });
            mp.setOnErrorListener((p, what, extra) -> {
                // При сворачивании плеер освобождается, и система может прислать «ошибку» уже
                // после этого — раньше из-за неё видео выключалось до перезапуска TikTok
                if (released || player != p) return true;
                if (listener != null) listener.onError("player error " + what + "/" + extra);
                return true;
            });
            mp.setOnPreparedListener(MediaPlayer::start);
            mp.prepareAsync();
        } catch (Throwable t) {
            if (listener != null) listener.onError(String.valueOf(t));
        }
    }

    @Override
    public void onSurfaceTextureSizeChanged(SurfaceTexture st, int width, int height) {
        applyTransform();
    }

    @Override
    public boolean onSurfaceTextureDestroyed(SurfaceTexture st) {
        releasePlayer();
        ready = false;
        return true;
    }

    @Override
    public void onSurfaceTextureUpdated(SurfaceTexture st) {}
}
