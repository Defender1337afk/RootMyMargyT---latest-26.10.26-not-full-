package cat.narezany.rootmymargyt;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Typeface;
import android.os.SystemClock;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import java.lang.ref.WeakReference;
import java.util.Random;

import cat.narezany.margyt.plugin.PluginContext;

/**
 * ClawdPetView — Clawd-питомец поверх TikTok. Тап — случайная эмоция, двойной тап — прыжок
 * с праздником, частые тапы — влюбляется, 45 секунд без внимания — засыпает. Таскается
 * пальцем, место запоминается.
 *
 * Тот же пиксельный Clawd, что в Clawd Run: тело 12×8, ручки, четыре ножки; эмоции — глаза
 * 3×3 пикселя, румянец, очки, колпачок и частицы. Перерисовка: во время эмоций — каждый
 * кадр, в покое — 10 раз в секунду (моргание), скрытый — никогда.
 */
public final class ClawdPetView extends View {

    public static final String KEY_ENABLED = "clawd_pet_enabled";
    public static final String KEY_WHERE = "clawd_pet_where";
    private static final String KEY_X = "clawd_pet_x";
    private static final String KEY_Y = "clawd_pet_y";
    private static final String KEY_SEEN = "clawd_pet_seen";
    public static final String[] WHERE_NAMES = {"Везде в TikTok", "Только в профиле"};
    public static final String KEY_REACT = "clawd_pet_react";
    public static final String KEY_TALK = "clawd_pet_talk";

    // События, на которые Clawd реагирует (EV_RAIL_BASE + тип кнопки ленты: 0 лайк … 3 поделиться)
    static final int EV_LIKE = 1, EV_SWIPE = 2, EV_PROFILE = 3, EV_RECORD = 4, EV_ACHIEVEMENT = 5,
        EV_COMMENT = 6, EV_VIDEO = 7, EV_RAIL_BASE = 100;
    public static final String KEY_SENSES = "clawd_pet_senses";

    private static final String[] SAY_LIKE = {"Ого, лайк! ❤", "Мне тоже понравилось", "Лайк засчитан", "Это база"};
    private static final String[] SAY_COMMENTS = {"Что там пишут?", "Ну-ка почитаем…", "Комменты — лучшая часть"};
    private static final String[] SAY_FAVORITE = {"Сохраним на потом 😎", "В избранное, отлично"};
    private static final String[] SAY_SHARE = {"Кидай друзьям!", "Поделимся!"};
    private static final String[] SAY_DIZZY = {"Помедленнее!", "Голова кружится…", "Столько видео…"};
    private static final String[] SAY_PROFILE = {"О, это мы!", "Красивый профиль", "Привет, я Clawd 👋"};
    private static final String[] SAY_NIGHT = {"Поздно уже… 🌙", "Ещё одно видео — и спать?"};
    private static final String[] SAY_SESSION = {"Уже час листаем 👀", "Может, перерыв? 🙂"};

    private static PluginContext margytStatic;
    private static int pendingEvent = 0, pendingArg = 0;
    private static String pendingText = null;
    private static long pendingAt = 0L;
    private static boolean lastProfileShown = false;
    private static long lastProfileReact = -600000L;
    private static final long SESSION_START = SystemClock.uptimeMillis();
    private static long lastSessionNudge = 0L;
    private static boolean greeted = false;
    public static final String TAG_VIEW = "rootmymargyt_clawd_pet";

    // Эмоции
    private static final int IDLE = 0, HAPPY = 1, LOVE = 2, SURPRISED = 3, ANGRY = 4, DIZZY = 5,
        CRY = 6, COOL = 7, WINK = 8, THINK = 9, PARTY = 10, SLEEPY = 11;
    private static final int[] TAP_EMOTIONS = {HAPPY, LOVE, SURPRISED, ANGRY, DIZZY, CRY, COOL, WINK, THINK, PARTY};
    private static final int ALL_SEEN = (1 << 12) - 2; // все, кроме IDLE

    // Частицы
    private static final int P_HEART = 0, P_Z = 1, P_TEAR = 2, P_CONFETTI = 3, P_STEAM = 4, P_QUESTION = 5, P_STAR = 6;
    private static final int MAX_P = 18;

    private static final int BODY = 0xFFD97757, BODY_LIGHT = 0xFFE8956F, BODY_DARK = 0xFFB85C3E,
        LEGS = 0xFFC4623F, EYE = 0xFF2B1A14, BLUSH = 0xFFFF8FA3, PINK = 0xFFFF4D6D;

    // Модель питомца: Clawd (как раньше) или Boykisser — белый котик с чёрной
    // обводкой и ушками. Скелет и все эмоции общие; у Boykisser фирменные «> <»
    // глаза уже совпадают с дефолтной эмоцией, меняются только палитра и ушки.
    public static final String KEY_MODEL = "clawd_pet_model";
    public static final int MODEL_CLAWD = 0, MODEL_BOYKISSER = 1;
    public static final String[] MODEL_NAMES = {"Clawd", "Boykisser"};
    // Палитра Boykisser.
    private static final int BK_BODY = 0xFFFFFFFF, BK_OUTLINE = 0xFF151515, BK_EAR_IN = 0xFFFF8FA3;
    private int model = MODEL_CLAWD;
    private static final int[] CONFETTI = {0xFFFFD54F, 0xFF4FC3F7, 0xFFFF8A65, 0xFF81C784, 0xFFBA68C8, 0xFFF06292};

    private static WeakReference<ClawdPetView> current = new WeakReference<>(null);
    /** decor, куда оверлей уже поставлен в очередь на добавление: пока он «в пути», второй не создаём. */
    private static WeakReference<ViewGroup> pendingFor = new WeakReference<>(null);
    /** Окно питомца: сверху место под колпачок и частицы, даже в прыжке. */
    private static final int VIEW_W_DP = 84, VIEW_H_DP = 100;

    private final PluginContext margyt;
    private final float d;
    private final float p;      // размер «пикселя» Clawd
    private final Random rnd = new Random();
    private final Paint pix = new Paint();
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path heart = new Path();
    private final Path spiral = new Path();
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);

    private int emotion = IDLE;
    private long emotionUntil = 0L;
    private long emotionStart = 0L;
    private long lastInteraction = SystemClock.uptimeMillis();
    private long nextBlink = 0L;
    private long blinkUntil = 0L;
    private long bounceStart = -10000L;
    private long hopStart = -10000L;
    private long lastEmit = 0L;
    private long lastFrame = 0L;
    private final long[] recentTaps = new long[5];
    private int tapIndex = 0;
    private long lastTapAt = 0L;

    private final int[] pType = new int[MAX_P];
    private final float[] pX = new float[MAX_P], pY = new float[MAX_P], pVX = new float[MAX_P], pVY = new float[MAX_P];
    private final float[] pLife = new float[MAX_P], pMax = new float[MAX_P];
    private final int[] pColor = new int[MAX_P];

    private float downRawX, downRawY, startTX, startTY;
    private boolean dragging = false;
    private final int slop;

    private ClawdBubbleView bubble;
    private long lastReact = 0L;
    private final long[] swipes = new long[6];
    private int swipeIndex = 0;
    private long dizzyCooldownUntil = 0L;
    private long lastClockCheck = 0L;
    private boolean night = false;

    // Прогулка вокруг «дома» — места, куда Clawd поставили
    private float homeX = Float.NaN;
    private float walkFrom, walkTo;
    private long walkStart = 0L, nextWalkAt = 0L;
    private static final long WALK_MS = 1600L;

    private ClawdPetView(Context ctx, PluginContext margyt) {
        super(ctx);
        this.margyt = margyt;
        this.model = getModel(margyt);
        this.d = ctx.getResources().getDisplayMetrics().density;
        this.p = 4f * d;
        this.slop = ViewConfiguration.get(ctx).getScaledTouchSlop();
        setClickable(true);
        setContentDescription("Clawd");
        text.setTypeface(Typeface.create("sans-serif-black", Typeface.NORMAL));
        text.setTextAlign(Paint.Align.CENTER);
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeCap(Paint.Cap.ROUND);
        line.setStrokeWidth(0.7f * p);
        line.setColor(EYE);
        scheduleBlink(SystemClock.uptimeMillis());
    }

    // ───────────────────────────── настройки и показ

    public static boolean isEnabled(PluginContext m) {
        return m != null && m.getBoolean(KEY_ENABLED, false);
    }

    public static int getWhere(PluginContext m) {
        int w = m != null ? m.getInt(KEY_WHERE, 0) : 0;
        return w == 1 ? 1 : 0;
    }

    public static void setWhere(PluginContext m, int where) {
        if (m != null) m.prefs().edit().putInt(KEY_WHERE, where).apply();
    }

    public static int getModel(PluginContext m) {
        int v = m != null ? m.getInt(KEY_MODEL, MODEL_CLAWD) : MODEL_CLAWD;
        return v == MODEL_BOYKISSER ? MODEL_BOYKISSER : MODEL_CLAWD;
    }

    public static void setModel(PluginContext m, int model) {
        if (m != null) m.prefs().edit().putInt(KEY_MODEL, model == MODEL_BOYKISSER ? MODEL_BOYKISSER : MODEL_CLAWD).apply();
    }

    /** Из preDraw-наблюдателя. */
    public static void update(final Activity activity, final PluginContext m, boolean profileShown) {
        try {
            if (activity == null || activity.isFinishing() || activity.getWindow() == null) return;
            final ViewGroup decor = (ViewGroup) activity.getWindow().getDecorView();
            ClawdPetView v = current.get();
            if (v != null && v.getParent() != decor) v = null;

            // В экранах самого мода (настройки MargyT) питомец не нужен
            boolean modScreen = activity.getClass().getName().startsWith("cat.narezany.margyt");
            boolean want = isEnabled(m) && !modScreen && (getWhere(m) == 0 || profileShown);
            margytStatic = m;
            // Смена модели применяется живьём, без пересоздания питомца.
            if (v != null) { int nm = getModel(m); if (v.model != nm) { v.model = nm; v.invalidate(); } }
            if (!want) {
                if (v != null && v.getVisibility() != GONE) v.setVisibility(GONE);
                if (v != null && v.bubble != null && v.bubble.getVisibility() != GONE) v.bubble.setVisibility(GONE);
                lastProfileShown = profileShown;
                return;
            }
            if (v == null) {
                // preDraw идёт каждый кадр, а добавление — после кадра: без этой проверки
                // за время ожидания создавались дубли
                if (pendingFor.get() == decor || decor.findViewWithTag(TAG_VIEW) != null) return;
                final ClawdPetView fresh = new ClawdPetView(activity, m);
                fresh.setTag(TAG_VIEW);
                pendingFor = new WeakReference<>(decor);
                decor.post(() -> {
                    pendingFor = new WeakReference<>(null);
                    if (fresh.getParent() == null && !activity.isFinishing() && decor.findViewWithTag(TAG_VIEW) == null) {
                        decor.addView(fresh, new FrameLayout.LayoutParams(
                            Math.round(VIEW_W_DP * fresh.d), Math.round(VIEW_H_DP * fresh.d)));
                        fresh.place(decor);
                        current = new WeakReference<>(fresh);
                        // Облачко — отдельный некликабельный вид рядом: касания идут сквозь него
                        ClawdBubbleView b = new ClawdBubbleView(activity);
                        b.setTag(ClawdBubbleView.TAG_VIEW);
                        decor.addView(b, new FrameLayout.LayoutParams(1, 1));
                        fresh.bubble = b;
                    }
                });
                return;
            }
            if (v.getVisibility() != VISIBLE) {
                v.setVisibility(VISIBLE);
                v.bringToFront();
                if (v.bubble != null) v.bubble.bringToFront();
                v.invalidate();
            }
            long now = SystemClock.uptimeMillis();
            // Зашли в свой профиль — иногда радуется (не чаще раза в 3 минуты)
            if (profileShown && !lastProfileShown && now - lastProfileReact > 180000L && isReact(m)) {
                lastProfileReact = now;
                v.handleEvent(EV_PROFILE, 0, null);
            }
            lastProfileShown = profileShown;
            // Рекорд или ачивка случились, пока Clawd был скрыт
            if (pendingEvent != 0) {
                int e = pendingEvent;
                pendingEvent = 0;
                if (now - pendingAt < 600000L) v.handleEvent(e, pendingArg, pendingText);
            }
        } catch (Throwable ignored) {}
    }

    public static boolean isReact(PluginContext m) {
        return m == null || m.getBoolean(KEY_REACT, true);
    }

    public static boolean isTalk(PluginContext m) {
        return m == null || m.getBoolean(KEY_TALK, true);
    }

    /** Читает комментарии и «смотрит» видео. */
    public static boolean isSenses(PluginContext m) {
        return m == null || m.getBoolean(KEY_SENSES, true);
    }

    static boolean wantsSenses() {
        return wantsReactions() && isSenses(margytStatic) && isTalk(margytStatic);
    }

    /** Для TouchSpy: стоит ли вообще смотреть на касания. */
    static boolean wantsReactions() {
        ClawdPetView v = current.get();
        return v != null && v.getVisibility() == VISIBLE && isEnabled(margytStatic) && isReact(margytStatic);
    }

    static boolean isOverPet(float rawX, float rawY) {
        ClawdPetView v = current.get();
        if (v == null || v.getVisibility() != VISIBLE) return false;
        android.graphics.Rect r = new android.graphics.Rect();
        return v.getGlobalVisibleRect(r) && r.contains((int) rawX, (int) rawY);
    }

    /** Событие из TikTok / игры. Если Clawd скрыт — рекорд и ачивку он отметит, когда появится. */
    static void react(int event, int arg) {
        react(event, arg, null);
    }

    static void react(int event, int arg, String text) {
        try {
            if (!isEnabled(margytStatic) || !isReact(margytStatic)) return;
            ClawdPetView v = current.get();
            if (v == null || v.getVisibility() != VISIBLE) {
                if (event == EV_RECORD || event == EV_ACHIEVEMENT) {
                    pendingEvent = event;
                    pendingArg = arg;
                    pendingText = text;
                    pendingAt = SystemClock.uptimeMillis();
                }
                return;
            }
            v.handleEvent(event, arg, text);
        } catch (Throwable ignored) {}
    }

    private String pick(String[] lines) {
        return lines[rnd.nextInt(lines.length)];
    }

    private void say(String line) {
        if (bubble != null && isTalk(margyt)) bubble.say(line);
    }

    private void handleEvent(int event, int arg, String text) {
        long now = SystemClock.uptimeMillis();
        boolean important = event == EV_RECORD || event == EV_ACHIEVEMENT;
        if (event == EV_SWIPE) {
            // Шесть пролистываний за 7 секунд — кружится голова
            swipes[swipeIndex] = now;
            swipeIndex = (swipeIndex + 1) % swipes.length;
            if (now - swipes[swipeIndex] > 7000L || now < dizzyCooldownUntil) return;
            dizzyCooldownUntil = now + 30000L;
            setEmotion(DIZZY, now);
            say(pick(SAY_DIZZY));
        } else {
            if (!important && now - lastReact < 1200L) return;
            switch (event) {
                case EV_LIKE:
                case EV_RAIL_BASE:
                    setEmotion(LOVE, now);
                    say(pick(SAY_LIKE));
                    break;
                case EV_RAIL_BASE + 1:
                    setEmotion(THINK, now);
                    say(pick(SAY_COMMENTS));
                    break;
                case EV_RAIL_BASE + 2:
                    setEmotion(COOL, now);
                    say(pick(SAY_FAVORITE));
                    break;
                case EV_RAIL_BASE + 3:
                    setEmotion(HAPPY, now);
                    say(pick(SAY_SHARE));
                    break;
                case EV_PROFILE:
                    setEmotion(HAPPY, now);
                    say(pick(SAY_PROFILE));
                    break;
                case EV_RECORD:
                    hopStart = now;
                    setEmotion(PARTY, now);
                    say("Новый рекорд: " + arg + "! 🏆");
                    break;
                case EV_ACHIEVEMENT:
                    hopStart = now;
                    setEmotion(PARTY, now);
                    say(text != null ? "Ачивка: " + text + "!" : "Ачивка!");
                    break;
                case EV_COMMENT:
                    // Настроение комментария → эмоция Clawd
                    setEmotion(arg == ClawdBrain.FUNNY ? HAPPY : arg == ClawdBrain.SAD ? CRY
                        : arg == ClawdBrain.ANGRY ? ANGRY : arg == ClawdBrain.LOVE ? LOVE : SURPRISED, now);
                    if (text != null) say(text);
                    break;
                case EV_VIDEO:
                    setEmotion(THINK, now);
                    if (text != null) say(text);
                    break;
                default:
                    return;
            }
        }
        lastReact = now;
        bounceStart = now;
        lastInteraction = now;
        invalidate();
    }

    private void place(View parent) {
        int pw = parent.getWidth() > 0 ? parent.getWidth() : getResources().getDisplayMetrics().widthPixels;
        int ph = parent.getHeight() > 0 ? parent.getHeight() : getResources().getDisplayMetrics().heightPixels;
        float w = VIEW_W_DP * d, h = VIEW_H_DP * d;
        float fx = margyt != null ? margyt.prefs().getFloat(KEY_X, -1f) : -1f;
        float fy = margyt != null ? margyt.prefs().getFloat(KEY_Y, -1f) : -1f;
        float x = fx < 0 ? pw - w - 12 * d : fx * pw;
        float y = fy < 0 ? ph * 0.56f : fy * ph;
        setTranslationX(Math.max(0, Math.min(pw - w, x)));
        setTranslationY(Math.max(0, Math.min(ph - h, y)));
        homeX = getTranslationX();
        nextWalkAt = SystemClock.uptimeMillis() + 6000L;
    }

    // ───────────────────────────── касания

    @Override
    public boolean onTouchEvent(MotionEvent ev) {
        View parent = getParent() instanceof View ? (View) getParent() : null;
        switch (ev.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                walkStart = 0L; // взяли в руки — прогулка прерывается
                downRawX = ev.getRawX();
                downRawY = ev.getRawY();
                startTX = getTranslationX();
                startTY = getTranslationY();
                dragging = false;
                return true;
            case MotionEvent.ACTION_MOVE: {
                float dx = ev.getRawX() - downRawX, dy = ev.getRawY() - downRawY;
                if (!dragging && Math.hypot(dx, dy) > slop) dragging = true;
                if (dragging && parent != null) {
                    setTranslationX(Math.max(0, Math.min(parent.getWidth() - getWidth(), startTX + dx)));
                    setTranslationY(Math.max(0, Math.min(parent.getHeight() - getHeight(), startTY + dy)));
                }
                return true;
            }
            case MotionEvent.ACTION_UP:
                if (dragging) {
                    if (parent != null && margyt != null && parent.getWidth() > 0) {
                        margyt.prefs().edit()
                            .putFloat(KEY_X, getTranslationX() / parent.getWidth())
                            .putFloat(KEY_Y, getTranslationY() / parent.getHeight())
                            .apply();
                    }
                    homeX = getTranslationX();
                    walkStart = 0L;
                    nextWalkAt = SystemClock.uptimeMillis() + 8000L;
                } else {
                    onTap();
                }
                dragging = false;
                return true;
            case MotionEvent.ACTION_CANCEL:
                dragging = false;
                return true;
            default:
                return true;
        }
    }

    private void onTap() {
        long now = SystemClock.uptimeMillis();
        performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
        Activity act = getContext() instanceof Activity ? (Activity) getContext() : null;
        int taps = Achievements.add(margyt, "pet_taps", 1);
        if (taps >= 50) Achievements.unlockWithToast(act, margyt, "pet_50");

        boolean wasSleeping = emotion == SLEEPY;
        boolean doubleTap = now - lastTapAt < 300L;
        lastTapAt = now;
        recentTaps[tapIndex] = now;
        tapIndex = (tapIndex + 1) % recentTaps.length;
        boolean petting = now - recentTaps[tapIndex] < 2000L; // пять тапов за 2 секунды

        if (wasSleeping) {
            setEmotion(SURPRISED, now);
            Achievements.unlockWithToast(act, margyt, "wake_up");
            if (night) say(pick(SAY_NIGHT));
        } else if (doubleTap) {
            hopStart = now;
            setEmotion(PARTY, now);
        } else if (petting) {
            setEmotion(LOVE, now);
            say("Мур… то есть, биип ❤");
        } else {
            int next;
            do {
                next = TAP_EMOTIONS[rnd.nextInt(TAP_EMOTIONS.length)];
            } while (next == emotion);
            setEmotion(next, now);
        }
        bounceStart = now;
        lastInteraction = now;
        invalidate();
    }

    private void setEmotion(int e, long now) {
        emotion = e;
        emotionStart = now;
        emotionUntil = e == SLEEPY ? Long.MAX_VALUE : now + 2600L;
        lastEmit = 0L;
        burst(e);
        int seen = margyt != null ? margyt.getInt(KEY_SEEN, 0) : 0;
        int nowSeen = seen | (1 << e);
        if (nowSeen != seen && margyt != null) {
            margyt.prefs().edit().putInt(KEY_SEEN, nowSeen).apply();
            if ((nowSeen & ALL_SEEN) == ALL_SEEN) {
                Achievements.unlockWithToast(getContext() instanceof Activity ? (Activity) getContext() : null, margyt, "all_emotions");
            }
        }
    }

    private void scheduleBlink(long now) {
        nextBlink = now + 2500 + rnd.nextInt(2500);
    }

    // ───────────────────────────── частицы

    private float headX() {
        return getWidth() / 2f;
    }

    private float headY() {
        return getHeight() - 11 * p;
    }

    private void spawn(int type, float x, float y, float vx, float vy, float life, int color) {
        for (int i = 0; i < MAX_P; i++) {
            if (pLife[i] > 0) continue;
            pType[i] = type;
            pX[i] = x;
            pY[i] = y;
            pVX[i] = vx;
            pVY[i] = vy;
            pLife[i] = life;
            pMax[i] = life;
            pColor[i] = color;
            return;
        }
    }

    /** Разовый всплеск при смене эмоции. */
    private void burst(int e) {
        float x = headX(), y = headY();
        switch (e) {
            case LOVE:
                for (int i = 0; i < 3; i++) spawn(P_HEART, x + (i - 1) * 8 * d, y, (i - 1) * 10 * d, -30 * d, 1.2f, PINK);
                break;
            case PARTY:
                for (int i = 0; i < 12; i++) {
                    double a = -Math.PI * rnd.nextFloat();
                    float sp = (40 + rnd.nextFloat() * 50) * d;
                    spawn(P_CONFETTI, x, y, (float) Math.cos(a) * sp, (float) Math.sin(a) * sp, 1.3f, CONFETTI[i % CONFETTI.length]);
                }
                break;
            case THINK:
                spawn(P_QUESTION, x + 14 * d, y - 4 * d, 0, -6 * d, 2.4f, 0xFFFFFFFF);
                break;
            case SURPRISED:
                spawn(P_STAR, x - 18 * d, y + 2 * d, -12 * d, -14 * d, 0.6f, 0xFFFFE082);
                spawn(P_STAR, x + 18 * d, y + 2 * d, 12 * d, -14 * d, 0.6f, 0xFFFFE082);
                break;
            default:
                break;
        }
    }

    /** Постоянный «поток» частиц для некоторых эмоций. */
    private void emit(long now) {
        float x = headX(), y = headY();
        long every;
        switch (emotion) {
            case LOVE: every = 500; break;
            case SLEEPY: every = 900; break;
            case CRY: every = 320; break;
            case ANGRY: every = 420; break;
            default: return;
        }
        if (now - lastEmit < every) return;
        lastEmit = now;
        switch (emotion) {
            case LOVE:
                spawn(P_HEART, x + (rnd.nextFloat() - 0.5f) * 30 * d, y, (rnd.nextFloat() - 0.5f) * 14 * d, -28 * d, 1.2f, PINK);
                break;
            case SLEEPY:
                spawn(P_Z, x + 14 * d, y - 2 * d, 8 * d, -16 * d, 1.8f, 0xFFFFFFFF);
                break;
            case CRY: {
                boolean left = rnd.nextBoolean();
                float ex = getWidth() / 2f + (left ? -3.5f : 3.5f) * p;
                spawn(P_TEAR, ex, headY() + 6 * p, 0, 30 * d, 0.7f, 0xFF64B5F6);
                break;
            }
            case ANGRY:
                spawn(P_STEAM, x + (rnd.nextBoolean() ? -1 : 1) * 22 * d, y + 4 * d, 0, -22 * d, 0.8f, 0xCCFFFFFF);
                break;
            default:
                break;
        }
    }

    private boolean stepParticles(float dt) {
        boolean any = false;
        for (int i = 0; i < MAX_P; i++) {
            if (pLife[i] <= 0) continue;
            any = true;
            pLife[i] -= dt;
            pX[i] += pVX[i] * dt;
            pY[i] += pVY[i] * dt;
            if (pType[i] == P_CONFETTI || pType[i] == P_TEAR) pVY[i] += 160 * d * dt; // падают
        }
        return any;
    }

    // ───────────────────────────── отрисовка

    @Override
    protected void onDraw(Canvas c) {
        long now = SystemClock.uptimeMillis();
        float dt = lastFrame == 0 ? 0f : Math.min(0.05f, (now - lastFrame) / 1000f);
        lastFrame = now;

        if (emotion != SLEEPY && emotion != IDLE && now > emotionUntil) emotion = IDLE;
        checkClock(now);
        // Ночью засыпает быстрее
        if (emotion == IDLE && now - lastInteraction > (night ? 15000L : 45000L)) setEmotion(SLEEPY, now);
        float walk = stepWalk(now);
        if (emotion == IDLE && now > nextBlink) {
            blinkUntil = now + 130;
            scheduleBlink(now);
        }
        emit(now);
        boolean particles = stepParticles(dt);

        // Пружинка после тапа и прыжок
        float tb = (now - bounceStart) / 1000f;
        float squash = tb < 0.8f ? (float) (0.16 * Math.sin(tb * 22) * Math.exp(-tb * 6)) : 0f;
        float th = (now - hopStart) / 1000f;
        float hop = th < 0.45f ? (float) Math.sin(Math.PI * th / 0.45f) * 22 * d : 0f;
        float breathe = emotion == SLEEPY ? (float) Math.sin(now / 700.0) * 0.03f : 0f;

        float feetX = getWidth() / 2f, feetY = getHeight() - 2 * d;
        // Тень
        fill.setColor(0x33000000);
        float sh = 1f - hop / (60 * d);
        c.drawOval(feetX - 7 * p * sh, feetY - 2 * d, feetX + 7 * p * sh, feetY + 2 * d, fill);

        c.save();
        c.translate(0, -hop);
        c.scale(1f - squash, 1f + squash + breathe, feetX, feetY);
        drawClawd(c, feetX, feetY, now);
        c.restore();

        drawParticles(c);
        if (emotion == DIZZY) drawOrbit(c, now);

        // Облачко держится над головой, куда бы Clawd ни ушёл
        if (bubble != null && bubble.isTalking() && getParent() instanceof View) {
            bubble.follow(getTranslationX() + getWidth() / 2f, getTranslationY() + getHeight() - 11 * p - 6 * d - hop,
                ((View) getParent()).getWidth());
        }

        boolean moving = tb < 0.8f || th < 0.45f || walk > 0f;
        if (moving || (emotion != IDLE && emotion != SLEEPY)) postInvalidateOnAnimation();
        else if (emotion == SLEEPY || particles) postInvalidateDelayed(50);  // дыхание и «z» — 20 кадров хватает
        else postInvalidateDelayed(100);                                      // покой: только моргание
    }

    /** Раз в 5 секунд: ночь ли, не пора ли напомнить про перерыв, поздороваться утром. */
    private void checkClock(long now) {
        if (now - lastClockCheck < 5000L) return;
        lastClockCheck = now;
        int hour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY);
        night = hour < 6;
        if (!isReact(margyt) || emotion != IDLE) return;
        if (!greeted) {
            greeted = true;
            if (hour >= 6 && hour < 11) {
                setEmotion(HAPPY, now);
                say("Доброе утро! ☀");
                return;
            }
        }
        if (now - SESSION_START > 3600000L && now - lastSessionNudge > 1800000L) {
            lastSessionNudge = now;
            setEmotion(THINK, now);
            say(pick(SAY_SESSION));
        }
    }

    /** Прогулка: в покое изредка проходит пару шагов вокруг дома. Возвращает ход (0, если стоит). */
    private float stepWalk(long now) {
        if (Float.isNaN(homeX) || dragging || !(getParent() instanceof View)) return 0f;
        if (walkStart == 0L) {
            if (emotion != IDLE || now < nextWalkAt) return 0f;
            int pw = ((View) getParent()).getWidth();
            float range = 40 * d;
            walkFrom = getTranslationX();
            walkTo = Math.max(0f, Math.min(pw - getWidth(), homeX + (rnd.nextFloat() * 2f - 1f) * range));
            walkStart = now;
        }
        float t = (now - walkStart) / (float) WALK_MS;
        if (t >= 1f) {
            setTranslationX(walkTo);
            walkStart = 0L;
            nextWalkAt = now + 8000L + rnd.nextInt(7000);
            return 0f;
        }
        float e = t < 0.5f ? 2 * t * t : 1 - (float) Math.pow(-2 * t + 2, 2) / 2; // плавно разгоняется и тормозит
        setTranslationX(walkFrom + (walkTo - walkFrom) * e);
        return 1f;
    }

    private void px(Canvas c, float left, float top, int col, int row, int w, int h, int color) {
        pix.setColor(color);
        c.drawRect(left + col * p, top + row * p, left + (col + w) * p, top + (row + h) * p, pix);
    }

    private void drawClawd(Canvas c, float feetX, float feetY, long now) {
        int bodyW = 12, bodyH = 8, legH = 3;
        float left = feetX - bodyW * p / 2f;
        float top = feetY - (bodyH + legH) * p;
        boolean bk = model == MODEL_BOYKISSER;
        int baseBody = bk ? BK_BODY : BODY;
        int legCol = bk ? BK_BODY : LEGS;
        int body = emotion == ANGRY ? M3X.mix(baseBody, 0xFFE53935, 0.35f + 0.1f * (float) Math.sin(now / 90.0)) : baseBody;

        // Кошачьи ушки Boykisser — за телом, поэтому рисуем первыми
        if (bk) {
            boykisserEar(c, left, top, 0, true);
            boykisserEar(c, left, top, bodyW - 4, false);
        }

        // Ножки (во сне неподвижны, в покое чуть переступают)
        boolean walking = walkStart != 0L && now - walkStart < WALK_MS;
        boolean step = emotion != SLEEPY && ((now / (walking ? 140 : 400)) % 2 == 0);
        int[] cols = {1, 4, bodyW - 5, bodyW - 2};
        for (int k = 0; k < 4; k++) {
            int lift = step && (emotion == PARTY || walking) && (k % 2 == 0) ? 1
                : !step && walking && (k % 2 == 1) ? 1 : 0;
            int lh = legH - lift;
            px(c, left, top, cols[k], bodyH, 1, lh, legCol);
            if (bk) px(c, left, top, cols[k], bodyH + lh - 1, 1, 1, BK_OUTLINE); // носочки-обводка
        }
        // Ручки (на празднике подняты)
        int armRow = emotion == PARTY ? 1 : 3;
        px(c, left, top, -1, armRow, 1, 2, body);
        px(c, left, top, bodyW, armRow, 1, 2, body);
        // Тело
        px(c, left, top, 0, 0, bodyW, bodyH, body);
        if (bk) {
            // Белое тело с чёткой чёрной обводкой (как на рисунке boykisser)
            px(c, left, top, 0, 0, bodyW, 1, BK_OUTLINE);           // верх
            px(c, left, top, 0, bodyH - 1, bodyW, 1, BK_OUTLINE);   // низ
            px(c, left, top, 0, 0, 1, bodyH, BK_OUTLINE);           // левый край
            px(c, left, top, bodyW - 1, 0, 1, bodyH, BK_OUTLINE);   // правый край
            px(c, left, top, -1, armRow, 1, 1, BK_OUTLINE);         // кончики ручек
            px(c, left, top, bodyW, armRow + 1, 1, 1, BK_OUTLINE);
        } else {
            px(c, left, top, 0, 0, bodyW, 1, emotion == ANGRY ? M3X.mix(BODY_LIGHT, 0xFFFF7043, 0.4f) : BODY_LIGHT);
            px(c, left, top, 0, bodyH - 1, bodyW, 1, BODY_DARK);
            px(c, left, top, bodyW - 1, 1, 1, bodyH - 1, BODY_DARK);
        }

        // Колпачок на празднике
        if (emotion == PARTY) {
            px(c, left, top, 3, -1, 6, 1, 0xFF7E57C2);
            px(c, left, top, 4, -2, 4, 1, 0xFFFFD54F);
            px(c, left, top, 5, -3, 2, 1, 0xFF7E57C2);
            px(c, left, top, 5, -4, 2, 1, 0xFFF06292);
        }

        drawFace(c, left, top, bodyW, now);
    }

    private void drawFace(Canvas c, float left, float top, int bodyW, long now) {
        int lx = 2, rx = bodyW - 5, ey = 3;
        boolean blink = emotion == IDLE && now < blinkUntil;
        switch (blink ? -1 : emotion) {
            case -1: // моргнул
                px(c, left, top, lx, ey + 1, 3, 1, EYE);
                px(c, left, top, rx, ey + 1, 3, 1, EYE);
                break;
            case HAPPY:
            case PARTY:
                caret(c, left, top, lx, ey);
                caret(c, left, top, rx, ey);
                px(c, left, top, 1, 6, 1, 1, BLUSH);
                px(c, left, top, bodyW - 2, 6, 1, 1, BLUSH);
                px(c, left, top, 5, 5, 2, 1, EYE); // улыбка
                px(c, left, top, 4, 4, 1, 1, EYE);
                px(c, left, top, 7, 4, 1, 1, EYE);
                break;
            case LOVE:
                heartEye(c, left + (lx + 1.5f) * p, top + (ey + 1.5f) * p);
                heartEye(c, left + (rx + 1.5f) * p, top + (ey + 1.5f) * p);
                px(c, left, top, 1, 6, 1, 1, BLUSH);
                px(c, left, top, bodyW - 2, 6, 1, 1, BLUSH);
                break;
            case SURPRISED:
                ring(c, left, top, lx, ey);
                ring(c, left, top, rx, ey);
                px(c, left, top, 5, 6, 2, 1, EYE); // «о»
                break;
            case ANGRY:
                px(c, left, top, lx, ey - 1, 1, 1, EYE);
                px(c, left, top, lx + 1, ey, 1, 1, EYE);
                px(c, left, top, lx + 2, ey + 1, 1, 1, EYE);
                px(c, left, top, rx + 2, ey - 1, 1, 1, EYE);
                px(c, left, top, rx + 1, ey, 1, 1, EYE);
                px(c, left, top, rx, ey + 1, 1, 1, EYE);
                px(c, left, top, lx + 1, ey + 2, 1, 1, EYE);
                px(c, left, top, rx + 1, ey + 2, 1, 1, EYE);
                px(c, left, top, 4, 6, 4, 1, EYE); // сжатый рот
                break;
            case DIZZY:
                swirl(c, left + (lx + 1.5f) * p, top + (ey + 1.5f) * p, now, false);
                swirl(c, left + (rx + 1.5f) * p, top + (ey + 1.5f) * p, now, true);
                break;
            case CRY:
                px(c, left, top, lx, ey, 3, 1, EYE);
                px(c, left, top, lx + 1, ey + 1, 1, 2, EYE);
                px(c, left, top, rx, ey, 3, 1, EYE);
                px(c, left, top, rx + 1, ey + 1, 1, 2, EYE);
                px(c, left, top, lx + 1, ey + 3, 1, 1, 0xFF64B5F6);
                px(c, left, top, rx + 1, ey + 3, 1, 1, 0xFF64B5F6);
                break;
            case COOL:
                px(c, left, top, 1, ey, bodyW - 2, 1, 0xFF111111);
                px(c, left, top, lx, ey, 3, 2, 0xFF111111);
                px(c, left, top, rx, ey, 3, 2, 0xFF111111);
                px(c, left, top, lx, ey, 1, 1, 0xFFFFFFFF);
                px(c, left, top, rx, ey, 1, 1, 0xFFFFFFFF);
                px(c, left, top, 5, 6, 3, 1, EYE); // ухмылка
                px(c, left, top, 8, 5, 1, 1, EYE);
                break;
            case WINK:
                gt(c, left, top, lx, ey);
                px(c, left, top, rx, ey + 1, 3, 1, EYE);
                px(c, left, top, 5, 6, 2, 1, EYE);
                break;
            case THINK:
                px(c, left, top, lx + 2, ey, 1, 1, EYE);
                px(c, left, top, rx + 2, ey, 1, 1, EYE);
                px(c, left, top, 6, 6, 2, 1, EYE);
                break;
            case SLEEPY:
                px(c, left, top, lx, ey + 2, 3, 1, EYE);
                px(c, left, top, rx, ey + 2, 3, 1, EYE);
                break;
            default: // фирменные > <
                gt(c, left, top, lx, ey);
                lt(c, left, top, rx, ey);
                if (model == MODEL_BOYKISSER) { // блаш и ротик, как на рисунке boykisser
                    px(c, left, top, 1, 6, 1, 1, BLUSH);
                    px(c, left, top, bodyW - 2, 6, 1, 1, BLUSH);
                    px(c, left, top, 5, 6, 2, 1, EYE);
                }
                break;
        }
    }

    private void gt(Canvas c, float l, float t, int x, int y) {
        px(c, l, t, x, y, 1, 1, EYE);
        px(c, l, t, x + 1, y + 1, 1, 1, EYE);
        px(c, l, t, x, y + 2, 1, 1, EYE);
    }

    private void lt(Canvas c, float l, float t, int x, int y) {
        px(c, l, t, x + 2, y, 1, 1, EYE);
        px(c, l, t, x + 1, y + 1, 1, 1, EYE);
        px(c, l, t, x + 2, y + 2, 1, 1, EYE);
    }

    /** Треугольное кошачье ушко Boykisser: белое с чёрной обводкой и розовой серединкой. */
    private void boykisserEar(Canvas c, float left, float top, int baseCol, boolean leftEar) {
        int earH = 4;
        for (int i = 0; i < earH; i++) {
            int row = -earH + i;        // -4..-1, кончик сверху
            int w = i + 1;              // 1..4, расширяется книзу
            int col = leftEar ? baseCol : baseCol + (earH - w);
            px(c, left, top, col, row, w, 1, BK_BODY);              // белая заливка
            px(c, left, top, col, row, 1, 1, BK_OUTLINE);          // левый край
            px(c, left, top, col + w - 1, row, 1, 1, BK_OUTLINE);  // правый край
        }
        px(c, left, top, baseCol + (leftEar ? 1 : 2), -1, 1, 1, BK_EAR_IN); // розовая серединка
    }

    private void caret(Canvas c, float l, float t, int x, int y) {
        px(c, l, t, x, y + 1, 1, 1, EYE);
        px(c, l, t, x + 1, y, 1, 1, EYE);
        px(c, l, t, x + 2, y + 1, 1, 1, EYE);
    }

    private void ring(Canvas c, float l, float t, int x, int y) {
        px(c, l, t, x, y, 3, 1, EYE);
        px(c, l, t, x, y + 2, 3, 1, EYE);
        px(c, l, t, x, y + 1, 1, 1, EYE);
        px(c, l, t, x + 2, y + 1, 1, 1, EYE);
    }

    /** Спиралька в два витка, медленно крутится (глаза — в разные стороны). */
    private void swirl(Canvas c, float cx, float cy, long now, boolean mirror) {
        spiral.rewind();
        float maxR = 1.7f * p;
        double spin = now / 260.0 * (mirror ? -1 : 1);
        for (int i = 0; i <= 28; i++) {
            double a = i / 28.0 * Math.PI * 4;
            float rr = (float) (maxR * i / 28.0);
            float x = cx + (float) Math.cos(a + spin) * rr * (mirror ? -1 : 1);
            float y = cy + (float) Math.sin(a + spin) * rr;
            if (i == 0) spiral.moveTo(x, y);
            else spiral.lineTo(x, y);
        }
        c.drawPath(spiral, line);
    }

    /** Глаз-сердечко чуть больше клетки глаза и слегка пульсирует. */
    private void heartEye(Canvas c, float cx, float cy) {
        float s = 1.9f * p * (1f + 0.08f * (float) Math.sin(SystemClock.uptimeMillis() / 120.0));
        heart.rewind();
        heart.moveTo(cx, cy + s * 0.85f);
        heart.cubicTo(cx - s * 1.5f, cy - s * 0.1f, cx - s * 0.6f, cy - s * 1.15f, cx, cy - s * 0.35f);
        heart.cubicTo(cx + s * 0.6f, cy - s * 1.15f, cx + s * 1.5f, cy - s * 0.1f, cx, cy + s * 0.85f);
        fill.setColor(PINK);
        fill.setAlpha(255);
        c.drawPath(heart, fill);
    }

    private void drawParticles(Canvas c) {
        for (int i = 0; i < MAX_P; i++) {
            if (pLife[i] <= 0) continue;
            float a = Math.min(1f, pLife[i] / (pMax[i] * 0.5f));
            int alpha = Math.round(255 * a);
            float x = pX[i], y = pY[i];
            switch (pType[i]) {
                case P_HEART: {
                    float s = 5 * d;
                    heart.rewind();
                    heart.moveTo(x, y + s);
                    heart.cubicTo(x - s * 1.6f, y - s * 0.2f, x - s * 0.6f, y - s * 1.3f, x, y - s * 0.4f);
                    heart.cubicTo(x + s * 0.6f, y - s * 1.3f, x + s * 1.6f, y - s * 0.2f, x, y + s);
                    fill.setColor(pColor[i]);
                    fill.setAlpha(alpha);
                    c.drawPath(heart, fill);
                    break;
                }
                case P_Z:
                    text.setColor(0xFFFFFFFF);
                    text.setAlpha(alpha);
                    text.setTextSize((10 + (1f - pLife[i] / pMax[i]) * 8) * d);
                    text.setShadowLayer(2 * d, 0, 0, 0x88000000);
                    c.drawText("z", x, y, text);
                    break;
                case P_QUESTION:
                    text.setColor(0xFFFFFFFF);
                    text.setAlpha(alpha);
                    text.setTextSize(16 * d);
                    text.setShadowLayer(2 * d, 0, 0, 0x88000000);
                    c.drawText("?", x, y, text);
                    break;
                case P_TEAR:
                case P_CONFETTI:
                case P_STAR:
                    pix.setColor(pColor[i]);
                    pix.setAlpha(alpha);
                    float s = (pType[i] == P_CONFETTI ? 2.5f : 2f) * d;
                    c.drawRect(x - s, y - s, x + s, y + s, pix);
                    pix.setAlpha(255);
                    break;
                case P_STEAM:
                    fill.setColor(pColor[i]);
                    fill.setAlpha(Math.round(alpha * 0.8f));
                    c.drawCircle(x, y, (3 + (1f - pLife[i] / pMax[i]) * 4) * d, fill);
                    break;
                default:
                    break;
            }
        }
        fill.setAlpha(255);
    }

    /** Звёздочки по кругу над головой — головокружение. */
    private void drawOrbit(Canvas c, long now) {
        float cx = headX(), cy = headY() - 4 * d;
        pix.setColor(0xFFFFE082);
        for (int k = 0; k < 3; k++) {
            double a = now / 220.0 + k * Math.PI * 2 / 3;
            float x = cx + (float) Math.cos(a) * 18 * d;
            float y = cy + (float) Math.sin(a) * 5 * d;
            float s = 2.2f * d;
            c.drawRect(x - s, y - s * 0.4f, x + s, y + s * 0.4f, pix);
            c.drawRect(x - s * 0.4f, y - s, x + s * 0.4f, y + s, pix);
        }
    }
}
