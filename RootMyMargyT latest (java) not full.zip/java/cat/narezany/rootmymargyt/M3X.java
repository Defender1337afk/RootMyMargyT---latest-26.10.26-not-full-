package cat.narezany.rootmymargyt;

import android.animation.ValueAnimator;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.TextView;

/**
 * M3X — маленький набор Material 3 Expressive для кнопок и списков плагина.
 *
 * - Нажатие: кнопка сжимается и «квадратнеет» (скругление уменьшается), при отпускании
 *   пружинит обратно с перелётом — так в Expressive меняется форма кнопок.
 * - Списки: строки группы — отдельные плашки с зазором 2dp; у крайних скругление
 *   большое снаружи, у остальных маленькое (сегментированные группы Android 16).
 * - Отклик касания — Ripple поверх формы.
 *
 * Анимации только на свойствах View и одном GradientDrawable: без выделения памяти на кадр.
 */
public final class M3X {

    public static final String TAG_DIVIDER = "m3x_divider";

    private static final int TAG_MORPH = 0x7F0B99A0;

    private M3X() {}

    public static int dp(Context ctx, float v) {
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, ctx.getResources().getDisplayMetrics()));
    }

    /** Смешивает два цвета: t = 0 — первый, t = 1 — второй. */
    public static int mix(int a, int b, float t) {
        float u = 1f - t;
        return Color.argb(
            Math.round(Color.alpha(a) * u + Color.alpha(b) * t),
            Math.round(Color.red(a) * u + Color.red(b) * t),
            Math.round(Color.green(a) * u + Color.green(b) * t),
            Math.round(Color.blue(a) * u + Color.blue(b) * t));
    }

    public static boolean isLight(int c) {
        return (0.299 * Color.red(c) + 0.587 * Color.green(c) + 0.114 * Color.blue(c)) / 255.0 > 0.6;
    }

    /** Цвет текста поверх заливки. */
    public static int onColor(int fill) {
        return isLight(fill) ? 0xFF1A1A1F : 0xFFFFFFFF;
    }

    /** Тональный контейнер: акцент, разбавленный фоном (как secondaryContainer в M3). */
    public static int tonal(int accent, int surface) {
        return mix(surface, accent | 0xFF000000, 0.28f);
    }

    public static GradientDrawable shape(int color, float radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(radius);
        return g;
    }

    public static GradientDrawable shape(int color, float[] radii) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadii(radii);
        return g;
    }

    /** Ripple поверх формы; маска — та же форма. */
    public static Drawable ripple(GradientDrawable content, int rippleColor) {
        return new RippleDrawable(ColorStateList.valueOf(rippleColor), content, null);
    }

    // ───────────────────────────── Нажатие ─────────────────────────────

    private static final class Morph {
        final GradientDrawable shape;
        final float[] rest;
        final float[] pressed;
        final float[] now = new float[8];
        ValueAnimator anim;

        Morph(GradientDrawable shape, float[] rest, float[] pressed) {
            this.shape = shape;
            this.rest = rest.clone();
            this.pressed = pressed.clone();
        }
    }

    /**
     * Expressive-нажатие: сжатие + смена формы. Касание не потребляется — клики и
     * долгие нажатия работают как раньше.
     *
     * @param shape          фон, у которого меняем скругление (может быть null — тогда только сжатие)
     * @param restRadii      скругления в покое (8 значений, как у setCornerRadii)
     * @param pressedRadii   скругления в нажатом состоянии
     */
    @SuppressLint("ClickableViewAccessibility")
    public static void pressable(final View v, GradientDrawable shape, float[] restRadii, float[] pressedRadii, final float scale) {
        final Morph morph = shape != null && restRadii != null && pressedRadii != null
            ? new Morph(shape, restRadii, pressedRadii) : null;
        v.setTag(TAG_MORPH, morph);
        v.setOnTouchListener((view, ev) -> {
            switch (ev.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    view.animate().cancel();
                    view.animate().scaleX(scale).scaleY(scale).setDuration(110)
                        .setInterpolator(new DecelerateInterpolator()).start();
                    if (morph != null) animateMorph(morph, true);
                    break;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    view.animate().cancel();
                    view.animate().scaleX(1f).scaleY(1f).setDuration(380)
                        .setInterpolator(new OvershootInterpolator(3.2f)).start();
                    if (morph != null) animateMorph(morph, false);
                    break;
                default:
                    break;
            }
            return false;
        });
    }

    /** Простой вариант: все углы одинаковые, при нажатии скругление уменьшается до pressedRadius. */
    public static void pressable(View v, GradientDrawable shape, float radius, float pressedRadius) {
        pressable(v, shape, all(radius), all(pressedRadius), 0.94f);
    }

    public static float[] all(float r) {
        return new float[] {r, r, r, r, r, r, r, r};
    }

    private static void animateMorph(final Morph m, boolean down) {
        if (m.anim != null) m.anim.cancel();
        final float[] from = currentRadii(m);
        final float[] to = down ? m.pressed : m.rest;
        ValueAnimator a = ValueAnimator.ofFloat(0f, 1f);
        a.setDuration(down ? 120 : 420);
        a.setInterpolator(down ? new DecelerateInterpolator() : new OvershootInterpolator(2.2f));
        a.addUpdateListener(anim -> {
            float t = (float) anim.getAnimatedValue();
            for (int i = 0; i < 8; i++) m.now[i] = Math.max(0f, from[i] + (to[i] - from[i]) * t);
            m.shape.setCornerRadii(m.now);
        });
        m.anim = a;
        a.start();
    }

    private static float[] currentRadii(Morph m) {
        // Пока анимации не было, текущие — это покой
        boolean touched = false;
        for (float f : m.now) if (f != 0f) { touched = true; break; }
        return touched ? m.now.clone() : m.rest.clone();
    }

    // ───────────────────────────── Кнопки ─────────────────────────────

    public static final int FILLED = 0;
    public static final int TONAL = 1;
    public static final int OUTLINED = 2;

    /** Кнопка-«таблетка» в стиле M3 Expressive: высота 52dp, при нажатии квадратнеет. */
    public static TextView button(Context ctx, String text, int style, int accent, int surface) {
        TextView b = new TextView(ctx);
        b.setText(text);
        b.setGravity(android.view.Gravity.CENTER);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        b.setTypeface(android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.BOLD));
        b.setMinHeight(dp(ctx, 52));
        b.setPadding(dp(ctx, 22), dp(ctx, 12), dp(ctx, 22), dp(ctx, 12));
        b.setClickable(true);
        b.setFocusable(true);

        int fill;
        int textColor;
        if (style == FILLED) {
            fill = accent | 0xFF000000;
            textColor = onColor(fill);
        } else if (style == TONAL) {
            fill = tonal(accent, surface);
            textColor = mix(accent | 0xFF000000, 0xFFFFFFFF, 0.55f);
        } else {
            fill = 0x00000000;
            textColor = accent | 0xFF000000;
        }
        float r = dp(ctx, 26);
        GradientDrawable shape = shape(fill, r);
        if (style == OUTLINED) shape.setStroke(dp(ctx, 1.5f), mix(accent | 0xFF000000, surface, 0.4f));
        b.setTextColor(textColor);
        b.setBackground(ripple(shape, (textColor & 0x00FFFFFF) | 0x33000000));
        pressable(b, shape, r, dp(ctx, 12));
        return b;
    }

    // ───────────────────────────── Списки ─────────────────────────────

    /**
     * Превращает карточку со строками и разделителями в сегментированную группу M3 Expressive:
     * разделители (TAG_DIVIDER) убираются, каждая строка получает свою плашку, между ними 2dp.
     * Кликабельные строки получают отклик и Expressive-нажатие.
     */
    public static void segment(ViewGroup card, int surface, int accent) {
        Context ctx = card.getContext();
        for (int i = card.getChildCount() - 1; i >= 0; i--) {
            View c = card.getChildAt(i);
            if (TAG_DIVIDER.equals(c.getTag())) card.removeViewAt(i);
        }
        card.setBackground(null);

        float big = dp(ctx, 24);
        float small = dp(ctx, 6);
        float pressedR = dp(ctx, 28);
        int gap = dp(ctx, 2);
        int n = card.getChildCount();
        for (int i = 0; i < n; i++) {
            View row = card.getChildAt(i);
            float top = i == 0 ? big : small;
            float bottom = i == n - 1 ? big : small;
            float[] rest = {top, top, top, top, bottom, bottom, bottom, bottom};
            GradientDrawable bg = shape(surface, rest);
            row.setBackground(row.isClickable() ? ripple(bg, (accent & 0x00FFFFFF) | 0x2A000000) : bg);
            if (row.isClickable()) {
                // Нажатая строка скругляется со всех сторон и чуть сжимается
                pressable(row, bg, rest, all(pressedR), 0.97f);
            }
            ViewGroup.LayoutParams lp = row.getLayoutParams();
            if (lp instanceof ViewGroup.MarginLayoutParams) {
                ((ViewGroup.MarginLayoutParams) lp).topMargin = i == 0 ? 0 : gap;
                row.setLayoutParams(lp);
            }
        }
    }

    /** Делает Expressive-нажатие всем кликабельным элементам дерева, у которых фон — форма. */
    public static void expressify(View root) {
        if (root == null) return;
        if (root.isClickable() && root.getTag(TAG_MORPH) == null) {
            Drawable bg = root.getBackground();
            if (bg instanceof GradientDrawable) {
                GradientDrawable g = (GradientDrawable) bg;
                float r = radiusOf(g, dp(root.getContext(), 12));
                pressable(root, g, all(r), all(Math.max(dp(root.getContext(), 4), r * 0.45f)), 0.95f);
            }
        }
        if (root instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) root;
            for (int i = 0; i < g.getChildCount(); i++) expressify(g.getChildAt(i));
        }
    }

    private static float radiusOf(GradientDrawable g, float fallback) {
        try {
            if (android.os.Build.VERSION.SDK_INT >= 24) {
                float[] radii = g.getCornerRadii();
                if (radii != null && radii.length > 0 && radii[0] > 0) return radii[0];
                if (g.getCornerRadius() > 0) return g.getCornerRadius();
            }
        } catch (Throwable ignored) {}
        return fallback;
    }
}
