package cat.narezany.rootmymargyt;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.os.SystemClock;
import android.util.TypedValue;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;

import java.util.ArrayList;
import java.util.List;

/**
 * GraviboardOverlayView — Физический полноэкранный холст для видео-карточек:
 * 
 * - Идеальное скругление углов (16dp) с защитой от размытия и четкой рамкой.
 * - Уменьшение карточек при встряхивании (~35%) для компактного и стильного полета.
 * - Интерактивное швыряние пальцем (Touch Drag & Fling Physics): хватайте любое видео и бросайте его!
 * - Плавный возврат на сетку с раскрытием до исходного размера.
 */
public final class GraviboardOverlayView extends View {

    public static final String TAG = "rootmymargyt_graviboard_overlay";
    public static final float TARGET_SCALE = 0.65f; // Уменьшение на 35% при полете

    public static class FloatingCard {
        public View origView;
        public Bitmap bitmap;
        public android.graphics.BitmapShader shader;
        public Paint shaderPaint;
        public float origScreenX, origScreenY;
        public float currentX, currentY;
        public float vx, vy;
        public float rotation;
        public float vRot;
        public int width, height;
        public float currentScale = 1.0f;
        public boolean isGrabbed = false;
    }

    private final Paint bitmapPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final Paint borderPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path clipPath = new Path();
    private final RectF clipRect = new RectF();

    private final List<FloatingCard> cards = new ArrayList<>();
    private boolean isAnimatingBack = false;

    // Интерактивный захват пальцем
    private FloatingCard draggedCard = null;
    private float lastTouchX = 0f;
    private float lastTouchY = 0f;
    private long lastTouchTime = 0;
    private float touchDownX = 0f;
    private float touchDownY = 0f;

    public GraviboardOverlayView(Context context) {
        super(context);
        borderPaint.setStyle(Paint.Style.STROKE);
        borderPaint.setStrokeWidth(dp(1.5f));
        borderPaint.setColor(0x33FFFFFF);
    }

    public void setCards(List<FloatingCard> newCards) {
        this.cards.clear();
        this.cards.addAll(newCards);
        this.isAnimatingBack = false;
        this.draggedCard = null;

        // Плавная анимация уменьшения превьюшек до TARGET_SCALE при старте физики
        ValueAnimator shrinkAnim = ValueAnimator.ofFloat(1.0f, TARGET_SCALE);
        shrinkAnim.setDuration(280);
        shrinkAnim.setInterpolator(new OvershootInterpolator(1.1f));
        shrinkAnim.addUpdateListener(animation -> {
            float s = (float) animation.getAnimatedValue();
            for (FloatingCard c : cards) {
                c.currentScale = s;
            }
            invalidate();
        });
        shrinkAnim.start();

        setVisibility(VISIBLE);
        bringToFront();
        invalidate();
    }

    public List<FloatingCard> getCards() {
        return cards;
    }

    public boolean hasCards() {
        return !cards.isEmpty();
    }

    public boolean isAnimatingBack() {
        return isAnimatingBack;
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (cards.isEmpty() || isAnimatingBack) return false;

        int action = event.getActionMasked();
        float x = event.getX();
        float y = event.getY();
        long now = SystemClock.uptimeMillis();

        switch (action) {
            case MotionEvent.ACTION_DOWN: {
                touchDownX = x;
                touchDownY = y;
                lastTouchX = x;
                lastTouchY = y;
                lastTouchTime = now;

                // Ищем верхнюю карточку под пальцем
                draggedCard = null;
                for (int i = cards.size() - 1; i >= 0; i--) {
                    FloatingCard c = cards.get(i);
                    float sw = c.width * c.currentScale;
                    float sh = c.height * c.currentScale;

                    if (x >= c.currentX && x <= c.currentX + sw &&
                        y >= c.currentY && y <= c.currentY + sh) {
                        draggedCard = c;
                        c.isGrabbed = true;
                        c.vx = 0f;
                        c.vy = 0f;
                        c.vRot = 0f;

                        // Перемещаем взятую карточку на самый верх списка (поверх остальных)
                        cards.remove(i);
                        cards.add(c);

                        try {
                            performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);
                        } catch (Throwable ignored) {}
                        break;
                    }
                }
                return draggedCard != null;
            }

            case MotionEvent.ACTION_MOVE: {
                if (draggedCard != null) {
                    float dx = x - lastTouchX;
                    float dy = y - lastTouchY;
                    long dt = Math.max(1, now - lastTouchTime);

                    draggedCard.currentX += dx;
                    draggedCard.currentY += dy;

                    // Вычисляем скорость броска
                    float vx = (dx / dt) * 16f;
                    float vy = (dy / dt) * 16f;
                    draggedCard.vx = vx;
                    draggedCard.vy = vy;
                    draggedCard.vRot = (dx - dy) * 0.08f;

                    lastTouchX = x;
                    lastTouchY = y;
                    lastTouchTime = now;
                    invalidate();
                    return true;
                }
                break;
            }

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL: {
                if (draggedCard != null) {
                    draggedCard.isGrabbed = false;
                    draggedCard = null;
                    invalidate();
                    return true;
                }
                break;
            }
        }

        return super.onTouchEvent(event);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (cards.isEmpty()) return;

        float cornerRadius = dp(16f); // Идеальное скругление карточки

        for (int i = 0; i < cards.size(); i++) {
            FloatingCard card = cards.get(i);
            if (card.bitmap != null && !card.bitmap.isRecycled()) {
                canvas.save();

                float scaledW = card.width * card.currentScale;
                float scaledH = card.height * card.currentScale;
                float localRadius = cornerRadius / Math.max(0.01f, card.currentScale);

                canvas.translate(card.currentX, card.currentY);
                canvas.rotate(card.rotation, scaledW / 2f, scaledH / 2f);
                canvas.scale(card.currentScale, card.currentScale);

                clipRect.set(0, 0, card.width, card.height);
                if (card.shaderPaint != null) {
                    canvas.drawRoundRect(clipRect, localRadius, localRadius, card.shaderPaint);
                } else {
                    canvas.drawBitmap(card.bitmap, 0, 0, bitmapPaint);
                }

                // Очертание карточки
                borderPaint.setStrokeWidth(dp(1.5f) / Math.max(0.01f, card.currentScale));
                canvas.drawRoundRect(clipRect, localRadius, localRadius, borderPaint);

                canvas.restore();
            }
        }
    }

    public void animateBack(final Runnable onComplete) {
        if (cards.isEmpty()) {
            if (onComplete != null) onComplete.run();
            return;
        }

        isAnimatingBack = true;
        draggedCard = null;

        final List<float[]> startStates = new ArrayList<>();
        for (FloatingCard card : cards) {
            startStates.add(new float[] { card.currentX, card.currentY, card.rotation, card.currentScale });
        }

        ValueAnimator anim = ValueAnimator.ofFloat(0f, 1f);
        anim.setDuration(380);
        anim.setInterpolator(new DecelerateInterpolator(1.2f));
        anim.addUpdateListener(animation -> {
            float frac = (float) animation.getAnimatedValue();
            for (int i = 0; i < cards.size(); i++) {
                FloatingCard card = cards.get(i);
                float[] start = startStates.get(i);
                card.currentX = start[0] + (card.origScreenX - start[0]) * frac;
                card.currentY = start[1] + (card.origScreenY - start[1]) * frac;
                card.rotation = start[2] * (1f - frac);
                card.currentScale = start[3] + (1.0f - start[3]) * frac; // Раскрытие обратно до 1.0f
            }
            invalidate();
        });

        anim.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                isAnimatingBack = false;
                for (FloatingCard card : cards) {
                    if (card.origView != null) {
                        card.origView.setVisibility(View.VISIBLE);
                    }
                    if (card.bitmap != null && !card.bitmap.isRecycled()) {
                        card.bitmap.recycle();
                        card.bitmap = null;
                    }
                    card.shader = null;
                    card.shaderPaint = null;
                }
                cards.clear();
                setVisibility(GONE);
                if (onComplete != null) onComplete.run();
            }
        });

        anim.start();
    }

    private float dp(float v) {
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }
}
