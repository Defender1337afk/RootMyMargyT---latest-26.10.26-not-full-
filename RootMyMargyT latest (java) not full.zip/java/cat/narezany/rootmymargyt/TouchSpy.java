package cat.narezany.rootmymargyt;

import android.app.Activity;
import android.graphics.Rect;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Proxy;
import java.util.Map;
import java.util.WeakHashMap;

/**
 * TouchSpy — смотрит на касания в окне TikTok, чтобы Clawd-питомец на них реагировал.
 *
 * Только наблюдает: каждое событие уходит дальше без изменений, ничего не потребляется.
 * Узнаёт:
 * - тап по кнопке справа (лайк / комментарии / избранное / поделиться) — по реестру MargyT;
 * - двойной тап по видео — так в TikTok ставится лайк;
 * - быстрые свайпы вверх в ленте — «листает слишком быстро».
 */
final class TouchSpy {

    private static final WeakHashMap<Window, Boolean> HOOKED = new WeakHashMap<>();

    private static float downX, downY;
    private static long downAt;
    private static float lastTapX, lastTapY;
    private static long lastTapAt;
    private static final Rect R = new Rect();

    private TouchSpy() {}

    static void install(final Activity activity) {
        if (activity == null || activity.getWindow() == null) return;
        final Window window = activity.getWindow();
        synchronized (HOOKED) {
            if (HOOKED.containsKey(window)) return;
            HOOKED.put(window, Boolean.TRUE);
        }
        final Window.Callback base = window.getCallback();
        if (base == null) return;
        Window.Callback spy = (Window.Callback) Proxy.newProxyInstance(
            base.getClass().getClassLoader(),
            new Class<?>[] {Window.Callback.class},
            (proxy, method, args) -> {
                if ("dispatchTouchEvent".equals(method.getName()) && args != null && args.length == 1
                        && args[0] instanceof MotionEvent) {
                    try {
                        observe(activity, (MotionEvent) args[0]);
                    } catch (Throwable ignored) {
                        // наблюдение никогда не должно ломать касания
                    }
                }
                try {
                    return method.invoke(base, args);
                } catch (InvocationTargetException e) {
                    throw e.getCause() != null ? e.getCause() : e;
                }
            });
        window.setCallback(spy);
    }

    private static void observe(Activity activity, MotionEvent ev) {
        boolean pet = ClawdPetView.wantsReactions();
        int action = ev.getActionMasked();
        if (action == MotionEvent.ACTION_DOWN) {
            downX = ev.getRawX();
            downY = ev.getRawY();
            downAt = SystemClock.uptimeMillis();
            return;
        }
        if (action != MotionEvent.ACTION_UP) return;

        long now = SystemClock.uptimeMillis();
        float x = ev.getRawX(), y = ev.getRawY();
        float dx = x - downX, dy = y - downY;
        View decor = activity.getWindow().getDecorView();
        float density = decor.getResources().getDisplayMetrics().density;
        int h = decor.getHeight();

        // Касания по самому Clawd — его собственные
        if (pet && ClawdPetView.isOverPet(x, y)) return;

        boolean tap = Math.hypot(dx, dy) < 12 * density && now - downAt < 350;
        if (tap) {
            TilkajoModeEngine.onTap(activity, x, y); // режим Тилкайо: подпрыгнуть и мяукнуть
            int kind = railKindAt(x, y);
            if (kind >= 0) {
                if (kind == 0) FunFx.onLike(activity, x, y); // кнопка лайка
                if (pet) ClawdPetView.react(ClawdPetView.EV_RAIL_BASE + kind, 0);
                lastTapAt = 0;
                return;
            }
            boolean doubleTap = now - lastTapAt < 320 && Math.hypot(x - lastTapX, y - lastTapY) < 60 * density;
            lastTapAt = now;
            lastTapX = x;
            lastTapY = y;
            if (doubleTap && inFeed(decor)) {
                FunFx.onLike(activity, x, y); // двойной тап по видео — лайк
                if (pet) ClawdPetView.react(ClawdPetView.EV_LIKE, 0);
            }
            return;
        }

        // Свайп вверх на треть экрана, быстрый — пролистнул видео
        if (pet && h > 0 && -dy > h * 0.15f && Math.abs(dx) < Math.abs(dy) && now - downAt < 600 && inFeed(decor)) {
            ClawdPetView.react(ClawdPetView.EV_SWIPE, 0);
        }
    }

    /** Тип кнопки ленты под точкой: 0 лайк, 1 комментарии, 2 избранное, 3 поделиться; −1 — не кнопка. */
    private static int railKindAt(float x, float y) {
        Map<View, Integer> rail = FeedCountsEngine.readRail();
        if (rail == null) return -1;
        for (Map.Entry<View, Integer> e : rail.entrySet()) {
            View v = e.getKey();
            if (v == null || !v.isShown()) continue;
            if (v.getGlobalVisibleRect(R) && R.contains((int) x, (int) y)) return e.getValue();
        }
        return -1;
    }

    private static boolean inFeed(View decor) {
        return decor instanceof ViewGroup && ProfileLocator.hasVideoFeedMarkers((ViewGroup) decor);
    }
}
