package cat.narezany.rootmymargyt;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Locale;

import cat.narezany.rootmymargyt.core.Host;

/**
 * UI-тулкит настроек в стиле MargyT (Material 3 Expressive): карточки, строки-переключатели,
 * строки-действия, заголовки секций, разделители. Цвета берутся из живой темы мода через
 * {@link Host} (акцент/фон карточки/текст), поэтому плагин совпадает со светлой/тёмной темой и акцентом.
 *
 * Вынесено из god-класса AstraExploitEngine в отдельный переиспользуемый модуль (рекод 5.1).
 */
public final class SettingsUi {

    private SettingsUi() {}

    // Фолбэки на случай старой сборки мода без Skin/Accent.
    public static final int DEFAULT_CARD_BG = 0xFF161823;
    public static final int DEFAULT_ACCENT  = 0xFF00F2FE;
    public static final int DEFAULT_TEXT    = 0xFFFFFFFF;
    public static final int DEFAULT_MUTED   = 0x99FFFFFF;

    /** Слушатель переключателя строки. */
    public interface OnChecked {
        void onChecked(boolean checked);
    }

    // ─────────────────────────── тема (через Host) ───────────────────────────

    public static int getAccent(Context ctx)    { return Host.accent(DEFAULT_ACCENT); }
    public static int getCardBg(Context ctx)    { return Host.skinCard(ctx, DEFAULT_CARD_BG); }
    public static int getTextColor(Context ctx) { return Host.skinText(ctx, DEFAULT_TEXT); }
    public static int getMutedColor(Context ctx){ return Host.skinMuted(ctx, DEFAULT_MUTED); }

    // ─────────────────────────── карточки / секции ───────────────────────────

    public static LinearLayout createM3Card(Context ctx) {
        LinearLayout card = new LinearLayout(ctx);
        card.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(getCardBg(ctx));
        bg.setCornerRadius(dp(ctx, 22)); // M3 Expressive: крупное скругление
        card.setBackground(bg);
        return card;
    }

    public static View wrapCard(Context ctx, View card) {
        if (card instanceof LinearLayout) M3X.segment((LinearLayout) card, getCardBg(ctx), getAccent(ctx));
        LinearLayout wrap = new LinearLayout(ctx);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setPadding(dp(ctx, 12), 0, dp(ctx, 12), dp(ctx, 6));
        wrap.addView(card, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return wrap;
    }

    public static TextView createSectionHeader(Context ctx, String title) {
        TextView view = new TextView(ctx);
        view.setText(title.toUpperCase(Locale.ROOT));
        view.setTextColor(getAccent(ctx));
        view.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        view.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        view.setLetterSpacing(0.06f);
        view.setPadding(dp(ctx, 20), dp(ctx, 16), dp(ctx, 16), dp(ctx, 6));
        return view;
    }

    public static View createDivider(Context ctx) {
        View v = new View(ctx);
        // Из темы: тонкая линия, слегка отличная от фона карточки.
        v.setBackgroundColor(M3X.mix(getCardBg(ctx), getTextColor(ctx), 0.12f) | 0xFF000000);
        v.setTag(M3X.TAG_DIVIDER);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(ctx, 1));
        lp.setMargins(dp(ctx, 16), 0, dp(ctx, 16), 0);
        v.setLayoutParams(lp);
        return v;
    }

    // ─────────────────────────── строки ───────────────────────────

    /** M3-ripple по цвету акцента для нажимаемых строк (state-layer). */
    public static Drawable rowRipple(Context ctx) {
        int accent = getAccent(ctx);
        ColorStateList ripple = ColorStateList.valueOf((accent & 0x00FFFFFF) | 0x33000000);
        return new RippleDrawable(ripple, null, new ColorDrawable(0xFFFFFFFF));
    }

    public static View createSwitchRow(Context ctx, String title, String desc, boolean initial, final OnChecked listener) {
        LinearLayout row = baseRow(ctx);
        row.addView(texts(ctx, title, desc), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        final M3Switch sw = new M3Switch(ctx, getAccent(ctx), getCardBg(ctx));
        sw.setChecked(initial);
        sw.setOnCheckedChangeListener((buttonView, isChecked) -> {
            buttonView.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);
            if (listener != null) listener.onChecked(isChecked);
        });
        row.addView(sw);

        row.setForeground(rowRipple(ctx));
        row.setOnClickListener(v -> sw.toggle());
        return row;
    }

    public static View createActionRow(Context ctx, String title, String desc, final Runnable onClick) {
        LinearLayout row = baseRow(ctx);
        row.addView(texts(ctx, title, desc), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView chevron = new TextView(ctx);
        chevron.setText("›");
        chevron.setTextColor(getMutedColor(ctx));
        chevron.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
        chevron.setPadding(dp(ctx, 8), 0, 0, 0);
        row.addView(chevron);

        row.setForeground(rowRipple(ctx));
        row.setOnClickListener(v -> {
            v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);
            if (onClick != null) onClick.run();
        });
        return row;
    }

    private static LinearLayout baseRow(Context ctx) {
        LinearLayout row = new LinearLayout(ctx);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setMinimumHeight(dp(ctx, 54));
        row.setPadding(dp(ctx, 16), dp(ctx, 10), dp(ctx, 16), dp(ctx, 10));
        return row;
    }

    private static LinearLayout texts(Context ctx, String title, String desc) {
        LinearLayout texts = new LinearLayout(ctx);
        texts.setOrientation(LinearLayout.VERTICAL);

        TextView t = new TextView(ctx);
        t.setText(title);
        t.setTextColor(getTextColor(ctx));
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        t.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        texts.addView(t);

        if (desc != null && !desc.isEmpty()) {
            TextView d = new TextView(ctx);
            d.setText(desc);
            d.setTextColor(getMutedColor(ctx));
            d.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
            d.setPadding(0, dp(ctx, 2), 0, 0);
            texts.addView(d);
        }
        return texts;
    }

    /** Строку createActionRow построили с подзаголовком-TextView вторым в блоке текстов — меняем его. */
    public static void updateActionRowSubtitle(View rowView, String newSubtitle) {
        if (rowView instanceof ViewGroup) {
            ViewGroup vg = (ViewGroup) rowView;
            View texts = vg.getChildAt(0);
            if (texts instanceof ViewGroup) {
                ViewGroup tg = (ViewGroup) texts;
                if (tg.getChildCount() > 1 && tg.getChildAt(1) instanceof TextView) {
                    ((TextView) tg.getChildAt(1)).setText(newSubtitle);
                }
            }
        }
    }

    /** Переключатель в строке createSwitchRow стоит последним ребёнком; listener строки отработает сам. */
    public static void setSwitchRowChecked(View row, boolean checked) {
        if (!(row instanceof ViewGroup)) return;
        ViewGroup g = (ViewGroup) row;
        View last = g.getChildCount() > 0 ? g.getChildAt(g.getChildCount() - 1) : null;
        if (last instanceof CompoundButton) ((CompoundButton) last).setChecked(checked);
    }

    public static int dp(Context ctx, int val) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, val, ctx.getResources().getDisplayMetrics());
    }

    public static int dp4(Context ctx) {
        return dp(ctx, 4);
    }

    // ─────────────────────────── диалог выбора (M3 Expressive) ───────────────────────────

    public interface OnChoice {
        void onChoice(int index);
    }

    /** Нижний список-выбор в стиле MargyT: пилюли, галочка на выбранном, акцент из темы. */
    public static void showChoiceDialog(final Activity activity, String titleText, String subtitleText,
                                        final String[] names, final int current, final OnChoice onChoice) {
        if (activity == null || activity.isFinishing()) return;
        final Dialog d = new Dialog(activity);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout box = new LinearLayout(activity);
        box.setOrientation(LinearLayout.VERTICAL);
        int p = dp(activity, 20);
        box.setPadding(p, p, p, p);

        final int accent = getAccent(activity);
        final int surface = 0xFF1E1E28;
        box.setBackground(M3X.shape(surface, dp(activity, 28)));

        TextView title = new TextView(activity);
        title.setText(titleText);
        title.setTextSize(18);
        title.setTextColor(0xFFFFFFFF);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setPadding(0, 0, 0, dp(activity, 4));
        box.addView(title);

        if (subtitleText != null) {
            TextView subtitle = new TextView(activity);
            subtitle.setText(subtitleText);
            subtitle.setTextSize(12);
            subtitle.setTextColor(0xFFAAAAAA);
            subtitle.setPadding(0, 0, 0, dp(activity, 14));
            box.addView(subtitle);
        }

        for (int i = 0; i < names.length; i++) {
            final int idx = i;
            final boolean selected = idx == current;

            LinearLayout row = new LinearLayout(activity);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(activity, 14), dp(activity, 12), dp(activity, 14), dp(activity, 12));

            row.setMinimumHeight(dp(activity, 52));
            float pill = dp(activity, 26);
            GradientDrawable rBg = M3X.shape(selected ? M3X.tonal(accent, surface) : 0x0FFFFFFF, pill);
            row.setBackground(M3X.ripple(rBg, (accent & 0x00FFFFFF) | 0x33000000));
            M3X.pressable(row, rBg, pill, dp(activity, 12));

            TextView tv = new TextView(activity);
            tv.setText(names[idx]);
            tv.setTextSize(15);
            tv.setTextColor(selected ? M3X.mix(accent | 0xFF000000, 0xFFFFFFFF, 0.55f) : 0xFFFFFFFF);
            tv.setTypeface(Typeface.create("sans-serif-medium", selected ? Typeface.BOLD : Typeface.NORMAL));
            row.addView(tv, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

            if (selected) {
                TextView chk = new TextView(activity);
                chk.setText("✓");
                chk.setTextColor(M3X.mix(accent | 0xFF000000, 0xFFFFFFFF, 0.55f));
                chk.setTextSize(16);
                chk.setTypeface(Typeface.DEFAULT_BOLD);
                row.addView(chk);
            }

            row.setOnClickListener(v -> {
                v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);
                d.dismiss();
                if (onChoice != null) onChoice.onChoice(idx);
            });

            LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            rlp.bottomMargin = dp(activity, 6);
            box.addView(row, rlp);
        }

        M3X.expressify(box);

        d.setContentView(box);
        if (d.getWindow() != null) {
            d.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            int w = (int) (activity.getResources().getDisplayMetrics().widthPixels * 0.90f);
            d.getWindow().setLayout(w, ViewGroup.LayoutParams.WRAP_CONTENT);
        }
        d.show();
    }
}
