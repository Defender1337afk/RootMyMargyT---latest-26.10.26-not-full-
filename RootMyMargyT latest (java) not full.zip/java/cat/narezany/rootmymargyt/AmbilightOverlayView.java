package cat.narezany.rootmymargyt;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.os.SystemClock;
import android.util.TypedValue;
import android.view.View;

/**
 * AmbilightOverlayView — Кинематографичная виньетка (Vignette) и Неоновая сакура.
 */
public class AmbilightOverlayView extends View {

    private boolean vignetteEnabled = false;
    private boolean sakuraEnabled = false;
    private boolean pulseEnabled = true;

    private final Paint vignettePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint sakuraPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    private RadialGradient vignetteShader = null;
    private int lastWidth = 0;
    private int lastHeight = 0;

    public AmbilightOverlayView(Context context) {
        super(context);
        setClickable(false);
        setFocusable(false);
    }

    public void setVignetteEnabled(boolean enabled) {
        this.vignetteEnabled = enabled;
        postInvalidate();
    }

    public boolean isVignetteEnabled() {
        return vignetteEnabled;
    }

    public void setSakuraEnabled(boolean enabled) {
        this.sakuraEnabled = enabled;
        postInvalidate();
    }

    public boolean isSakuraEnabled() {
        return sakuraEnabled;
    }

    public void setPulseEnabled(boolean pulse) {
        this.pulseEnabled = pulse;
        postInvalidate();
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        if (w > 0 && h > 0) {
            lastWidth = w;
            lastHeight = h;
            buildVignetteShader(w, h);
        }
    }

    private void buildVignetteShader(int w, int h) {
        float cx = w * 0.5f;
        float cy = h * 0.5f;
        float radius = (float) Math.hypot(cx, cy);

        vignetteShader = new RadialGradient(
                cx, cy, radius,
                new int[]{
                        0x00000000,
                        0x00000000,
                        0x35000000,
                        0x75000000,
                        0xB5000000
                },
                new float[]{0.0f, 0.42f, 0.68f, 0.86f, 1.0f},
                Shader.TileMode.CLAMP
        );
        vignettePaint.setShader(vignetteShader);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (!vignetteEnabled && !sakuraEnabled) return;

        int w = getWidth();
        int h = getHeight();
        if (w <= 0 || h <= 0) return;

        if (vignetteShader == null || w != lastWidth || h != lastHeight) {
            lastWidth = w;
            lastHeight = h;
            buildVignetteShader(w, h);
        }

        // 1. Кинематографичная виньетка
        if (vignetteEnabled && vignetteShader != null) {
            canvas.drawRect(0, 0, w, h, vignettePaint);
        }

        long now = SystemClock.uptimeMillis();

        // 2. Неоновая сакура
        if (sakuraEnabled) {
            drawSakuraGlow(canvas, w, h, now);
            postInvalidateOnAnimation();
        }
    }

    private void drawSakuraGlow(Canvas canvas, int w, int h, long now) {
        float glowSize = dp(28);
        float pulse = pulseEnabled ? 0.74f + 0.26f * (float) Math.sin(now * 0.0032) : 1.0f;
        float baseAngle = (now % 4500) / 4500.0f * 360f;

        int cTop = getSakuraColor(baseAngle, pulse);
        int cRight = getSakuraColor(baseAngle + 90f, pulse);
        int cBottom = getSakuraColor(baseAngle + 180f, pulse);
        int cLeft = getSakuraColor(baseAngle + 270f, pulse);

        LinearGradient topGrad = new LinearGradient(0, 0, 0, glowSize, cTop, Color.TRANSPARENT, Shader.TileMode.CLAMP);
        sakuraPaint.setShader(topGrad);
        canvas.drawRect(0, 0, w, glowSize, sakuraPaint);

        LinearGradient botGrad = new LinearGradient(0, h, 0, h - glowSize, cBottom, Color.TRANSPARENT, Shader.TileMode.CLAMP);
        sakuraPaint.setShader(botGrad);
        canvas.drawRect(0, h - glowSize, w, h, sakuraPaint);

        LinearGradient leftGrad = new LinearGradient(0, 0, glowSize, 0, cLeft, Color.TRANSPARENT, Shader.TileMode.CLAMP);
        sakuraPaint.setShader(leftGrad);
        canvas.drawRect(0, 0, glowSize, h, sakuraPaint);

        LinearGradient rightGrad = new LinearGradient(w, 0, w - glowSize, 0, cRight, Color.TRANSPARENT, Shader.TileMode.CLAMP);
        sakuraPaint.setShader(rightGrad);
        canvas.drawRect(w - glowSize, 0, w, h, sakuraPaint);

        sakuraPaint.setShader(null);
    }

    private int getSakuraColor(float deg, float pulse) {
        float norm = (deg % 360f + 360f) % 360f;
        int alpha = (int)(pulse * 195);
        float t = norm / 360f;
        int r, g, b;
        if (t < 0.5f) {
            float s = t * 2f;
            r = 0xFF;
            g = (int)(0x40 * (1 - s) + 0x80 * s);
            b = (int)(0x81 * (1 - s) + 0xAB * s);
        } else {
            float s = (t - 0.5f) * 2f;
            r = (int)(0xFF * (1 - s) + 0xE0 * s);
            g = (int)(0x80 * (1 - s) + 0x40 * s);
            b = (int)(0xAB * (1 - s) + 0xFB * s);
        }
        return Color.argb(alpha, r, g, b);
    }

    private float dp(float value) {
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, value, getResources().getDisplayMetrics());
    }
}
