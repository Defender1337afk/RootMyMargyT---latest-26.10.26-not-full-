package cat.narezany.rootmymargyt;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.os.Build;
import android.os.SystemClock;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.TextView;

import java.util.Random;

/**
 * AstraEasterEggDialog — пасхалка Astra 0.3, как у версии Android.
 *
 * Пять нажатий на баннер в «О проекте» открывают космос с логотипом «0.3 Astra»:
 * вокруг него по наклонённой орбите бежит светящаяся планетка, рядом мерцают
 * четырёхлучевые искры. Тап — вспышка и разгон орбиты, свайп — наклон и вращение.
 * Удержание логотипа запускает ClawdSpaceGame — как Landroid в Android 14,
 * только вместо корабля Clawd.
 */
public final class AstraEasterEggDialog {

    private AstraEasterEggDialog() {}

    public static void show(final Activity activity) {
        if (activity == null || activity.isFinishing()) return;

        final Dialog dialog = new Dialog(activity, android.R.style.Theme_Black_NoTitleBar_Fullscreen);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        Window window = dialog.getWindow();
        if (window != null) {
            window.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
            window.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.BLACK));
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(Color.TRANSPARENT);
            window.setNavigationBarColor(Color.TRANSPARENT);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                WindowManager.LayoutParams lp = window.getAttributes();
                if (lp != null) {
                    lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
                    window.setAttributes(lp);
                }
            }
        }

        final FrameLayout root = new FrameLayout(activity);
        root.setBackgroundColor(0xFF000000);

        final LogoView logo = new LogoView(activity);
        logo.onLaunchGame = () -> {
            root.removeAllViews();
            root.addView(new ClawdSpaceGame(activity), new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            addClose(activity, root, dialog);
        };
        root.addView(logo, new FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        addClose(activity, root, dialog);

        dialog.setContentView(root);
        dialog.show();
    }

    private static void addClose(Activity activity, FrameLayout root, Dialog dialog) {
        TextView btnClose = new TextView(activity);
        btnClose.setText("✕");
        btnClose.setTextColor(0xAAFFFFFF);
        btnClose.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
        btnClose.setGravity(Gravity.CENTER);
        int pad = dp(activity, 16);
        btnClose.setPadding(pad, pad, pad, pad);
        btnClose.setOnClickListener(v -> {
            v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);
            dialog.dismiss();
        });
        FrameLayout.LayoutParams lpClose = new FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lpClose.gravity = Gravity.TOP | Gravity.END;
        lpClose.topMargin = dp(activity, 32);
        lpClose.rightMargin = dp(activity, 16);
        root.addView(btnClose, lpClose);
    }

    static int dp(Context ctx, float val) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, val, ctx.getResources().getDisplayMetrics());
    }

    /** Логотип «0.3 Astra» с орбитой — то, что открывается по пяти нажатиям. */
    private static final class LogoView extends View {
        Runnable onLaunchGame;

        private final Random random = new Random(3);
        private final float d;
        private final float[] starX = new float[90], starY = new float[90], starA = new float[90], starS = new float[90];
        private final float[] burstX = new float[60], burstY = new float[60], burstVx = new float[60], burstVy = new float[60], burstLife = new float[60];

        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint orbit = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint big = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint word = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF oval = new RectF();
        private final Path sparkle = new Path();

        private float orbitAngle = 0f, orbitSpeed = 0.5f, tilt = -18f, spin = 0f;
        private float scale = 1f;
        private long downAt;
        private float downX, downY, lastX;
        private boolean moved, launched, pressed, onLogo;
        private long lastFrame;

        LogoView(Context c) {
            super(c);
            d = c.getResources().getDisplayMetrics().density;
            for (int i = 0; i < starX.length; i++) {
                starX[i] = random.nextFloat();
                starY[i] = random.nextFloat();
                starA[i] = random.nextFloat() * 6.28f;
                starS[i] = (0.6f + random.nextFloat() * 1.6f) * d;
            }
            big.setColor(0xFFFFFFFF);
            big.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
            big.setTextAlign(Paint.Align.CENTER);
            big.setShadowLayer(18 * d, 0, 0, 0xAAFFFFFF);
            word.setColor(0xFFFFFFFF);
            word.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
            word.setTextAlign(Paint.Align.CENTER);
            orbit.setStyle(Paint.Style.STROKE);
            orbit.setColor(0xEEFFFFFF);
            orbit.setStrokeCap(Paint.Cap.ROUND);
            orbit.setShadowLayer(8 * d, 0, 0, 0xCCFFFFFF);
            // Тени у текста и дуг аппаратно рисуются с Android 9; ниже — только программным слоем
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) setLayerType(LAYER_TYPE_SOFTWARE, null);
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downAt = SystemClock.uptimeMillis();
                    downX = lastX = e.getX();
                    downY = e.getY();
                    moved = false;
                    launched = false;
                    pressed = true;
                    onLogo = Math.hypot(downX - getWidth() / 2f, downY - getHeight() / 2f) < Math.min(getWidth(), getHeight()) * 0.42f;
                    scale = 0.94f;
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (Math.hypot(e.getX() - downX, e.getY() - downY) > 12 * d) moved = true;
                    spin += (e.getX() - lastX) * 0.35f;
                    tilt = Math.max(-60f, Math.min(60f, -18f + (e.getY() - downY) * 0.15f));
                    lastX = e.getX();
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    pressed = false;
                    scale = 1.08f;
                    if (!moved && !launched && SystemClock.uptimeMillis() - downAt < 300) {
                        performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
                        burst(getWidth() / 2f, getHeight() / 2f);
                        orbitSpeed = 4f;
                    }
                    return true;
            }
            return super.onTouchEvent(e);
        }

        private void burst(float x, float y) {
            for (int i = 0; i < burstX.length; i++) {
                double a = random.nextDouble() * Math.PI * 2;
                float s = (3 + random.nextFloat() * 9) * d;
                burstX[i] = x;
                burstY[i] = y;
                burstVx[i] = (float) Math.cos(a) * s;
                burstVy[i] = (float) Math.sin(a) * s;
                burstLife[i] = 1f;
            }
        }

        private void drawSparkle(Canvas c, float x, float y, float r, int alpha) {
            sparkle.rewind();
            sparkle.moveTo(x, y - r);
            sparkle.quadTo(x, y, x + r, y);
            sparkle.quadTo(x, y, x, y + r);
            sparkle.quadTo(x, y, x - r, y);
            sparkle.quadTo(x, y, x, y - r);
            fill.setColor(0xFFFFFFFF);
            fill.setAlpha(alpha);
            c.drawPath(sparkle, fill);
        }

        @Override
        protected void onDraw(Canvas c) {
            int w = getWidth(), h = getHeight();
            if (w <= 0) return;
            long now = SystemClock.uptimeMillis();
            float dt = lastFrame == 0 ? 0.016f : Math.min(0.05f, (now - lastFrame) / 1000f);
            lastFrame = now;

            // удержание без движения — в игру
            if (pressed && onLogo && !launched && !moved && now - downAt > 550 && onLaunchGame != null) {
                launched = true;
                performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
                post(onLaunchGame);
            }

            c.drawColor(0xFF000000);
            for (int i = 0; i < starX.length; i++) {
                float tw = 0.35f + 0.65f * (float) (0.5 + 0.5 * Math.sin(now / 700.0 + starA[i]));
                fill.setColor(0xFFFFFFFF);
                fill.setAlpha((int) (tw * 200));
                c.drawCircle(starX[i] * w, starY[i] * h, starS[i], fill);
            }

            scale += (1f - scale) * 0.12f;
            orbitSpeed += (0.5f - orbitSpeed) * 0.02f;
            orbitAngle += orbitSpeed * dt;
            spin *= 0.96f;

            float cx = w / 2f, cy = h / 2f;
            float size = Math.min(w, h) * 0.30f;

            // мягкое свечение за логотипом
            glow.setShader(new RadialGradient(cx, cy, size * 1.6f, new int[] {0x33FFFFFF, 0x10FFFFFF, 0x00000000},
                new float[] {0f, 0.5f, 1f}, Shader.TileMode.CLAMP));
            c.drawCircle(cx, cy, size * 1.6f, glow);

            c.save();
            c.translate(cx, cy);
            c.scale(scale, scale);

            // орбита: наклонённый эллипс, задняя половина — за цифрами
            c.save();
            c.rotate(tilt + spin);
            oval.set(-size * 1.25f, -size * 0.42f, size * 1.25f, size * 0.42f);
            orbit.setStrokeWidth(2.2f * d);
            c.drawArc(oval, 180, 180, false, orbit);
            c.restore();

            big.setTextSize(size * 0.95f);
            c.drawText("0.3", 0, size * 0.18f, big);
            word.setTextSize(size * 0.30f);
            c.drawText("Astra", 0, size * 0.62f, word);

            c.save();
            c.rotate(tilt + spin);
            c.drawArc(oval, 0, 180, false, orbit);
            // планетка на орбите
            float px = (float) Math.cos(orbitAngle) * size * 1.25f;
            float py = (float) Math.sin(orbitAngle) * size * 0.42f;
            fill.setColor(0xFFFFFFFF);
            fill.setAlpha(255);
            c.drawCircle(px, py, 4.5f * d, fill);
            c.restore();

            // искры как на ассете 0.3
            drawSparkle(c, size * 0.95f, -size * 0.55f, size * 0.32f, (int) (180 + 75 * Math.sin(now / 400.0)));
            drawSparkle(c, -size * 1.05f, -size * 0.2f, size * 0.12f, (int) (150 + 100 * Math.sin(now / 520.0 + 1)));
            drawSparkle(c, -size * 1.2f, size * 0.75f, size * 0.09f, (int) (150 + 100 * Math.sin(now / 610.0 + 2)));
            drawSparkle(c, size * 0.95f, size * 0.7f, size * 0.1f, (int) (150 + 100 * Math.sin(now / 480.0 + 3)));
            c.restore();

            for (int i = 0; i < burstX.length; i++) {
                if (burstLife[i] <= 0) continue;
                burstX[i] += burstVx[i];
                burstY[i] += burstVy[i];
                burstVx[i] *= 0.94f;
                burstVy[i] *= 0.94f;
                burstLife[i] -= 0.02f;
                drawSparkle(c, burstX[i], burstY[i], 5 * d * burstLife[i] + d, (int) (255 * Math.max(0, burstLife[i])));
            }

            word.setTextSize(11 * d);
            word.setAlpha(110);
            c.drawText("ASTRA ENGINE 0.3", cx, h - 48 * d, word);
            word.setAlpha(255);
            postInvalidateOnAnimation();
        }
    }
}
