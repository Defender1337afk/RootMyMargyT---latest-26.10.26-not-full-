package cat.narezany.rootmymargyt;

import android.app.Activity;

import cat.narezany.margyt.plugin.PluginContext;
import cat.narezany.rootmymargyt.core.Feature;
import cat.narezany.rootmymargyt.core.Root;

/**
 * Свой фон за шторкой комментариев — модуль-{@link Feature} над проверенным
 * {@link CommentWallpaperEngine} (поиск шторки, вуаль, уступка CommentStyle мода).
 * Движок device-проверенный, поэтому не переписан, а выведен из god-entry в реестр;
 * его рефлексия CommentStyle теперь берётся из {@code core.Host}.
 */
public final class CommentBackgroundFeature implements Feature {

    @Override public String id() { return "comment-bg"; }

    private static PluginContext m() { return Root.margyt(); }

    @Override
    public void onResume(Activity activity) {
        CommentWallpaperEngine.update(activity, m(), true);
    }

    @Override
    public void onScreen(Activity activity, String name) {
        CommentWallpaperEngine.update(activity, m(), true);
    }

    @Override
    public void onPause(Activity activity) {
        CommentWallpaperEngine.onPaused(activity);
    }

    @Override
    public void onTick(Activity activity, Tick tick) {
        // Движок сам троттлит обход (400 мс) и опрос — зовём каждый кадр без форса.
        CommentWallpaperEngine.update(activity, m());
    }
}
