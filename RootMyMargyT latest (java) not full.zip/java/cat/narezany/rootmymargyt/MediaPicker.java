package cat.narezany.rootmymargyt;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;

import cat.narezany.margyt.plugin.PluginContext;

/**
 * MediaPicker — выбор картинки или GIF из галереи для любого слота BackdropMedia.
 *
 * Работает так же, как галерея обоев профиля: на Activity добавляется невидимый Fragment,
 * он запускает системный выбор файла и получает результат. Выбранный файл копируется во
 * внутреннюю память приложения, так что разрешение на хранилище не нужно.
 */
public final class MediaPicker {

    public interface Done {
        /** Вызывается в главном потоке. ok == false, если файл не выбран или не прочитался. */
        void finished(boolean ok);
    }

    private MediaPicker() {}

    public static void pick(Activity activity, PluginContext margyt, String slot, String title, Done done) {
        if (activity == null || activity.isFinishing()) {
            if (done != null) done.finished(false);
            return;
        }
        try {
            PickerFragment frag = new PickerFragment();
            frag.init(margyt, slot, title, done);
            activity.getFragmentManager()
                    .beginTransaction()
                    .add(frag, "rootmymargyt_media_picker_" + slot)
                    .commitAllowingStateLoss();
        } catch (Throwable t) {
            Toast.makeText(activity, "Не удалось открыть галерею: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            if (done != null) done.finished(false);
        }
    }

    public static class PickerFragment extends android.app.Fragment {
        private static final int REQ_MEDIA = 0x524D;
        private PluginContext margyt;
        private String slot;
        private String title;
        private Done done;
        private boolean launched = false;

        public void init(PluginContext margyt, String slot, String title, Done done) {
            this.margyt = margyt;
            this.slot = slot;
            this.title = title == null ? "Выберите файл" : title;
            this.done = done;
        }

        @Override
        public void onActivityCreated(Bundle savedInstanceState) {
            super.onActivityCreated(savedInstanceState);
            if (launched) return;
            launched = true;
            if (slot == null) {
                finish(false);
                return;
            }
            try {
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                // Галереи по голому "image/*" часто прячут GIF; со списком типов
                // открывается выбор файлов, где GIF видны.
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[] {"image/*"});
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                startActivityForResult(Intent.createChooser(intent, title), REQ_MEDIA);
            } catch (Throwable t) {
                try {
                    Intent intent = new Intent(Intent.ACTION_PICK,
                            android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    startActivityForResult(intent, REQ_MEDIA);
                } catch (Throwable t2) {
                    toast("Галерея недоступна");
                    finish(false);
                }
            }
        }

        @Override
        public void onActivityResult(int requestCode, int resultCode, Intent data) {
            super.onActivityResult(requestCode, resultCode, data);
            if (requestCode != REQ_MEDIA) return;
            if (resultCode != Activity.RESULT_OK || data == null || data.getData() == null) {
                finish(false);
                return;
            }
            final Uri uri = data.getData();
            final Activity act = getActivity();
            if (act == null || act.isFinishing()) {
                finish(false);
                return;
            }
            final Context app = act.getApplicationContext();
            final PluginContext m = margyt;
            final String s = slot;
            final Handler ui = new Handler(Looper.getMainLooper());
            new Thread(new Runnable() {
                @Override
                public void run() {
                    final int kind = BackdropMedia.saveFromUri(app, uri, s, m);
                    ui.post(new Runnable() {
                        @Override
                        public void run() {
                            if (kind == BackdropMedia.KIND_NONE) {
                                toast(BackdropMedia.lastError());
                                finish(false);
                            } else {
                                toast(kind == BackdropMedia.KIND_ANIMATED
                                        ? "GIF сохранена, будет проигрываться"
                                        : "Картинка сохранена");
                                finish(true);
                            }
                        }
                    });
                }
            }, "rootmymargyt-media-copy").start();
        }

        private void toast(String text) {
            try {
                Activity a = getActivity();
                if (a != null && text != null && !text.isEmpty()) {
                    Toast.makeText(a, text, Toast.LENGTH_SHORT).show();
                }
            } catch (Throwable ignored) {}
        }

        private void finish(boolean ok) {
            Done d = done;
            done = null;
            try {
                if (getFragmentManager() != null) {
                    getFragmentManager().beginTransaction().remove(this).commitAllowingStateLoss();
                }
            } catch (Throwable ignored) {}
            if (d != null) d.finished(ok);
        }
    }
}
