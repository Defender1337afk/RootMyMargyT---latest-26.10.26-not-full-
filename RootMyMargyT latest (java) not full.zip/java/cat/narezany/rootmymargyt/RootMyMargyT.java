package cat.narezany.rootmymargyt;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Outline;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.os.Process;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.view.ViewTreeObserver;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.lang.reflect.Method;
import java.util.List;

import cat.narezany.margyt.plugin.MargyPlugin;
import cat.narezany.margyt.plugin.PluginContext;
import cat.narezany.rootmymargyt.core.FrameScheduler;
import cat.narezany.rootmymargyt.core.Root;

/**
 * RootMyMargyT — абсолютный Superuser / Root-пакет для MargyT.
 *
 * - Перетаскиваемая мини-иконка с серым шотландским котом (AssistiveTouch).
 * - Рамка аватара «Ушки фембоя» (адаптивная под все формы AvatarShape MargyT).
 * - Graviboard: монолитные карточки видео летают во весь экран без обрезки.
 * - Персистентный фон профиля: копируется во внутреннюю память, строго ТОЛЬКО в профиле.
 * - Реалистичный дождь со стеклянными каплями на экране (3D линзы с преломлением) и снег.
 * - 17 HD бейджей с Bulletproof Badge Engine: нулевое падение в зеленую ноту!
 * - Famous Mode — накрутка лайков, просмотров и подписчиков с кастомными числами.
 */
public class RootMyMargyT extends MargyPlugin {

    public static final String[] BADGE_TITLES = RootBadgeEngine.BADGE_TITLES;
    public static final String[] BADGE_DESCRIPTIONS = RootBadgeEngine.BADGE_DESCRIPTIONS;

    public static final String[] GRADIENT_NAMES = RootBadgeEngine.GRADIENT_NAMES;
    public static final String[][] GRADIENT_PALETTES = RootBadgeEngine.GRADIENT_PALETTES;

    private static final String FLOATING_BTN_TAG = "rootmymargyt_floating_btn";
    private static final String WEATHER_VIEW_TAG = "rootmymargyt_weather_overlay";
    private static final String AMBILIGHT_VIEW_TAG = "rootmymargyt_ambilight_overlay";

    public static Bitmap getBadgeBitmap(int idx) {
        String b64 = RootBadgeEngine.getBadgeBase64(idx);
        if (b64 != null) {
            return BadgeAssets.decode(b64);
        }
        return null;
    }

    @Override
    public void onStart(Context context) {
        try {
            // Новый фундамент: все фичи — как Feature через реестр Root, кадры — через FrameScheduler.
            Root.bind(margyt());
            // «Мы строго в профиле» — детектор фон-движка; кормит Tick.inProfile всем фичам.
            Root.setProfileProbe(a -> {
                View d = a.getWindow() != null ? a.getWindow().getDecorView() : null;
                return d instanceof ViewGroup && RootWallpaperEngine.isLocalUserProfileThrottled((ViewGroup) d);
            });
            // Порядок = порядок в кадре: бейджи/фоны → текст профиля → покадровые оверлеи последними.
            Root.register(new BadgesFeature());
            Root.register(new WallpaperFeature());
            Root.register(new CommentBackgroundFeature());
            Root.register(new ProfileTextFeature());
            Root.register(new OverlaysFeature());
            Root.dispatchStart(context);

            loadSavedWallpaper(context);
            LimitBugSwap.apply(context, margyt());

            boolean gravOn = margyt() != null && margyt().getBoolean("root_graviboard", false);
            GravityShakeEngine.getInstance().setEnabled(gravOn);
            GravityShakeEngine.getInstance().start(context);
        } catch (Throwable t) {
            if (margyt() != null) margyt().log("onStart error: " + t);
        }
    }

    @Override
    public List onFeed(List posts) {
        return Root.dispatchFeed(posts);
    }

    @Override
    public CharSequence onText(CharSequence text) {
        return Root.dispatchText(text);
    }

    @Override
    public void onActivityResumed(Activity activity) {
        if (activity == null || activity.isFinishing()) return;

        AstraExploitEngine.checkAndHandlePatchReboots(activity, margyt());
        AstraExploitEngine.injectIntoSettings(activity, margyt());

        Root.dispatchResume(activity); // бейджи/текст/фон профиля/фон комментов (через реестр Feature)
        // Clawd-питомец смотрит на касания (лайки, комментарии, свайпы) — только наблюдение
        TouchSpy.install(activity);
        TilkajoModeEngine.applyTilkajoMode(activity, margyt());
        removeFloatingButton(activity);
        FrameScheduler.install(activity); // единый покадровый планировщик (раздаёт Tick фичам)
        updateWeatherOverlay(activity);
        updateAmbilightOverlay(activity);

        FunFx.onResumed(activity, margyt());

        GravityShakeEngine.getInstance().start(activity);
        GravityShakeEngine.getInstance().setProfileActivity(activity);
    }

    @Override
    public void onActivityPaused(Activity activity) {
        Root.dispatchPause(activity); // LiveAvatarEngine.onPause теперь в OverlaysFeature
        FunFx.onPaused();
    }

    @Override
    public void onScreen(Activity activity, String name) {
        NavBarPositionEngine.noteScreen(name);
        if (activity != null && !activity.isFinishing()) {
            Root.dispatchScreen(activity, name);
            AstraExploitEngine.checkAndHandlePatchReboots(activity, margyt());
            AstraExploitEngine.injectIntoSettings(activity, margyt());

            TilkajoModeEngine.applyTilkajoMode(activity, margyt());
            removeFloatingButton(activity);
            FrameScheduler.install(activity);
            updateWeatherOverlay(activity);
            updateAmbilightOverlay(activity);

            NavBarPositionEngine.attachTouchHook(activity);
            NavBarPositionEngine.update(activity, margyt());
        }
    }

    @Override
    public String onName(String uid, String name) {
        // Детект владельца + защита бейджей/градиента — в BadgesFeature.onName (через реестр).
        return Root.dispatchName(uid, name);
    }

    @Override
    public void onAccountChanged(String uid) {
        // Аккаунт прогрузился — фичи перечитывают per-account состояние (фикс «первый заход: дефолт ник»).
        Root.dispatchAccountChanged(uid);
    }

    @Override
    public boolean onOpenSettings(Activity activity) {
        if (activity != null && !activity.isFinishing()) {
            try {
                Intent intent = new Intent(activity, Class.forName("cat.narezany.margyt.SettingsActivity"));
                activity.startActivity(intent);
                return true;
            } catch (Throwable t) {
                handleOpenRoot(activity);
                return true;
            }
        }
        return false;
    }

    public void handleOpenRoot(Activity activity) {
        if (!RootInstaller.isInstalled(margyt())) {
            RootInstaller.showInstallPrompt(activity, margyt(), () -> openRootPanel(activity));
        } else {
            openRootPanel(activity);
        }
    }

    public void openRootPanel(Activity activity) {
        RootBadgeEngine.enforceMemoryState(margyt());

        RootPanel.show(activity, margyt(), new RootPanel.Callback() {
            @Override
            public void onBadgesChanged() {
                RootBadgeEngine.enforceMemoryState(margyt());
                RootBadgeEngine.saveFilesAndJson(activity, margyt());
            }

            @Override
            public void onWallpaperSelected(String path) {
                copyAndSaveWallpaper(activity, path);
            }

            @Override
            public void onApplyWallpaperNow() {
                RootWallpaperEngine.invalidateBitmap();
                RootWallpaperEngine.updateProfileWallpaper(activity, margyt());
                CommentWallpaperEngine.update(activity, margyt(), true);
            }

            @Override
            public void onGradientSelected(int index) {
                RootBadgeEngine.enforceMemoryState(margyt());
                RootBadgeEngine.saveFilesAndJson(activity, margyt());
                if (margyt() != null) margyt().showWindow("Градиент ника", "Установлен стиль: " + GRADIENT_NAMES[index]);
            }

            @Override
            public void onFlushMemory() {
                flushMemory(activity);
            }

            @Override
            public void onToggleGravityShake(boolean on) {
                GravityShakeEngine.getInstance().setEnabled(on);
                if (margyt() != null) margyt().showWindow("Graviboard", on ? "📱 Падающие видео активны! Потрясите телефон в профиле!" : "Graviboard выключен.");
            }

            @Override
            public void onTestGraviboardNow() {
                GravityShakeEngine.getInstance().triggerManually(activity);
            }

            @Override
            public void onWeatherModeSelected(int mode, boolean droplets) {
                updateWeatherOverlay(activity);
                if (margyt() != null) {
                    String desc = (mode == WeatherOverlayView.MODE_RAIN) ? "🌧️ Реалистичный дождь включен!" :
                                  (mode == WeatherOverlayView.MODE_SNOW) ? "❄️ Зимний снегопад включен!" :
                                  (mode == WeatherOverlayView.MODE_SAKURA) ? "🌸 Лепестки сакуры включены!" : "Погода выключена.";
                    margyt().showWindow("Погодные эффекты", desc);
                }
            }

            @Override
            public void onAmbilightChanged() {
                updateAmbilightOverlay(activity);
            }

            @Override
            public void onTilkajoModeChanged(boolean on) {
                if (activity != null) {
                    TilkajoModeEngine.applyTilkajoMode(activity, margyt());
                    ViewGroup decor = (ViewGroup) activity.getWindow().getDecorView();
                    ImageView fBtn = decor.findViewWithTag(FLOATING_BTN_TAG);
                    if (fBtn != null) {
                        Bitmap bmp = on ? TilkajoAssets.getCircleTilkajoIcon() : CatAssets.getCatBitmap();
                        if (bmp != null) fBtn.setImageBitmap(bmp);
                    }
                }
                if (margyt() != null) {
                    margyt().showWindow("Режим Тилкайо", on ? "🐾 Режим Тилкайо активен! Кнопки ленты и нижней панели — Тилкайо, тапни — мяукнет." : "Режим Тилкайо выключен.");
                }
            }

            @Override
            public void onFastRestart() {
                fastRestartApp(activity);
            }

            @Override
            public void onReinstallRoot() {
                RootInstaller.showInstallPrompt(activity, margyt(), () -> openRootPanel(activity));
            }

            @Override
            public void onNavBarPositionChanged(int pos) {
                NavBarPositionEngine.applyPosition(activity, margyt());
            }
        });
    }


    public void copyAndSaveWallpaper(Activity activity, String sourcePath) {
        boolean ok = RootWallpaperEngine.saveWallpaperFromPath(activity, sourcePath, margyt());
        if (ok) {
            Toast.makeText(activity, "Обои профиля сохранены персистентно!", Toast.LENGTH_SHORT).show();
            RootWallpaperEngine.updateProfileWallpaper(activity, margyt());
        }
    }

    public static void saveWallpaperFromUri(Context context, android.net.Uri uri, PluginContext margyt) {
        boolean ok = RootWallpaperEngine.saveWallpaperFromUri(context, uri, margyt);
        if (ok) {
            Toast.makeText(context, "Обои профиля сохранены персистентно!", Toast.LENGTH_SHORT).show();
            if (context instanceof Activity) {
                RootWallpaperEngine.updateProfileWallpaper((Activity) context, margyt);
            }
        }
    }

    private void loadSavedWallpaper(Context context) {
        RootWallpaperEngine.getWallpaperBitmap(context, margyt());
    }

    private void updateWeatherOverlay(Activity activity) {
        updateWeatherOverlayStatic(activity, margyt());
    }

    public static void updateWeatherOverlayStatic(Activity activity, PluginContext margyt) {
        if (activity == null || activity.isFinishing()) return;

        ViewGroup decor = (ViewGroup) activity.getWindow().getDecorView();
        WeatherOverlayView weatherView = decor.findViewWithTag(WEATHER_VIEW_TAG);

        int mode = margyt != null ? margyt.getInt("weather_mode", WeatherOverlayView.MODE_OFF) : WeatherOverlayView.MODE_OFF;
        boolean droplets = margyt != null && margyt.getBoolean("weather_droplets_blur", false);

        if (mode == WeatherOverlayView.MODE_OFF) {
            if (weatherView != null) weatherView.setVisibility(View.GONE);
            return;
        }

        if (weatherView == null) {
            weatherView = new WeatherOverlayView(activity);
            weatherView.setTag(WEATHER_VIEW_TAG);
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
            );
            decor.addView(weatherView, lp);
        }

        weatherView.setWeatherMode(mode, droplets);
        weatherView.bringToFront();
    }

    private void updateAmbilightOverlay(Activity activity) {
        updateAmbilightOverlayStatic(activity, margyt());
    }

    public static void updateAmbilightOverlayStatic(Activity activity, PluginContext margyt) {
        if (activity == null || activity.isFinishing()) return;

        ViewGroup decor = (ViewGroup) activity.getWindow().getDecorView();
        AmbilightOverlayView ambilightView = decor.findViewWithTag(AMBILIGHT_VIEW_TAG);

        boolean sakura = margyt != null && (margyt.getBoolean("sakura_neon", false) || margyt.getBoolean("sakura_glow_enabled", false));
        boolean vignette = margyt != null && (margyt.getBoolean("vignette_effect", false) || margyt.getBoolean("vignette_enabled", false));
        boolean pulse = margyt != null && margyt.getBoolean("sakura_pulse", true);

        if (!sakura && !vignette) {
            if (ambilightView != null) ambilightView.setVisibility(View.GONE);
            return;
        }

        if (ambilightView == null) {
            ambilightView = new AmbilightOverlayView(activity);
            ambilightView.setTag(AMBILIGHT_VIEW_TAG);
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
            );
            decor.addView(ambilightView, lp);
        }

        ambilightView.setVisibility(View.VISIBLE);
        ambilightView.setSakuraEnabled(sakura);
        ambilightView.setVignetteEnabled(vignette);
        ambilightView.setPulseEnabled(pulse);
        ambilightView.bringToFront();
    }

    private void removeFloatingButton(final Activity activity) {
        if (activity == null || activity.isFinishing()) return;
        try {
            final ViewGroup decor = (ViewGroup) activity.getWindow().getDecorView();
            if (decor != null) {
                View existing = decor.findViewWithTag(FLOATING_BTN_TAG);
                if (existing != null) {
                    decor.removeView(existing);
                }
            }
        } catch (Throwable ignored) {}
    }

    private void flushMemory(Activity activity) {
        try {
            long before = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
            System.gc();
            Runtime.getRuntime().gc();
            RootBadgeEngine.enforceMemoryState(margyt());
            long after = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
            long freed = Math.max(0, before - after) / 1024 / 1024;
            String msg = "Superuser RAM оптимизирована!\nОсвобождено: ~" + freed + " MB";
            Toast.makeText(activity, msg, Toast.LENGTH_SHORT).show();
        } catch (Throwable t) {
            Toast.makeText(activity, "Память оптимизирована.", Toast.LENGTH_SHORT).show();
        }
    }

    public static void fastRestartApp(Activity activity) {
        try {
            Context ctx = activity.getApplicationContext();
            Intent intent = ctx.getPackageManager().getLaunchIntentForPackage(ctx.getPackageName());
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                ctx.startActivity(intent);
            }
            Process.killProcess(Process.myPid());
            System.exit(0);
        } catch (Throwable t) {
            activity.finishAffinity();
        }
    }

    private static int dp(Context ctx, int val) {
        return (int) TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP, val, ctx.getResources().getDisplayMetrics()
        );
    }
}
