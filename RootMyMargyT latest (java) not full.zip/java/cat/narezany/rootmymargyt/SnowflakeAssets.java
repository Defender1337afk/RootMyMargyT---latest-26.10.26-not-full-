package cat.narezany.rootmymargyt;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;

/**
 * SnowflakeAssets — HD текстура снежинки от пользователя с чистой альфа-прозрачностью.
 */
public final class SnowflakeAssets {
    private static Bitmap snowflakeBitmap;

    public static final String SNOWFLAKE_B64 = 
        "iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAYAAADimHc4AAAVlUlEQVR42u1dabRdRZX+zrn3vYQkakiQQIQMBIEA2oKCghgGEUVQJIRJoEUQV0t3FIceBBpB" +
        "ltLSCxRaRZciKjSwXAaZJTJEoiIEghGaKQxGyGKeyfjuPefrH+crsinqnFvnvnf7vbScte660xmqdu29aw9f7UpIYj08xgKYDeC9AJ4DcA2ARQAS/b/edCoZ" +
        "YQOQAEj1OfcI6Yi7EYCfAdjX/LcKwJkAvl4yAO6+NK8RcaQjiPhNESbTKwHQMP839P9cEb+l89oANgBwKoAP6pyGIXyfuW8+0vqdjiDObwOYBGAnADM1IJne" +
        "U8O1u+v3VIRuGuIe5HF8ooGaCGAHANtpQPKR0vd0hBCfAI4AcL10+R8BXAZglgYmF7ETAKM8ybAEz/W5qc85gKMBXKf73grglwC2GTGDQHI4Xw2970qyzeJo" +
        "cd3xIslzSW5lrrlV/7XNee7zD8157yJ5nTknI5nr80MkZ5BMSKbDSYPh5gCKY78orh7Qey7Of4t0/gKplyaANRX3WwFgDICTAPwWwId1r8xI2hoAMwDsre/p" +
        "cE98w3nkasPbzefEs1oyAJOlOi4DsFlAfbpzdwRwOYAP6Xc3V6RGVTn1tPVIMFmHewAa4vRLAPyduLM/QDCKaLMDZqn9vIfe27q3P1e0zYD95o1JeJ0KugDA" +
        "zQBG63tWMsm2O3CsU11Nb4BgLKomgHM0AIkxTf8mB8BZLU8DmAPgmwBeNvNA7g1CiLB+f5oBwjvf4E4ARwE4wdybb3jC6yZIAHgXgBMBHKzvrQjClw0uzWCe" +
        "JW/5Wf2WvRGKeD33pkZPHyGJmOIRM+ZoG0n4vUIU1+t7X4QqG/ED0PC4Nh/CDtmYzRYAvgLgM8aDTSqkwf7/uAj/Y2MNDWUcKDHhERhDoecDUCa+yRBzVdNI" +
        "w04AvgZgv8hrLwZwCoCHzQSeDbH1lpUwT96rAUiM1bCTYjJ9AP4MYL7n7PRCLfUB+CcF3d7kmZ/umY/JCbuoh+rG9XEigI8A2BJFSPxmAHfXpkENt9m57J8i" +
        "uYKvPS4kuYFc+1647E29QPJ3FaGIs3VOX49CDO6e25G83aPBCyQP9M4bslCEE63dAPxQ7n5L3DUA4EgAn685UdY5rCnZV3HeaKPr8x5Yak79fB/Ae9R3R4Px" +
        "mm82qxPiqDMAAPBRRSMzEaJp9OHHvEmprpqpMxBVjl1e47lJzXbmALZXWNvSoF//TQDwTuNgDrkj1g7c3FkDbzZxlqTGs63D1ejC3u/GcrGWW1JTavsrJD2r" +
        "2/5mCWEa3k3dsbbiAX0oMlNrIyYix0394qg1AO7Xsxo9UiGpiYz2KRj3CoC/1jQgBkra5kIoK4w0hmiZV0mAa2TLvHJzk3tKJAAA3iqLAB24IDHzyW0okiR3" +
        "Kjazt2lkOsQmbY4imX+snrtY/ZkH4N011MZEzYEMxLRWA7jPSHOIlkmZBDjiT5F5tZHc9qvl1KADV8Y4OW6+2BHAVZq43PFBAHsqMHcSgKdMunGwsa42gKkA" +
        "vgtgf0+dzAawM4Btxb1lkuB8iakAxhlpDWkCF0KZLHN9cwBPokBvPPcaf0HmUKLXe0ne5plXS0meINNuW5KrTWaJ5vNTykLZTFdZBuxqXTPgmZKZPi8i+W5z" +
        "nTUr/1hhhn7PnN9n+nY8yWXm3LZpu8vAHWVM3lDb3f2ODmTuHA1eJjmW5JtIfl6ZN3ssIrmlzcSlZsRnKC6/sxGZDEWy5NsAbtDsvybAJZRYTogw42CQCmkg" +
        "vNGSo7cQwBkosmItcWsdc7EllXg5gO+Jc/08QWL6MiUidA6Znwj0H5La4wD8SSHvGQa5sVb9Otlea03AqQCmSTT69LJh4VkAfiFrx3bUTT7jAEyvsK6sjr2n" +
        "RN86GEmmAf03qcC9TCoyiYgjpQA+B+AmAB83fWhWDNg9gwhPu/5OEbPOMIZEakzVNoAPoEB/5AASC/dYbS5iwE7PTVCrjLBrIxv8QgdiOkuopcn6CgCn6/eq" +
        "nPBqzV3z5CxtHkhLVnF3jGStrbim3xgRiedrODptap1JC+VYLOugGTKXAiZVKAg3rYMt7867L7LDThrGSnQXamLzB88Rd0/1YT8PzlJFeEeDThLgEkJjIwyN" +
        "NOAfuEn7PADLHd1s7nUtimzRvAAYKib54QYgM+iGpIJTYx026zjtqjnJV3OJSeZsYdRNGqnXnwPwUskAOBXiwg5b1HBiafrQpzDOaa+51szyiQkkHShrKPMs" +
        "nrIj1+sZkv9FcvMSC8Y9YzrJNZ4FwRKLiCXYnqp21LkfSf4pYP2k3m+bk/wByVcqnhNqy2pZbocGaI1Q1LHffD9F5lbMINjjSZL/TnKyZ4K6gZhiIqp5oOE+" +
        "gQZztCv+c/e/1otgWsJPIXkqyWdrPNMCwHY39+r3I6WpFyNxkb1NABwv6yOv4aY7HM8kZaPmK5s1wQTSUhRJ+GUV5twfdE46iHi+jS/dDWBp4HnunGX6vd84" +
        "buPVhwVKBk2MCAb6x3gAxwA40ADP8tdMzl4MfxuS3yX5YI2Rzkt+t47K3SQP8dTcpQEOHTBx/Z1I3mL+a9XgQHvuT0hOMzDFVuC8r3nc/w9SS/a8vEb/Q5K2" +
        "mOQXSU60qsh9mEjydGExGfAYQw9uBz6HxN92+BqSe+iZZ1YQ5Bqd8xaS31KyI2YQ7MA/TfLvdZ+3kXw0oNbcuQdorjo0MOhZRd/yiAHy7/EUyf+UxwyQHE/y" +
        "Jo+YWQXR7X8veZNpu6QhmbluQFx5ZUVI4Q6Skwyn7EryxpJ5IvTbjSR3NtdvTfKJijnmQpKXR0zaPrOtJrmyxnX2v5+RHAeJBUmu7TCK9r+XSX5dqbn3kPxR" +
        "CWdVcU3VpLhMkx+MUTBW0tAKiH5mJv9PkRznXft+nd/JiqoiYMs772KSO5B8p1TmM17/O2mFNsldQfLbemir5KFt08lFJOeS3CQQrPoIyas0kJ06M9DBLHxC" +
        "XGvNwZhg3PeNxdUwwb/jIhijVcEUmZH460jOCvR/mp7/UIQKc+2dDZL7ezo/C4zeApKzPfMsNZ20ptVHTeK8aiDKdLg7d2dN2n16b+q9UzQ0NZFLd+1Xak7k" +
        "vrRkJH9F8gMR/d+E5Fe9pH1u6Dug74+TnAGSo6WT/eNFkheQ3NuIdKIHJiWh5oaZPA8geWcHvV1ltx/lOXPNGuHofjMIIHl+hE9QNp/cTnIf8/xGCerBd9wm" +
        "kvyEtEao7/9CMrUOwlGavJaQ/I6J7VvzLImEkLjPY2TiLe/CiXlC6m5Dz6O+NUICXDs30j0er8EEjluXkDzYzCNJJA3SAA0OEJNfIxV2nDsXgRuOCohZHbyP" +
        "kxLrUb+V5Lwa3q0llO/G3xIxB2xK8jMBNRD73BMDNKmLM0oqElOv0r1pwqQu+DbgLXLrBivpon/jUaxWOQjFKsXYvKvzvNsA3gfgUgCfFe6mURHKprzOM01+" +
        "OqsBQXHPnaPrL0Kx1Gmtl8KN8Yhp0qmNAJIvC0ETu1lpblcouutmAjgcwCeVnKizWKMM6pEGkM/+eY8CeJuJy6MkHB3LCBmAG1EsDF+oMLLFFA0alDxYeLoF" +
        "o45BsUTocAAHGPwmXxf/eD2QKvEQbf65VfcoI1yj5FkNb2BDaOsQHP5BDcZ8JddbHYC6PR8A9+ApgiYeBmArIeccp5ZlonJDUPf/SkELG12sB4gBlKUG2dDS" +
        "syzuKa2QQCtJbQBLJBUXAXixG1T0YNcJu0n5EC9Mm3eIn/iufE7yXoV7J5Pcj+RvveDcYELSvk+zUM/YnuQZJO8POGN5hXnsRwseMOHmroDJg1lcvZuJA7Ui" +
        "kyXueEQm4xySEwKDe7wiqEN1XEXySM/Cg0zcT3txplgztW3CH1O6HYRuoeIuhBHrXTou/h9l2zYOmGvuvWkcmcN1Td3kjAsf3GqirzB4HN+mHysc0n9IImPD" +
        "zE5i5nTAQ/VkpfyYLiyAHMDGMk/7SqyUtpkTOEgDYUNBJieWPIvmWc8LrdGsaQEOblHKIFTQgYHcQWy44XmSv5SL7zs4m8grv3kIVdBiw6X2tamQbhcbdRqr" +
        "gpzkL5ej+X+mgqwof0GhaX8iyyISJiS5Ssn/uSqecbBUQExCJJZYLdO2SzV3TSX5zQB0sIqJMg9K6eJEu9RdFWNfgzFDnek1HcCn5e1uW2L6lZmhTQ/63u+t" +
        "lG8M4Qob52us0Wt8YPVNEtHWFSjK6VwK4FdSW12boUPpiE0Q0ngfodk29ZyaWEeMJc5RVmNAsgpnLsYRCzl+LwL4ubCmCwazMnKoF2r7C6wTgZc+Jsl4R6T3" +
        "WhWKoDjQxWRGldxjpf5rmsFMBxGKcJjR8+UB3+v1OesibMPQJGxNwGZFzDsmDGuvG63Jb55g7nlNU7LlQbv36LBK8jySeymn3ClhXoXyeJjkfJKHqQ/+as1k" +
        "ELSxeRN0mrmTQYSj+7zfz+0iLEzZ8scZJyomITOK5DEkH+vCc3YJ86YHqGr0IhxtkwYnKlnwazkkO3SRkEm8hm+gxR331OBER4SHZSJu6GWiYlKSTQOBPF1Q" +
        "kDqDnynMcKxHxGYkt/d533cn+WPlMq6WtfdqQqZPNrl/DAiusZsRw9iU5BglUe4eBJTwSPPMblKSTQ9iWTcn7I4b1JexHVKSSSAl+UlBfgYCzziZZAMkDzJB" +
        "q1YJIOvXJI/w9GGjJCn9YZK/CSTl66QDKeRBaiQvNilvCdGv73O7QNf5YIIbNb/4WNfU6/8kQX0WBe5nk/IrSO4MFmjmrCRh7Q/GYpL/aNSCD0u5VmClGIxN" +
        "VjEJrjQqsGHQDSD5h4iUZL+Z8EBy3w64oKxCRVoarJBBsV2g/5uT/LIHRCjDBzlGOAIiKOWKVwGz7I0ellhvS3JHkpdEArOySLTyX+StWnDVeJL/ygIeHkK4" +
        "5UrkHx7Ib+9SAW/PIz3hllcX4myS7xANugVm7QuFAJZGqIwQvO5FhRPqQBMd9vP6ACe7Tv5OYWon2rMM53eCJrakiqaagdhRIRM/yumk4hySV0TkIfx8xgvC" +
        "oJb1syx+RJKnuTkAJDfThPt0hR1eZaNXjfaAacRizTmjSZ5VAc69wlgdJwuRFmPTWwIvk8S4AN+yCnDux6XmDpSuzzrEovJAu/MOIWurPT7r5hAEJpBTPIno" +
        "ZDLmEQN0h5B1fUavL6iAp58lPXtTF/D03LM6/pvkzJLJ293zS4YG4xRkvDeCwLHGxYACd1818PSEBp6eeqblJDk/V3gqpo4V4wh/opf1cnbynQGOdM+4y0DS" +
        "sy5W6PjXLRHnlUnA+cbcde2cwNcvts5qmrGvSN3O9vyJ1HfErKNhG3EEyedqQgupRh8vZJo129wgv9l0LO9yedFQLlFaZExX34OdzmLRyoou0H1PiYalHnWo" +
        "GlRTCZFbagBrLar5JI/wdpGee5/pzQ2xop1HwNuzLhbp3R5wrnyPdqbU2aqaK2Namld2q1qk5x6+vYEQ1uF6R8xzOuAobTYtqynS7ZpcXyfsscyoyaQC65ma" +
        "YGCrC2k8X/nwV503ux54imLdM4SbadQoGZOYBdgNsyANFUWPYuPodrOGu1QqYZoXUnafb1Y4+n0BRF1Vuyfrvs9XFIBtmsKAZehBlsAmXdj6GCV0vuDalZoB" +
        "OEzEX6uEeRpoSNahIys7xMjdeTtEQiBdcY1VAH4C4P0oCiz5pXPc5zu0Sv5iw0BZZAGRSR0wp26Xjycr2p6UlPWxbTlMYIFXa0W4Y3kgTUhveWmjhGtZM4WY" +
        "RqAnXFvuFVj2WHHPaFTvrvQ8iqq7RwN4xCD48opn9WmVfUzbGh1qYNg6pXlJQoZ+ESIo4/OsUR8tb+uQJQC+4ZXkstxBkxXrtHT/7RUi3DapwEtQVNG6zsBY" +
        "GFEMfJSgg3sod+s4sBW43qUfZ0Yyz31eQRHL8Y8IkHyfx/Uto0ovNHBGpiYh/RyK8jDPSke7cjWLpbt2BXCtuMxP6TU0+g9EVNYCgCe85Du91OMSAIeqM0+Y" +
        "ssWosVi8KX19uCTiMXOfPFCw48+R918ZUDnufWsUlcBmqSbEQ6ZORALgSgDfsrRregnqC9SQfVCUfblf+nQV1tVLSwZR8sWd8yPh/fsDawt+jqJe9DPmt3aX" +
        "FR5TU8r4LlVcOdRrTxPA7SJcEoF0bnQwGMaiKNx0KoAfoCj/NkXPv9yrm4cy0BVKVs3sHbDRnSn3oFnbm0YAez9hwterFSfa1/NHQum9mIRMswROmSgWdbfM" +
        "yNXKXUyPAFb1mcrBZQ7eKhbLVpNASjYUcQhudmDNT7vaxYlYWlJqxsH7kojiqom44Qrds63FFQPebhkYQni6k6Z5KErZb6MSNUu9eayT9C6XRtjAU8W55p6p" +
        "4vbcq7HEkIVYttKkTAwnV6gbt6laKwLyQWOd3O/do+7SqLrgrAaKXToW1cT2uD6/rAEYE9hqMff8n459SbvY8yUPVDjJzHtSgyB+3bqsxxsr0HPQ0kijwQ7A" +
        "X1EUfM0DlVcaddF8aY2GA8AtpuGueLdTWwtNpSzWREznNTeOiNkMNIaR8pqD50rtLDVqsi1auP/uqrPOLq0pvvPlC/iFqy835lXWo+2uYGxqdCgrnPRggyIb" +
        "ZpgrB7FfNOjT/PclzRHRcMW6Gzi4huyFYi9fV+zu+sia0d3AHhsi+hgUO+79c6B0ppsM/4Jik4dr0fv9YjZVzGkrmcy/l2TUokFdbGjVdiDpEE+edguT3SR5" +
        "syKsqxaAn6JYK/xQj7YwKetrT7cwqaq936tNfLZEUfJsriQgiyhD6RjlSQBnoyik2u5BVfYy9PV6u42VrVsHIatPQ1F8tS483S7mvgHFdlgL/j9tY9UL4js7" +
        "eiupmzkY/EZuLqK6CkUl3fMUMOvFrk/r7QA4vbkBikqNX9YElw2RNWMXazwqafipjIYUw7yX5HAPgNP3Gyv0vGcHddOO8AWqrnVq6TzNK8TQbu623m3m6dTA" +
        "sSL+2pJ6z1W7pIZCHCEd3zRllT+HorzCsG9rPtwD4NTD/iaGn5YkaJoK3j1SUfD1F3o1jVPIQGowR7EjFP7Wt7N1xFjqca4jvKtY/gCK3VUPwbqkeCgnvFzW" +
        "06koMncNb/cnmkFfOBJoMBJUEFCk6dwCOxqVsQbFThS7oNjSfADVOeFxsnhOQ5EIudLLc2d6xhJJSjrcltBIUEEJijo8c1DUjM5E+AUoql+dgCLd2V8j1zBK" +
        "9zoARQZsAdZtULEARYr1mZGwo/Zw7ylvJ87rUCyAni6iPCI10jSQGJbodueFrvbUTIIiATMfxdLZVOGJFT0MHK53A2D3e39J6iEUD3JtvQ1FIHDAI2CKdZs2" +
        "27BAUwS/q4dxq/VWBfl2emIioImXlnTq6gwAl0klNUwm7lyFHXzObpswRzoS1M5IjQXV8Rv6UYTE99Xv10rNJIPYCWlYjv8F4NEhSyRCX3AAAAAASUVORK5C" +
        "YII=";

    public static synchronized Bitmap getSnowflakeBitmap() {
        if (snowflakeBitmap == null || snowflakeBitmap.isRecycled()) {
            try {
                byte[] bytes = Base64.decode(SNOWFLAKE_B64, Base64.DEFAULT);
                snowflakeBitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
            } catch (Throwable t) {
                snowflakeBitmap = null;
            }
        }
        return snowflakeBitmap;
    }
}
