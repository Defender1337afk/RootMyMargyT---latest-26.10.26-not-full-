package cat.narezany.rootmymargyt;

import android.app.Activity;
import android.content.Context;
import android.graphics.Matrix;
import android.graphics.RectF;
import android.os.SystemClock;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.Window;
import android.view.animation.DecelerateInterpolator;
import android.widget.TextView;

import java.lang.ref.WeakReference;
import java.lang.reflect.Field;
import java.lang.reflect.Proxy;
import java.util.Map;
import java.util.WeakHashMap;

import cat.narezany.margyt.plugin.PluginContext;

/**
 * NavBarPositionEngine — положение нижней панели вкладок TikTok (капсулы MargyT).
 *
 * 0: снизу (по умолчанию)
 * 1: вверху — только в ленте и остальных вкладках; в профиле панель всегда внизу,
 *    иначе закрыла бы шапку профиля.
 *
 * Вызывается на каждом кадре, поэтому:
 * - профиль определяется по выбранной вкладке (дёшево), полный обход дерева — только
 *   запасной путь и с кэшем;
 * - переходы (вверх/вниз, компактный размер в профиле) анимируются один раз при смене
 *   состояния, а между ними положение лишь поправляется, если TikTok его сбросил.
 *
 * Панель, поднятая наверх, выходит за границы родителя, и касания до неё сами не доходят —
 * их доставляет перехватчик Window.Callback.
 */
public final class NavBarPositionEngine {

    public static final int POS_BOTTOM = 0;
    public static final int POS_TOP = 1;

    public static final String KEY_POSITION = "navbar_position";
    public static final String KEY_COMPACT_IN_PROFILE = "navbar_compact_in_profile";
    /** Что делает поднятая наверх панель в профиле и поиске: 0 — опускается на место, 1 — прячется. */
    public static final String KEY_AWAY = "navbar_top_away";
    public static final String[] AWAY_NAMES = {"Опускать вниз", "Прятать"};

    public static final String[] POSITION_NAMES = new String[] {
        "Снизу (По умолчанию)",
        "Вверху (В ленте)"
    };

    private static final float COMPACT_SCALE = 0.84f;
    private static final long ANIM_MS = 220L;

    private static final WeakHashMap<Window, Boolean> HOOKED_WINDOWS = new WeakHashMap<>();
    private static WeakReference<ViewGroup> cachedBar = new WeakReference<>(null);
    private static WeakReference<Activity> cachedActivity = new WeakReference<>(null);

    private static WeakReference<View> cachedContentContainer = new WeakReference<>(null);
    private static WeakReference<View> lastShiftedContainer = new WeakReference<>(null);

    /** Последнее применённое состояние: по его смене запускается анимация. */
    private static WeakReference<ViewGroup> lastBar = new WeakReference<>(null);
    private static int lastEffectivePos = -1;
    private static boolean lastProfile = false;
    private static boolean lastCompact = false;
    private static boolean lastHidden = false;
    private static long animatingUntil = 0L;

    /** Последний экран, о котором сообщил MargyT (onScreen), — по нему узнаём поиск. */
    private static String lastScreen = "";
    private static long lastScreenAt = 0L;
    private static boolean searchCached = false;
    private static long searchCheckedAt = 0L;

    private NavBarPositionEngine() {}

    // ───────────────────────────── Настройки ─────────────────────────────

    public static int getPosition(PluginContext margyt) {
        if (margyt == null) return POS_BOTTOM;
        int p = margyt.getInt(KEY_POSITION, POS_BOTTOM);
        if (p != POS_TOP && p != POS_BOTTOM) {
            // Устаревшее значение (например, бывший режим «слева» = 2)
            margyt.prefs().edit().putInt(KEY_POSITION, POS_BOTTOM).apply();
            p = POS_BOTTOM;
        }
        return p;
    }

    public static void setPosition(PluginContext margyt, int pos) {
        if (margyt == null) return;
        if (pos != POS_TOP) pos = POS_BOTTOM;
        margyt.prefs().edit().putInt(KEY_POSITION, pos).apply();
    }

    public static boolean isCompactInProfile(PluginContext margyt) {
        return margyt == null || margyt.getBoolean(KEY_COMPACT_IN_PROFILE, true);
    }

    public static void setCompactInProfile(PluginContext margyt, boolean on) {
        if (margyt != null) margyt.prefs().edit().putBoolean(KEY_COMPACT_IN_PROFILE, on).apply();
    }

    public static int getAway(PluginContext margyt) {
        return margyt != null && margyt.getInt(KEY_AWAY, 0) == 1 ? 1 : 0;
    }

    public static void setAway(PluginContext margyt, int away) {
        if (margyt != null) margyt.prefs().edit().putInt(KEY_AWAY, away).apply();
    }

    /** Из onScreen: имя класса экрана. */
    public static void noteScreen(String name) {
        lastScreen = name == null ? "" : name.toLowerCase(java.util.Locale.ROOT);
        lastScreenAt = SystemClock.uptimeMillis();
        searchCheckedAt = 0L;
    }

    /**
     * Открыт ли поиск — по строке поиска вверху экрана (проверка по дереву не чаще раза в 300 мс).
     * Имя экрана от MargyT помогает только первые 1.5 с, пока строка появляется: о возврате
     * в ленту внутри той же activity MargyT может и не сообщить, и панель застряла бы внизу.
     */
    private static boolean isSearchActive(View decor) {
        long now = SystemClock.uptimeMillis();
        if (lastScreen.contains("search") && now - lastScreenAt < 1500L) return true;
        if (now - searchCheckedAt < 300L) return searchCached;
        searchCheckedAt = now;
        int w = decor.getWidth(), h = decor.getHeight();
        searchCached = w > 0 && h > 0 && findSearchField(decor, w, h, 0);
        return searchCached;
    }

    private static boolean findSearchField(View v, int w, int h, int depth) {
        if (v == null || depth > 35 || v.getVisibility() != View.VISIBLE) return false;
        if (v instanceof android.widget.EditText && v.isShown() && v.getWidth() >= w * 0.4f) {
            int[] at = new int[2];
            v.getLocationOnScreen(at);
            if (at[1] < h * 0.25f) {
                CharSequence hint = ((android.widget.EditText) v).getHint();
                String s = (hint != null ? hint : "").toString().toLowerCase(java.util.Locale.ROOT);
                if (s.contains("поиск") || s.contains("search") || s.contains("искать") || s.contains("найти")
                        || s.contains("пошук")) {
                    return true;
                }
            }
        }
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) {
                if (findSearchField(g.getChildAt(i), w, h, depth + 1)) return true;
            }
        }
        return false;
    }

    public static String getPositionTitle(int pos) {
        if (pos >= 0 && pos < POSITION_NAMES.length) return POSITION_NAMES[pos];
        return POSITION_NAMES[POS_BOTTOM];
    }

    // ───────────────────────────── Поиск панели ─────────────────────────────

    @SuppressWarnings("unchecked")
    public static ViewGroup findNavBar(Activity activity) {
        if (activity == null || activity.isFinishing()) return null;

        ViewGroup cached = cachedBar.get();
        if (cached != null && cachedActivity.get() == activity && cached.isAttachedToWindow()
                && cached.getVisibility() == View.VISIBLE) {
            return cached;
        }

        View decor = activity.getWindow() != null ? activity.getWindow().getDecorView() : null;
        if (decor == null) return null;

        // 1. Панель, на которую MargyT уже надел капсулу (cat.narezany.margyt.NavBar.BARS)
        try {
            Class<?> navBarClass = Class.forName("cat.narezany.margyt.NavBar");
            Field barsF = navBarClass.getDeclaredField("BARS");
            barsF.setAccessible(true);
            Map<View, ?> bars = (Map<View, ?>) barsF.get(null);
            if (bars != null) {
                for (View v : bars.keySet()) {
                    if (v instanceof ViewGroup && v.isAttachedToWindow() && v.getVisibility() == View.VISIBLE
                            && v.getRootView() == decor) {
                        return remember((ViewGroup) v, activity);
                    }
                }
            }
        } catch (Throwable ignored) {}

        // 2. Сами — по тем же правилам, что MargyT
        ViewGroup found = scanForBar(decor, decor, 0);
        return found != null ? remember(found, activity) : null;
    }

    private static ViewGroup remember(ViewGroup bar, Activity activity) {
        cachedBar = new WeakReference<>(bar);
        cachedActivity = new WeakReference<>(activity);
        return bar;
    }

    private static ViewGroup scanForBar(View view, View root, int depth) {
        if (!(view instanceof ViewGroup) || depth > 30 || view.getVisibility() != View.VISIBLE) return null;
        ViewGroup group = (ViewGroup) view;
        if (isBar(group, root)) return group;
        for (int i = 0; i < group.getChildCount(); i++) {
            ViewGroup found = scanForBar(group.getChildAt(i), root, depth + 1);
            if (found != null) return found;
        }
        return null;
    }

    /**
     * Ряд одинаковых кликабельных вкладок внизу экрана, ровно одна выбрана.
     * Положение берётся без нашего сдвига, иначе поднятая наверх панель не узнавалась бы,
     * а строка вкладок профиля («видео / лайки / репосты») — узнавалась.
     */
    private static boolean isBar(ViewGroup group, View root) {
        int wide = group.getWidth(), tall = group.getHeight();
        if (tall <= 0 || wide < root.getWidth() * 0.9f || tall > root.getHeight() * 0.15f) return false;
        int[] at = new int[2], origin = new int[2];
        group.getLocationOnScreen(at);
        root.getLocationOnScreen(origin);
        float layoutTop = at[1] - group.getTranslationY() - origin[1];
        if (layoutTop < root.getHeight() * 0.8f) return false;

        int tabs = 0, named = 0, selected = 0, width = -1;
        for (int i = 0; i < group.getChildCount(); i++) {
            View child = group.getChildAt(i);
            if (child.getVisibility() != View.VISIBLE) continue;
            if (!(child instanceof ViewGroup) || !child.isClickable()) return false;
            if (width < 0) width = child.getWidth();
            else if (Math.abs(child.getWidth() - width) > 2) return false;
            tabs++;
            if (hasTabName((ViewGroup) child)) named++;
            if (child.isSelected()) selected++;
        }
        return tabs >= 3 && tabs <= 6 && named >= 2 && selected == 1 && width > 0;
    }

    private static boolean hasTabName(ViewGroup tab) {
        for (int i = 0; i < tab.getChildCount(); i++) {
            View child = tab.getChildAt(i);
            if (child instanceof TextView) {
                CharSequence text = ((TextView) child).getText();
                if (text != null && text.length() > 0 && text.length() <= 24) return true;
            }
        }
        return false;
    }

    // ───────────────────────────── Применение ─────────────────────────────

    /** Снимает обрезку по границам у предков, чтобы поднятая панель была видна. */
    private static void unclipAncestors(View view) {
        if (view == null) return;
        ViewParent p = view.getParent();
        while (p instanceof ViewGroup) {
            ViewGroup vg = (ViewGroup) p;
            if (vg.getClipChildren()) vg.setClipChildren(false);
            if (vg.getClipToPadding()) vg.setClipToPadding(false);
            p = vg.getParent();
        }
    }

    public static int getStatusBarHeight(Context ctx) {
        if (ctx == null) return 72;
        int resId = ctx.getResources().getIdentifier("status_bar_height", "dimen", "android");
        if (resId > 0) return ctx.getResources().getDimensionPixelSize(resId);
        return dp(ctx, 28);
    }

    public static void applyPosition(Activity activity, PluginContext margyt) {
        if (activity == null || activity.isFinishing() || activity.getWindow() == null) return;
        ViewGroup bar = findNavBar(activity);
        if (bar == null || !bar.isAttachedToWindow()) return;

        View decor = activity.getWindow().getDecorView();
        // Панель другой activity не трогаем (например, когда настройку меняют из экрана настроек)
        if (bar.getRootView() != decor) return;

        int rootH = decor.getHeight();
        int barW = bar.getWidth();
        int barH = bar.getHeight();
        if (rootH <= 0 || barW <= 0 || barH <= 0 || !(bar.getParent() instanceof View)) return;

        boolean isProfile = isProfileActive(bar, decor);
        int wanted = getPosition(margyt);
        // Поднятая панель закрыла бы верхние кнопки профиля и строку поиска — там она уходит
        boolean away = wanted == POS_TOP && (isProfile || isSearchActive(decor));
        boolean hidden = away && getAway(margyt) == 1;
        int effectivePos = away ? POS_BOTTOM : wanted;
        boolean compact = isProfile && isCompactInProfile(margyt);

        // Остатки старого режима «слева»
        if (bar.getRotation() != 0f) bar.setRotation(0f);
        if (bar.getTranslationX() != 0f) bar.setTranslationX(0f);

        // Где панель стоит по разметке, без наших сдвигов и масштаба
        int[] parentLoc = new int[2];
        ((View) bar.getParent()).getLocationOnScreen(parentLoc);
        int[] rootLoc = new int[2];
        decor.getLocationOnScreen(rootLoc);
        float layoutTop = parentLoc[1] + bar.getTop();

        float targetScale = compact ? COMPACT_SCALE : 1f;
        float targetTransY = 0f;
        float targetAlpha = 1f;
        int chinH = 0;
        if (hidden) {
            // Уезжает за верхний край и гаснет; касания до неё не доходят (перехватчик смотрит на alpha)
            targetTransY = rootLoc[1] - layoutTop - barH * 1.3f;
            targetAlpha = 0f;
        }
        if (effectivePos == POS_TOP) {
            // «Подбородок» — место, которое панель занимала внизу; на столько опускаем ленту
            chinH = Math.round(rootLoc[1] + rootH - layoutTop);
            if (chinH <= 0 || chinH > rootH * 0.25f) chinH = barH;
            targetTransY = rootLoc[1] + getStatusBarHeight(activity) + dp(activity, 4) - layoutTop;
        }

        // Компактная панель сжимается к нижнему краю, а не к центру — не повисает над краем экрана
        bar.setPivotX(barW / 2f);
        bar.setPivotY(barH);

        boolean changed = lastBar.get() != bar || lastEffectivePos != effectivePos
            || lastProfile != isProfile || lastCompact != compact || lastHidden != hidden;
        long now = SystemClock.uptimeMillis();
        if (changed) {
            boolean first = lastBar.get() != bar;
            lastBar = new WeakReference<>(bar);
            lastEffectivePos = effectivePos;
            lastProfile = isProfile;
            lastCompact = compact;
            lastHidden = hidden;
            if (first) {
                bar.setScaleX(targetScale);
                bar.setScaleY(targetScale);
                bar.setTranslationY(targetTransY);
                bar.setAlpha(targetAlpha);
            } else {
                animatingUntil = now + ANIM_MS + 50;
                bar.animate().cancel();
                bar.animate()
                    .scaleX(targetScale).scaleY(targetScale)
                    .translationY(targetTransY)
                    .alpha(targetAlpha)
                    .setDuration(ANIM_MS)
                    .setInterpolator(new DecelerateInterpolator())
                    .start();
            }
        } else if (now >= animatingUntil) {
            // TikTok мог пересобрать или сбросить панель — молча возвращаем на место
            if (Math.abs(bar.getScaleX() - targetScale) > 0.005f) {
                bar.setScaleX(targetScale);
                bar.setScaleY(targetScale);
            }
            if (Math.abs(bar.getTranslationY() - targetTransY) > 1f) bar.setTranslationY(targetTransY);
            if (Math.abs(bar.getAlpha() - targetAlpha) > 0.01f) bar.setAlpha(targetAlpha);
        }

        if (effectivePos == POS_TOP) {
            unclipAncestors(bar);
            attachTouchHook(activity);
            applyContentContainerShift(activity, bar, chinH, changed);
        } else {
            resetContentContainerShift(activity, bar, changed);
        }
    }

    private static void applyContentContainerShift(Activity activity, ViewGroup bar, int shiftY, boolean animate) {
        View content = findFeedContentContainer(activity, bar);
        if (content == null) return;
        lastShiftedContainer = new WeakReference<>(content);
        unclipAncestors(content);
        moveContent(content, shiftY, animate);
    }

    private static void resetContentContainerShift(Activity activity, ViewGroup bar, boolean animate) {
        View content = lastShiftedContainer.get();
        if (content != null) moveContent(content, 0f, animate);
        View current = cachedContentContainer.get();
        if (current != null && current != content) moveContent(current, 0f, animate);
    }

    private static void moveContent(View content, float y, boolean animate) {
        if (Math.abs(content.getTranslationY() - y) <= 0.5f) return;
        if (animate) {
            content.animate().cancel();
            content.animate().translationY(y).setDuration(ANIM_MS)
                .setInterpolator(new DecelerateInterpolator()).start();
        } else if (SystemClock.uptimeMillis() >= animatingUntil) {
            content.setTranslationY(y);
        }
    }

    /** Главный контейнер страниц (сосед панели по иерархии). */
    public static View findFeedContentContainer(Activity activity, ViewGroup bar) {
        if (activity == null || bar == null) return null;
        View cached = cachedContentContainer.get();
        if (cached != null && cached.isAttachedToWindow() && cached.getVisibility() == View.VISIBLE) return cached;

        View decor = activity.getWindow() != null ? activity.getWindow().getDecorView() : null;
        if (decor == null) return null;
        int rootW = decor.getWidth();
        int rootH = decor.getHeight();
        if (rootW <= 0 || rootH <= 0) return null;

        View current = bar;
        ViewParent p = current.getParent();
        while (p instanceof ViewGroup && p != decor) {
            ViewGroup vg = (ViewGroup) p;
            View bestChild = null;
            int maxArea = 0;
            for (int i = 0; i < vg.getChildCount(); i++) {
                View child = vg.getChildAt(i);
                if (child == current || isDescendant(bar, child)) continue;
                if (child.getVisibility() == View.VISIBLE
                        && child.getWidth() >= rootW * 0.70f && child.getHeight() >= rootH * 0.55f) {
                    int area = child.getWidth() * child.getHeight();
                    if (area > maxArea) {
                        maxArea = area;
                        bestChild = child;
                    }
                }
            }
            if (bestChild != null) {
                cachedContentContainer = new WeakReference<>(bestChild);
                return bestChild;
            }
            current = vg;
            p = vg.getParent();
        }
        return null;
    }

    private static boolean isDescendant(View child, View root) {
        if (child == null || root == null) return false;
        ViewParent p = child.getParent();
        while (p instanceof View) {
            if (p == root) return true;
            p = p.getParent();
        }
        return false;
    }

    /**
     * Профиль ли сейчас: по выбранной вкладке (у TikTok «Профиль» последняя). Обход дерева —
     * только если выбранной вкладки не видно, и то через кэш на 250 мс.
     */
    public static boolean isProfileActive(ViewGroup bar, View decor) {
        if (bar != null) {
            View selected = null;
            View lastVisible = null;
            for (int i = 0; i < bar.getChildCount(); i++) {
                View tab = bar.getChildAt(i);
                if (tab == null || tab.getVisibility() != View.VISIBLE) continue;
                lastVisible = tab;
                if (tab.isSelected()) selected = tab;
            }
            if (selected != null && (selected == lastVisible || isProfileTab(selected))) return true;
        }
        return decor instanceof ViewGroup && RootWallpaperEngine.isLocalUserProfileThrottled((ViewGroup) decor);
    }

    private static boolean isProfileTab(View tab) {
        if (tab instanceof ViewGroup) {
            ViewGroup vg = (ViewGroup) tab;
            for (int i = 0; i < vg.getChildCount(); i++) {
                View child = vg.getChildAt(i);
                if (child instanceof TextView) {
                    CharSequence cs = ((TextView) child).getText();
                    if (cs != null) {
                        String s = cs.toString().trim().toLowerCase();
                        if (s.contains("профиль") || s.contains("profile") || s.equals("я") || s.equals("me")) return true;
                    }
                }
                if (child instanceof ViewGroup && isProfileTab(child)) return true;
            }
        }
        return false;
    }

    // ───────────────────────────── Касания ─────────────────────────────

    /** Видимые границы панели на экране с учётом сдвига и масштаба. */
    public static RectF getVisualBounds(View bar) {
        if (bar == null || !(bar.getParent() instanceof View)) return new RectF();
        int[] parentLoc = new int[2];
        ((View) bar.getParent()).getLocationOnScreen(parentLoc);
        RectF r = new RectF(0, 0, bar.getWidth(), bar.getHeight());
        bar.getMatrix().mapRect(r);
        r.offset(parentLoc[0] + bar.getLeft(), parentLoc[1] + bar.getTop());
        return r;
    }

    /** Доставляет касание в панель, переводя экранные координаты в её собственные. */
    private static boolean deliverTouchToBar(ViewGroup bar, MotionEvent ev) {
        if (bar == null || !(bar.getParent() instanceof View)) return false;
        try {
            int[] parentLoc = new int[2];
            ((View) bar.getParent()).getLocationOnScreen(parentLoc);
            // getMatrix() задаёт сдвиг и масштаб относительно (left, top) панели в родителе
            float[] pts = new float[] {
                ev.getRawX() - parentLoc[0] - bar.getLeft(),
                ev.getRawY() - parentLoc[1] - bar.getTop()
            };
            Matrix inverse = new Matrix();
            if (!bar.getMatrix().invert(inverse)) return false;
            inverse.mapPoints(pts);

            MotionEvent local = MotionEvent.obtain(ev);
            local.setLocation(pts[0], pts[1]);
            try {
                return bar.dispatchTouchEvent(local);
            } finally {
                local.recycle();
            }
        } catch (Throwable t) {
            return false;
        }
    }

    public static void attachTouchHook(final Activity activity) {
        if (activity == null || activity.isFinishing()) return;
        final Window window = activity.getWindow();
        if (window == null) return;

        synchronized (HOOKED_WINDOWS) {
            if (HOOKED_WINDOWS.containsKey(window)) return;
            HOOKED_WINDOWS.put(window, Boolean.TRUE);
        }

        final Window.Callback base = window.getCallback();
        if (base == null) return;

        final boolean[] touchingBar = new boolean[] { false };

        Window.Callback proxy = (Window.Callback) Proxy.newProxyInstance(
            base.getClass().getClassLoader(),
            new Class<?>[] { Window.Callback.class },
            (p, method, args) -> {
                if ("dispatchTouchEvent".equals(method.getName()) && args != null && args.length == 1
                        && args[0] instanceof MotionEvent) {
                    MotionEvent ev = (MotionEvent) args[0];
                    int action = ev.getActionMasked();
                    ViewGroup bar = cachedBar.get();
                    boolean raised = bar != null && bar.isAttachedToWindow() && bar.getVisibility() == View.VISIBLE
                        && bar.getAlpha() > 0.1f && bar.getTranslationY() < -1f;

                    if (action == MotionEvent.ACTION_DOWN) {
                        touchingBar[0] = raised && getVisualBounds(bar).contains(ev.getRawX(), ev.getRawY());
                    }
                    if (touchingBar[0] && bar != null) {
                        boolean handled = deliverTouchToBar(bar, ev);
                        if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
                            touchingBar[0] = false;
                        }
                        if (handled) return true;
                        // Панель не взяла нажатие — дальнейшие события жеста пусть идут как обычно
                        if (action == MotionEvent.ACTION_DOWN) touchingBar[0] = false;
                    }
                }
                try {
                    return method.invoke(base, args);
                } catch (java.lang.reflect.InvocationTargetException e) {
                    throw e.getCause() != null ? e.getCause() : e;
                }
            }
        );

        window.setCallback(proxy);
    }

    public static void update(Activity activity, PluginContext margyt) {
        // Перф: при дефолте (панель снизу, без «компактной в профиле») каждый кадр панель не трогаем —
        // иначе зря ищем навбар в дереве и считаем раскладку. На смену настройки/экрана applyPosition
        // всё равно вызывается (колбэк настроек + onScreen), поэтому переход на дефолт применится.
        if (getPosition(margyt) == POS_BOTTOM && !isCompactInProfile(margyt)) return;
        try {
            applyPosition(activity, margyt);
        } catch (Throwable ignored) {
            // панель разобрана посреди кадра — на следующем кадре попробуем снова
        }
    }

    private static int dp(Context ctx, int val) {
        if (ctx == null) return val * 2;
        return (int) TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP, val, ctx.getResources().getDisplayMetrics()
        );
    }
}
