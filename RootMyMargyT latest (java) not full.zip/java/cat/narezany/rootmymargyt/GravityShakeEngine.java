package cat.narezany.rootmymargyt;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Shader;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.HapticFeedbackConstants;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * GravityShakeEngine — Graviboard для MargyT без обрезки!
 * 
 * Строго захватывает ТОЛЬКО активную текущую вкладку профиля (мои видео),
 * игнорируя скрытые вкладки репостов и лайков в ViewPager.
 */
public final class GravityShakeEngine implements SensorEventListener {

    private static GravityShakeEngine instance;

    public static synchronized GravityShakeEngine getInstance() {
        if (instance == null) {
            instance = new GravityShakeEngine();
        }
        return instance;
    }

    private SensorManager sensorManager;
    private android.content.Context appContext;
    private Sensor accelerometer;
    private boolean isRegistered = false;
    private boolean isEnabled = false;

    private float gravityX = 0f;
    private float gravityY = 9.8f;
    private long lastShakeTime = 0;
    private long lastCollisionHapticTime = 0;

    private boolean isPhysicsActive = false;
    private final Handler physicsHandler = new Handler(Looper.getMainLooper());
    private Activity currentActivity;
    private GraviboardOverlayView currentOverlay;

    private final Random random = new Random();

    private GravityShakeEngine() {}

    public void start(Context context) {
        if (context != null) appContext = context.getApplicationContext();
        // Перф/батарея: акселерометр регистрируем ТОЛЬКО когда Graviboard включён.
        // Раньше сенсор на SENSOR_DELAY_GAME (~50Гц) висел всегда, даже при выключенной фиче.
        if (!isEnabled || isRegistered || appContext == null) return;
        try {
            sensorManager = (SensorManager) appContext.getSystemService(Context.SENSOR_SERVICE);
            if (sensorManager != null) {
                accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
                if (accelerometer != null) {
                    sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_GAME);
                    isRegistered = true;
                }
            }
        } catch (Throwable ignored) {}
    }

    public void stop() {
        if (sensorManager != null && isRegistered) {
            sensorManager.unregisterListener(this);
            isRegistered = false;
        }
        resetAllToOriginal();
    }

    public void setEnabled(boolean enabled) {
        this.isEnabled = enabled;
        if (enabled) {
            start(appContext); // включили — регистрируем сенсор (если контекст уже известен)
        } else {
            stop();            // выключили — снимаем акселерометр, чтобы не ел батарею
            resetAllToOriginal();
        }
    }

    public boolean isEnabled() {
        return isEnabled;
    }

    public void setProfileActivity(Activity activity) {
        if (activity != null) {
            this.currentActivity = activity;
        }
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (!isEnabled || event.sensor.getType() != Sensor.TYPE_ACCELEROMETER) return;

        float x = event.values[0];
        float y = event.values[1];
        float z = event.values[2];

        gravityX = -x;
        gravityY = y;

        float gX = x / SensorManager.GRAVITY_EARTH;
        float gY = y / SensorManager.GRAVITY_EARTH;
        float gZ = z / SensorManager.GRAVITY_EARTH;
        float gForce = (float) Math.sqrt(gX * gX + gY * gY + gZ * gZ);
        long now = SystemClock.uptimeMillis();

        if (gForce > 1.85f && now - lastShakeTime > 1000) {
            lastShakeTime = now;
            onShakeDetected();
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {}

    public void triggerManually(Activity activity) {
        if (activity != null) this.currentActivity = activity;
        onShakeDetected();
    }

    private void onShakeDetected() {
        if (currentActivity == null || currentActivity.isFinishing()) return;

        if (isPhysicsActive) {
            resetAllToOriginal();
            try {
                currentActivity.getWindow().getDecorView().performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);
                Toast.makeText(currentActivity, "Видео вернулись на сетку 📌", Toast.LENGTH_SHORT).show();
            } catch (Throwable ignored) {}
        } else {
            startPhysicsSimulation();
        }
    }

    private void startPhysicsSimulation() {
        if (currentActivity == null || currentActivity.isFinishing()) return;

        ViewGroup decor = (ViewGroup) currentActivity.getWindow().getDecorView();
        int screenW = currentActivity.getResources().getDisplayMetrics().widthPixels;
        int screenH = currentActivity.getResources().getDisplayMetrics().heightPixels;

        List<View> wholeVideoCards = new ArrayList<>();
        findOnlyVideoCards(decor, wholeVideoCards, screenW, screenH);

        if (wholeVideoCards.isEmpty()) {
            Toast.makeText(currentActivity, "Graviboard: Откройте вкладку с вашими видео в профиле и потрясите телефон!", Toast.LENGTH_SHORT).show();
            return;
        }

        GraviboardOverlayView overlay = decor.findViewWithTag(GraviboardOverlayView.TAG);
        if (overlay == null) {
            overlay = new GraviboardOverlayView(currentActivity);
            overlay.setTag(GraviboardOverlayView.TAG);
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
            );
            decor.addView(overlay, lp);
        }
        currentOverlay = overlay;

        int[] decorLoc = new int[2];
        decor.getLocationOnScreen(decorLoc);

        List<GraviboardOverlayView.FloatingCard> floatingList = new ArrayList<>();

        for (View v : wholeVideoCards) {
            if (floatingList.size() >= 9) break; // Ограничиваем до 9 видимых карточек для плавных 120 FPS
            if (v.getWidth() <= 0 || v.getHeight() <= 0) continue;

            try {
                int origW = v.getWidth();
                int origH = v.getHeight();

                // Оптимизация памяти: 0.5x масштаб и RGB_565 (экономия 87% оперативной памяти)
                int captureW = Math.max(1, origW / 2);
                int captureH = Math.max(1, origH / 2);
                Bitmap bmp = Bitmap.createBitmap(captureW, captureH, Bitmap.Config.RGB_565);
                Canvas c = new Canvas(bmp);
                c.scale(0.5f, 0.5f);
                v.draw(c);

                int[] loc = new int[2];
                v.getLocationOnScreen(loc);

                GraviboardOverlayView.FloatingCard card = new GraviboardOverlayView.FloatingCard();
                card.origView = v;
                card.bitmap = bmp;
                card.width = origW;
                card.height = origH;
                card.origScreenX = loc[0] - decorLoc[0];
                card.origScreenY = loc[1] - decorLoc[1];
                card.currentX = card.origScreenX;
                card.currentY = card.origScreenY;

                card.vx = (random.nextFloat() - 0.5f) * 32f;
                card.vy = -16f - random.nextFloat() * 22f;
                card.rotation = 0f;
                card.vRot = (random.nextFloat() - 0.5f) * 12f;

                // Аппаратный BitmapShader с автоматическим масштабированием до исходного размера
                BitmapShader shader = new BitmapShader(bmp, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
                Matrix matrix = new Matrix();
                matrix.setScale((float) origW / captureW, (float) origH / captureH);
                shader.setLocalMatrix(matrix);

                Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
                p.setShader(shader);

                card.shader = shader;
                card.shaderPaint = p;

                floatingList.add(card);
                v.setVisibility(View.INVISIBLE);
            } catch (Throwable ignored) {}
        }

        if (floatingList.isEmpty()) return;

        overlay.setCards(floatingList);
        isPhysicsActive = true;

        try {
            decor.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
            Toast.makeText(currentActivity, "⚡ Graviboard: Ваши видео летают во весь экран! Наклоняйте телефон!", Toast.LENGTH_SHORT).show();
        } catch (Throwable ignored) {}

        physicsHandler.post(physicsRunnable);
    }

    private final Runnable physicsRunnable = new Runnable() {
        @Override
        public void run() {
            if (!isPhysicsActive || currentActivity == null || currentActivity.isFinishing() || currentOverlay == null) {
                isPhysicsActive = false;
                return;
            }

            if (currentOverlay.isAnimatingBack()) return;

            int screenW = currentActivity.getResources().getDisplayMetrics().widthPixels;
            int screenH = currentActivity.getResources().getDisplayMetrics().heightPixels;

            List<GraviboardOverlayView.FloatingCard> cards = currentOverlay.getCards();
            int n = cards.size();

            // 1. Движение, гравитация и отскок от границ экрана
            for (int i = 0; i < n; i++) {
                GraviboardOverlayView.FloatingCard card = cards.get(i);
                if (card.isGrabbed) continue;

                card.vx += gravityX * 1.15f;
                card.vy += gravityY * 1.15f;

                card.vx *= 0.982f;
                card.vy *= 0.982f;
                card.vRot *= 0.985f;

                card.currentX += card.vx;
                card.currentY += card.vy;
                card.rotation += card.vRot;

                float scaledW = card.width * card.currentScale;
                float scaledH = card.height * card.currentScale;

                float minX = 0;
                float maxX = screenW - scaledW;
                float minY = 0;
                float maxY = screenH - scaledH;

                if (card.currentX < minX) {
                    card.currentX = minX;
                    card.vx = -card.vx * 0.72f;
                    card.vRot = (random.nextFloat() - 0.5f) * 8f;
                } else if (card.currentX > maxX) {
                    card.currentX = maxX;
                    card.vx = -card.vx * 0.72f;
                    card.vRot = (random.nextFloat() - 0.5f) * 8f;
                }

                if (card.currentY < minY) {
                    card.currentY = minY;
                    card.vy = -card.vy * 0.72f;
                } else if (card.currentY > maxY) {
                    card.currentY = maxY;
                    card.vy = -card.vy * 0.72f;
                }
            }

            // 2. Межобъектные коллизии (Card-to-Card Elastic Collisions)
            for (int i = 0; i < n; i++) {
                GraviboardOverlayView.FloatingCard a = cards.get(i);
                float wa = a.width * a.currentScale;
                float ha = a.height * a.currentScale;
                float cxa = a.currentX + wa * 0.5f;
                float cya = a.currentY + ha * 0.5f;

                for (int j = i + 1; j < n; j++) {
                    GraviboardOverlayView.FloatingCard b = cards.get(j);
                    float wb = b.width * b.currentScale;
                    float hb = b.height * b.currentScale;
                    float cxb = b.currentX + wb * 0.5f;
                    float cyb = b.currentY + hb * 0.5f;

                    float dx = cxb - cxa;
                    float dy = cyb - cya;

                    float minSepX = (wa + wb) * 0.48f;
                    float minSepY = (ha + hb) * 0.48f;

                    float nx = dx / minSepX;
                    float ny = dy / minSepY;
                    float distSq = nx * nx + ny * ny;

                    if (distSq < 1.0f && distSq > 0.0001f) {
                        float dist = (float) Math.sqrt(distSq);
                        float overlap = 1.0f - dist;

                        float dirX = dx / (dist * minSepX);
                        float dirY = dy / (dist * minSepY);
                        float dirLen = (float) Math.sqrt(dirX * dirX + dirY * dirY);
                        if (dirLen > 0.0001f) {
                            dirX /= dirLen;
                            dirY /= dirLen;
                        }

                        // Разделение позиций (анти-проникновение)
                        float sepX = dirX * overlap * minSepX * 0.5f;
                        float sepY = dirY * overlap * minSepY * 0.5f;

                        if (!a.isGrabbed && !b.isGrabbed) {
                            a.currentX -= sepX;
                            a.currentY -= sepY;
                            b.currentX += sepX;
                            b.currentY += sepY;
                        } else if (!a.isGrabbed) {
                            a.currentX -= sepX * 2f;
                            a.currentY -= sepY * 2f;
                        } else if (!b.isGrabbed) {
                            b.currentX += sepX * 2f;
                            b.currentY += sepY * 2f;
                        }

                        // Упругий импульс отскока
                        float relVx = b.vx - a.vx;
                        float relVy = b.vy - a.vy;
                        float velAlongNormal = relVx * dirX + relVy * dirY;

                        if (velAlongNormal < 0) {
                            float restitution = 0.78f;
                            float impulse = -(1f + restitution) * velAlongNormal * 0.5f;

                            if (velAlongNormal < -15f && currentActivity != null) {
                                long now = SystemClock.uptimeMillis();
                                if (now - lastCollisionHapticTime > 350) {
                                    lastCollisionHapticTime = now;
                                    try {
                                        currentActivity.getWindow().getDecorView().performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
                                    } catch (Throwable ignored) {}
                                }
                            }

                            if (!a.isGrabbed) {
                                a.vx -= impulse * dirX;
                                a.vy -= impulse * dirY;
                                a.vRot += (random.nextFloat() - 0.5f) * 6.5f;
                            }
                            if (!b.isGrabbed) {
                                b.vx += impulse * dirX;
                                b.vy += impulse * dirY;
                                b.vRot += (random.nextFloat() - 0.5f) * 6.5f;
                            }
                        }
                    }
                }
            }

            currentOverlay.invalidate();
            physicsHandler.postDelayed(this, 16);
        }
    };

    public void resetAllToOriginal() {
        isPhysicsActive = false;
        physicsHandler.removeCallbacks(physicsRunnable);

        if (currentOverlay != null && currentOverlay.hasCards()) {
            currentOverlay.animateBack(() -> isPhysicsActive = false);
        }
    }

    /**
     * Поиск видеокарточек ТОЛЬКО текущей видимой вкладки:
     * строго проверяет, чтобы координата X сетки RecyclerView была по центру экрана (не в фоне ViewPager),
     * и чтобы карточки были физически видимы на экране!
     */
    private void findOnlyVideoCards(ViewGroup root, List<View> out, int screenW, int screenH) {
        if (root == null) return;

        List<ViewGroup> recyclers = new ArrayList<>();
        findRecyclerContainers(root, recyclers, 0);

        ViewGroup bestVideoGrid = null;
        int maxVideoCells = 0;

        for (ViewGroup rv : recyclers) {
            if (!rv.isShown() || rv.getVisibility() != View.VISIBLE) continue;

            // Сетка ОБЯЗАНА быть активной вкладкой на экране (не смещенной за экран в ViewPager)
            int[] rvLoc = new int[2];
            rv.getLocationOnScreen(rvLoc);
            if (Math.abs(rvLoc[0]) > 60) {
                // Смещена влево или вправо (репосты, избранное, лайки) - пропускаем!
                continue;
            }

            int childCount = rv.getChildCount();
            if (childCount == 0) continue;

            int videoCellCount = 0;
            for (int i = 0; i < childCount; i++) {
                View cell = rv.getChildAt(i);
                if (cell == null || !cell.isShown() || cell.getWidth() <= 0 || cell.getHeight() <= 0) continue;

                int[] cellLoc = new int[2];
                cell.getLocationOnScreen(cellLoc);
                // Карточка должна быть физически в границах экрана
                if (cellLoc[0] < -20 || cellLoc[0] >= screenW || cellLoc[1] < -20 || cellLoc[1] >= screenH) {
                    continue;
                }

                int w = cell.getWidth();
                int h = cell.getHeight();
                if (w >= screenW * 0.18f && w <= screenW * 0.52f && h >= w * 1.05f) {
                    videoCellCount++;
                }
            }

            if (videoCellCount > maxVideoCells) {
                maxVideoCells = videoCellCount;
                bestVideoGrid = rv;
            }
        }

        if (bestVideoGrid != null) {
            int count = bestVideoGrid.getChildCount();
            for (int i = 0; i < count; i++) {
                View cell = bestVideoGrid.getChildAt(i);
                if (cell != null && cell.isShown() && cell.getWidth() > 0 && cell.getHeight() > 0) {
                    int[] cellLoc = new int[2];
                    cell.getLocationOnScreen(cellLoc);
                    if (cellLoc[0] < -20 || cellLoc[0] >= screenW || cellLoc[1] < -20 || cellLoc[1] >= screenH) {
                        continue;
                    }
                    int w = cell.getWidth();
                    int h = cell.getHeight();
                    if (w >= screenW * 0.18f && h >= 100) {
                        out.add(cell);
                    }
                }
            }
            return;
        }

        List<ViewGroup> genericGrids = new ArrayList<>();
        findGenericGridContainers(root, genericGrids, screenW, screenH, 0);

        for (ViewGroup grid : genericGrids) {
            int[] gLoc = new int[2];
            grid.getLocationOnScreen(gLoc);
            if (Math.abs(gLoc[0]) > 60) continue;

            int count = grid.getChildCount();
            for (int i = 0; i < count; i++) {
                View cell = grid.getChildAt(i);
                if (cell != null && cell.isShown() && cell.getWidth() > 0 && cell.getHeight() > 0) {
                    int[] cellLoc = new int[2];
                    cell.getLocationOnScreen(cellLoc);
                    if (cellLoc[0] < -20 || cellLoc[0] >= screenW || cellLoc[1] < -20 || cellLoc[1] >= screenH) {
                        continue;
                    }
                    int w = cell.getWidth();
                    int h = cell.getHeight();
                    if (w >= screenW * 0.18f && w <= screenW * 0.52f && h >= w * 1.05f) {
                        out.add(cell);
                    }
                }
            }
            if (!out.isEmpty()) return;
        }
    }

    private void findRecyclerContainers(ViewGroup group, List<ViewGroup> out, int depth) {
        if (group == null || depth > 25) return;

        String name = group.getClass().getName();
        if (name.contains("RecyclerView") || name.contains("NestedScrollView") ||
            (group.getClass().getSuperclass() != null && group.getClass().getSuperclass().getName().contains("RecyclerView"))) {
            out.add(group);
        }

        int count = group.getChildCount();
        for (int i = 0; i < count; i++) {
            View child = group.getChildAt(i);
            if (child instanceof ViewGroup) {
                findRecyclerContainers((ViewGroup) child, out, depth + 1);
            }
        }
    }

    private void findGenericGridContainers(ViewGroup group, List<ViewGroup> out, int screenW, int screenH, int depth) {
        if (group == null || depth > 25) return;

        int count = group.getChildCount();
        if (count >= 3) {
            int videoLikeCards = 0;
            for (int i = 0; i < count; i++) {
                View child = group.getChildAt(i);
                if (child != null && child.isShown()) {
                    int w = child.getWidth();
                    int h = child.getHeight();
                    if (w >= screenW * 0.20f && w <= screenW * 0.48f && h >= w * 1.05f) {
                        videoLikeCards++;
                    }
                }
            }
            if (videoLikeCards >= 2) {
                out.add(group);
                return;
            }
        }

        for (int i = 0; i < count; i++) {
            View child = group.getChildAt(i);
            if (child instanceof ViewGroup) {
                findGenericGridContainers((ViewGroup) child, out, screenW, screenH, depth + 1);
            }
        }
    }
}
