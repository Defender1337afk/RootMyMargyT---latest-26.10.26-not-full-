package cat.narezany.rootmymargyt;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.Toast;

import java.lang.ref.WeakReference;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.Random;

import cat.narezany.margyt.plugin.PluginContext;

/**
 * FunFx — инструменты RootMyMargyT 5.1 (вкладка MargyT «Инструменты»):
 *  - экранное время: сегодня / вчера / за неделю, по дням хранится в настройках плагина;
 *  - дневной лимит с напоминаниями и, по желанию, ч/б экраном после лимита;
 *  - таймер сна: предупреждает за 30 секунд и сворачивает TikTok;
 *  - не гасить экран, пока открыт TikTok;
 *  - плашка сессии «⏱ время · ❤ лайки» и напоминание о перерыве каждые 30 минут;
 *  - фильтр экрана: ч/б, ночной (тёплый), сепия;
 *  - приветствие Clawd при запуске.
 *
 * Лайки для плашки считает TouchSpy (он только наблюдает за касаниями).
 */
final class FunFx {

    static final String KEY_SESSION = "fx_session_pill";
    static final String KEY_BREAK = "fx_break_reminder";
    static final String KEY_GREETING = "fx_clawd_greeting";
    static final String KEY_FILTER = "fx_screen_filter";
    static final String KEY_LIMIT_MIN = "fx_daily_limit_min";
    static final String KEY_LIMIT_GRAY = "fx_limit_grayscale";
    static final String KEY_KEEP_ON = "fx_keep_screen_on";
    private static final String KEY_HISTORY = "fx_screen_time_days"; // "yyyyMMdd:ms;yyyyMMdd:ms;..."

    static final String[] FILTER_NAMES = {"Выключен", "Чёрно-белый — меньше залипаешь", "Ночной — тёплый экран", "Сепия"};
    static final int[] LIMIT_MIN = {0, 30, 60, 90, 120, 180};
    static final String[] LIMIT_NAMES = {"Без лимита", "30 минут", "1 час", "1,5 часа", "2 часа", "3 часа"};
    static final int[] SLEEP_MIN = {0, 15, 30, 45, 60, 90};
    static final String[] SLEEP_NAMES = {"Выключен", "Через 15 минут", "Через 30 минут", "Через 45 минут", "Через 1 час", "Через 1,5 часа"};

    private static final String TAG_VIEW = "rootmymargyt_funfx";
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static final long BREAK_EVERY_MS = 30 * 60_000L;
    private static final long LIMIT_NAG_MS = 10 * 60_000L;

    private static PluginContext margyt;
    private static WeakReference<Activity> resumed = new WeakReference<>(null);
    private static WeakReference<PillView> overlay = new WeakReference<>(null);

    // сессия и день
    private static long foregroundMs, resumedAt, pausedAt, nextBreakAt = BREAK_EVERY_MS;
    private static long countedUntil; // до какого момента время уже записано в историю дня
    private static long lastLimitNag;
    private static int likes;
    private static boolean greeted;
    // таймер сна
    private static long sleepAt;
    private static boolean sleepWarned;

    private FunFx() {}

    private static boolean on(String key) {
        return margyt != null && margyt.getBoolean(key, false);
    }

    // ───────────────────────────── жизненный цикл ─────────────────────────────

    static void onResumed(Activity activity, PluginContext m) {
        margyt = m;
        if (activity == null || activity.isFinishing()) return;
        resumed = new WeakReference<>(activity);
        long now = SystemClock.elapsedRealtime();
        if (pausedAt > 0 && now - pausedAt > 10 * 60_000L) { // долго не было — новая сессия
            foregroundMs = 0;
            likes = 0;
            nextBreakAt = BREAK_EVERY_MS;
        }
        resumedAt = now;
        countedUntil = now;
        applyFilter(activity);
        applyKeepOn(activity);
        greet(activity);
        // плашка — только поверх TikTok, не поверх настроек MargyT и окон плагинов
        boolean modScreen = activity.getClass().getName().startsWith("cat.narezany");
        if (on(KEY_SESSION) && !modScreen) {
            PillView v = ensureOverlay(activity);
            if (v != null) v.bringToFront();
        } else {
            PillView v = overlay.get();
            if (v != null) v.setVisibility(View.GONE);
        }
        MAIN.removeCallbacks(TICK);
        MAIN.postDelayed(TICK, 1000);
    }

    static void onPaused() {
        long now = SystemClock.elapsedRealtime();
        recordDay(now);
        if (resumedAt > 0) foregroundMs += now - resumedAt;
        resumedAt = 0;
        pausedAt = now;
        MAIN.removeCallbacks(TICK);
    }

    private static long sessionMs() {
        return foregroundMs + (resumedAt > 0 ? SystemClock.elapsedRealtime() - resumedAt : 0);
    }

    private static int tickCount;

    /** Раз в секунду: плашка, перерыв, лимит, таймер сна; раз в минуту — запись экранного времени. */
    private static final Runnable TICK = new Runnable() {
        @Override
        public void run() {
            long now = SystemClock.elapsedRealtime();
            Activity a = resumed.get();
            PillView v = overlay.get();
            if (v != null && on(KEY_SESSION)) v.invalidate();
            if (++tickCount % 60 == 0) recordDay(now);

            if (a != null && on(KEY_BREAK) && sessionMs() >= nextBreakAt) {
                nextBreakAt += BREAK_EVERY_MS;
                toast(a, "🧡 Clawd: ты в TikTok уже " + format(sessionMs()) + " — может, перерыв? Попей воды 💧");
            }

            int limitMin = margyt != null ? margyt.getInt(KEY_LIMIT_MIN, 0) : 0;
            if (a != null && limitMin > 0 && todayMs() >= limitMin * 60_000L) {
                if (lastLimitNag == 0 || now - lastLimitNag >= LIMIT_NAG_MS) {
                    lastLimitNag = now;
                    toast(a, "⏳ Clawd: дневной лимит " + format(limitMin * 60_000L) + " уже вышел. Сегодня ты тут " + format(todayMs()));
                    if (on(KEY_LIMIT_GRAY)) applyFilter(a);
                }
            }

            if (sleepAt > 0) {
                if (!sleepWarned && now >= sleepAt - 30_000L && a != null) {
                    sleepWarned = true;
                    toast(a, "😴 Через 30 секунд таймер сна свернёт TikTok");
                }
                if (now >= sleepAt) {
                    sleepAt = 0;
                    if (a != null) {
                        toast(a, "🌙 Clawd: спокойной ночи! Таймер сна свернул TikTok");
                        a.moveTaskToBack(true);
                    }
                }
            }
            if (resumedAt > 0) MAIN.postDelayed(this, 1000);
        }
    };

    private static void toast(Context c, String s) {
        Toast.makeText(c, s, Toast.LENGTH_LONG).show();
    }

    static String format(long ms) {
        long min = ms / 60_000L;
        return min < 60 ? min + " мин" : (min / 60) + " ч " + (min % 60) + " мин";
    }

    /** Лайк из TouchSpy: только счётчик для плашки. */
    static void onLike(Activity activity, float rawX, float rawY) {
        likes++;
        LikeBurstView.burst(activity, margyt, rawX, rawY); // салют сердечек у пальца
    }

    // ───────────────────────────── экранное время по дням ─────────────────────────────

    private static String dayKey(long offsetDays) {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_YEAR, (int) -offsetDays);
        return new SimpleDateFormat("yyyyMMdd", Locale.ROOT).format(cal.getTime());
    }

    private static long dayMs(String key) {
        if (margyt == null) return 0;
        String all = margyt.getString(KEY_HISTORY, "");
        for (String part : all.split(";")) {
            int i = part.indexOf(':');
            if (i > 0 && part.substring(0, i).equals(key)) {
                try {
                    return Long.parseLong(part.substring(i + 1));
                } catch (Throwable ignored) {}
            }
        }
        return 0;
    }

    /** Время сегодня: записанное + ещё не записанный хвост текущего захода. */
    static long todayMs() {
        long pending = resumedAt > 0 ? SystemClock.elapsedRealtime() - countedUntil : 0;
        return dayMs(dayKey(0)) + Math.max(0, pending);
    }

    /** Дописывает время с прошлой записи к сегодняшнему дню; хранит последние 8 дней. */
    private static void recordDay(long now) {
        if (margyt == null || countedUntil == 0 || resumedAt == 0) return;
        long add = now - countedUntil;
        countedUntil = now;
        if (add <= 0) return;
        String today = dayKey(0);
        long total = dayMs(today) + add;
        StringBuilder sb = new StringBuilder(today).append(':').append(total);
        for (int d = 1; d < 8; d++) {
            String k = dayKey(d);
            long ms = dayMs(k);
            if (ms > 0) sb.append(';').append(k).append(':').append(ms);
        }
        margyt.prefs().edit().putString(KEY_HISTORY, sb.toString()).apply();
    }

    static String screenTimeSummary() {
        long week = 0;
        for (int d = 0; d < 7; d++) week += d == 0 ? todayMs() : dayMs(dayKey(d));
        return "Сегодня " + format(todayMs()) + " · вчера " + format(dayMs(dayKey(1))) + " · за неделю " + format(week);
    }

    static String screenTimeDetails() {
        StringBuilder sb = new StringBuilder();
        SimpleDateFormat show = new SimpleDateFormat("EEEE, d MMMM", new Locale("ru"));
        long week = 0;
        for (int d = 0; d < 7; d++) {
            long ms = d == 0 ? todayMs() : dayMs(dayKey(d));
            week += ms;
            Calendar cal = Calendar.getInstance();
            cal.add(Calendar.DAY_OF_YEAR, -d);
            String name = d == 0 ? "Сегодня" : d == 1 ? "Вчера" : show.format(cal.getTime());
            sb.append(name).append(" — ").append(format(ms)).append('\n');
        }
        sb.append("\nВсего за неделю: ").append(format(week)).append("\nВ среднем в день: ").append(format(week / 7));
        int limit = margyt != null ? margyt.getInt(KEY_LIMIT_MIN, 0) : 0;
        if (limit > 0) sb.append("\nДневной лимит: ").append(format(limit * 60_000L));
        return sb.toString();
    }

    // ───────────────────────────── таймер сна ─────────────────────────────

    static void setSleepTimer(int minutes) {
        sleepWarned = false;
        sleepAt = minutes > 0 ? SystemClock.elapsedRealtime() + minutes * 60_000L : 0;
        MAIN.removeCallbacks(TICK);
        if (resumedAt > 0) MAIN.postDelayed(TICK, 1000);
    }

    static String sleepTimerSummary() {
        if (sleepAt <= 0) return "Выключен";
        long left = sleepAt - SystemClock.elapsedRealtime();
        return left <= 0 ? "Сейчас сработает" : "Осталось " + Math.max(1, left / 60_000L) + " мин";
    }

    // ───────────────────────────── экран ─────────────────────────────

    static void applyKeepOn(Activity activity) {
        if (activity == null || activity.getWindow() == null) return;
        if (on(KEY_KEEP_ON)) activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        else activity.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    private static boolean limitReached() {
        int limitMin = margyt != null ? margyt.getInt(KEY_LIMIT_MIN, 0) : 0;
        return limitMin > 0 && on(KEY_LIMIT_GRAY) && todayMs() >= limitMin * 60_000L;
    }

    static void applyFilter(Activity activity) {
        if (activity == null || activity.getWindow() == null) return;
        View decor = activity.getWindow().getDecorView();
        int mode = margyt != null ? margyt.getInt(KEY_FILTER, 0) : 0;
        if (mode == 0 && limitReached()) mode = 1; // лимит вышел — ч/б, чтобы меньше тянуло листать
        try {
            ColorMatrixColorFilter filter = null;
            if (mode == 1) {
                ColorMatrix cm = new ColorMatrix();
                cm.setSaturation(0f);
                filter = new ColorMatrixColorFilter(cm);
            } else if (mode == 2) {
                filter = new ColorMatrixColorFilter(new float[] {
                    0.95f, 0, 0, 0, 0,
                    0, 0.78f, 0, 0, 0,
                    0, 0, 0.55f, 0, 0,
                    0, 0, 0, 1, 0});
            } else if (mode == 3) {
                filter = new ColorMatrixColorFilter(new float[] {
                    0.393f, 0.769f, 0.189f, 0, 0,
                    0.349f, 0.686f, 0.168f, 0, 0,
                    0.272f, 0.534f, 0.131f, 0, 0,
                    0, 0, 0, 1, 0});
            }
            if (Build.VERSION.SDK_INT >= 31) {
                decor.setRenderEffect(filter == null ? null : android.graphics.RenderEffect.createColorFilterEffect(filter));
            } else if (filter != null) {
                Paint p = new Paint();
                p.setColorFilter(filter);
                decor.setLayerType(View.LAYER_TYPE_HARDWARE, p);
            } else if (decor.getLayerType() == View.LAYER_TYPE_HARDWARE) {
                decor.setLayerType(View.LAYER_TYPE_NONE, null);
            }
        } catch (Throwable ignored) {}
    }

    // ───────────────────────────── приветствие ─────────────────────────────

    private static final String[] PHRASES = {
        "Не забудь лайкнуть хорошее видео 🧡", "Сегодня отличный день для мемов", "Я присмотрю за лимитами 🐞",
        "Не листай слишком быстро — я не успеваю смотреть", "Ты сегодня классно выглядишь ✨",
        "Помни: воду тоже надо пить 💧", "Если что — я в профиле, тыкни меня", "Готов к Clawd Run? 🏃"
    };

    private static void greet(Activity activity) {
        if (greeted || !on(KEY_GREETING)) return;
        greeted = true;
        int hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        String hello = hour >= 5 && hour < 12 ? "Доброе утро" : hour >= 12 && hour < 18 ? "Добрый день"
            : hour >= 18 && hour < 23 ? "Добрый вечер" : "Доброй ночи, полуночник";
        toast(activity, "🧡 Clawd: " + hello + "! " + PHRASES[new Random().nextInt(PHRASES.length)]);
    }

    // ───────────────────────────── плашка сессии ─────────────────────────────

    private static PillView ensureOverlay(Activity activity) {
        if (activity == null || activity.getWindow() == null) return null;
        ViewGroup decor = (ViewGroup) activity.getWindow().getDecorView();
        PillView v = overlay.get();
        if (v != null && v.getParent() == decor) {
            if (v.getVisibility() != View.VISIBLE) v.setVisibility(View.VISIBLE);
            return v;
        }
        View existing = decor.findViewWithTag(TAG_VIEW);
        if (existing instanceof PillView) {
            overlay = new WeakReference<>((PillView) existing);
            existing.setVisibility(View.VISIBLE);
            return (PillView) existing;
        }
        v = new PillView(activity);
        v.setTag(TAG_VIEW);
        decor.addView(v, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        overlay = new WeakReference<>(v);
        return v;
    }

    /** Плашка «⏱ 23 мин · ❤ 12» под статус-баром; касания не перехватывает. */
    private static final class PillView extends View {
        private final float d;
        private final Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF pill = new RectF();

        PillView(Context c) {
            super(c);
            d = c.getResources().getDisplayMetrics().density;
            setClickable(false);
            setFocusable(false);
            setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);
            bg.setColor(0x8C000000);
            text.setColor(0xFFFFFFFF);
            text.setTextSize(11 * d);
            text.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
            text.setTextAlign(Paint.Align.CENTER);
        }

        @Override
        public boolean onTouchEvent(MotionEvent event) {
            return false;
        }

        @Override
        protected void onDraw(Canvas c) {
            if (!on(KEY_SESSION)) return;
            String s = "⏱ " + format(sessionMs()) + "   ❤ " + likes;
            float tw = text.measureText(s) + 20 * d;
            int id = getResources().getIdentifier("status_bar_height", "dimen", "android");
            float top = (id > 0 ? getResources().getDimensionPixelSize(id) : 24 * d) + 2 * d;
            pill.set(getWidth() / 2f - tw / 2f, top, getWidth() / 2f + tw / 2f, top + 20 * d);
            c.drawRoundRect(pill, 10 * d, 10 * d, bg);
            c.drawText(s, getWidth() / 2f, top + 14 * d, text);
        }
    }
}
