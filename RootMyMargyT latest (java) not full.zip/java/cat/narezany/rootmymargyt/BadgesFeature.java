package cat.narezany.rootmymargyt;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.Looper;
import android.util.Base64;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import cat.narezany.margyt.plugin.PluginContext;
import cat.narezany.rootmymargyt.core.Feature;
import cat.narezany.rootmymargyt.core.HostBadges;
import cat.narezany.rootmymargyt.core.Root;

/**
 * Бейджи MargyT и 18 градиентов ника.
 *
 * Непрерывно держит кастомные бейджи и градиент локального аккаунта в статических картах
 * мода ({@code Badges.numbered/known}, {@code Looks.gradients}) — мод перечитывает их с сервера,
 * поэтому плагин переинъектирует по тяжёлому тику и сторож-таймеру. Всё device-проверенное
 * сохранено: невидимый бейдж-носитель градиента, обрезка соринок, запрет серверного «owner»
 * (иначе мод откроет Админку), гарантия бейджа/градиента владельца MargyT, ремонт badges.json.
 *
 * Рефлексия вынесена в {@link HostBadges}. «1 после ника» и стили текста — в ProfileTextFeature.
 */
public final class BadgesFeature implements Feature {

    // ─────────────────────────── данные (не логика Gemini — контент) ───────────────────────────

    /** id бейджей плагина. Нулевой — «root_owner», НЕ «owner»: по «owner» мод открывает Админку. */
    public static final String[] BADGE_IDS = {
        "root_owner", "old", "cup", "supporter", "artist",
        "chonky", "helper", "claudity", "tilcayo", "boykisser",
        "bughunter", "calculator", "cool", "cool_purple", "hype",
        "verified", "watermelon", "root_friend"
    };

    public static final String[] BADGE_TITLES = {
        "Владелец", "Старожил MargyT", "Топ Просмотров", "Поддержал", "Художник",
        "Чонки Кот", "Помощник", "Claudity", "Толстый Тилкайо", "Бойкиссер",
        "Баг хантер", "Калькуляторщик", "Крутой (Брочадо)", "Крутой (Фиолетовый)", "Мемодел",
        "Галочка верификации", "Арбуз", "Друг"
    };

    public static final String[] BADGE_DESCRIPTIONS = {
        "Владелец Margy и MargyT",
        "Сидишь в MargyT до 24 сентября",
        "Победитель конкурса по просмотрам",
        "Поддержал монетой разработку MargyT",
        "Нарисовал логотип для MargyT",
        "Эксклюзивный золотой пухляш Margy",
        "Помог с разработкой ядра MargyT",
        "Таинственный фиолетовый бейдж архитектора",
        "нарез",
        "это бейджик кодера плагина",
        "нашёл баг в MargyT и рассказал о нём",
        "успел купить значок в коллаборации с Деп калькулятором",
        "ну ты крутой брочадо",
        "ну ты крутой брочадо",
        "мемодел, хайпует плесень",
        "Официальная синяя галочка верификации профиля",
        "арбуз",
        "звезда «друга автора MargyT» — копия скрытого бейджа, только в RootMyMargyT"
    };

    public static final String[] GRADIENT_NAMES = {
        "Без градиента (Обычный)",
        "Neon Sunset (Неон Розовый-Фиолетовый-Синий)",
        "Cyber Gold (Кибер Золото и Пламя)",
        "Matrix Green (Матричный Неон)",
        "Deep Violet (Космический Фиолетовый)",
        "Ice Blue (Ледяной Азур)",
        "Blood Ruby (Кровавый Рубин)",
        "Sakura Blossom (Цветение Сакуры)",
        "Toxic Lime (Ядовитый Лайм-Изумруд)",
        "Electric Lavender (Электрическая Лаванда)",
        "Fire & Magma (Огненная Магма)",
        "Midnight Abyss (Полуночная Бездна)",
        "Rainbow Prism (Радужная Призма)",
        "Glitch Cyberpunk (Глитч Бирюза-Фуксия)",
        "Bubblegum Candy (Сладкая Вата)",
        "Ghost Silver (Призрачный Серебристый)",
        "Dark Royalty (Королевский Пурпур и Золото)",
        "Solar Flare (Солнечная Вспышка)",
        "Nordic Aurora (Северное Сияние)"
    };

    public static final String[][] GRADIENT_PALETTES = {
        {},
        {"ff007f", "7928ca", "0070f3"},
        {"ffd700", "ff8c00", "ff0055"},
        {"00ff66", "00e5ff", "10b981"},
        {"8a2be2", "da70d6", "4b0082"},
        {"00f2fe", "4facfe", "00c6ff"},
        {"ff0844", "ff4e50", "990000"},
        {"ff758c", "ff7eb3", "fbc2eb"},
        {"a8ff78", "78ffd6", "11998e"},
        {"b993d6", "8ca6db", "6a11cb"},
        {"f12711", "f5af19", "ff4b2b"},
        {"0f2027", "203a43", "4ca1af"},
        {"ff0000", "ffa500", "ffff00", "00ff00", "00ffff", "0000ff", "8b00ff"},
        {"00f0ff", "ff003c", "ffe600"},
        {"f857a6", "ff5858", "ff9a9e"},
        {"e0e0e0", "f5f7fa", "c3cfe2"},
        {"654ea3", "eaafc8", "ffd700"},
        {"f83600", "fe8c00", "f9d423"},
        {"00c9ff", "92fe9d", "00f2fe"}
    };

    public static final String OWNER_UID = "7693136224597312513";
    public static final String OWNER_USERNAME = "defender676767";
    public static final String OWNER_BADGE_ID = "owner_boykisser";
    public static final String MARGYT_OWNER_UID = "7551880794956989495";

    /** Невидимый бейдж-носитель: при градиенте без бейджей не даёт моду выбросить спаны TikTok (иначе «ник 1»). */
    static final String CARRIER_ID = "rmm_gradient_carrier";

    private static final String KEY_GRADIENT = "nick_gradient_choice";
    private static final String KEY_MASK = "badges_mask";

    // ─────────────────────────── состояние ───────────────────────────

    private static Object[] rootNumbered;      // Badges$Badge[] заготовок плагина
    private static Object carrierBadge;
    private static final Map<String, Bitmap> BITMAP_CACHE = new HashMap<>();
    public static final Set<String> SEEN_UIDS = new HashSet<>();
    private static boolean initialized;

    private final Handler main = new Handler(Looper.getMainLooper());
    private boolean watchdogStarted;

    @Override public String id() { return "badges"; }

    private static PluginContext m() { return Root.margyt(); }

    // ─────────────────────────── жизненный цикл ───────────────────────────

    @Override
    public void onStart(Context ctx) {
        init(ctx);
        enforce();
        saveFilesAndJson(ctx, m());
        startWatchdog();
    }

    @Override
    public void onResume(android.app.Activity activity) {
        enforce();
    }

    @Override
    public void onScreen(android.app.Activity activity, String name) {
        // Смена экрана (открытие профиля) — мод перечитывает бейджи, восстанавливаем сразу.
        enforce();
    }

    @Override
    public void onAccountChanged(String uid) {
        // Аккаунт прогрузился: на первом заходе accountId ещё мог быть null, и наш uid не попадал
        // в карты до ручного обновления. Теперь сохраняем точный uid и сразу применяем бейджи/градиент.
        PluginContext margyt = m();
        if (margyt != null && uid != null && !uid.isEmpty()) {
            margyt.prefs().edit().putString("local_my_account_uid", uid).apply();
            SEEN_UIDS.add(uid);
        }
        enforce();
    }

    @Override
    public void onTick(android.app.Activity activity, Tick tick) {
        // Проверка дешёвая (только чтение карт мода, без записи в prefs) — гоняем каждый кадр,
        // чтобы после перезатирания модом бейджи/градиент возвращались за ~1 кадр, а не за 250 мс.
        // Тяжёлый enforce внутри срабатывает лишь когда что-то реально пропало.
        checkAndEnforce();
    }

    @Override
    public String onName(String uid, String name) {
        PluginContext margyt = m();
        if (margyt == null) return name;
        try {
            String myUid = margyt.accountId();
            if (myUid != null && !myUid.isEmpty() && myUid.equals(uid)) {
                margyt.prefs().edit().putString("local_my_account_uid", myUid).apply();
            }
            if (name != null && !name.isEmpty() && isOwner(name)) {
                margyt.prefs().edit().putString("local_my_account_name", name).apply();
                if (uid != null && !uid.isEmpty()) {
                    margyt.prefs().edit().putString("local_my_account_uid", uid).apply();
                    SEEN_UIDS.add(uid);
                }
            }
            if (uid != null && !uid.isEmpty() && isOwner(uid)) {
                margyt.prefs().edit().putString("local_my_account_uid", uid).apply();
                SEEN_UIDS.add(uid);
            }
            if (name != null && !name.isEmpty()) {
                String savedUid = margyt.getString("local_my_account_uid", "");
                if ((uid != null && uid.equals(savedUid)) || (myUid != null && uid != null && uid.equals(myUid))) {
                    margyt.prefs().edit().putString("local_my_account_name", name).apply();
                }
            }
        } catch (Throwable ignored) {}
        enforce();
        return name;
    }

    private void startWatchdog() {
        if (watchdogStarted) return;
        watchdogStarted = true;
        main.postDelayed(new Runnable() {
            @Override public void run() {
                try { enforce(); } catch (Throwable ignored) {}
                main.postDelayed(this, 3000);
            }
        }, 3000);
    }

    private void enforce() { enforceMemoryState(m()); }

    // ─────────────────────────── картинки бейджей ───────────────────────────

    public static String getBadgeBase64(int index) {
        switch (index) {
            case 0: return BadgeAssets.PNG_OWNER;
            case 1: return BadgeAssets.PNG_OLD;
            case 2: return BadgeAssets.PNG_CUP;
            case 3: return BadgeAssets.PNG_SUPPORTER;
            case 4: return BadgeAssets.PNG_ARTIST;
            case 5: return BadgeAssets.PNG_CHONKY;
            case 6: return BadgeAssets.PNG_HELPER;
            case 7: return BadgeAssets.PNG_CLAUDITY;
            case 8: return BadgeAssets.PNG_TILCAYO;
            case 9: return BadgeAssets.PNG_BOYKISSER;
            case 10: return BadgeAssets.PNG_BUGHUNTER;
            case 11: return BadgeAssets.PNG_CALCULATOR;
            case 12: return BadgeAssets.PNG_COOL;
            case 13: return BadgeAssets.PNG_COOL_PURPLE;
            case 14: return BadgeAssets.PNG_HYPE;
            case 15: return BadgeAssets.PNG_VERIFIED;
            case 16: return BadgeAssets.PNG_WATERMELON;
            case 17: return BadgeAssets.PNG_FRIEND;
            default: return null;
        }
    }

    public static Bitmap getBadgeBitmap(int idx) {
        String b64 = getBadgeBase64(idx);
        return b64 != null ? BadgeAssets.decode(b64) : null;
    }

    /**
     * Обрезка бейджа по заметной фигуре, без случайных соринок.
     * Мод считает краем любой пиксель с alpha&gt;=8, и пара почти невидимых точек у Claudity
     * держала лишнюю рамку — звезда выходила мельче. Тут рамка берётся только по крупным пятнам.
     */
    static Bitmap trimSpecks(Bitmap src) {
        try {
            int w = src.getWidth(), h = src.getHeight();
            int[] px = new int[w * h];
            src.getPixels(px, 0, w, 0, 0, w, h);
            int[] label = new int[w * h];
            int[] stack = new int[w * h];
            List<int[]> comps = new ArrayList<>(); // {size, left, top, right, bottom, maxAlpha}
            int biggest = 0, cur = 0;
            for (int i = 0; i < px.length; i++) {
                if (label[i] != 0 || (px[i] >>> 24) < 8) continue;
                cur++;
                int sp = 0, size = 0, l = w, t = h, r = -1, b = -1, maxA = 0;
                stack[sp++] = i;
                label[i] = cur;
                while (sp > 0) {
                    int p = stack[--sp];
                    size++;
                    maxA = Math.max(maxA, px[p] >>> 24);
                    int x = p % w, y = p / w;
                    if (x < l) l = x;
                    if (x > r) r = x;
                    if (y < t) t = y;
                    if (y > b) b = y;
                    for (int dy = -1; dy <= 1; dy++) {
                        for (int dx = -1; dx <= 1; dx++) {
                            int nx = x + dx, ny = y + dy;
                            if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue;
                            int q = ny * w + nx;
                            if (label[q] == 0 && (px[q] >>> 24) >= 8) {
                                label[q] = cur;
                                stack[sp++] = q;
                            }
                        }
                    }
                }
                comps.add(new int[] {size, l, t, r, b, maxA});
                if (size > biggest) biggest = size;
            }
            int keep = Math.max(6, biggest / 20);
            int l = w, t = h, r = -1, b = -1;
            for (int[] c : comps) {
                if (c[0] < keep && c[5] < 200) continue;
                if (c[1] < l) l = c[1];
                if (c[2] < t) t = c[2];
                if (c[3] > r) r = c[3];
                if (c[4] > b) b = c[4];
            }
            if (r < l || b < t || (l == 0 && t == 0 && r == w - 1 && b == h - 1)) return src;
            return Bitmap.createBitmap(src, l, t, r - l + 1, b - t + 1);
        } catch (Throwable ignored) {
            return src;
        }
    }

    public static synchronized void init(Context context) {
        if (initialized) return;
        if (!HostBadges.available()) return;
        try {
            rootNumbered = HostBadges.newBadgeArray(BADGE_IDS.length);
            for (int i = 0; i < BADGE_IDS.length; i++) {
                String id = BADGE_IDS[i];
                String image = id + ".png";
                rootNumbered[i] = HostBadges.newBadge(id, image, 0, BADGE_TITLES[i], BADGE_DESCRIPTIONS[i], "OK");

                String b64 = getBadgeBase64(i);
                if (b64 != null) {
                    try {
                        byte[] raw = Base64.decode(b64, Base64.DEFAULT);
                        Bitmap bmp = BitmapFactory.decodeByteArray(raw, 0, raw.length);
                        if (bmp != null) {
                            bmp = trimSpecks(bmp);
                            bmp = HostBadges.crop(bmp);
                            BITMAP_CACHE.put(image, bmp);
                        }
                    } catch (Throwable ignored) {}
                }
            }

            carrierBadge = HostBadges.newBadge(CARRIER_ID, CARRIER_ID + ".png", 0, "MargyT", "", "OK");
            // Прозрачный, ширина = 1/64 высоты строки — мод идёт по ветке «бейдж нарисован».
            BITMAP_CACHE.put(CARRIER_ID + ".png", Bitmap.createBitmap(1, 64, Bitmap.Config.ARGB_8888));

            injectPictures();
            repairMargyTJsonIfNeeded(context);
            initialized = true;
        } catch (Throwable ignored) {}
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    public static synchronized void injectPictures() {
        if (BITMAP_CACHE.isEmpty()) return;
        Map pictures = HostBadges.pictures();
        if (pictures != null) {
            synchronized (pictures) {
                for (Map.Entry<String, Bitmap> e : BITMAP_CACHE.entrySet()) pictures.put(e.getKey(), e.getValue());
            }
        }
        HostBadges.clearAsked();
    }

    // ─────────────────────────── badges.json владельцев мода ───────────────────────────

    private static final String AUTHENTIC_MARGYT_JSON =
        "{\n" +
        "  \"badges\": [\n" +
        "    {\n" +
        "      \"id\": \"owner\",\n" +
        "      \"users\": [\"7551880794956989495\"],\n" +
        "      \"colour\": \"8DD1B0\",\n" +
        "      \"title\": \"MargyT\",\n" +
        "      \"text\": \"The owner of Margy and MargyT\",\n" +
        "      \"text_ru\": \"Владелец Margy и MargyT\",\n" +
        "      \"text_uk\": \"Власник Margy і MargyT\",\n" +
        "      \"button\": \"Got it\",\n" +
        "      \"button_ru\": \"Понятно\",\n" +
        "      \"button_uk\": \"Зрозуміло\"\n" +
        "    },\n" +
        "    {\n" +
        "      \"id\": \"helper\",\n" +
        "      \"users\": [\"6525428607760733199\"],\n" +
        "      \"colour\": \"64B5F6\",\n" +
        "      \"title\": \"MargyT\",\n" +
        "      \"text\": \"помог с разработкой MargyT\",\n" +
        "      \"button\": \"Got it\",\n" +
        "      \"button_ru\": \"Понятно\",\n" +
        "      \"button_uk\": \"Зрозуміло\"\n" +
        "    },\n" +
        "    {\n" +
        "      \"id\": \"hype\",\n" +
        "      \"users\": [\"7547438221832160262\"],\n" +
        "      \"colour\": \"E57373\",\n" +
        "      \"title\": \"MargyT\",\n" +
        "      \"text\": \"мемодел, хайпует плесень\",\n" +
        "      \"button\": \"Got it\",\n" +
        "      \"button_ru\": \"Понятно\",\n" +
        "      \"button_uk\": \"Зрозуміло\"\n" +
        "    },\n" +
        "    {\n" +
        "      \"id\": \"icon\",\n" +
        "      \"users\": [\n" +
        "        \"7287645946535560197\",\n" +
        "        \"7643071085839533070\",\n" +
        "        \"7639730829493896210\",\n" +
        "        \"7510468511841141767\",\n" +
        "        \"6774941623367320582\",\n" +
        "        \"7573980629898494987\",\n" +
        "        \"7547438221832160262\",\n" +
        "        \"7662504626076730386\",\n" +
        "        \"7163703793812554757\",\n" +
        "        \"7386219126748267525\",\n" +
        "        \"7676876536330650638\",\n" +
        "        \"7307204820577387525\"\n" +
        "      ],\n" +
        "      \"colour\": \"B388FF\",\n" +
        "      \"title\": \"MargyT\",\n" +
        "      \"text\": \"drew an icon MargyT ships with\",\n" +
        "      \"text_ru\": \"нарисовал иконку, которая есть в MargyT\",\n" +
        "      \"text_uk\": \"намалював іконку, яка є в MargyT\",\n" +
        "      \"button\": \"Got it\",\n" +
        "      \"button_ru\": \"Понятно\",\n" +
        "      \"button_uk\": \"Зрозуміло\"\n" +
        "    },\n" +
        "    {\n" +
        "      \"id\": \"supporter\",\n" +
        "      \"users\": [\n" +
        "        \"7492852642231059461\",\n" +
        "        \"7600534060289082382\",\n" +
        "        \"7660087479496016903\"\n" +
        "      ],\n" +
        "      \"colour\": \"FF6FA5\",\n" +
        "      \"title\": \"MargyT\",\n" +
        "      \"text\": \"supported the making of MargyT\",\n" +
        "      \"text_ru\": \"поддержал разработку MargyT\",\n" +
        "      \"text_uk\": \"підтримав розробку MargyT\",\n" +
        "      \"button\": \"Got it\",\n" +
        "      \"button_ru\": \"Понятно\",\n" +
        "      \"button_uk\": \"Зрозуміло\"\n" +
        "    },\n" +
        "    {\n" +
        "      \"id\": \"chonky\",\n" +
        "      \"users\": [\n" +
        "        \"7641667656839382038\",\n" +
        "        \"7662504626076730386\"\n" +
        "      ],\n" +
        "      \"colour\": \"FFE9A0\",\n" +
        "      \"title\": \"MargyT\",\n" +
        "      \"text\": \"толстопузая маргиТ\",\n" +
        "      \"button\": \"uhh nope\",\n" +
        "      \"button_ru\": \"нет\",\n" +
        "      \"button_uk\": \"no\"\n" +
        "    }\n" +
        "  ],\n" +
        "  \"gradients\": {\n" +
        "    \"7551880794956989495\": [\"8DD1B0\", \"64B5F6\"],\n" +
        "    \"7492852642231059461\": [\"FF6FA5\", \"B388FF\"],\n" +
        "    \"7600534060289082382\": [\"FF6FA5\", \"8DD1B0\"],\n" +
        "    \"7660087479496016903\": [\"FF6FA5\", \"64B5F6\"]\n" +
        "  }\n" +
        "}";

    public static void repairMargyTJsonIfNeeded(Context context) {
        if (context == null) return;
        try {
            File baseDir = new File(context.getFilesDir(), "margyt");
            if (!baseDir.exists()) baseDir.mkdirs();
            File jsonFile = new File(baseDir, "badges.json");
            boolean needRepair = false;

            if (!jsonFile.exists() || jsonFile.length() < 100) {
                needRepair = true;
            } else {
                try {
                    FileInputStream fis = new FileInputStream(jsonFile);
                    byte[] buf = new byte[(int) jsonFile.length()];
                    int read = fis.read(buf);
                    fis.close();
                    if (read > 0) {
                        String s = new String(buf, 0, read, "UTF-8");
                        if (!s.contains(MARGYT_OWNER_UID)) needRepair = true;
                    } else {
                        needRepair = true;
                    }
                } catch (Throwable t) {
                    needRepair = true;
                }
            }

            if (needRepair) {
                byte[] raw = AUTHENTIC_MARGYT_JSON.getBytes("UTF-8");
                FileOutputStream fos = new FileOutputStream(jsonFile, false);
                fos.write(raw);
                fos.flush();
                fos.close();

                HostBadges.apply(raw, false);
                HostBadges.clearTag();
                HostBadges.refresh(context);
            }
        } catch (Throwable ignored) {}
    }

    // ─────────────────────────── владелец плагина ───────────────────────────

    public static boolean isOwner(String uidOrName) {
        if (uidOrName == null) return false;
        String s = uidOrName.trim().replace("@", "");
        return s.equals(OWNER_UID) || s.equalsIgnoreCase(OWNER_USERNAME);
    }

    public static boolean isOwner(PluginContext margyt) {
        if (margyt == null) return false;
        try {
            String live = margyt.accountId();
            if (live != null && isOwner(live)) return true;
            String savedUid = margyt.getString("local_my_account_uid", "");
            if (savedUid != null && isOwner(savedUid)) return true;
            String savedName = margyt.getString("local_my_account_name", "");
            if (savedName != null && isOwner(savedName)) return true;
        } catch (Throwable ignored) {}
        return false;
    }

    /** Серверный «owner» открывает Админку — своему аккаунту не вешаем. */
    private static boolean isAdminBadge(Object badge) {
        return "owner".equals(HostBadges.badgeId(badge));
    }

    public static Set<String> getLocalUserUids(PluginContext margyt) {
        Set<String> set = new HashSet<>();
        set.add("root_user");
        String live = margyt != null ? margyt.accountId() : null;
        if (live != null && !live.isEmpty()) {
            set.add(live);
            margyt.prefs().edit().putString("local_my_account_uid", live).apply();
        }
        addSavedUids(margyt, set);
        return set;
    }

    /** То же, что {@link #getLocalUserUids}, но БЕЗ записи в prefs — для частых проверок каждый кадр. */
    private static Set<String> localUidsReadOnly(PluginContext margyt) {
        Set<String> set = new HashSet<>();
        set.add("root_user");
        String live = margyt != null ? margyt.accountId() : null;
        if (live != null && !live.isEmpty()) set.add(live);
        addSavedUids(margyt, set);
        return set;
    }

    private static void addSavedUids(PluginContext margyt, Set<String> set) {
        if (margyt == null) return;
        String saved = margyt.getString("local_my_account_uid", "");
        if (saved != null && !saved.isEmpty()) set.add(saved);
        String name = margyt.getString("local_my_account_name", "");
        if (name != null && !name.isEmpty()) {
            set.add(name);
            set.add("@" + name);
            set.add(name.toLowerCase());
            set.add("@" + name.toLowerCase());
        }
    }

    // ─────────────────────────── контроль и переинъекция ───────────────────────────

    @SuppressWarnings("rawtypes")
    public static void checkAndEnforce(PluginContext margyt) {
        try {
            if (!initialized || rootNumbered == null || !HostBadges.available()) { enforceMemoryState(margyt); return; }

            Map currentKnown = HostBadges.known();
            if (currentKnown == null || !currentKnown.containsKey("root_user")) { enforceMemoryState(margyt); return; }

            Set<String> myUids = localUidsReadOnly(margyt); // без записи в prefs — вызывается каждый кадр
            for (String u : myUids) {
                if (!currentKnown.containsKey(u)) { enforceMemoryState(margyt); return; }
            }
            if (!currentKnown.containsKey(MARGYT_OWNER_UID)) { enforceMemoryState(margyt); return; }

            int gradIdx = margyt != null ? margyt.getInt(KEY_GRADIENT, 0) : 0;
            Map currentGrads = HostBadges.looksGradients();
            if (currentGrads == null || !currentGrads.containsKey(MARGYT_OWNER_UID)) { enforceMemoryState(margyt); return; }

            if (gradIdx > 0) {
                if (!currentGrads.containsKey("root_user")) { enforceMemoryState(margyt); return; }
                for (String u : myUids) {
                    if (!currentGrads.containsKey(u)) { enforceMemoryState(margyt); return; }
                }
            }
        } catch (Throwable ignored) {
            enforceMemoryState(margyt);
        }
    }

    public void checkAndEnforce() { checkAndEnforce(m()); }

    @SuppressWarnings({"unchecked", "rawtypes"})
    public static synchronized void enforceMemoryState(PluginContext margyt) {
        if (!initialized && margyt != null && margyt.context() != null) init(margyt.context());
        if (rootNumbered == null || !HostBadges.available()) return;

        try {
            Object[] currentNumbered = HostBadges.numbered();

            List<Object> mergedList = new ArrayList<>();
            Map<String, Object> badgeMap = new HashMap<>();

            // 1. Сохраняем все серверные бейджи мода на их индексах
            if (currentNumbered != null) {
                for (Object b : currentNumbered) {
                    if (b != null) {
                        mergedList.add(b);
                        String id = HostBadges.badgeId(b);
                        if (id != null && !badgeMap.containsKey(id)) badgeMap.put(id, b);
                    }
                }
            }

            // 2. Добавляем недостающие заготовки плагина
            for (int i = 0; i < BADGE_IDS.length; i++) {
                String id = BADGE_IDS[i];
                if (!badgeMap.containsKey(id)) {
                    Object customB = rootNumbered[i];
                    if (customB != null && mergedList.size() < 64) {
                        mergedList.add(customB);
                        badgeMap.put(id, customB);
                    }
                }
            }

            if (carrierBadge != null && !badgeMap.containsKey(CARRIER_ID) && mergedList.size() < 64) {
                mergedList.add(carrierBadge);
                badgeMap.put(CARRIER_ID, carrierBadge);
            }

            HostBadges.setNumbered(mergedList.toArray(HostBadges.newBadgeArray(mergedList.size())));

            int mask = (margyt != null && margyt.prefs().contains(KEY_MASK)) ? margyt.getInt(KEY_MASK, 0) : 0;
            Set<String> myUids = getLocalUserUids(margyt);

            List<Object> localBadgesList = new ArrayList<>();
            for (int i = 0; i < BADGE_IDS.length; i++) {
                if ((mask & (1 << i)) != 0) {
                    Object b = badgeMap.get(BADGE_IDS[i]);
                    if (b != null && !isAdminBadge(b)) localBadgesList.add(b);
                }
            }
            int gradChoice = margyt != null ? margyt.getInt(KEY_GRADIENT, 0) : 0;
            Object carrier = badgeMap.get(CARRIER_ID);
            if (gradChoice > 0 && carrier != null) localBadgesList.add(carrier);
            Object[] myBadges = localBadgesList.toArray(HostBadges.newBadgeArray(localBadgesList.size()));

            Map existingKnown = HostBadges.known();
            Map newKnown = existingKnown != null ? new HashMap(existingKnown) : new HashMap();
            for (String u : myUids) newKnown.put(u, myBadges);

            // Владелец MargyT всегда со своим бейджем
            if (!newKnown.containsKey(MARGYT_OWNER_UID)) {
                Object ownerBadge = badgeMap.get("owner");
                if (ownerBadge != null) {
                    Object[] arr = HostBadges.newBadgeArray(1);
                    arr[0] = ownerBadge;
                    newKnown.put(MARGYT_OWNER_UID, arr);
                }
            }
            HostBadges.setKnown(newKnown);

            // Градиенты ника (Looks.gradients)
            int gradIdx = margyt != null ? margyt.getInt(KEY_GRADIENT, 0) : 0;
            Map existingGrads = HostBadges.looksGradients();
            Map newGrads = existingGrads != null ? new HashMap(existingGrads) : new HashMap();

            if (!newGrads.containsKey(MARGYT_OWNER_UID)) {
                newGrads.put(MARGYT_OWNER_UID, new int[] { 0xFF000000 | 0x8DD1B0, 0xFF000000 | 0x64B5F6 });
            }

            if (gradIdx > 0 && gradIdx < GRADIENT_PALETTES.length) {
                String[] pal = GRADIENT_PALETTES[gradIdx];
                int[] cols = new int[pal.length];
                for (int c = 0; c < pal.length; c++) cols[c] = 0xFF000000 | Integer.parseInt(pal[c], 16);
                for (String u : myUids) newGrads.put(u, cols);
                newGrads.put(OWNER_UID, cols);
                newGrads.put(OWNER_USERNAME, cols);
                newGrads.put("@" + OWNER_USERNAME, cols);
                for (String su : SEEN_UIDS) newGrads.put(su, cols);
            } else {
                for (String u : myUids) {
                    if (!MARGYT_OWNER_UID.equals(u)) newGrads.remove(u);
                }
            }
            HostBadges.setLooksGradients(newGrads);

            injectPictures();
        } catch (Throwable ignored) {}
    }

    // ─────────────────────────── файлы бейджей ───────────────────────────

    /** Поднять, когда меняется обработка картинок (trimSpecks): файлы перепишутся один раз. */
    private static final int BADGE_FILES_VERSION = 2;
    private static final String KEY_BADGE_FILES_VERSION = "badge_files_version";

    public static synchronized void saveFilesAndJson(Context context, PluginContext margyt) {
        if (context == null) return;
        try {
            File baseDir = new File(context.getFilesDir(), "margyt/badges");
            if (!baseDir.exists()) baseDir.mkdirs();

            for (int i = 0; i < BADGE_IDS.length; i++) {
                File badgeFile = new File(baseDir, BADGE_IDS[i] + ".png");
                Bitmap clean = BITMAP_CACHE.get(BADGE_IDS[i] + ".png");
                boolean stale = margyt == null || margyt.getInt(KEY_BADGE_FILES_VERSION, 0) < BADGE_FILES_VERSION;
                if (clean != null && (stale || !badgeFile.exists() || badgeFile.length() == 0)) {
                    // Через временный файл — мод не прочитает недописанный PNG.
                    File tmp = new File(baseDir, BADGE_IDS[i] + ".png.tmp");
                    FileOutputStream fos = new FileOutputStream(tmp, false);
                    clean.compress(Bitmap.CompressFormat.PNG, 100, fos);
                    fos.flush();
                    fos.close();
                    if (!tmp.renameTo(badgeFile)) tmp.delete();
                } else if (clean == null && (!badgeFile.exists() || badgeFile.length() == 0)) {
                    String b64 = getBadgeBase64(i);
                    if (b64 != null) {
                        byte[] raw = Base64.decode(b64, Base64.DEFAULT);
                        FileOutputStream fos = new FileOutputStream(badgeFile, false);
                        fos.write(raw);
                        fos.flush();
                        fos.close();
                    }
                }
            }

            if (margyt != null) margyt.prefs().edit().putInt(KEY_BADGE_FILES_VERSION, BADGE_FILES_VERSION).apply();

            File ownerBadgeFile = new File(baseDir, OWNER_BADGE_ID + ".png");
            if (ownerBadgeFile.exists()) ownerBadgeFile.delete();

            repairMargyTJsonIfNeeded(context);
            enforceMemoryState(margyt);
        } catch (Throwable ignored) {}
    }
}
