package cat.narezany.rootmymargyt;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.os.SystemClock;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

/**
 * ClawdBubbleView — облачко с репликой над Clawd-питомцем.
 *
 * Отдельный вид в decor, не кликабельный и не фокусируемый: касания проходят сквозь него
 * к TikTok. Положение и размер задаёт питомец (follow), сам вид — только рисует.
 * Длинная реплика переносится на 2–3 строки и висит дольше.
 */
final class ClawdBubbleView extends View {

    static final String TAG_VIEW = "rootmymargyt_clawd_bubble";

    private static final long ANIM_MS = 180L;
    private static final int MAX_LINES = 3;

    private final float d;
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private final Path tail = new Path();
    private final float lineH;
    private final float padX, padY, tailH;

    private String line = null;
    private long shownAt = 0L;
    private long showMs = 2800L;
    private float tailX = 0f;

    private String wrappedFor = null;
    private float wrappedMax = -1f;
    private final List<String> lines = new ArrayList<>();
    private float widest = 0f;

    ClawdBubbleView(Context ctx) {
        super(ctx);
        d = ctx.getResources().getDisplayMetrics().density;
        setClickable(false);
        setFocusable(false);
        setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);
        fill.setColor(0xF7FFFFFF);
        fill.setShadowLayer(4 * d, 0, d, 0x40000000);
        text.setColor(0xFF2B1A14);
        text.setTextSize(13 * d);
        text.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        text.setTextAlign(Paint.Align.CENTER);
        lineH = 17 * d;
        padX = 14 * d;
        padY = 9 * d;
        tailH = 7 * d;
        setVisibility(GONE);
    }

    void say(String s) {
        line = s;
        shownAt = SystemClock.uptimeMillis();
        // Длинную реплику успеваешь дочитать: +40 мс на символ, но не больше 6 секунд
        showMs = Math.min(6000L, 2800L + Math.max(0, s.length() - 18) * 40L);
        wrappedFor = null;
        setVisibility(VISIBLE);
        bringToFront();
        invalidate();
    }

    boolean isTalking() {
        return line != null && SystemClock.uptimeMillis() - shownAt < showMs;
    }

    String current() {
        return line;
    }

    /** Перенос по словам в пределах maxTextW, не больше MAX_LINES строк. */
    private void wrap(float maxTextW) {
        if (line.equals(wrappedFor) && maxTextW == wrappedMax) return;
        wrappedFor = line;
        wrappedMax = maxTextW;
        lines.clear();
        widest = 0f;
        String[] words = line.split(" ");
        StringBuilder cur = new StringBuilder();
        for (int i = 0; i < words.length; i++) {
            String tryLine = cur.length() == 0 ? words[i] : cur + " " + words[i];
            if (text.measureText(tryLine) <= maxTextW || cur.length() == 0) {
                cur.setLength(0);
                cur.append(tryLine);
            } else {
                if (lines.size() == MAX_LINES - 1) {
                    // последняя строка: всё оставшееся, обрезанное многоточием
                    StringBuilder rest = new StringBuilder(cur);
                    for (int k = i; k < words.length; k++) rest.append(' ').append(words[k]);
                    cur.setLength(0);
                    cur.append(ellipsize(rest.toString(), maxTextW));
                    break;
                }
                lines.add(cur.toString());
                cur.setLength(0);
                cur.append(words[i]);
            }
        }
        if (cur.length() > 0) lines.add(ellipsize(cur.toString(), maxTextW));
        for (String l : lines) widest = Math.max(widest, text.measureText(l));
    }

    private String ellipsize(String s, float maxW) {
        if (text.measureText(s) <= maxW) return s;
        int n = s.length();
        while (n > 1 && text.measureText(s.substring(0, n) + "…") > maxW) n--;
        return s.substring(0, n).trim() + "…";
    }

    /**
     * Ставит облачко над головой питомца, не вылезая за края экрана.
     * @param headCx X центра головы, @param headTop Y макушки — в координатах родителя
     */
    void follow(float headCx, float headTop, int parentW) {
        if (line == null) return;
        float maxTextW = Math.min(parentW * 0.8f, 300 * d) - padX * 2;
        wrap(maxTextW);
        float w = widest + padX * 2;
        float h = lines.size() * lineH + padY * 2 + tailH;
        float x = Math.max(4 * d, Math.min(parentW - w - 4 * d, headCx - w / 2f));
        setTranslationX(x);
        setTranslationY(headTop - h - 2 * d);
        tailX = Math.max(14 * d, Math.min(w - 14 * d, headCx - x));
        if (getLayoutParams() != null && (getLayoutParams().width != Math.round(w) || getLayoutParams().height != Math.round(h))) {
            getLayoutParams().width = Math.round(w);
            getLayoutParams().height = Math.round(h);
            requestLayout();
        }
    }

    @Override
    protected void onDraw(Canvas c) {
        if (line == null || lines.isEmpty()) return;
        long t = SystemClock.uptimeMillis() - shownAt;
        if (t > showMs) {
            line = null;
            setVisibility(GONE);
            return;
        }
        float k = Math.min(1f, Math.min(t, showMs - t) / (float) ANIM_MS);
        float w = getWidth(), h = getHeight();
        c.save();
        c.scale(0.85f + 0.15f * k, 0.85f + 0.15f * k, tailX, h);
        fill.setAlpha(Math.round(0xF7 * k));
        text.setAlpha(Math.round(255 * k));

        rect.set(2 * d, 2 * d, w - 2 * d, h - tailH);
        c.drawRoundRect(rect, 14 * d, 14 * d, fill);
        tail.rewind();
        tail.moveTo(tailX - 6 * d, h - tailH - 1);
        tail.lineTo(tailX, h - 1);
        tail.lineTo(tailX + 6 * d, h - tailH - 1);
        tail.close();
        c.drawPath(tail, fill);
        float y = padY + lineH * 0.78f;
        for (String l : lines) {
            c.drawText(l, w / 2f, y, text);
            y += lineH;
        }
        c.restore();
        postInvalidateOnAnimation();
    }
}
